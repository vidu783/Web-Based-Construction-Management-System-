import dotenv from 'dotenv';
dotenv.config();

import { sendSms } from './src/utils/smsHelper.js';

(async () => {
    console.log("Sending test SMS to 0729212363 (Kamal)...");
    const success = await sendSms("0729212363", "Hi Kamal, this is a test SMS from DU Homes backend to verify the connection.");
    console.log("Success:", success);
})();
