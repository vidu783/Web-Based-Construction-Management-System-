import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
dotenv.config();

async function test() {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  const chat = ai.chats.create({
    model: "gemini-2.5-flash",
  });
  console.log("Starting...");
  try {
    const res = await chat.sendMessage("who ar the best workers");
    console.log("No tools success:", res.text.substring(0, 20));
  } catch (err) {
    console.error("No tools err:", err.message);
  }

  const chatT = ai.chats.create({
    model: "gemini-2.5-flash",
    config: {
      tools: [{ functionDeclarations: [{ name: "foo", description: "foo" }] }]
    }
  });
  try {
    const res = await chatT.sendMessage({ message: "who ar the best workers" });
    console.log("Tools success:", res.functionCalls?.[0]?.name);
    
    if (res.functionCalls) {
      const call = res.functionCalls[0];
      const next = await chatT.sendMessage({ message: [{ functionResponse: { name: call.name, response: { ok: true } } }] });
      console.log("Follow up success", next.text);
    }
  } catch (err) {
    console.error("Tools err:", err.stack);
  }
}

test();
