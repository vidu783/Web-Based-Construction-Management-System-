import { createClient } from "@supabase/supabase-js";
import 'dotenv/config';

const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_KEY
);

async function check() {
    console.log("Checking profiles table schema...");
    const { data: profiles, error: err1 } = await supabase.from('profiles').select('*').limit(1);
    if (err1) {
        console.error("Fetch Error:", err1);
        return;
    }
    
    if (profiles.length === 0) {
        console.log("No profiles found to test.");
        return;
    }
    
    const testUserId = profiles[0].id;
    console.log("Testing with user:", testUserId, profiles[0].full_name);
    
    const { error: profileError } = await supabase.from("profiles").update({ role: "company_owner" }).eq("id", testUserId);
    console.log("Profile update result error:", profileError || "SUCCESS!");
    
    if (!profileError) {
        await supabase.from("profiles").update({ role: profiles[0].role }).eq("id", testUserId);
    }
}

check();
