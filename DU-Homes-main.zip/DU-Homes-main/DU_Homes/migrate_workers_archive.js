// Migration: add is_archived column to workers table
import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
dotenv.config();

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);

async function run() {
    console.log("Running migration: add is_archived to workers...");

    // Use Supabase's rpc to run raw SQL via the postgres role
    const { error } = await supabase.rpc("run_sql", {
        query: `ALTER TABLE workers ADD COLUMN IF NOT EXISTS is_archived BOOLEAN NOT NULL DEFAULT FALSE;`
    });

    if (error) {
        // rpc might not exist — try a direct fetch to the REST API SQL endpoint
        console.log("RPC not available, trying direct SQL via REST...", error.message);

        const url = `${process.env.SUPABASE_URL}/rest/v1/rpc/run_sql`;
        const resp = await fetch(`${process.env.SUPABASE_URL}/pg/query`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "apikey": process.env.SUPABASE_SERVICE_KEY,
                "Authorization": `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
            },
            body: JSON.stringify({ query: "ALTER TABLE workers ADD COLUMN IF NOT EXISTS is_archived BOOLEAN NOT NULL DEFAULT FALSE;" }),
        });
        if (resp.ok) {
            console.log("✅ Migration complete via REST");
        } else {
            const txt = await resp.text();
            console.log("❌ REST also failed:", txt);
            console.log("\n👉 Please run this SQL manually in your Supabase dashboard SQL editor:");
            console.log("   ALTER TABLE workers ADD COLUMN IF NOT EXISTS is_archived BOOLEAN NOT NULL DEFAULT FALSE;");
        }
        return;
    }

    console.log("✅ Migration complete: is_archived column added to workers");
}

run().catch(console.error);
