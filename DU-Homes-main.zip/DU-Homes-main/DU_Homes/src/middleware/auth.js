import { getSupabaseClient } from "../supabaseClient.js";

/**
 * Middleware: Verify JWT token from Authorization header
 * Attaches req.user with the authenticated user object
 */
export async function requireAuth(req, res, next) {
    // Always pass OPTIONS preflight through — no token needed for CORS
    if (req.method === "OPTIONS") return next();

    const authHeader = req.headers.authorization;
    const token = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : null;

    if (!token) {
        return res.status(401).json({ error: "Authentication required" });
    }

    try {
        const supabase = getSupabaseClient();
        const { data: { user }, error } = await supabase.auth.getUser(token);

        if (error || !user) {
            return res.status(401).json({ error: "Invalid or expired token" });
        }

        // Attach user to request object for downstream use
        req.user = user;
        next();
    } catch (e) {
        console.error("Auth middleware error:", e.message);
        res.status(401).json({ error: "Authentication failed" });
    }
}

/**
 * Middleware: Check if authenticated user has one of the required roles
 * Must be used AFTER requireAuth
 */
export function requireRole(...allowedRoles) {
    return async (req, res, next) => {
        try {
            const supabase = getSupabaseClient();
            const { data: profile, error } = await supabase
                .from("profiles")
                .select("role")
                .eq("id", req.user.id)
                .single();

            if (error || !profile) {
                return res.status(403).json({ error: "User profile not found" });
            }

            if (!allowedRoles.includes(profile.role)) {
                return res.status(403).json({ error: "Insufficient permissions" });
            }

            req.userRole = profile.role;
            next();
        } catch (e) {
            console.error("Role check error:", e.message);
            res.status(403).json({ error: "Permission check failed" });
        }
    };
}
