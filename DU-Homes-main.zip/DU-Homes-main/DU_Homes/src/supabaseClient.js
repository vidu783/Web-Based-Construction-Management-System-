import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
dotenv.config();

const supabaseUrl = process.env.SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_KEY;
const anonKey = process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl) throw new Error("SUPABASE_URL is missing in .env");

let _serviceClient = null;
let _anonClient = null;

export function getSupabaseClient() {
    if (!serviceKey) throw new Error("SUPABASE_SERVICE_KEY is missing in .env");
    if (!_serviceClient) {
        _serviceClient = createClient(supabaseUrl, serviceKey);
    }
    return _serviceClient;
}

export function getAnonClient() {
    if (!anonKey) throw new Error("SUPABASE_ANON_KEY is missing in .env");
    if (!_anonClient) {
        _anonClient = createClient(supabaseUrl, anonKey);
    }
    return _anonClient;
}

export function getEphemeralAuthClient() {
    if (!anonKey) throw new Error("SUPABASE_ANON_KEY is missing in .env");
    return createClient(supabaseUrl, anonKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false,
        }
    });
}

export function getServiceClient() {
    return getSupabaseClient();
}
