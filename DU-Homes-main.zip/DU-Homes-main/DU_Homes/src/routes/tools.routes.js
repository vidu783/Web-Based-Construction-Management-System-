import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";
import { createNotification } from "./notifications.routes.js";
import { snapshotBeforeDelete } from "../utils/snapshotHelper.js";

const router = Router();

const LOW_STOCK_THRESHOLD = 2; // alert when available <= this value


// GET all tools
router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("tools")
            .select("*")
            .order("name");
        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// GET single tool
router.get("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("tools")
            .select("*")
            .eq("id", req.params.id)
            .single();
        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// POST create tool
router.post("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { name, tool_code, total_qty, condition, notes } = req.body;
        if (!name || !name.trim()) return res.status(400).json({ error: "Tool name is required" });

        const qty = parseInt(total_qty) || 0;

        const payload = {
            name: name.trim(),
            tool_code: (tool_code || "").trim(),
            total_qty: qty,
            available: qty, // Always starts with all units available
            condition: condition || "good",
            notes: (notes || "").trim(),
        };

        console.log("Creating tool:", payload);

        const { data, error } = await supabase.from("tools").insert([payload]).select().single();
        if (error) {
            console.error("Supabase insert error:", error);
            return res.status(400).json({ error: error.message });
        }
        res.status(201).json(data);
    } catch (e) {
        console.error("Server error:", e);
        res.status(500).json({ error: e.message });
    }
});

// PUT update tool
router.put("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        
        const { data: oldData } = await supabase.from("tools").select("total_qty").eq("id", req.params.id).single();

        const { name, tool_code, total_qty, condition, notes } = req.body;
        const payload = {};

        if (name !== undefined) payload.name = name.trim();
        if (tool_code !== undefined) payload.tool_code = (tool_code || "").trim();
        if (condition !== undefined) payload.condition = condition;
        if (notes !== undefined) payload.notes = (notes || "").trim();
        if (total_qty !== undefined) payload.total_qty = parseInt(total_qty) || 0;

        if (Object.keys(payload).length === 0) {
            return res.status(400).json({ error: "No fields to update" });
        }

        // We MUST recalculate available dynamically if total_qty changes. 
        // We completely ignore the frontend's 'available' field since it's stale.
        let newAvailable = null;
        let oldAvailable = null;

        if (total_qty !== undefined) {
            const { data: allocs } = await supabase.from("tool_allocations")
                .select("qty")
                .eq("tool_id", req.params.id)
                .neq("status", "returned")
                .is("returned_date", null);
            
            const allocatedSum = (allocs || []).reduce((sum, a) => sum + (parseInt(a.qty) || 0), 0);
            // Clamp to 0 — available can never be negative
            payload.available = Math.max(0, payload.total_qty - allocatedSum);
            newAvailable = payload.available;
            oldAvailable = Math.max(0, (oldData ? oldData.total_qty : 0) - allocatedSum);
        }

        const { data, error } = await supabase
            .from("tools")
            .update(payload)
            .eq("id", req.params.id)
            .select()
            .single();
        if (error) return res.status(400).json({ error: error.message });

        // Low-stock alert: ONLY notify if available stock actually DECREASED during this update (e.g., total_qty was reduced)
        if (newAvailable !== null) {
            if (newAvailable <= LOW_STOCK_THRESHOLD && newAvailable < oldAvailable) {
                // Prevent duplicate UNREAD alerts for the same tool to avoid spam
                const { data: existingAlert } = await supabase
                    .from("notifications")
                    .select("id")
                    .eq("type", "low_stock")
                    .eq("is_read", false)
                    .contains("metadata", { tool_id: data.id })
                    .limit(1);

                if (!existingAlert || existingAlert.length === 0) {
                    await createNotification(supabase, {
                        user_id: null, // broadcast to all
                        message: `Low Stock Alert: "${data.name}" has only ${newAvailable} unit(s) remaining (threshold: ${LOW_STOCK_THRESHOLD})`,
                        type: "low_stock",
                        metadata: { tool_id: data.id, tool_name: data.name, available: newAvailable, threshold: LOW_STOCK_THRESHOLD },
                    });
                }
            } else if (newAvailable > LOW_STOCK_THRESHOLD) {
                // Auto-dismiss low stock alerts if stock is replenished
                await supabase.from("notifications")
                    .delete()
                    .eq("type", "low_stock")
                    .contains("metadata", { tool_id: data.id });
            }
        }

        res.json(data);


    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// DELETE tool
router.delete("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data: tool } = await supabase.from("tools").select("*").eq("id", req.params.id).single();
        if (tool) {
            await snapshotBeforeDelete(req.params.id, "tool", tool.name || "Unknown Tool", {
                tool_code:  tool.tool_code,
                condition:  tool.condition,
                total_qty:  tool.total_qty,
                notes:      tool.notes,
            });
        }
        const { error } = await supabase.from("tools").delete().eq("id", req.params.id);
        if (error) return res.status(400).json({ error: error.message });
        res.json({ message: "Deleted" });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

export default router;
