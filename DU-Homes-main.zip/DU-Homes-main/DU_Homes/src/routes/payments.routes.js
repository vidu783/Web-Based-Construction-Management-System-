import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";
import { createNotification } from "./notifications.routes.js";
import { snapshotBeforeDelete } from "../utils/snapshotHelper.js";
import { sendSms } from "../utils/smsHelper.js";

const router = Router();

/* helper: calculate pay */
const calcPay = (daily_rate, normal_hours, ot_hours) => {
    const hourly = Number(daily_rate) / 8;
    const base_pay = +(hourly * Number(normal_hours)).toFixed(2);
    const ot_pay = +(hourly * 1.5 * Number(ot_hours)).toFixed(2);
    return { base_pay, ot_pay };
};

/*  GET /payments  list with filters  */
router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        let query = supabase
            .from("payments")
            .select("*")
            .order("date", { ascending: false });

        const { date, worker_id, site_id, status, from, to } = req.query;

        if (date) query = query.eq("date", date);
        if (worker_id) query = query.eq("worker_id", worker_id);
        if (site_id) query = query.eq("site_id", site_id);
        if (status) query = query.eq("status", status);
        if (from) query = query.gte("date", from);
        if (to) query = query.lte("date", to);

        const { data, error } = await query;
        if (error) return res.status(400).json({ error: error.message });
        res.json(data || []);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/*  GET /payments/:id  single record  */
router.get("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("payments")
            .select("*")
            .eq("id", req.params.id)
            .single();
        if (error) return res.status(404).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/*  POST /payments  create  */
router.post("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const {
            worker_id, site_id, date,
            daily_rate, normal_hours = 8, ot_hours = 0,
            deductions = 0, base_pay, ot_pay, net_pay,
            status = "pending", notes = "",
            category = "salary", method = "cash", reference = "",
        } = req.body;

        // worker_id is optional for non-salary expenses
        let rate = Number(daily_rate);
        if (!rate && worker_id) {
            const { data: worker } = await supabase.from("workers").select("daily_rate").eq("id", worker_id).single();
            rate = Number(worker?.daily_rate || 0);
        }

        let finalBasePay, finalOtPay, finalNetPay;
        const isSalaryRel = ["salary", "advance", "bonus"].includes(category);

        if (base_pay !== undefined && ot_pay !== undefined && net_pay !== undefined) {
            finalBasePay = Number(base_pay);
            finalOtPay = Number(ot_pay);
            finalNetPay = Number(net_pay);
        } else if (!isSalaryRel) {
            finalBasePay = 0;
            finalOtPay = 0;
            finalNetPay = Number(net_pay || 0);
        } else {
            const calc = calcPay(rate, normal_hours, ot_hours);
            finalBasePay = calc.base_pay;
            finalOtPay = calc.ot_pay;
            finalNetPay = +(finalBasePay + finalOtPay - Number(deductions)).toFixed(2);
        }

        const { data, error } = await supabase
            .from("payments")
            .insert([{
                worker_id, site_id, date: date || new Date().toISOString().slice(0, 10),
                daily_rate: rate, normal_hours: Number(normal_hours), ot_hours: Number(ot_hours),
                base_pay: finalBasePay, ot_pay: finalOtPay, deductions: Number(deductions), net_pay: finalNetPay,
                status, notes,
                category, method, reference,
            }])
            .select("*")
            .single();

        if (error) return res.status(400).json({ error: error.message });

        // ── SMS Notification Logic ──
        if (status === "paid" && category === "salary" && worker_id) {
            // Fetch worker details in background to send SMS
            supabase.from("workers").select("full_name, phone").eq("id", worker_id).single()
                .then(({ data: wData }) => {
                    if (wData && wData.phone) {
                        const message = `Dear ${wData.full_name}, a salary payment of Rs. ${finalNetPay} has been recorded for you on ${date || new Date().toISOString().slice(0, 10)}. - DU Homes`;
                        sendSms(wData.phone, message);
                    }
                })
                .catch(err => console.error("Failed to fetch worker for SMS:", err));
        }

        res.status(201).json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/*  PUT /payments/:id  update  */
router.put("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const {
            daily_rate, normal_hours, ot_hours,
            deductions, status, notes,
            worker_id, site_id, date,
            base_pay, ot_pay, net_pay,
            category, method, reference,
        } = req.body;

        // Fetch old payment to avoid spamming SMS on generic updates
        const { data: oldPayment } = await supabase.from("payments").select("status, category, worker_id, net_pay, date").eq("id", req.params.id).single();

        const updates = {};
        if (daily_rate !== undefined) updates.daily_rate = Number(daily_rate);
        if (normal_hours !== undefined) updates.normal_hours = Number(normal_hours);
        if (ot_hours !== undefined) updates.ot_hours = Number(ot_hours);
        if (deductions !== undefined) updates.deductions = Number(deductions);
        if (status !== undefined) updates.status = status;
        if (notes !== undefined) updates.notes = notes;
        if (worker_id !== undefined) updates.worker_id = worker_id;
        if (site_id !== undefined) updates.site_id = site_id;
        if (date !== undefined) updates.date = date;
        if (category !== undefined) updates.category = category;
        if (method !== undefined) updates.method = method;
        if (reference !== undefined) updates.reference = reference;

        const isSalaryRel = ["salary", "advance", "bonus"].includes(category || "");

        if (base_pay !== undefined && ot_pay !== undefined && net_pay !== undefined) {
            updates.base_pay = Number(base_pay);
            updates.ot_pay = Number(ot_pay);
            updates.net_pay = Number(net_pay);
        } else if (category && !isSalaryRel) {
            updates.base_pay = 0;
            updates.ot_pay = 0;
            updates.net_pay = Number(net_pay !== undefined ? net_pay : 0);
        } else if (updates.daily_rate !== undefined || updates.normal_hours !== undefined || updates.ot_hours !== undefined) {
            const { data: current } = await supabase.from("payments").select("*").eq("id", req.params.id).single();
            const rate = updates.daily_rate ?? current.daily_rate;
            const hrs = updates.normal_hours ?? current.normal_hours;
            const ot = updates.ot_hours ?? current.ot_hours;
            const ded = updates.deductions ?? current.deductions;
            const calc = calcPay(rate, hrs, ot);
            updates.base_pay = calc.base_pay;
            updates.ot_pay = calc.ot_pay;
            updates.net_pay = +(calc.base_pay + calc.ot_pay - Number(ded)).toFixed(2);
        }

        const { data, error } = await supabase
            .from("payments")
            .update(updates)
            .eq("id", req.params.id)
            .select("*")
            .single();

        if (error) return res.status(400).json({ error: error.message });

        // ── SMS Notification Logic (Only when transitioning to PAID) ──
        const isNowPaid = status === "paid";
        const wasNotPaid = oldPayment && oldPayment.status !== "paid";
        const finalCategory = category || oldPayment?.category;
        const finalWorkerId = worker_id || oldPayment?.worker_id;
        const finalNetPay = net_pay !== undefined ? net_pay : oldPayment?.net_pay;

        if (isNowPaid && wasNotPaid && finalCategory === "salary" && finalWorkerId) {
            supabase.from("workers").select("full_name, phone").eq("id", finalWorkerId).single()
                .then(({ data: wData }) => {
                    if (wData && wData.phone) {
                        const message = `Dear ${wData.full_name}, a salary payment of Rs. ${finalNetPay} has been recorded for you on ${updates.date || oldPayment?.date || new Date().toISOString().slice(0, 10)}. - DU Homes`;
                        sendSms(wData.phone, message);
                    }
                })
                .catch(err => console.error("Failed to fetch worker for SMS:", err));
        }

        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/*  PATCH /payments/:id/pay  mark as paid — triggers in-app salary notification */
router.patch("/:id/pay", async (req, res) => {
    try {
        const supabase = getSupabaseClient();

        // Fetch payment with worker info for notification message
        const { data: payment, error: fetchErr } = await supabase
            .from("payments")
            .select("*")
            .eq("id", req.params.id)
            .single();

        if (fetchErr) return res.status(404).json({ error: fetchErr.message });

        const { data, error } = await supabase
            .from("payments")
            .update({ status: "paid" })
            .eq("id", req.params.id)
            .select("*")
            .single();

        if (error) return res.status(400).json({ error: error.message });

        // Fire salary credit notification (non-blocking)
        const workerName = payment?.workers?.full_name || "Worker";
        const netPay = Number(payment?.net_pay || 0).toLocaleString("en-LK", { minimumFractionDigits: 2 });
        await createNotification(supabase, {
            user_id: null, // broadcast — admins + finance officers poll this
            message: `Salary Paid: ${workerName} received Rs ${netPay} on ${data.date}`,
            type: "salary_paid",
            metadata: { payment_id: data.id, worker_id: payment?.workers?.id, amount: data.net_pay, date: data.date },
        });

        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/*  DELETE /payments/:id  */
router.delete("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data: rec } = await supabase.from("payments").select("*").eq("id", req.params.id).single();
        if (rec) {
            await snapshotBeforeDelete(req.params.id, "payment",
                `Payment ${rec.date} Rs.${rec.net_pay}`,
                { worker_id: rec.worker_id, site_id: rec.site_id, date: rec.date, net_pay: rec.net_pay, status: rec.status, category: rec.category });
        }
        const { error } = await supabase.from("payments").delete().eq("id", req.params.id);
        if (error) return res.status(400).json({ error: error.message });
        res.json({ message: "Deleted" });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

export default router;
