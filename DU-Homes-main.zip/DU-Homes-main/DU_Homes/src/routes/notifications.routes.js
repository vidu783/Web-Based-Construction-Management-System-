import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";

const router = Router();

/**
 * Confirming Service Role Key Usage:
 * The getSupabaseClient() function in ../supabaseClient.js initializes 
 * the client using process.env.SUPABASE_SERVICE_KEY.
 * This bypasses Row Level Security (RLS) entirely.
 */

/* GET /notifications — return both user-specific AND broadcast notifications */
router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const userId = req.user.id;

        let query = supabase
            .from("notifications")
            .select("*")
            .or(`user_id.eq.${userId},user_id.is.null`) // user-specific + broadcast
            .order("created_at", { ascending: false })
            .limit(50);

        if (req.query.unread_only === "true") {
            query = query.eq("is_read", false);
        }

        const { data, error } = await query;
        if (error) {
            console.error("[GET /notifications] Supabase error:", error);
            return res.status(400).json({ error: error.message });
        }
        console.log(`[GET /notifications] Returning ${(data || []).length} rows for user ${userId}`);
        res.json(data || []);
    } catch (e) {
        console.error("[GET /notifications] Catch:", e.message);
        res.status(500).json({ error: e.message });
    }
});

/* GET /notifications/unread-count — for badge display */
router.get("/unread-count", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const userId = req.user.id;

        // Get all notifications for this user (broadcast or user-specific) that are unread
        const { data, error } = await supabase
            .from("notifications")
            .select("id, is_read")
            .or(`user_id.eq.${userId},user_id.is.null`);

        if (error) {
            console.error("[unread-count] Supabase error:", error);
            return res.status(400).json({ error: error.message });
        }
        const count = (data || []).filter(n => !n.is_read).length;
        res.json({ count });
    } catch (e) {
        console.error("[unread-count] Catch:", e.message);
        res.status(500).json({ error: e.message });
    }
});

/* PATCH /mark-all-read — mark all (user-specific + broadcast) as read */
router.patch("/mark-all-read", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const userId = req.user.id;

        // Step 1: Get IDs of all unread notifications for this user (broadcast + user-specific)
        const { data: unread, error: fetchErr } = await supabase
            .from("notifications")
            .select("id")
            .eq("is_read", false)
            .or(`user_id.eq.${userId},user_id.is.null`);

        if (fetchErr) {
            console.error("[MARK ALL READ] Fetch error:", fetchErr);
            return res.status(500).json({ error: fetchErr.message });
        }

        if (!unread || unread.length === 0) {
            console.log("[MARK ALL READ] No unread notifications to update");
            return res.json({ success: true, updated: 0 });
        }

        // Step 2: Update by specific IDs (avoids filter chaining issues)
        const ids = unread.map(n => n.id);
        const { data, error } = await supabase
            .from("notifications")
            .update({ is_read: true })
            .in("id", ids)
            .select();

        if (error) {
            console.error("[MARK ALL READ] Update error:", error);
            return res.status(500).json({ error: error.message });
        }

        console.log("[MARK ALL READ] Updated", data?.length || 0, "notifications");
        res.json({ success: true, updated: data?.length || 0 });
    } catch (e) {
        console.error("[MARK ALL READ] Catch:", e.message);
        res.status(500).json({ error: e.message });
    }
});

/* PATCH /:id/read — mark single notification as read */
router.patch("/:id/read", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { id } = req.params;

        // Strictly by ID. No user filter needed because ID is unique.
        const { data, error } = await supabase
            .from("notifications")
            .update({ is_read: true })
            .eq("id", id)
            .select();

        if (error) {
            console.error("[MARK READ] Error:", error);
            return res.status(500).json({ error: error.message });
        }

        if (!data || data.length === 0) {
            console.warn("[MARK READ] No rows updated for id:", id);
            return res.status(404).json({ error: "Notification not found" });
        }

        console.log("[MARK READ] Success:", id);
        res.json({ success: true });
    } catch (e) {
        console.error("[MARK READ] Catch:", e.message);
        res.status(500).json({ error: e.message });
    }
});

/* POST /notifications/seed-test — insert a test notification (for debugging) */
router.post("/seed-test", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { error } = await supabase.from("notifications").insert({
            user_id: null, // broadcast to all
            message: "⚠️ Low Stock Alert: \"Test Tool\" has only 1 unit(s) remaining (threshold: 2)",
            type: "low_stock",
            is_read: false,
            metadata: { tool_id: "test", tool_name: "Test Tool", available: 1, threshold: 2 },
        });
        if (error) {
            console.error("[seed-test] Error:", error);
            return res.status(500).json({ error: error.message });
        }
        res.json({ success: true, message: "Test notification created" });
    } catch (e) {
        console.error("[seed-test] Catch:", e.message);
        res.status(500).json({ error: e.message });
    }
});

/* POST /notifications/cleanup-negative — delete ALL stale low_stock notifications */
router.post("/cleanup-negative", async (req, res) => {
    try {
        const supabase = getSupabaseClient();

        // Delete ALL low_stock notifications — they may contain stale/wrong values.
        // Fresh correct ones will be auto-generated on next tool edit or allocation.
        const { error: delErr } = await supabase
            .from("notifications")
            .delete()
            .eq("type", "low_stock");

        if (delErr) {
            console.error("[cleanup-negative] Delete error:", delErr);
            return res.status(500).json({ error: delErr.message });
        }

        console.log("[cleanup-negative] Deleted all stale low_stock notifications");
        res.json({ success: true, message: "All stale low_stock notifications deleted" });
    } catch (e) {
        console.error("[cleanup-negative] Catch:", e.message);
        res.status(500).json({ error: e.message });
    }
});



/* Internal helper — used by other routes to insert notifications */
export async function createNotification(supabase, { user_id = null, message, type = "info", metadata = null }) {
    try {
        await supabase.from("notifications").insert({
            user_id,
            message,
            type,
            is_read: false,
            metadata,
        });
    } catch (e) {
        console.error("[Notification] Failed to create:", e.message);
    }
}

export default router;
