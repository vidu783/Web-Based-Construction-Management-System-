import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";
import { snapshotBeforeDelete } from "../utils/snapshotHelper.js";

const router = Router();

/*  GET all  */
router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("officers")
            .select("*")
            .order("created_at", { ascending: false });
        if (error) return res.status(400).json({ error: error.message });
        const normalized = (data || []).map((o) => ({
            ...o,
            full_name: o.full_name || o.name || "",
            name: o.name || o.full_name || "",
        }));
        res.json(normalized);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/*  GET by id  */
router.get("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("officers")
            .select("*")
            .eq("id", req.params.id)
            .single();
        if (error) return res.status(404).json({ error: error.message });
        data.full_name = data.full_name || data.name || "";
        data.name = data.name || data.full_name || "";
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/*  GET by user_id  */
router.get("/by-user/:userId", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("officers")
            .select("*")
            .eq("user_id", req.params.userId)
            .single();
        if (error) return res.status(404).json({ error: "Officer not linked" });
        data.full_name = data.full_name || data.name || "";
        data.name = data.name || data.full_name || "";
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/*  POST create  */
router.post("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { full_name, name, phone, email, role, nic, user_id } = req.body;
        const officerName = full_name || name || "";
        if (!officerName) return res.status(400).json({ error: "Officer name is required" });

        const payload = {
            name: officerName,
            full_name: officerName,
            phone: phone || "",
            email: email || "",
            role: role || "site_officer",
            nic: nic || "",
            user_id: user_id || null,
        };

        const { data, error } = await supabase
            .from("officers")
            .insert([payload])
            .select()
            .single();
        if (error) return res.status(400).json({ error: error.message });

        data.full_name = data.full_name || data.name || officerName;
        data.name = data.name || data.full_name || officerName;
        res.status(201).json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/*  PUT update  */
router.put("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { full_name, name, phone, email, role, nic, user_id } = req.body;
        const payload = {};
        const officerName = full_name || name;
        if (officerName !== undefined) {
            payload.name = officerName;
            payload.full_name = officerName;
        }
        if (phone !== undefined) payload.phone = phone;
        if (email !== undefined) payload.email = email;
        if (role !== undefined) payload.role = role;
        if (nic !== undefined) payload.nic = nic;
        if (user_id !== undefined) payload.user_id = user_id;

        const { data, error } = await supabase
            .from("officers")
            .update(payload)
            .eq("id", req.params.id)
            .select()
            .single();
        if (error) return res.status(400).json({ error: error.message });

        data.full_name = data.full_name || data.name || "";
        data.name = data.name || data.full_name || "";
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/*  PATCH link  */
router.patch("/:id/link", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { user_id } = req.body;
        if (!user_id) return res.status(400).json({ error: "user_id required" });

        const { data: existing } = await supabase
            .from("officers")
            .select("id, full_name, name")
            .eq("user_id", user_id)
            .neq("id", req.params.id);
        if (existing && existing.length > 0) {
            return res.status(400).json({
                error: `Already linked to: ${existing[0].full_name || existing[0].name}`,
            });
        }

        const { data, error } = await supabase
            .from("officers")
            .update({ user_id })
            .eq("id", req.params.id)
            .select()
            .single();
        if (error) return res.status(400).json({ error: error.message });
        data.full_name = data.full_name || data.name || "";
        data.name = data.name || data.full_name || "";
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/*  PATCH unlink  */
router.patch("/:id/unlink", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("officers")
            .update({ user_id: null })
            .eq("id", req.params.id)
            .select()
            .single();
        if (error) return res.status(400).json({ error: error.message });
        data.full_name = data.full_name || data.name || "";
        data.name = data.name || data.full_name || "";
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/*  DELETE — smoothly remove officer and assignments */
router.delete("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();

        const { data: officer } = await supabase.from("officers").select("*").eq("id", req.params.id).single();
        
        if (officer) {
            const officerName = officer.full_name || officer.name;
            
            // Check if they have recorded any deployments
            if (officerName) {
                const { count: depCount } = await supabase
                    .from("deployments")
                    .select("id", { count: "exact", head: true })
                    .eq("recorded_by_name", officerName);

                if (depCount > 0) {
                    return res.status(409).json({
                        error: "Cannot delete officer: record is in use",
                        detail: `This officer has recorded ${depCount} deployment(s).`,
                    });
                }
            }

            await snapshotBeforeDelete(req.params.id, "officer", officerName || "Unknown Officer", {
                phone: officer.phone,
                email: officer.email,
                role:  officer.role,
                nic:   officer.nic,
            });
        }

        // Smoothly delete assignments so we don't leave a mess or block deletion unnecessarily
        await supabase.from("assignments").delete().eq("officer_id", req.params.id);

        const { error } = await supabase.from("officers").delete().eq("id", req.params.id);
        if (error) return res.status(400).json({ error: error.message });
        
        res.json({ message: "Officer deleted" });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

export default router;
