import { Router } from "express";
import { createClient } from "@supabase/supabase-js";

const router = Router();

const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY
);

// ─── Helper ───────────────────────────────────────────────────────────────────
function log(action, detail = "") {
    console.log(`[OT] ${action}${detail ? ` — ${detail}` : ""}`);
}

function err(res, status, message, detail) {
    console.error(`[OT ERROR] ${message}`, detail || "");
    return res.status(status).json({ error: message, ...(detail ? { detail: String(detail) } : {}) });
}

// ─── Role checker: resolves the role of the requesting user from JWT ──────────
async function getUserRole(req) {
    try {
        const token = req.headers.authorization?.replace("Bearer ", "");
        if (!token) return null;
        const { data: { user }, error } = await supabase.auth.getUser(token);
        if (error || !user) return null;
        const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single();
        return profile?.role || null;
    } catch {
        return null;
    }
}

// Roles allowed to approve/reject OT
const OT_REVIEW_ROLES = ["admin", "finance_officer", "project_manager"];

// ─── GET / — list with optional filters ──────────────────────────────────────
router.get("/", async (req, res) => {
    try {
        const { status, site_id, worker_id, date, date_from, date_to, month } = req.query;
        let query = supabase.from("ot_requests").select("*").order("created_at", { ascending: false });

        if (status) query = query.eq("status", status);
        if (site_id) query = query.eq("site_id", site_id);
        if (worker_id) query = query.eq("worker_id", worker_id);
        if (date) query = query.eq("date", date);
        if (date_from) query = query.gte("date", date_from);
        if (date_to) query = query.lte("date", date_to);
        if (month) {
            // month format: "YYYY-MM"
            const start = `${month}-01`;
            const y = parseInt(month.split("-")[0]);
            const m = parseInt(month.split("-")[1]);
            const end = new Date(y, m, 0).toISOString().slice(0, 10); // last day of month
            query = query.gte("date", start).lte("date", end);
        }

        const { data, error: dbErr } = await query;
        if (dbErr) return err(res, 500, "Failed to fetch OT requests", dbErr.message);

        log("LIST", `${(data || []).length} records`);
        res.json(data || []);
    } catch (e) {
        return err(res, 500, "Server error", e.message);
    }
});

// ─── POST / — create single (UPSERT: override if same worker+site+date) ─────
router.post("/", async (req, res) => {
    try {
        const { worker_id, site_id, date, ot_hours, reason, requested_by } = req.body;

        if (!worker_id || !site_id || !date || ot_hours === undefined) {
            return err(res, 400, "Missing required fields: worker_id, site_id, date, ot_hours");
        }

        if (Number(ot_hours) < 0 || Number(ot_hours) > 12) {
            return err(res, 400, "OT hours must be between 0 and 12");
        }

        // Check for existing request (same worker + site + date)
        const { data: existing } = await supabase
            .from("ot_requests")
            .select("id, status")
            .eq("worker_id", worker_id)
            .eq("site_id", site_id)
            .eq("date", date)
            .limit(1);

        if (existing && existing.length > 0) {
            const old = existing[0];
            // Override existing request regardless of status (approved/pending/rejected)
            const { data: updated, error: upErr } = await supabase
                .from("ot_requests")
                .update({
                    ot_hours: Number(ot_hours),
                    reason: reason || null,
                    requested_by: requested_by || null,
                    status: "pending",
                    reviewed_by: null,
                    reviewed_at: null,
                    review_note: null,
                    created_at: new Date().toISOString(),
                })
                .eq("id", old.id)
                .select()
                .single();

            if (upErr) return err(res, 500, "Failed to update existing OT request", upErr.message);
            log("UPSERT (updated)", `worker=${worker_id} site=${site_id} date=${date} hrs=${ot_hours} (was ${old.status})`);
            return res.json({ ...updated, _action: "updated" });
        }

        // No existing — insert new
        const { data: inserted, error: insErr } = await supabase
            .from("ot_requests")
            .insert({
                worker_id,
                site_id,
                date,
                ot_hours: Number(ot_hours),
                reason: reason || null,
                requested_by: requested_by || null,
                status: "pending",
            })
            .select()
            .single();

        if (insErr) return err(res, 500, "Failed to create OT request", insErr.message);
        log("CREATE", `worker=${worker_id} site=${site_id} date=${date} hrs=${ot_hours}`);
        res.status(201).json({ ...inserted, _action: "created" });
    } catch (e) {
        return err(res, 500, "Server error", e.message);
    }
});

// ─── POST /bulk — create/upsert multiple (one per worker+site+date) ──────────
router.post("/bulk", async (req, res) => {
    try {
        const { requests } = req.body;
        if (!Array.isArray(requests) || requests.length === 0) {
            return err(res, 400, "requests array is required and must not be empty");
        }

        const results = { created: 0, updated: 0, skipped: 0, errors: [] };

        for (const r of requests) {
            const { worker_id, site_id, date, ot_hours, reason, requested_by } = r;

            if (!worker_id || !site_id || !date || ot_hours === undefined) {
                results.errors.push({ worker_id, error: "Missing required fields" });
                results.skipped++;
                continue;
            }

            if (Number(ot_hours) <= 0) {
                results.skipped++;
                continue; // skip zero/negative OT
            }

            if (Number(ot_hours) > 12) {
                results.errors.push({ worker_id, error: "OT hours exceeds 12" });
                results.skipped++;
                continue;
            }

            // Check existing
            const { data: existing } = await supabase
                .from("ot_requests")
                .select("id, status")
                .eq("worker_id", worker_id)
                .eq("site_id", site_id)
                .eq("date", date)
                .limit(1);

            if (existing && existing.length > 0) {
                const old = existing[0];
                // Update
                const { error: upErr } = await supabase
                    .from("ot_requests")
                    .update({
                        ot_hours: Number(ot_hours),
                        reason: reason || null,
                        requested_by: requested_by || null,
                        status: "pending",
                        reviewed_by: null,
                        reviewed_at: null,
                        review_note: null,
                        created_at: new Date().toISOString(),
                    })
                    .eq("id", old.id);

                if (upErr) {
                    results.errors.push({ worker_id, error: upErr.message });
                    results.skipped++;
                } else {
                    results.updated++;
                }
            } else {
                // Insert new
                const { error: insErr } = await supabase
                    .from("ot_requests")
                    .insert({
                        worker_id,
                        site_id,
                        date,
                        ot_hours: Number(ot_hours),
                        reason: reason || null,
                        requested_by: requested_by || null,
                        status: "pending",
                    });

                if (insErr) {
                    results.errors.push({ worker_id, error: insErr.message });
                    results.skipped++;
                } else {
                    results.created++;
                }
            }
        }

        log("BULK UPSERT", `created=${results.created} updated=${results.updated} skipped=${results.skipped}`);
        res.status(201).json(results);
    } catch (e) {
        return err(res, 500, "Server error", e.message);
    }
});

// ─── BULK APPROVE ────────────────────────────────────────────────────────────
router.post("/bulk-approve", async (req, res) => {
    try {
        // Role enforcement
        const userRole = await getUserRole(req);
        if (!OT_REVIEW_ROLES.includes(userRole)) {
            return err(res, 403, "Only Finance Officers, Project Managers, and Admins can approve OT requests");
        }

        const { ids, reviewed_by, review_note } = req.body;
        if (!Array.isArray(ids) || ids.length === 0) return err(res, 400, "ids array required");

        const { data, error: dbErr } = await supabase
            .from("ot_requests")
            .update({
                status: "approved",
                reviewed_by: reviewed_by || null,
                reviewed_at: new Date().toISOString(),
                review_note: review_note || null,
            })
            .in("id", ids)
            .select();

        if (dbErr) return err(res, 500, "Bulk approve failed", dbErr.message);
        log("BULK APPROVE", `${ids.length} requests`);
        res.json({ updated: (data || []).length, data });
    } catch (e) {
        return err(res, 500, "Server error", e.message);
    }
});

router.put("/bulk-approve", async (req, res) => {
    // Alias — same logic
    req.method = "POST";
    return router.handle(req, res);
});

// ─── BULK REJECT ─────────────────────────────────────────────────────────────
router.post("/bulk-reject", async (req, res) => {
    try {
        // Role enforcement
        const userRole = await getUserRole(req);
        if (!OT_REVIEW_ROLES.includes(userRole)) {
            return err(res, 403, "Only Finance Officers, Project Managers, and Admins can reject OT requests");
        }

        const { ids, reviewed_by, review_note } = req.body;
        if (!Array.isArray(ids) || ids.length === 0) return err(res, 400, "ids array required");

        const { data, error: dbErr } = await supabase
            .from("ot_requests")
            .update({
                status: "rejected",
                reviewed_by: reviewed_by || null,
                reviewed_at: new Date().toISOString(),
                review_note: review_note || null,
            })
            .in("id", ids)
            .select();

        if (dbErr) return err(res, 500, "Bulk reject failed", dbErr.message);
        log("BULK REJECT", `${ids.length} requests`);
        res.json({ updated: (data || []).length, data });
    } catch (e) {
        return err(res, 500, "Server error", e.message);
    }
});

router.put("/bulk-reject", async (req, res) => {
    req.method = "POST";
    return router.handle(req, res);
});

// ─── SINGLE APPROVE (PUT + PATCH + POST) ────────────────────────────────────
async function approveOne(req, res) {
    try {
        // Role enforcement: only finance_officer, admin, project_manager can approve
        const userRole = await getUserRole(req);
        if (!OT_REVIEW_ROLES.includes(userRole)) {
            return err(res, 403, "Only Finance Officers, Project Managers, and Admins can approve OT requests");
        }

        const { id } = req.params;
        const { reviewed_by, review_note } = req.body || {};
        log("Approving", id);

        const { data, error: dbErr } = await supabase
            .from("ot_requests")
            .update({
                status: "approved",
                reviewed_by: reviewed_by || null,
                reviewed_at: new Date().toISOString(),
                review_note: review_note || null,
            })
            .eq("id", id)
            .select()
            .single();

        if (dbErr) return err(res, 500, "Approve failed", dbErr.message);
        if (!data) return err(res, 404, "OT request not found");
        log("APPROVED", id);
        res.json(data);
    } catch (e) {
        return err(res, 500, "Server error", e.message);
    }
}
router.put("/:id/approve", approveOne);
router.patch("/:id/approve", approveOne);
router.post("/:id/approve", approveOne);

// ─── SINGLE REJECT (PUT + PATCH + POST) ─────────────────────────────────────
async function rejectOne(req, res) {
    try {
        // Role enforcement
        const userRole = await getUserRole(req);
        if (!OT_REVIEW_ROLES.includes(userRole)) {
            return err(res, 403, "Only Finance Officers, Project Managers, and Admins can reject OT requests");
        }

        const { id } = req.params;
        const { reviewed_by, review_note } = req.body || {};
        log("Rejecting", id);

        const { data, error: dbErr } = await supabase
            .from("ot_requests")
            .update({
                status: "rejected",
                reviewed_by: reviewed_by || null,
                reviewed_at: new Date().toISOString(),
                review_note: review_note || null,
            })
            .eq("id", id)
            .select()
            .single();

        if (dbErr) return err(res, 500, "Reject failed", dbErr.message);
        if (!data) return err(res, 404, "OT request not found");
        log("REJECTED", id);
        res.json(data);
    } catch (e) {
        return err(res, 500, "Server error", e.message);
    }
}
router.put("/:id/reject", rejectOne);
router.patch("/:id/reject", rejectOne);
router.post("/:id/reject", rejectOne);

// ─── GET /:id ────────────────────────────────────────────────────────────────
router.get("/:id", async (req, res) => {
    try {
        const { data, error: dbErr } = await supabase
            .from("ot_requests")
            .select("*")
            .eq("id", req.params.id)
            .single();

        if (dbErr) return err(res, 500, "Fetch failed", dbErr.message);
        if (!data) return err(res, 404, "Not found");
        res.json(data);
    } catch (e) {
        return err(res, 500, "Server error", e.message);
    }
});

// ─── PUT /:id — update ──────────────────────────────────────────────────────
router.put("/:id", async (req, res) => {
    try {
        const updates = {};
        const allowed = ["worker_id", "site_id", "date", "ot_hours", "reason", "status", "requested_by", "reviewed_by", "reviewed_at", "review_note"];
        for (const key of allowed) {
            if (req.body[key] !== undefined) updates[key] = req.body[key];
        }

        if (Object.keys(updates).length === 0) return err(res, 400, "No valid fields to update");

        const { data, error: dbErr } = await supabase
            .from("ot_requests")
            .update(updates)
            .eq("id", req.params.id)
            .select()
            .single();

        if (dbErr) return err(res, 500, "Update failed", dbErr.message);
        if (!data) return err(res, 404, "Not found");
        log("UPDATED", req.params.id);
        res.json(data);
    } catch (e) {
        return err(res, 500, "Server error", e.message);
    }
});

// ─── DELETE /:id ─────────────────────────────────────────────────────────────
router.delete("/:id", async (req, res) => {
    try {
        const { error: dbErr } = await supabase
            .from("ot_requests")
            .delete()
            .eq("id", req.params.id);

        if (dbErr) return err(res, 500, "Delete failed", dbErr.message);
        log("DELETED", req.params.id);
        res.json({ success: true });
    } catch (e) {
        return err(res, 500, "Server error", e.message);
    }
});

export default router;
