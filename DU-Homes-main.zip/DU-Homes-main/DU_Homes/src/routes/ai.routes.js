import express from "express";
import Groq from "groq-sdk";
import { getSupabaseClient } from "../supabaseClient.js";
import { requireRole } from "../middleware/auth.js";

const router = express.Router();

// ============================================================
// FIX 2: STARTUP CONNECTION TEST
// ============================================================
(async () => {
  try {
    const sb = getSupabaseClient();
    const { data, error } = await sb.from("workers").select("id").limit(1);
    if (error) {
      console.error("[AI] STARTUP TEST FAILED — workers table:", error.message);
      console.error("[AI] Hint: Check SUPABASE_SERVICE_KEY in .env");
    } else {
      console.log(`[AI] STARTUP TEST PASSED — workers table accessible, got ${data?.length} row(s)`);
    }
  } catch (e) {
    console.error("[AI] STARTUP TEST EXCEPTION:", e.message);
  }
})();

// ============================================================
// GLOBAL CACHE (Enhancement 7)
// ============================================================
const dataCache = { data: null, timestamp: 0 };
const CACHE_TTL = 30000; // 30 seconds

// ============================================================
// ELITE HELPERS (Memory & Response Post-Processing)
// ============================================================

function analyzeHistory(history) {
  const context = { mentionedWorkers: [], mentionedSites: [], lastTopic: "general" };
  if (!history || history.length === 0) return context;
  const recent = history.slice(-6);
  recent.forEach((h) => {
    const text = (h.text || h.content || "").toLowerCase();
    if (text.includes("worker") || text.includes("perera") || text.includes("amal")) context.lastTopic = "workers";
    if (text.includes("site") || text.includes("field")) context.lastTopic = "sites";
    if (text.includes("pay") || text.includes("cost")) context.lastTopic = "payments";
  });
  return context;
}

function postProcessResponse(reply, dbData) {
  let cleaned = reply;
  const uuidRegex = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi;
  const matches = cleaned.match(uuidRegex);
  if (matches && dbData.workers) {
    matches.forEach((uuid) => {
      const worker = dbData.workers.find((w) => w.id === uuid);
      if (worker) cleaned = cleaned.replace(new RegExp(uuid, "g"), `**${worker.full_name || worker.name}**`);
    });
  }
  const hasData = (dbData.workers?.length > 0 || dbData.fields?.length > 0);
  const saysNoData = /don't have access|cannot access|no data available|no record|not found/i.test(cleaned);
  if (hasData && saysNoData && cleaned.length < 200) {
    return "Let me check the latest records for you... " + cleaned;
  }
  return cleaned;
}

// ============================================================
// DIAGNOSTIC ENDPOINT
// ============================================================
router.get("/debug", requireRole("admin"), async (req, res) => {
  const supabase = getSupabaseClient();
  const results = {};
  const tables = ["workers", "sites", "deployments", "deployment_workers", "attendance", "payments", "officers", "ot_requests", "tools", "assignments", "tool_allocations"];
  for (const table of tables) {
    try {
      const { data, error } = await supabase.from(table).select("*").limit(3);
      results[table] = { success: !error, count: data?.length || 0, columns: data?.[0] ? Object.keys(data[0]) : [], error: error?.message || null };
    } catch (e) { results[table] = { success: false, error: e.message }; }
  }
  res.json({ summary: results, groq: !!process.env.GROQ_API_KEY });
});

// ========================================================================
// SYSTEM LOGIC: Smart Data Fetcher (Keyword-Based Retrieval)
// GOAL: Decide which database tables to query based on the user's question.
// WHY: We don't want to send ALL data to the AI every time (too expensive).
// ========================================================================
async function fetchRelevantData(message, historyContext = {}) {
  const sb = getSupabaseClient();
  const msg = message.toLowerCase();
  const today = new Date().toISOString().slice(0, 10);
  const currentMonth = today.slice(0, 7);
  const data = {};
  const isFollowUp = !!historyContext.isFollowUp;

  // Step 1: Detect Keywords
  // We use simple String.includes() or Regex to see if the user is asking 
  // about "workers", "money", "tools", etc.
  const needs = {
    workers: /worker|employee|staff|mason|plumber|carpenter|helper|painter|electrician|who (is|are)|how many people|who are|crew|team|labour|labor|manpower|names|list/i.test(msg),
    sites: /site|work site|job site|area|zone|where|field|project|location|construction|building/i.test(msg),
    attendance: /attend|today's attendance|present|absent|came|come|show up|who came|who was|leave|missing|not present|who didn't|who not|absent today|attendance rate|turnout/i.test(msg),
    deployments: /deploy|deployed|assigned to|working at|sent to|who is at|site a|today|who went|who was sent|working where|stationed/i.test(msg),
    payments: /pay|payment|bill|expense|budget|total cost|how much|spending|dues|outstanding|unpaid|owed|salary|wage|earn|paid|payroll|money|financial|cost|income|net pay|deduction/i.test(msg),
    tools: /tool|material|asset|resource|supply|supplies|gear|equipment|machine|inventory|allocated|hoard/i.test(msg),
    officers: /officer|site officer|in charge|responsible|head|lead|contact person|manager|admin|finance|supervisor|who manage|who run/i.test(msg),
    ot: /ot |extra work|additional hours|overtime request|ot hours|overtime pay|overtime|over time|extra hour|ot request/i.test(msg),
    assignments: /assign|which officer|who manage|site officer/i.test(msg),
    leaderboard: /highest|lowest|most days|most paid|compare|comparison|productive|hardworking|best|worst|top|bottom|rank|leader|perform|most|least/i.test(msg),
    general: /report|brief|briefing|update|what's happening|status update|tell me about|info|dashboard|overview|summary|stat|how is|how are things|general|everything/i.test(msg),
  };

  if (isFollowUp) needs.general = true;

  // FIX 7: Greeting with quick stats
  const isGreeting = /^(hi|hello|hey|good morning|good afternoon|good evening|sup|yo|what's up)[\s!.,?]*$/i.test(msg.trim());
  if (isGreeting) {
    try {
      const [wRes, dRes, otRes] = await Promise.all([
        sb.from("workers").select("id", { count: "exact", head: true }),
        sb.from("deployments").select("id", { count: "exact", head: true }).eq("date", today),
        sb.from("ot_requests").select("id", { count: "exact", head: true }).eq("status", "pending"),
      ]);
      return { _context: "greeting", quick_stats: { total_workers: wRes.count || 0, deployments_today: dRes.count || 0, pending_ot: otRes.count || 0 } };
    } catch (e) { return { _context: "greeting" }; }
  }

  const needsSomething = Object.values(needs).some(Boolean);
  if (!needsSomething) needs.general = true;

  if (needs.general || needs.deployments || needs.attendance || needs.ot || needs.leaderboard) needs.workers = true;
  if (needs.general) Object.keys(needs).forEach(k => needs[k] = true);

  try {
    // Queries use select("*") per FIX 3
    if (needs.workers || needs.leaderboard) {
      const { data: workers } = await sb.from("workers").select("*");
      if (workers?.[0]) console.log("[AI] Worker columns:", Object.keys(workers[0]).join(", "));
      data.workers = (workers || []).map(w => ({
        id: w.id,
        full_name: w.full_name || w.name || `${w.first_name || ""} ${w.last_name || ""}`.trim() || null,
        type: w.worker_type || w.type || w.role || "not specified",
        daily_rate: w.daily_rate || w.basic_salary || 0,
        phone: w.phone || null
      }));
      data.total_workers = data.workers.length;
    }

    if (needs.sites || needs.deployments) {
      const [{ data: fields }, { data: deps }, { data: dwRows }] = await Promise.all([
        sb.from("sites").select("*"),
        sb.from("deployments").select("*").eq("date", today),
        sb.from("deployment_workers").select("*"),
      ]);
      data.fields = (fields || []).map(s => ({ id: s.id, name: s.name || s.site_name || null }));
      const workerMap = {}; if (data.workers) data.workers.forEach(w => { workerMap[w.id] = w; });
      const siteMap = {}; data.fields.forEach(s => { siteMap[s.id] = s.name; });
 
      data.today_deployments = (deps || []).map(d => {
        const myWorkers = (dwRows || []).filter(dw => dw.deployment_id === d.id);
        return {
          site: siteMap[d.site_id] || "site not registered",
          worker_count: myWorkers.length,
          workers: myWorkers.map(dw => workerMap[dw.worker_id] ? { name: workerMap[dw.worker_id].full_name, type: workerMap[dw.worker_id].type } : { name: "record missing", id: dw.worker_id }),
        };
      });
      data.total_workers_deployed = (data.today_deployments || []).reduce((s, d) => s + d.worker_count, 0);
    }

    if (needs.attendance) {
      const { data: att } = await sb.from("attendance").select("*").eq("date", today);
      const records = att || [];
      const present = records.filter(a => (a.status || "").toLowerCase() === "present");
      data.today_attendance = { present_count: present.length, total_recorded: records.length };
    }

    if (needs.payments) {
      const { data: pmts } = await sb.from("payments").select("*").gte("date", `${currentMonth}-01`);
      let total = 0; (pmts || []).forEach(p => total += Number(p.net_pay || 0));
      data.monthly_payroll = { total_net: total, month: currentMonth };
    }

    // FIX 8: Cross-References
    if (data.workers && data.today_attendance && data.today_deployments) {
      data.cross_references = {
        total_present: data.today_attendance.present_count || 0,
        total_deployed: data.total_workers_deployed || 0,
        attendance_rate: data.total_workers > 0 ? Math.round((data.today_attendance.present_count / data.total_workers) * 100) + "%" : "N/A",
      };
    }

    if (needs.general) { dataCache.data = data; dataCache.timestamp = Date.now(); }
  } catch (err) { console.error("[AI] Fetch Error:", err.message); }

  return data;
}

// ANALYZE CONVERSATION CONTEXT: Track topics and follow-ups
function analyzeConversationContext(history, message) {
    const context = { 
        lastTopic: "general", 
        isFollowUp: false,
        mentionedSites: [],
        recentKeywords: []
    };
    
    if (!history || history.length === 0) return context;
    
    const recent = history.slice(-4);
    const lowerMsg = message.toLowerCase();
    
    // Detect follow-up patterns
    context.isFollowUp = /^(what about|how about|and |also |tell me more|more details|what are the|show me|list)/i.test(message.trim().toLowerCase());
    
    // Analyze recent conversation topics
    recent.forEach(h => {
        const text = (h.text || h.content || "").toLowerCase();
        if (text.includes("deploy") || text.includes("site") || text.includes("worker")) {
            context.lastTopic = "deployments";
        } else if (text.includes("pay") || text.includes("cost") || text.includes("financial")) {
            context.lastTopic = "finance";
        } else if (text.includes("attend") || text.includes("present") || text.includes("absent")) {
            context.lastTopic = "attendance";
        } else if (text.includes("tool") || text.includes("stock") || text.includes("allocation")) {
            context.lastTopic = "tools";
        }
    });
    
    return context;
}

// ============================================================
// CHAT ENDPOINT: FIX 10 (Retry Logic) & FIX 9 (Prompt)
// ============================================================
router.post("/chat", async (req, res) => {
  try {
    const { message, userName, history, context } = req.body;
    if (!message) return res.status(400).json({ error: "Message is required." });

    const apiKey = process.env.GROQ_API_KEY;
    const groq = new Groq({ apiKey });
    const today = new Date().toISOString().slice(0, 10);
    
    // Analyze conversation history for context
    const conversationContext = analyzeConversationContext(history, message);

    // If frontend sends context, use it (immediate solution)
    let dbData = {};
    let dataSection = "";
    
    if (context && context.todayDeployments) {
      dbData = context; // Track for postProcessResponse if needed
      dataSection = `
STRUCTURED DASHBOARD DATA:
${JSON.stringify({
    insights: context.insights,
    stats: context.stats,
    todayDeployments: context.todayDeployments,
    finances: context.finances,
    toolAlerts: context.toolAlerts
}, null, 2)}

ANALYSIS FOCUS AREAS:
- Overall Status: ${context.insights?.generalStatus || "Unknown"}
- Attendance: ${context.insights?.isAttendancePerfect ? "Perfect (100%)" : `Issues detected (${context.stats?.absentToday || 0} absent)`}
- Top Active Site: ${context.insights?.topSite?.name || "None"} (${context.insights?.topSite?.count || 0} workers)
- Financial Status: ${context.insights?.hasPendingPayments ? "Has pending payments" : "Current"}
- Tool Status: ${context.insights?.criticalLowStock > 0 ? `${context.insights.criticalLowStock} items low stock` : "Well stocked"}
`;
    } else {
      // Fallback: Smart Data Fetcher
      dbData = await fetchRelevantData(message, analyzeHistory(history));
      const isGreeting = dbData._context === "greeting";
      dataSection = `\n\nLIVE DATABASE DATA:\n${JSON.stringify(dbData, null, 1)}`;
      if (isGreeting && dbData.quick_stats) {
        dataSection = `\n\nQUICK STATS: ${JSON.stringify(dbData.quick_stats)}\nUse these stats naturally in your greeting.`;
      }
    }

    // ========================================================================
    // SYSTEM LOGIC: RAG Architecture (Retrieval Augmented Generation)
    // 1. SYSTEM PROMPT: Instructions on how the AI should behave.
    // 2. LIVE DATA: The JSON stats we fetched earlier.
    // 3. HISTORY: The last 12 messages for conversation memory.
    // ========================================================================
    const systemPrompt = `You are DU AI — the Senior Executive AI Analyst for DU Homes Construction Management System.
Speaking with: ${userName || "Site Manager"}
Today: ${today} | Time: ${new Date().toLocaleTimeString("en-LK")}

PERSONALITY & BEHAVIOR:
- Be intelligent, concise, and professional.
- Focus on INSIGHTS (tell the user what the numbers mean).
- Use bullet points for lists.

DATA INJECTION (The "Knowledge" of the AI):
${dataSection}`;

    let messages = [{ role: "system", content: systemPrompt }];
    if (history?.length > 0) {
      let foundFirst = false;
      for (const h of history.slice(-12)) {
        const role = h.role === "assistant" ? "assistant" : "user";
        const content = h.text || h.content || "";
        if (!content) continue;
        if (role === "user") foundFirst = true;
        if (foundFirst) messages.push({ role, content: String(content) });
      }
    }
    messages.push({ role: "user", content: String(message) });

    let reply = "";
    let attempts = 0;
    while (attempts < 2) {
      try {
        const completion = await groq.chat.completions.create({ model: "llama-3.3-70b-versatile", messages, temperature: 0.6, max_tokens: 2048 });
        reply = completion.choices[0]?.message?.content || "";
        if (reply) break;
      } catch (err) {
        if (err.status === 429 && attempts === 0) {
          console.log("[AI] Rate limit — retrying in 2s...");
          await new Promise(r => setTimeout(r, 2000));
          attempts++;
        } else throw err;
      }
    }
    if (!reply) reply = "I'm experiencing high demand right now. Please try again in a moment.";

    console.log(`[AI] Analyzed Query: ${message.substring(0, 60)}${message.length > 60 ? "..." : ""} | Response Length: ${reply.length} | User: ${userName || "Anonymous"}`);
    return res.json({ text: postProcessResponse(reply, dbData) });

  } catch (error) {
    console.error("[AI] Error:", error.message);
    let errorMessage = "Analysis interrupted.";
    let statusCode = 500;
    
    if (error.message.toLowerCase().includes('rate limit')) {
      errorMessage = "AI service temporarily busy (Rate Limit). Please try again in 1 minute.";
      statusCode = 429;
    } else if (error.message.toLowerCase().includes('timeout') || error.status === 408) {
      errorMessage = "Analysis taking longer than expected. Please try a simpler question.";
      statusCode = 408;
    }
    
    res.status(statusCode).json({ error: errorMessage, retryable: statusCode !== 500 });
  }
});

router.get("/health", (req, res) => res.json({ status: "polish v5.1" }));
export default router;
