import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

const router = Router();

/* GET /audit-logs — admin only, paginated */
router.get("/", requireRole("admin"), async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { page = 1, limit = 50, from, to, action, user_id } = req.query;
        const offset = (Number(page) - 1) * Number(limit);

        let query = supabase
            .from("audit_logs")
            .select("*", { count: "exact" })
            .order("created_at", { ascending: false })
            .range(offset, offset + Number(limit) - 1);

        if (from) query = query.gte("created_at", from);
        if (to) query = query.lte("created_at", to + "T23:59:59Z");
        if (action) query = query.eq("action", action);
        if (user_id) query = query.eq("user_id", user_id);

        const { data, count, error } = await query;
        if (error) return res.status(400).json({ error: error.message });

        res.json({
            data: data || [],
            total: count || 0,
            page: Number(page),
            limit: Number(limit),
            pages: Math.ceil((count || 0) / Number(limit)),
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* Internal helper — insert a log entry, used by other routes */
export async function writeAuditLog(supabase, { user_id, user_email, action, resource, ip_address, detail }) {
    try {
        await supabase.from("audit_logs").insert({
            user_id: user_id || null,
            user_email: user_email || null,
            action,
            resource: resource || null,
            ip_address: ip_address || null,
            detail: detail || null,
        });
    } catch (e) {
        console.error("[AuditLog] Failed to write:", e.message);
    }
}

export default router;
