import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";
import { snapshotBeforeDelete } from "../utils/snapshotHelper.js";

const router = Router();

// ── GET / ── 
// List attendance records. Supports filtering by date, worker, or site via query parameters.
router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        let query = supabase.from("attendance").select("*").order("date", { ascending: false });

        if (req.query.date) query = query.eq("date", req.query.date);
        if (req.query.from) query = query.gte("date", req.query.from);
        if (req.query.to) query = query.lte("date", req.query.to);
        if (req.query.worker_id) query = query.eq("worker_id", req.query.worker_id);
        if (req.query.site_id) query = query.eq("site_id", req.query.site_id);
        if (req.query.status) query = query.eq("status", req.query.status);

        const { data, error } = await query;
        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ── GET /:id ── 
// Retrieve a single attendance record by its ID.
router.get("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("attendance")
            .select("*")
            .eq("id", req.params.id)
            .single();
        if (error) return res.status(404).json({ error: "Record not found" });
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ── POST / ── 
// Record attendance for a worker.
// LOGIC: Automatically checks if a record already exists for the given worker/site/date.
// If it exists, it updates the status; otherwise, it creates a new record.
router.post("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { worker_id, site_id, date, status } = req.body;
        if (!worker_id || !site_id || !date) return res.status(400).json({ error: "worker_id, site_id, and date are required" });

        // DUPLICATE PREVENTION: Check if a record exists for this specific day/worker.
        const { data: existing } = await supabase
            .from("attendance")
            .select("id")
            .eq("worker_id", worker_id)
            .eq("site_id", site_id)
            .eq("date", date)
            .maybeSingle();

        if (existing) {
            // Update the existing record instead of creating a duplicate.
            const { data, error } = await supabase
                .from("attendance")
                .update({ status: status || "present" })
                .eq("id", existing.id)
                .select()
                .single();
            if (error) return res.status(400).json({ error: error.message });
            return res.json(data);
        }

        // Create a new record if none exists.
        const { data, error } = await supabase
            .from("attendance")
            .insert({ worker_id, site_id, date, status: status || "present" })
            .select()
            .single();
        if (error) return res.status(400).json({ error: error.message });
        res.status(201).json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ── PUT /:id ── 
// Update the status (Present/Absent) of an existing attendance record.
router.put("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { status } = req.body;
        const { data, error } = await supabase
            .from("attendance")
            .update({ status })
            .eq("id", req.params.id)
            .select()
            .single();
        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ── DELETE /:id ── 
// Remove an attendance record and save a snapshot for historical audits.
router.delete("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data: rec } = await supabase.from("attendance").select("*").eq("id", req.params.id).single();

        // PRESERVATION: Capture details before permanent deletion.
        if (rec) {
            await snapshotBeforeDelete(req.params.id, "attendance",
                `Attendance ${rec.date} (${rec.status})`,
                { worker_id: rec.worker_id, site_id: rec.site_id, date: rec.date, status: rec.status });
        }

        const { error } = await supabase.from("attendance").delete().eq("id", req.params.id);
        if (error) return res.status(400).json({ error: error.message });
        res.json({ message: "Attendance record deleted" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

export default router;
