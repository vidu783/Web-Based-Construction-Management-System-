import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";
import { snapshotBeforeDelete } from "../utils/snapshotHelper.js";
import multer from "multer";

const router = Router();

/* ── multer: memory storage (we upload buffer to Supabase Storage) ── */
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
    fileFilter: (req, file, cb) => {
        const allowed = ["image/jpeg", "image/png", "application/pdf"];
        if (allowed.includes(file.mimetype)) cb(null, true);
        else cb(new Error("Only JPG, PNG, and PDF files are allowed"), false);
    },
});

/* ── POST /tool-bills/upload  — upload bill image ── */
router.post("/upload", upload.single("bill_image"), async (req, res) => {
    try {
        if (!req.file) return res.status(400).json({ error: "No file uploaded" });

        const supabase = getSupabaseClient();
        const { tool_id, uploaded_by, uploader_role, note, recorded_by_name, recorded_by_role } = req.body;
        const authenticatedUserId = req.user?.id || null;
        const finalUploadedBy = authenticatedUserId || uploaded_by;
        const finalUploaderRole = uploader_role === "site_officer" ? "project_manager" : uploader_role;

        if (!finalUploadedBy) return res.status(400).json({ error: "uploaded_by is required" });
        if (authenticatedUserId && uploaded_by && uploaded_by !== authenticatedUserId) {
            return res.status(403).json({ error: "uploaded_by does not match authenticated user" });
        }
        if (!uploader_role || !["admin", "project_manager", "site_officer"].includes(uploader_role)) {
            return res.status(400).json({ error: "uploader_role must be admin, project_manager, or site_officer" });
        }

        // Generate unique file name
        const ext = req.file.originalname.split(".").pop() || "bin";
        const fileName = `bill_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
        const filePath = `bills/${fileName}`;

        // Upload to Supabase Storage
        const { error: uploadError } = await supabase.storage
            .from("tool-bills")
            .upload(filePath, req.file.buffer, {
                contentType: req.file.mimetype,
                upsert: false,
            });

        if (uploadError) {
            console.error("Storage upload error:", uploadError);
            return res.status(500).json({ error: "File upload failed: " + uploadError.message });
        }

        // Get public URL
        const { data: urlData } = supabase.storage.from("tool-bills").getPublicUrl(filePath);
        const publicUrl = urlData?.publicUrl || filePath;

        // Create record
        const { data, error } = await supabase
            .from("tool_bills")
            .insert([{
                tool_id: tool_id || null,
                uploaded_by: finalUploadedBy,
                uploader_role: finalUploaderRole,
                image_path: publicUrl,
                file_name: req.file.originalname,
                file_type: req.file.mimetype,
                note: (note || "").trim() || null,
                is_read: false,
                status: "Pending",
                recorded_by_name: (recorded_by_name || "").trim() || null,
                recorded_by_role: (recorded_by_role || uploader_role || "").trim() || null,
            }])
            .select("*")
            .single();

        if (error) {
            console.error("DB insert error:", error);
            return res.status(400).json({ error: error.message });
        }

        res.status(201).json(data);
    } catch (e) {
        console.error("Upload error:", e);
        res.status(500).json({ error: e.message });
    }
});

/* ── GET /tool-bills/unread-count — notification badge count ── */
router.get("/unread-count", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { count, error } = await supabase
            .from("tool_bills")
            .select("*", { count: "exact", head: true })
            .eq("is_read", false);

        if (error) return res.status(400).json({ error: error.message });
        res.json({ count: count || 0 });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── GET /tool-bills — list all bills ── */
router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        let query = supabase
            .from("tool_bills")
            .select("*")
            .order("created_at", { ascending: false });

        const { status, search } = req.query;
        if (status) query = query.eq("status", status);
        if (search) query = query.ilike("tools.name", `%${search}%`);

        const { data, error } = await query;
        if (error) return res.status(400).json({ error: error.message });
        res.json(data || []);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── GET /tool-bills/:id — single bill details ── */
router.get("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("tool_bills")
            .select("*")
            .eq("id", req.params.id)
            .single();

        if (error) return res.status(404).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── PATCH /tool-bills/:id/mark-read — dismiss red dot for this bill ── */
router.patch("/:id/mark-read", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("tool_bills")
            .update({ is_read: true, updated_at: new Date().toISOString() })
            .eq("id", req.params.id)
            .select()
            .single();

        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── PUT /tool-bills/:id/mark — update bill status ── */
router.put("/:id/mark", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { status, reject_reason } = req.body;

        if (!status || !["Pending", "In Progress", "Processed", "Rejected"].includes(status)) {
            return res.status(400).json({ error: "Invalid status" });
        }

        const updates = { status, updated_at: new Date().toISOString() };
        if (status === "Rejected" && reject_reason) updates.reject_reason = reject_reason;

        const { data, error } = await supabase
            .from("tool_bills")
            .update(updates)
            .eq("id", req.params.id)
            .select()
            .single();

        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── DELETE /tool-bills/:id — delete bill ── */
router.delete("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data: rec } = await supabase.from("tool_bills").select("*").eq("id", req.params.id).single();
        if (rec) {
            await snapshotBeforeDelete(req.params.id, "tool_bill",
                rec.file_name || `Tool Bill ${req.params.id}`,
                { status: rec.status, note: rec.note, uploaded_by: rec.uploaded_by });
        }
        const { error } = await supabase.from("tool_bills").delete().eq("id", req.params.id);
        if (error) return res.status(400).json({ error: error.message });
        res.json({ message: "Bill deleted" });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

export default router;
