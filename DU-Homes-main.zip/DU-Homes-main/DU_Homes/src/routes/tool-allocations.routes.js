import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";
import { snapshotBeforeDelete } from "../utils/snapshotHelper.js";
import { createNotification } from "./notifications.routes.js";

const router = Router();
const LOW_STOCK_THRESHOLD = 2;

// ── INTERNAL HELPER: Recalculate Tool Availability ── 
// LOGIC: Automatically calculates how many units of a tool are left by subtracting 
// active allocations from the total quantity. Also triggers/dismisses low-stock alerts.
async function recalculateToolAvailable(supabase, tool_id) {
    const { data: tool } = await supabase.from("tools").select("total_qty, name, available").eq("id", tool_id).single();
    if (!tool) return;
    
    // Sum up all tools that are currently 'allocated' (not yet returned)
    const { data: allocs } = await supabase.from("tool_allocations")
        .select("qty")
        .eq("tool_id", tool_id)
        .neq("status", "returned")
        .is("returned_date", null);
        
    const allocatedSum = (allocs || []).reduce((sum, a) => sum + (parseInt(a.qty) || 0), 0);
    const newAvailable = Math.max(0, (tool.total_qty || 0) - allocatedSum);
    const oldAvailable = Math.max(0, tool.available !== null ? tool.available : tool.total_qty);
    
    // Update the master tools table with the new available count
    await supabase.from("tools").update({ available: newAvailable }).eq("id", tool_id);
    
    // NOTIFICATION LOGIC: Trigger an alert if stock is low.
    if (newAvailable <= LOW_STOCK_THRESHOLD && newAvailable < oldAvailable) {
        const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
        const { data: existingAlert } = await supabase
            .from("notifications")
            .select("id")
            .eq("type", "low_stock")
            .contains("metadata", { tool_id: tool_id })
            .gte("created_at", since)
            .limit(1);

        if (!existingAlert || existingAlert.length === 0) {
            await createNotification(supabase, {
                user_id: null,
                message: `Low Stock Alert: "${tool.name}" has only ${newAvailable} unit(s) remaining.`,
                type: "low_stock",
                metadata: { tool_id, tool_name: tool.name, available: newAvailable, threshold: LOW_STOCK_THRESHOLD },
            });
        }
    } else if (newAvailable > LOW_STOCK_THRESHOLD) {
        // Automatically dismiss the alert if stock is replenished.
        await supabase.from("notifications")
            .delete()
            .eq("type", "low_stock")
            .contains("metadata", { tool_id: tool_id });
    }
}

// ── GET / ── 
// List all tool allocations.
router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        let query = supabase
            .from("tool_allocations")
            .select("*")
            .order("allocated_date", { ascending: false });

        if (req.query.site_id) query = query.eq("site_id", req.query.site_id);
        if (req.query.tool_id) query = query.eq("tool_id", req.query.tool_id);
        if (req.query.status) query = query.eq("status", req.query.status);

        const { data, error } = await query;
        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ── GET /:id ── 
// Fetch details for a specific allocation.
router.get("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("tool_allocations")
            .select("*")
            .eq("id", req.params.id)
            .single();
        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ── POST / ── 
// Record a new tool allocation. 
// LOGIC: Includes a validation step to ensure requested quantity does not exceed available stock.
router.post("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { tool_id, site_id, worker_id, qty, allocated_date, returned_date, status, notes } = req.body;

        if (!tool_id || !site_id || !worker_id) {
            return res.status(400).json({ error: "tool_id, site_id, and worker_id are required" });
        }

        const payload = {
            tool_id,
            site_id,
            worker_id: worker_id || null,
            qty: parseInt(qty) || 1,
            allocated_date: allocated_date || new Date().toISOString().slice(0, 10),
            returned_date: returned_date || null,
            status: status || "allocated",
            notes: (notes || "").trim(),
        };

        const is_returned = payload.status === "returned" || !!payload.returned_date;
        if (!is_returned) {
            const { data: tool } = await supabase.from("tools").select("total_qty").eq("id", tool_id).single();
            if (!tool) return res.status(404).json({ error: "Tool not found" });

            const { data: allocs } = await supabase.from("tool_allocations")
                .select("qty")
                .eq("tool_id", tool_id)
                .neq("status", "returned")
                .is("returned_date", null);

            const allocatedSum = (allocs || []).reduce((sum, a) => sum + (parseInt(a.qty) || 0), 0);
            const available = (tool.total_qty || 0) - allocatedSum;

            if (payload.qty > available) {
                return res.status(400).json({ error: `Cannot allocate ${payload.qty}. Only ${available} available.` });
            }
        }

        const { data, error } = await supabase
            .from("tool_allocations")
            .insert([payload])
            .select("*")
            .single();
        if (error) return res.status(400).json({ error: error.message });
        
        // Sync the master stock table after a successful allocation.
        await recalculateToolAvailable(supabase, tool_id);
        
        res.status(201).json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ── PUT /:id ── 
// Update an allocation record (e.g., marking as 'returned').
router.put("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { tool_id, site_id, worker_id, qty, allocated_date, returned_date, status, notes } = req.body;
        const payload = {};

        if (tool_id !== undefined) payload.tool_id = tool_id;
        if (site_id !== undefined) payload.site_id = site_id;
        if (worker_id !== undefined) payload.worker_id = worker_id || null;
        if (qty !== undefined) payload.qty = parseInt(qty) || 1;
        if (allocated_date !== undefined) payload.allocated_date = allocated_date;
        if (returned_date !== undefined) payload.returned_date = returned_date || null;
        if (status !== undefined) payload.status = status;
        if (notes !== undefined) payload.notes = (notes || "").trim();

        if (Object.keys(payload).length === 0) {
            return res.status(400).json({ error: "No fields to update" });
        }

        const { data: existing } = await supabase.from("tool_allocations").select("*").eq("id", req.params.id).single();
        if (!existing) return res.status(404).json({ error: "Allocation not found" });

        const checkQty = payload.qty !== undefined ? payload.qty : existing.qty;
        const checkStatus = payload.status !== undefined ? payload.status : existing.status;
        const checkRetDate = payload.returned_date !== undefined ? payload.returned_date : existing.returned_date;
        const checkToolId = payload.tool_id !== undefined ? payload.tool_id : existing.tool_id;

        const is_returned = checkStatus === "returned" || !!checkRetDate;
        
        if (!is_returned) {
            const { data: tool } = await supabase.from("tools").select("total_qty").eq("id", checkToolId).single();
            if (!tool) return res.status(404).json({ error: "Tool not found" });

            const { data: allocs } = await supabase.from("tool_allocations")
                .select("qty")
                .eq("tool_id", checkToolId)
                .neq("id", req.params.id) 
                .neq("status", "returned")
                .is("returned_date", null);

            const allocatedSum = (allocs || []).reduce((sum, a) => sum + (parseInt(a.qty) || 0), 0);
            const available = (tool.total_qty || 0) - allocatedSum;

            if (checkQty > available) {
                return res.status(400).json({ error: `Cannot allocate ${checkQty}. Only ${available} available.` });
            }
        }

        const { data, error } = await supabase
            .from("tool_allocations")
            .update(payload)
            .eq("id", req.params.id)
            .select("*")
            .single();
        if (error) return res.status(400).json({ error: error.message });
        
        // Recalculate availability after modification.
        await recalculateToolAvailable(supabase, checkToolId);
        if (existing.tool_id !== checkToolId) {
            await recalculateToolAvailable(supabase, existing.tool_id);
        }

        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ── DELETE /:id ── 
// Permanently remove an allocation and snapshot details.
router.delete("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data: rec } = await supabase.from("tool_allocations")
            .select("*")
            .eq("id", req.params.id).single();
            
        // DATA PROTECTION: Snapshot record details before deletion.
        if (rec) {
            const toolName = rec.tools?.name || rec.tool_id;
            const workerName = rec.workers?.full_name || rec.worker_id;
            await snapshotBeforeDelete(req.params.id, "tool_allocation",
                `${toolName} → ${workerName} (${rec.allocated_date})`,
                { tool_id: rec.tool_id, site_id: rec.site_id, worker_id: rec.worker_id, qty: rec.qty, status: rec.status });
        }
        
        const { error } = await supabase.from("tool_allocations").delete().eq("id", req.params.id);
        if (error) return res.status(400).json({ error: error.message });
        
        if (rec) {
            await recalculateToolAvailable(supabase, rec.tool_id);
        }

        res.json({ message: "Deleted" });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

export default router;
