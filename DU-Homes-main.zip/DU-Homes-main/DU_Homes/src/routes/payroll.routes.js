import { Router } from "express";
import PDFDocument from "pdfkit";
import { getSupabaseClient } from "../supabaseClient.js";

const router = Router();

function monthRange(monthStr) {
    const start = new Date(monthStr);
    if (Number.isNaN(start.getTime())) return null;

    const y = start.getFullYear();
    const m = start.getMonth();
    const rangeStart = new Date(Date.UTC(y, m, 1));
    const rangeEnd = new Date(Date.UTC(y, m + 1, 0));

    return {
        start: rangeStart.toISOString().slice(0, 10),
        end: rangeEnd.toISOString().slice(0, 10),
    };
}

/**
 * CORE LOGIC: Standardized Payroll Calculation
 * 
 * DESIGN RATIONALE: To provide a consistent financial framework across different 
 * worker types. Standardizes the conversion from daily rates to hourly payouts.
 * 
 * BUSINESS RULES: 
 * 1. Hourly Rate: Derived from the Daily Rate based on a standard 8-hour shift.
 * 2. Overtime (OT): Calculated at a 1.5x multiplier of the base hourly rate.
 */
function calcPay(daily_rate, normal_hours, ot_hours) {
    const rate = Number(daily_rate || 0);
    const nH = Number(normal_hours || 0);
    const oH = Number(ot_hours || 0);

    // Baseline: Determine the value of one labor hour
    const hourRate = rate / 8 || 0;

    // Fixed Compensation: Payment for standard operational hours
    const base_pay = nH * hourRate;

    // Variable Compensation: Overtime calculated at 150% of the hourly rate
    const ot_pay = oH * hourRate * 1.5;

    // Reconciliation: Sum of fixed and variable components
    const total_pay = base_pay + ot_pay;

    return { base_pay, ot_pay, total_pay };
}

// GET payroll runs
router.get("/runs", async (req, res) => {
    try {
        const supabase = getSupabaseClient();

        const { data, error } = await supabase
            .from("payroll_runs")
            .select("*")
            .order("created_at", { ascending: false });

        if (error) return res.status(400).json({ error: error.message });
        res.json(data || []);
    } catch (e) {
        res.status(500).json({ error: e.message || "Server error" });
    }
});

// GET payroll items for a run
router.get("/runs/:id/items", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { id } = req.params;

        const { data, error } = await supabase
            .from("payroll_items")
            .select("*")
            .eq("payroll_run_id", id)
            .order("created_at", { ascending: true });

        if (error) return res.status(400).json({ error: error.message });
        res.json(data || []);
    } catch (e) {
        res.status(500).json({ error: e.message || "Server error" });
    }
});

// PUT finalize payroll run
router.put("/runs/:id/finalize", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { id } = req.params;

        const { data: run, error: runErr } = await supabase
            .from("payroll_runs")
            .select("*")
            .eq("id", id)
            .single();

        if (runErr) return res.status(400).json({ error: runErr.message });

        if (run.status === "finalized") {
            return res.status(400).json({ error: "Already finalized" });
        }

        const { data, error } = await supabase
            .from("payroll_runs")
            .update({ status: "finalized" })
            .eq("id", id)
            .select()
            .single();

        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message || "Server error" });
    }
});

// PDF export
router.get("/runs/:id/pdf", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { id } = req.params;

        const { data: run, error: runErr } = await supabase
            .from("payroll_runs")
            .select("*")
            .eq("id", id)
            .single();

        if (runErr) return res.status(400).json({ error: runErr.message });

        const { data: items, error: itemErr } = await supabase
            .from("payroll_items")
            .select("*")
            .eq("payroll_run_id", id)
            .order("created_at", { ascending: true });

        if (itemErr) return res.status(400).json({ error: itemErr.message });

        res.setHeader("Content-Type", "application/pdf");
        res.setHeader(
            "Content-Disposition",
            `inline; filename="payroll_${run.month || run.id}.pdf"`
        );

        const doc = new PDFDocument({ margin: 40, size: "A4" });
        doc.pipe(res);

        doc.fontSize(18).text("DU Homes - Payroll Report", { align: "center" });
        doc.moveDown(0.5);

        doc.fontSize(11).text(`Run ID: ${run.id}`);
        doc.text(`Month: ${run.month || "-"}`);
        doc.text(`Status: ${run.status || "-"}`);
        doc.text(`Created At: ${run.created_at || "-"}`);
        doc.moveDown(1);

        const startX = 40;
        let y = doc.y;
        const col = { worker: startX, basic: 240, ot: 320, ded: 390, net: 470 };

        doc.fontSize(11).text("Worker", col.worker, y);
        doc.text("Basic", col.basic, y);
        doc.text("OT", col.ot, y);
        doc.text("Ded", col.ded, y);
        doc.text("Net", col.net, y);
        y += 18;

        doc.moveTo(startX, y).lineTo(555, y).stroke();
        y += 8;

        let totalNet = 0;

        doc.fontSize(10);
        for (const it of items || []) {
            const name = it.workers?.full_name || it.worker_id;
            const basic = Number(it.basic_amount ?? it.base_pay ?? 0);
            const ot = Number(it.ot_amount ?? it.ot_pay ?? 0);
            const ded = Number(it.deductions ?? 0);
            const net = Number(it.net_total ?? it.total_pay ?? 0);

            totalNet += net;

            doc.text(String(name), col.worker, y, { width: 190 });
            doc.text(basic.toFixed(2), col.basic, y);
            doc.text(ot.toFixed(2), col.ot, y);
            doc.text(ded.toFixed(2), col.ded, y);
            doc.text(net.toFixed(2), col.net, y);
            y += 18;

            if (y > 760) {
                doc.addPage();
                y = 60;
            }
        }

        doc.moveDown(1);
        doc.fontSize(12).text(`Total Net: ${totalNet.toFixed(2)}`, { align: "right" });
        doc.end();
    } catch (e) {
        res.status(500).json({ error: e.message || "Server error" });
    }
});

// CSV export for payroll run
router.get("/runs/:id/csv", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { id } = req.params;

        const { data: run, error: runErr } = await supabase
            .from("payroll_runs")
            .select("*")
            .eq("id", id)
            .single();

        if (runErr) return res.status(400).json({ error: runErr.message });

        const { data: items, error: itemErr } = await supabase
            .from("payroll_items")
            .select("*")
            .eq("payroll_run_id", id)
            .order("created_at", { ascending: true });

        if (itemErr) return res.status(400).json({ error: itemErr.message });

        const lines = [];
        lines.push("Worker,Daily Rate,Basic Amount,OT Amount,Deductions,Net Total");

        let totalNet = 0;
        for (const it of items || []) {
            const name = (it.workers?.full_name || "Unknown").replace(/,/g, " ");
            const rate = Number(it.workers?.daily_rate || 0);
            const basic = Number(it.basic_amount || 0);
            const ot = Number(it.ot_amount || 0);
            const ded = Number(it.deductions || 0);
            const net = Number(it.net_total || 0);
            totalNet += net;
            lines.push(`${name},${rate.toFixed(2)},${basic.toFixed(2)},${ot.toFixed(2)},${ded.toFixed(2)},${net.toFixed(2)}`);
        }
        lines.push(`TOTAL,,,,,${totalNet.toFixed(2)}`);

        const csv = lines.join("\n");

        res.setHeader("Content-Type", "text/csv");
        res.setHeader("Content-Disposition", `attachment; filename="payroll_${run.month || run.id}.csv"`);
        res.send(csv);
    } catch (e) {
        res.status(500).json({ error: e.message || "Server error" });
    }
});

// DAILY salary sheet — FIXED: uses 'deployments' table instead of non-existent 'daily_deployments'
router.get("/daily", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { date } = req.query;

        if (!date) return res.status(400).json({ error: "date is required (YYYY-MM-DD)" });

        const { data: deployments, error: depErr } = await supabase
            .from("deployments")
            .select("id, date, site_id")
            .eq("date", date);

        if (depErr) return res.status(400).json({ error: depErr.message });

        if (!deployments?.length) {
            return res.json({ date, sites: [], grand_total: 0 });
        }

        const deploymentIds = deployments.map((d) => d.id);

        const [rowsRes, sitesRes, workersRes, deletedRes] = await Promise.all([
            supabase.from("deployment_workers").select("deployment_id, worker_id, status, normal_hours, ot_hours").in("deployment_id", deploymentIds),
            supabase.from("sites").select("id, name"),
            supabase.from("workers").select("id, full_name, daily_rate"),
            supabase.from("deleted_entities").select("entity_id, entity_type, entity_name")
        ]);

        if (rowsRes.error) return res.status(400).json({ error: rowsRes.error.message });

        const sitesMap = Object.fromEntries((sitesRes.data || []).map(s => [s.id, s]));
        const workersMap = Object.fromEntries((workersRes.data || []).map(w => [w.id, w]));
        const deletedMap = {};
        (deletedRes.data || []).forEach(d => {
            deletedMap[`${d.entity_type}:${d.entity_id}`] = d.entity_name;
        });

        const rows = rowsRes.data || [];

        const siteMap = {};

        for (const dep of deployments) {
            const siteInfo = sitesMap[siteId];
            const siteName = siteInfo?.name || deletedMap[`site:${siteId}`] || "Unknown Site";

            if (!siteMap[siteId]) {
                siteMap[siteId] = { site_id: siteId, site_name: siteName, workers: [], site_total: 0 };
            }

            const depWorkers = (rows || []).filter((r) => r.deployment_id === dep.id);

            for (const r of depWorkers) {
                if (String(r.status || "").toLowerCase() === "absent") continue;

                const workerInfo = workersMap[r.worker_id];
                const dailyRate = Number(workerInfo?.daily_rate || 0);
                const pay = calcPay(dailyRate, r.normal_hours, r.ot_hours);

                siteMap[siteId].workers.push({
                    worker_id: r.worker_id,
                    full_name: workerInfo?.full_name || deletedMap[`worker:${r.worker_id}`] || "Unknown Worker",
                    normal_hours: Number(r.normal_hours || 0),
                    ot_hours: Number(r.ot_hours || 0),
                    base_pay: pay.base_pay,
                    ot_pay: pay.ot_pay,
                    total_pay: pay.total_pay,
                });

                siteMap[siteId].site_total += pay.total_pay;
            }
        }

        const sites = Object.values(siteMap);
        const grand_total = sites.reduce((sum, s) => sum + Number(s.site_total || 0), 0);

        res.json({ date, sites, grand_total });
    } catch (e) {
        res.status(500).json({ error: e.message || "Server error" });
    }
});

// POST generate monthly payroll — FIXED: uses 'deployments' instead of 'daily_deployments'
router.post("/generate", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { month } = req.body;

        if (!month) return res.status(400).json({ error: "month is required (YYYY-MM-01)" });

        const range = monthRange(month);
        if (!range) return res.status(400).json({ error: "Invalid month format" });

        const { start, end } = range;

        const { data: deps, error: depErr } = await supabase
            .from("deployments")
            .select("id, date, site_id")
            .gte("date", start)
            .lte("date", end);

        if (depErr) return res.status(400).json({ error: depErr.message });

        const deploymentIds = (deps || []).map((d) => d.id);

        let rows = [];
        if (deploymentIds.length > 0) {
            const { data: rowsData, error: rowsErr } = await supabase
                .from("deployment_workers")
                .select("worker_id, status, normal_hours, ot_hours")
                .in("deployment_id", deploymentIds);

            if (rowsErr) return res.status(400).json({ error: rowsErr.message });
            rows = rowsData || [];
        }

        const summary = {};
        for (const r of rows) {
            if (String(r.status || "").toLowerCase() === "absent") continue;

            const wid = r.worker_id;
            if (!summary[wid]) {
                summary[wid] = {
                    worker_id: wid,
                    daily_rate: Number(r.workers?.daily_rate || 0),
                    normal_hours: 0,
                    ot_hours: 0,
                };
            }
            summary[wid].normal_hours += Number(r.normal_hours || 0);
            summary[wid].ot_hours += Number(r.ot_hours || 0);
        }

        const items = Object.values(summary).map((w) => {
            const pay = calcPay(w.daily_rate, w.normal_hours, w.ot_hours);
            return { ...w, ...pay };
        });

        const { data: existing, error: existingErr } = await supabase
            .from("payroll_runs")
            .select("*")
            .eq("month", month)
            .maybeSingle();

        if (existingErr) return res.status(400).json({ error: existingErr.message });

        let run = existing;

        if (!run) {
            const { data: runData, error: runErr } = await supabase
                .from("payroll_runs")
                .insert([{ month }])
                .select()
                .single();

            if (runErr) return res.status(400).json({ error: runErr.message });
            run = runData;
        } else {
            await supabase.from("payroll_items").delete().eq("payroll_run_id", run.id);
        }

        const insertItems = items.map((w) => {
            const deductions = 0;
            const net_total = Number(w.total_pay || 0) - deductions;

            return {
                payroll_run_id: run.id,
                worker_id: w.worker_id,
                basic_amount: Number(w.base_pay || 0),
                ot_amount: Number(w.ot_pay || 0),
                deductions,
                net_total,
                base_pay: Number(w.base_pay || 0),
                ot_pay: Number(w.ot_pay || 0),
                total_pay: Number(w.total_pay || 0),
            };
        });

        if (insertItems.length) {
            const { error: itemErr } = await supabase.from("payroll_items").insert(insertItems);
            if (itemErr) return res.status(400).json({ error: itemErr.message });
        }

        res.json({ ok: true, run_id: run.id, month, range: { start, end }, items_count: insertItems.length });
    } catch (e) {
        res.status(500).json({ error: e.message || "Server error" });
    }
});

// UPDATE a payroll item
router.put("/items/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { id } = req.params;
        const { basic_amount, ot_amount, deductions } = req.body;

        const basic = Number(basic_amount ?? 0);
        const ot = Number(ot_amount ?? 0);
        const ded = Number(deductions ?? 0);
        const net_total = basic + ot - ded;

        const { data, error } = await supabase
            .from("payroll_items")
            .update({
                basic_amount: basic,
                ot_amount: ot,
                deductions: ded,
                net_total,
                base_pay: basic,
                ot_pay: ot,
                total_pay: basic + ot,
            })
            .eq("id", id)
            .select("*")
            .single();

        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message || "Server error" });
    }
});

// DELETE a payroll item
router.delete("/items/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { id } = req.params;

        const { error } = await supabase
            .from("payroll_items")
            .delete()
            .eq("id", id);

        if (error) return res.status(400).json({ error: error.message });
        res.json({ ok: true, message: "Salary record deleted" });
    } catch (e) {
        res.status(500).json({ error: e.message || "Server error" });
    }
});

export default router;
