import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";
import { snapshotBeforeDelete } from "../utils/snapshotHelper.js";

const router = Router();

/* ═══════════════════════════════════════════════════
   REPORT route — MUST be BEFORE /:id
   ═══════════════════════════════════════════════════ */
router.get("/report", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { from, to, month } = req.query;

        // ── STEP 1: Fetch all necessary data separately to avoid join errors ──
        const [sitesRes, workersRes, deletedRes] = await Promise.all([
            supabase.from("sites").select("id, name, is_archived"),
            supabase.from("workers").select("id, full_name, worker_type, is_archived"),
            supabase.from("deleted_entities").select("entity_id, entity_type, entity_name")
        ]);

        const sitesMap = Object.fromEntries((sitesRes.data || []).map(s => [s.id, s]));
        const workersMap = Object.fromEntries((workersRes.data || []).map(w => [w.id, w]));
        
        // Build map for deleted entities to recover names
        const deletedMap = {};
        (deletedRes.data || []).forEach(d => {
            deletedMap[`${d.entity_type}:${d.entity_id}`] = d.entity_name;
        });

        // ── STEP 2: Fetch deployments with their worker links ──
        let query = supabase
            .from("deployments")
            .select("*, deployment_workers(*)")
            .order("date", { ascending: false });

        if (month) {
            const startDate = `${month}-01`;
            const [y, m] = month.split("-").map(Number);
            const endDate = new Date(y, m, 0).toISOString().slice(0, 10);
            query = query.gte("date", startDate).lte("date", endDate);
        } else {
            if (from) query = query.gte("date", from);
            if (to) query = query.lte("date", to);
        }

        const { data: deployments, error } = await query;
        if (error) return res.status(400).json({ error: error.message });

        // ── STEP 3: Combine data (Manual Join) ──
        const formattedDeployments = (deployments || []).map(dep => {
            const site = sitesMap[dep.site_id];
            return {
                id: dep.id,
                date: dep.date,
                notes: dep.notes,
                site_id: dep.site_id,
                site_name: site?.name || deletedMap[`site:${dep.site_id}`] || (dep.site_id ? `Unknown Site (${String(dep.site_id).slice(0, 8)})` : "Unknown Site"),
                site_archived: site?.is_archived || !!deletedMap[`site:${dep.site_id}`] || false,
                workers: (dep.deployment_workers || []).map(dw => {
                    const worker = workersMap[dw.worker_id];
                    const recoveredName = deletedMap[`worker:${dw.worker_id}`];
                    return {
                        ...dw,
                        worker_name: (worker?.full_name || recoveredName || "").trim() || (dw.worker_id ? `Unknown Worker (${String(dw.worker_id).slice(0, 8)})` : "Unknown Worker"),
                        worker_type: worker?.worker_type || "General",
                        is_archived: worker?.is_archived || !!recoveredName || false
                    };
                })
            };
        });

        // Calculate summary statistics
        const stats = {
            total_deployments: formattedDeployments.length,
            total_workers: 0,
            total_normal_hours: 0,
            total_ot_hours: 0,
            sites: [...new Set(formattedDeployments.map(d => d.site_id))]
        };

        formattedDeployments.forEach(dep => {
            dep.workers.forEach(w => {
                if (w.status === 'present') {
                    stats.total_workers++;
                    stats.total_normal_hours += parseFloat(w.normal_hours || 0);
                    stats.total_ot_hours += parseFloat(w.ot_hours || 0);
                }
            });
        });

        res.json({
            deployments: formattedDeployments,
            ...stats
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── GET / ── list all deployments ── */
router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        
        // 1. Fetch metadata for lookup
        const [sitesRes, workersRes, deletedRes] = await Promise.all([
            supabase.from("sites").select("id, name, is_archived"),
            supabase.from("workers").select("id, full_name, worker_type, is_archived"),
            supabase.from("deleted_entities").select("entity_id, entity_type, entity_name")
        ]);

        const sitesMap = Object.fromEntries((sitesRes.data || []).map(s => [s.id, s]));
        const workersMap = Object.fromEntries((workersRes.data || []).map(w => [w.id, w]));
        const deletedMap = {};
        (deletedRes.data || []).forEach(d => {
            deletedMap[`${d.entity_type}:${d.entity_id}`] = d.entity_name;
        });

        // 2. Fetch deployments
        let query = supabase
            .from("deployments")
            .select("*, deployment_workers(*)")
            .order("date", { ascending: false });

        const { date, site_id } = req.query;
        if (date) query = query.eq("date", date);
        if (site_id) query = query.eq("site_id", site_id);

        const { data: deployments, error } = await query;
        if (error) return res.status(400).json({ error: error.message });

        // 3. Map names for frontend ease
        const enriched = (deployments || []).map(dep => {
            const site = sitesMap[dep.site_id];
            return {
                ...dep,
                site_name: site?.name || deletedMap[`site:${dep.site_id}`] || "Unknown Site",
                site_archived: site?.is_archived || !!deletedMap[`site:${dep.site_id}`] || false,
                deployment_workers: (dep.deployment_workers || []).map(dw => {
                    const worker = workersMap[dw.worker_id];
                    const recoveredName = deletedMap[`worker:${dw.worker_id}`];
                    return {
                        ...dw,
                        worker_name: worker?.full_name || recoveredName || "Unknown Worker",
                        worker_type: worker?.worker_type || "General",
                        is_archived: worker?.is_archived || !!recoveredName || false
                    };
                })
            };
        });

        res.json(enriched);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── GET /:id ── single deployment ── */
router.get("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("deployments")
            .select("*, deployment_workers(*)")
            .eq("id", req.params.id)
            .single();
        if (error) return res.status(404).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── POST / ── create deployment ── */
router.post("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { site_id, date, notes } = req.body;
        if (!site_id || !date) return res.status(400).json({ error: "site_id and date are required" });

        // Validate: only one deployment per site per day
        const { data: existing } = await supabase
            .from("deployments")
            .select("id")
            .eq("site_id", site_id)
            .eq("date", date);
        if (existing && existing.length > 0) {
            return res.status(409).json({ error: "A deployment already exists for this site on this date. Each site can only have one deployment per day." });
        }

        const { data, error } = await supabase
            .from("deployments")
            .insert([{ site_id, date, notes: notes || "" }])
            .select("*, deployment_workers(*)")
            .single();

        if (error) return res.status(400).json({ error: error.message });
        res.status(201).json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── PUT /:id ── update deployment ── */
router.put("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { site_id, date, notes } = req.body;
        const payload = {};
        if (site_id !== undefined) payload.site_id = site_id;
        if (date !== undefined) payload.date = date;
        if (notes !== undefined) payload.notes = notes;

        const { data, error } = await supabase
            .from("deployments")
            .update(payload)
            .eq("id", req.params.id)
            .select("*, deployment_workers(*)")
            .single();

        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── DELETE /:id ── delete deployment ── */
router.delete("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data: dep } = await supabase.from("deployments").select("*").eq("id", req.params.id).single();
        if (dep) {
            await snapshotBeforeDelete(req.params.id, "deployment",
                `Deployment ${dep.date} @ ${dep.sites?.name || dep.site_id}`,
                { site_id: dep.site_id, date: dep.date, notes: dep.notes });
        }
        const { error } = await supabase.from("deployments").delete().eq("id", req.params.id);
        if (error) return res.status(400).json({ error: error.message });
        res.json({ message: "Deleted" });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* 
 * DATA CONSISTENCY: Automatic Attendance Synchronization
 * 
 * RATIONALE: To ensure transactional integrity between deployments and attendance.
 * When a worker's status is modified at the site level, this secondary process 
 * synchronizes the primary attendance ledger to prevent data discrepancies.
 * 
 * IMPLEMENTATION: Upserts record into the 'attendance' table based on 
 * unique constraint (worker_id, site_id, date).
 */
async function syncAttendance(supabase, deployment_id, worker_id, status, is_delete = false) {
    try {
        // Retrieve deployment metadata (context: site and date)
        const { data: dep } = await supabase
            .from("deployments")
            .select("site_id, date")
            .eq("id", deployment_id)
            .single();
        if (!dep) return;

        // Cleanup: Remove attendance record if worker is removed from deployment
        if (is_delete) {
            await supabase.from("attendance")
                .delete()
                .eq("worker_id", worker_id)
                .eq("date", dep.date);
            return;
        }

        // Status Normalization: Map deployment flags to attendance status
        let attStatus = "present";
        if (status === "absent") attStatus = "absent";

        // Persistence: Atomic upsert to ensure a single truth for daily attendance
        await supabase.from("attendance").upsert({
            worker_id,
            site_id: dep.site_id,
            date: dep.date,
            status: attStatus,
            deployment_id: deployment_id 
        }, { onConflict: "worker_id,site_id,date" });

    } catch (err) {
        console.error("[Sync:Attendance] Discrepancy error:", err);
    }
}

/* ── POST /:id/workers ── add worker to deployment ── */
router.post("/:id/workers", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const deployment_id = req.params.id;
        const { worker_id, status, task } = req.body;

        if (!worker_id) return res.status(400).json({ error: "worker_id is required" });

        // Check duplicate
        const { data: existing } = await supabase
            .from("deployment_workers")
            .select("id")
            .eq("deployment_id", deployment_id)
            .eq("worker_id", worker_id);

        if (existing && existing.length > 0)
            return res.status(400).json({ error: "Worker already added to this deployment" });

        const finalStatus = status || "present";
        const { data, error } = await supabase
            .from("deployment_workers")
            .insert([{
                deployment_id,
                worker_id,
                status: finalStatus,
                task: task || "",
            }])
            .select("*")
            .single();

        if (error) return res.status(400).json({ error: error.message });

        // Recommendation: Sync to attendance
        await syncAttendance(supabase, deployment_id, worker_id, finalStatus);

        res.status(201).json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── DELETE /:id/workers/:workerId ── remove worker ── */
router.delete("/:id/workers/:workerId", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { error } = await supabase
            .from("deployment_workers")
            .delete()
            .eq("deployment_id", req.params.id)
            .eq("worker_id", req.params.workerId);
        if (error) return res.status(400).json({ error: error.message });

        // Recommendation: Cleanup attendance
        await syncAttendance(supabase, req.params.id, req.params.workerId, null, true);

        res.json({ message: "Worker removed" });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── PUT /:id/workers/:workerId ── update worker status/task ── */
router.put("/:id/workers/:workerId", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { status, task } = req.body;
        const updates = {};
        if (status !== undefined) updates.status = status;
        if (task !== undefined) updates.task = task;

        const { data, error } = await supabase
            .from("deployment_workers")
            .update(updates)
            .eq("deployment_id", req.params.id)
            .eq("worker_id", req.params.workerId)
            .select("*")
            .single();

        if (error) return res.status(400).json({ error: error.message });

        // Recommendation: Sync to attendance if status changed
        if (status !== undefined) {
            await syncAttendance(supabase, req.params.id, req.params.workerId, status);
        }

        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

export default router;
