import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";
import { snapshotBeforeDelete } from "../utils/snapshotHelper.js";

const router = Router();

const today = () => new Date().toISOString().slice(0, 10);

// ── GET / ── 
// List all workers. Normalizes 'is_archived' boolean into a human-readable 'status' string.
router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        let query = supabase
            .from("workers")
            .select("*")
            .order("created_at", { ascending: false });

        // Only include archived workers if explicitly requested
        if (req.query.archived !== "true") {
            query = query.eq("is_archived", false);
        }

        const { data, error } = await query;
        if (error) return res.status(400).json({ error: error.message });

        const normalized = (data || []).map((w) => ({
            ...w,
            status: w.is_archived ? "archived" : "active",
        }));
        res.json(normalized);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ── GET /:id ── 
// Fetch details for a specific worker by ID.
router.get("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("workers")
            .select("*")
            .eq("id", req.params.id)
            .single();

        if (error) return res.status(404).json({ error: "Worker not found" });
        res.json({ ...data, status: data.is_archived ? "archived" : "active" });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ── POST / ── 
// Register a new worker in the system.
router.post("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { full_name, nic, phone, worker_type, daily_rate, emergency_contact, address } = req.body;

        if (!full_name) return res.status(400).json({ error: "full_name is required" });

        const payload = {
            full_name,
            nic: nic || null,
            phone: phone || null,
            worker_type: worker_type || null,
            daily_rate: Number(daily_rate) || 0,
            emergency_contact: emergency_contact || "",
            address: address || "",
            is_archived: false,
        };

        const { data, error } = await supabase
            .from("workers")
            .insert([payload])
            .select();

        if (error) return res.status(400).json({ error: error.message });
        const w = data[0];
        res.json({ ...w, status: "active" });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ── PUT /:id ── 
// Update profile information for an existing worker.
router.put("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { id } = req.params;
        const { full_name, nic, phone, worker_type, daily_rate, emergency_contact, address } = req.body;

        if (!full_name) return res.status(400).json({ error: "full_name is required" });

        const payload = {
            full_name,
            nic: nic || null,
            phone: phone || null,
            worker_type: worker_type || null,
            daily_rate: Number(daily_rate) || 0,
            emergency_contact: emergency_contact || "",
            address: address || "",
        };

        const { data, error } = await supabase
            .from("workers")
            .update(payload)
            .eq("id", id)
            .select();

        if (error) return res.status(400).json({ error: error.message });
        const w = data[0];
        res.json({ ...w, status: w.is_archived ? "archived" : "active" });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ── DELETE /:id ── 
// Securely remove or archive a worker.
// SAFETY CHECK: Prevents deletion if the worker has active or future deployments.
router.delete("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { id } = req.params;
        const todayDate = today();

        // ── STEP 1: Check for TODAY or FUTURE deployments ────────────────────
        // Get all deployment IDs this worker is part of
        const { data: workerDeployLinks } = await supabase
            .from("deployment_workers")
            .select("deployment_id")
            .eq("worker_id", id);

        const deploymentIds = (workerDeployLinks || []).map((d) => d.deployment_id);

        let futureDeployCount = 0;
        if (deploymentIds.length > 0) {
            const { count } = await supabase
                .from("deployments")
                .select("id", { count: "exact", head: true })
                .in("id", deploymentIds)
                .gte("date", todayDate); // today or future
            futureDeployCount = count || 0;
        }

        if (futureDeployCount > 0) {
            return res.status(409).json({
                error: "Cannot delete: worker is currently deployed",
                detail: `This worker is assigned to ${futureDeployCount} active or upcoming deployment(s). Remove them from those deployments first, then delete.`,
                reason: "active_deployment",
            });
        }

        // ── STEP 2: Snapshot to deleted_entities ─────────────────────────────
        const { data: worker, error: fetchErr } = await supabase.from("workers").select("*").eq("id", id).single();
        if (fetchErr || !worker) return res.status(404).json({ error: "Worker not found" });

        await snapshotBeforeDelete(id, "worker", worker.full_name || "Unknown Worker", {
            worker_type: worker.worker_type, daily_rate: worker.daily_rate, nic: worker.nic, phone: worker.phone, address: worker.address,
        });

        // ── STEP 3: Hard Delete (Instructor Requirement) ─────────────────────
        const { error } = await supabase.from("workers").delete().eq("id", id);
        if (error) return res.status(400).json({ error: error.message });

        return res.json({ ok: true, deleted: true, message: "Worker permanently deleted." });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

export default router;
