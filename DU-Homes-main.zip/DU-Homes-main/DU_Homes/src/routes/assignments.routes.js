import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";
import { snapshotBeforeDelete } from "../utils/snapshotHelper.js";

const router = Router();

router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("assignments")
            .select("*")
            .order("from_date", { ascending: false });
        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.get("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("assignments")
            .select("*")
            .eq("id", req.params.id)
            .single();
        if (error) return res.status(404).json({ error: "Assignment not found" });
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.post("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { site_id, officer_id, from_date, to_date } = req.body;
        if (!site_id || !officer_id) return res.status(400).json({ error: "Site and officer are required" });
        if (!from_date) return res.status(400).json({ error: "From date is required" });

        const payload = { site_id, officer_id, from_date };
        if (to_date) payload.to_date = to_date;

        // Validate: each site can only have one active officer
        const todayStr = new Date().toISOString().slice(0, 10);
        const { data: existing } = await supabase
            .from("assignments")
            .select("id, officer_id")
            .eq("site_id", site_id)
            .or(`to_date.is.null,to_date.gte.${todayStr}`);
        if (existing && existing.length > 0) {
            return res.status(409).json({ error: "This site already has an active officer assignment. Remove the existing assignment first." });
        }

        const { data, error } = await supabase
            .from("assignments")
            .insert(payload)
            .select("*")
            .single();
        if (error) return res.status(400).json({ error: error.message });
        res.status(201).json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.put("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { site_id, officer_id, from_date, to_date } = req.body;
        const updates = {};
        if (site_id) updates.site_id = site_id;
        if (officer_id) updates.officer_id = officer_id;
        if (from_date) updates.from_date = from_date;
        if (to_date !== undefined) updates.to_date = to_date || null;

        // Validate: if changing site, check the new site doesn't already have an active officer
        if (site_id) {
            const todayStr = new Date().toISOString().slice(0, 10);
            const { data: existing } = await supabase
                .from("assignments")
                .select("id")
                .eq("site_id", site_id)
                .neq("id", req.params.id)
                .or(`to_date.is.null,to_date.gte.${todayStr}`);
            if (existing && existing.length > 0) {
                return res.status(409).json({ error: "This site already has an active officer assignment." });
            }
        }

        const { data, error } = await supabase
            .from("assignments")
            .update(updates)
            .eq("id", req.params.id)
            .select("*")
            .single();
        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

router.delete("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data: rec } = await supabase
            .from("assignments")
            .select("*")
            .eq("id", req.params.id).single();
        if (rec) {
            const siteName = rec.sites?.name || rec.site_id;
            const officerName = rec.officers?.full_name || rec.officers?.name || rec.officer_id;
            await snapshotBeforeDelete(req.params.id, "assignment",
                `Assignment: ${officerName} @ ${siteName}`,
                { site_id: rec.site_id, officer_id: rec.officer_id, from_date: rec.from_date, to_date: rec.to_date });
        }
        const { error } = await supabase.from("assignments").delete().eq("id", req.params.id);
        if (error) return res.status(400).json({ error: error.message });
        res.json({ message: "Assignment deleted" });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

export default router;
