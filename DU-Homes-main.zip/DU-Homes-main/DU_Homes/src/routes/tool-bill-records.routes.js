import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";

const router = Router();

/* ══════════════════════════════════════════════════════════════
   POST /tool-bill-records — create a record WITH line items
   ══════════════════════════════════════════════════════════════ */
router.post("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const {
            bill_id, tool_id, custom_tool_name,
            bill_number, bill_date, vendor_name, vendor_contact,
            items = [],
            payment_amount = 0, payment_method = "Cash",
            reference_number, payment_date, payment_status = "Unpaid",
            remarks, entered_by,
        } = req.body;

        if (!bill_id) return res.status(400).json({ error: "bill_id is required" });

        // Tool selection: if both provided, prioritize tool_id
        let finalToolId = tool_id || null;
        let finalCustomName = custom_tool_name || null;
        if (finalToolId && finalCustomName) finalCustomName = null;

        // 1) Create the payment record
        const { data: record, error: recErr } = await supabase
            .from("tool_bill_records")
            .insert([{
                bill_id,
                tool_id: finalToolId,
                custom_tool_name: finalCustomName ? finalCustomName.trim() : null,
                item_name: (items[0]?.item_description || "").trim() || "Payment Record",
                quantity: items.length || 1,
                unit_price: 0,
                total_price: items.reduce((s, it) => s + ((parseInt(it.quantity) || 0) * (parseFloat(it.unit_price) || 0)), 0),
                bill_number: (bill_number || "").trim() || null,
                bill_date: bill_date || null,
                vendor_name: (vendor_name || "").trim() || null,
                vendor_contact: (vendor_contact || "").trim() || null,
                payment_amount: parseFloat(payment_amount) || 0,
                payment_method,
                reference_number: (reference_number || "").trim() || null,
                payment_date: payment_date || null,
                payment_status,
                remarks: (remarks || "").trim() || null,
                entered_by: entered_by || null,
            }])
            .select()
            .single();

        if (recErr) return res.status(400).json({ error: recErr.message });

        // 2) Create line items
        if (items.length > 0) {
            const itemRows = items
                .filter(it => (it.item_description || "").trim())
                .map(it => {
                    const qty = parseInt(it.quantity) || 1;
                    const price = parseFloat(it.unit_price) || 0;
                    return {
                        record_id: record.id,
                        item_description: it.item_description.trim(),
                        quantity: qty,
                        unit_price: price,
                        total_price: +(qty * price).toFixed(2),
                    };
                });

            if (itemRows.length > 0) {
                const { error: itemErr } = await supabase
                    .from("tool_bill_items")
                    .insert(itemRows);
                if (itemErr) console.error("Item insert error:", itemErr);
            }
        }

        // 3) Update bill status to "In Progress"
        await supabase
            .from("tool_bills")
            .update({ status: "In Progress", is_read: true, updated_at: new Date().toISOString() })
            .eq("id", bill_id)
            .in("status", ["Pending"]);

        // 4) Fetch back the full record with items
        const full = await fetchFullRecord(supabase, record.id);
        res.status(201).json(full);
    } catch (e) {
        console.error("Create bill record error:", e);
        res.status(500).json({ error: e.message });
    }
});

/* ══════════════════════════════════════════════════════════════
   GET /tool-bill-records — list records for a bill
   ══════════════════════════════════════════════════════════════ */
router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { bill_id } = req.query;

        let query = supabase
            .from("tool_bill_records")
            .select("*, tool_bill_items(*)")
            .order("created_at", { ascending: true });

        if (bill_id) query = query.eq("bill_id", bill_id);

        const { data, error } = await query;
        if (error) return res.status(400).json({ error: error.message });
        res.json(data || []);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ══════════════════════════════════════════════════════════════
   GET /tool-bill-records/summary?bill_id=x — count & total
   ══════════════════════════════════════════════════════════════ */
router.get("/summary", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { bill_id } = req.query;

        let query = supabase
            .from("tool_bill_records")
            .select("id, bill_id, payment_amount, custom_tool_name");

        if (bill_id) query = query.eq("bill_id", bill_id);

        const { data, error } = await query;
        if (error) return res.status(400).json({ error: error.message });

        // Group by bill_id
        const summaries = {};
        (data || []).forEach(r => {
            if (!summaries[r.bill_id]) summaries[r.bill_id] = { count: 0, total: 0, tNames: new Set() };
            summaries[r.bill_id].count++;
            summaries[r.bill_id].total += Number(r.payment_amount || 0);
            
            const tName = r.tools?.name || r.custom_tool_name;
            if (tName) summaries[r.bill_id].tNames.add(tName);
        });

        // Convert sets to array for JSON
        Object.keys(summaries).forEach(k => {
            summaries[k].tool_names = Array.from(summaries[k].tNames).join(", ");
            delete summaries[k].tNames;
        });

        res.json(summaries);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ══════════════════════════════════════════════════════════════
   GET /tool-bill-records/:id — single record with items
   ══════════════════════════════════════════════════════════════ */
router.get("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const full = await fetchFullRecord(supabase, req.params.id);
        if (!full) return res.status(404).json({ error: "Record not found" });
        res.json(full);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ══════════════════════════════════════════════════════════════
   PUT /tool-bill-records/:id — update record + replace items
   ══════════════════════════════════════════════════════════════ */
router.put("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const {
            tool_id, custom_tool_name,
            bill_number, bill_date, vendor_name, vendor_contact,
            items,
            payment_amount, payment_method,
            reference_number, payment_date, payment_status, remarks,
        } = req.body;

        const updates = { updated_at: new Date().toISOString() };

        // Tool selection
        if (tool_id !== undefined || custom_tool_name !== undefined) {
            let fTool = tool_id || null;
            let fCustom = custom_tool_name || null;
            if (fTool && fCustom) fCustom = null;
            updates.tool_id = fTool;
            updates.custom_tool_name = fCustom ? fCustom.trim() : null;
        }

        if (bill_number !== undefined) updates.bill_number = (bill_number || "").trim() || null;
        if (bill_date !== undefined) updates.bill_date = bill_date || null;
        if (vendor_name !== undefined) updates.vendor_name = (vendor_name || "").trim() || null;
        if (vendor_contact !== undefined) updates.vendor_contact = (vendor_contact || "").trim() || null;
        if (payment_amount !== undefined) updates.payment_amount = parseFloat(payment_amount) || 0;
        if (payment_method !== undefined) updates.payment_method = payment_method;
        if (reference_number !== undefined) updates.reference_number = (reference_number || "").trim() || null;
        if (payment_date !== undefined) updates.payment_date = payment_date || null;
        if (payment_status !== undefined) updates.payment_status = payment_status;
        if (remarks !== undefined) updates.remarks = (remarks || "").trim() || null;

        // Update items summary fields
        if (items && items.length > 0) {
            updates.item_name = (items[0]?.item_description || "").trim() || "Payment Record";
            updates.quantity = items.length;
            updates.total_price = items.reduce((s, it) => s + ((parseInt(it.quantity) || 0) * (parseFloat(it.unit_price) || 0)), 0);
        }

        const { error: updErr } = await supabase
            .from("tool_bill_records")
            .update(updates)
            .eq("id", req.params.id);

        if (updErr) return res.status(400).json({ error: updErr.message });

        // Replace items if provided
        if (items !== undefined) {
            // Delete old items
            await supabase.from("tool_bill_items").delete().eq("record_id", req.params.id);

            // Insert new items
            if (items.length > 0) {
                const itemRows = items
                    .filter(it => (it.item_description || "").trim())
                    .map(it => {
                        const qty = parseInt(it.quantity) || 1;
                        const price = parseFloat(it.unit_price) || 0;
                        return {
                            record_id: req.params.id,
                            item_description: it.item_description.trim(),
                            quantity: qty,
                            unit_price: price,
                            total_price: +(qty * price).toFixed(2),
                        };
                    });
                if (itemRows.length > 0) {
                    await supabase.from("tool_bill_items").insert(itemRows);
                }
            }
        }

        const full = await fetchFullRecord(supabase, req.params.id);
        res.json(full);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ══════════════════════════════════════════════════════════════
   DELETE /tool-bill-records/:id — delete record (items cascade)
   ══════════════════════════════════════════════════════════════ */
router.delete("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();

        // Get bill_id before delete
        const { data: record } = await supabase
            .from("tool_bill_records")
            .select("bill_id")
            .eq("id", req.params.id)
            .single();

        const { error } = await supabase
            .from("tool_bill_records")
            .delete()
            .eq("id", req.params.id);

        if (error) return res.status(400).json({ error: error.message });

        // If no more records, revert bill to Pending
        if (record?.bill_id) {
            const { count } = await supabase
                .from("tool_bill_records")
                .select("*", { count: "exact", head: true })
                .eq("bill_id", record.bill_id);

            if (count === 0) {
                await supabase
                    .from("tool_bills")
                    .update({ status: "Pending", updated_at: new Date().toISOString() })
                    .eq("id", record.bill_id);
            }
        }

        res.json({ message: "Record deleted" });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

/* ── helper: fetch full record with items ── */
async function fetchFullRecord(supabase, recordId) {
    const { data, error } = await supabase
        .from("tool_bill_records")
        .select("*, tool_bill_items(*)")
        .eq("id", recordId)
        .single();
    if (error) return null;
    return data;
}

export default router;
