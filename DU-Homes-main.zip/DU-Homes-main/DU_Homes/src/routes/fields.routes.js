// ============================================================================
// FEATURE: fields.routes.js — Sites/Fields API Routes
// Implemented by: IT24102845
// This route module provides full CRUD (Create, Read, Update, Delete) API
// endpoints for managing construction sites in the DU Homes system.
//
// FLOW: Available API endpoints:
//   1. GET    /fields      → List all active sites (pass ?archived=true for archived)
//   2. GET    /fields/:id  → Get a single site by ID
//   3. POST   /fields      → Create a new site
//   4. PUT    /fields/:id  → Update an existing site
//   5. DELETE /fields/:id  → Smart delete (archive or hard-delete)
//
// DB: All endpoints interact with the Supabase 'sites' table.
//   Table columns: id, name, address, nature_of_work, owner_name, owner_contact,
//                  is_archived, created_at
// ============================================================================

/* ── DU_Homes/src/routes/fields.routes.js ── */
import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";
import { snapshotBeforeDelete } from "../utils/snapshotHelper.js";

const router = Router();

const today = () => new Date().toISOString().slice(0, 10);

// ── GET / ── 
// List all construction sites. Supports filtering for archived sites.
router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        let query = supabase
            .from("sites")
            .select("*")
            .order("created_at", { ascending: false });

        // Only show archived sites if explicitly requested
        if (req.query.archived !== "true") {
            query = query.eq("is_archived", false);
        }

        const { data, error } = await query;
        if (error) return res.status(400).json({ error: error.message });
        res.json(data || []);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ── GET /:id ── 
// Retrieve a single site record by ID.
router.get("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data, error } = await supabase
            .from("sites")
            .select("*")
            .eq("id", req.params.id)
            .single();

        if (error) return res.status(404).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ── POST / ── 
// Create a new construction site.
router.post("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { name, address, nature_of_work, owner_name, owner_contact } = req.body;

        if (!name?.trim()) return res.status(400).json({ error: "name is required" });

        const { data, error } = await supabase
            .from("sites")
            .insert([{
                name: name.trim(),
                address: address || "",
                nature_of_work: nature_of_work || "",
                owner_name: owner_name || "",
                owner_contact: owner_contact || "",
                is_archived: false,
            }])
            .select()
            .single();

        if (error) return res.status(400).json({ error: error.message });
        res.status(201).json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ── PUT /:id ── 
// Update the information for an existing site.
router.put("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { name, address, nature_of_work, owner_name, owner_contact } = req.body;

        if (!name?.trim()) return res.status(400).json({ error: "name is required" });

        const { data, error } = await supabase
            .from("sites")
            .update({
                name: name.trim(),
                address: address || "",
                nature_of_work: nature_of_work || "",
                owner_name: owner_name || "",
                owner_contact: owner_contact || "",
            })
            .eq("id", req.params.id)
            .select()
            .single();

        if (error) return res.status(400).json({ error: error.message });
        res.json(data);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ── DELETE /:id ── 
// Securely remove or archive a site.
// SAFETY CHECK: Prevents deletion if the site has active or future deployments.
router.delete("/:id", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { id } = req.params;
        const todayDate = today();

        // ── STEP 1: Check for TODAY or FUTURE deployments ────────────────────
        const { count: futureDeployCount } = await supabase
            .from("deployments")
            .select("id", { count: "exact", head: true })
            .eq("site_id", id)
            .gte("date", todayDate);

        if ((futureDeployCount || 0) > 0) {
            return res.status(409).json({
                error: "Cannot delete: site has active or upcoming deployments",
                detail: `This site has ${futureDeployCount} active or upcoming deployment(s). Remove those deployments first, then delete the site.`,
                reason: "active_deployment",
            });
        }

        // ── STEP 2: Snapshot to deleted_entities ─────────────────────────────
        const { data: site, error: fetchErr } = await supabase.from("sites").select("*").eq("id", id).single();
        if (fetchErr || !site) return res.status(404).json({ error: "Site not found" });

        await snapshotBeforeDelete(id, "site", site.name || "Unknown Site", {
            address: site.address, owner_name: site.owner_name, owner_contact: site.owner_contact, nature_of_work: site.nature_of_work,
        });

        // ── STEP 3: Hard Delete (Instructor Requirement) ─────────────────────
        const { error } = await supabase.from("sites").delete().eq("id", id);
        if (error) return res.status(400).json({ error: error.message });

        return res.json({ ok: true, deleted: true, message: "Site permanently deleted." });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

export default router;
