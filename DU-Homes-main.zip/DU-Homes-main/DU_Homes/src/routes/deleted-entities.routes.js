import { Router } from "express";
import { getSupabaseClient } from "../supabaseClient.js";

const router = Router();

/**
 * GET /deleted-entities
 * Returns all deleted entity snapshots.
 * Filter by type: GET /deleted-entities?type=worker,site
 */
router.get("/", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        let query = supabase
            .from("deleted_entities")
            .select("*")
            .order("deleted_at", { ascending: false });

        if (req.query.type) {
            const types = req.query.type.split(",").map((t) => t.trim()).filter(Boolean);
            if (types.length > 0) query = query.in("entity_type", types);
        }

        const { data, error } = await query;
        if (error) return res.status(500).json({ error: error.message });
        res.json(data || []);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

export default router;
