import { Router } from "express";
import { getSupabaseClient, getEphemeralAuthClient } from "../supabaseClient.js";
import multer from "multer";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { writeAuditLog } from "./audit-logs.routes.js";

const router = Router();

//  multer: storage for profile pictures
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
    fileFilter: (req, file, cb) => {
        if (file.mimetype.startsWith("image/")) cb(null, true);
        else cb(new Error("Only images are allowed"), false);
    },
});

//  Backend Validation Helpers
const isValidEmail = (email) => /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email);
const isValidPhone = (phone) => !phone || /^[0-9]{10}$/.test(phone.replace(/[\s\-()]/g, ""));
const isValidPassword = (pw) => pw.length >= 8 && /[A-Z]/.test(pw) && /[a-z]/.test(pw) && /[0-9]/.test(pw);
const isValidName = (name) => name.trim().length >= 3 && !/[0-9]/.test(name);

// ============================================================================
// SYSTEM LOGIC: Registration & Login Logic
// GOAL: Securely manage users using Supabase Auth (for security) and
// 'profiles' table (for custom data like roles/phones).
// ============================================================================

// GOAL: Create a new user account
router.post("/register", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { email, password, full_name, phone } = req.body;

        // Step 1: Input Validation
        if (!email || !password) return res.status(400).json({ error: "Email and password are required" });
        if (!full_name || !full_name.trim()) return res.status(400).json({ error: "Full name is required" });

        // Step 2: Create User in Supabase Auth (Internal Database)
        // This handles password encryption and session management automatically.
        const { data: authData, error: authError } = await supabase.auth.admin.createUser({
            email: email.trim(),
            password,
            email_confirm: true,
            user_metadata: {
                full_name: full_name.trim(),
                phone: (phone || "").trim(),
                role: "site_officer",
            },
        });

        if (authError) return res.status(400).json({ error: authError.message });

        // Step 3: Mirror user data to our 'profiles' table
        // We do this so we can easily join user info with other tables like 'payments'.
        const { error: profileError } = await supabase.from("profiles").upsert({
            id: authData.user.id,
            email: email.trim(),
            full_name: full_name.trim(),
            phone: (phone || "").trim(),
            role: "site_officer",
        });

        // FIX: Previously profileError was silently ignored, leaving the user with no profile row.
        if (profileError) {
            console.error("Profile creation error:", profileError);
            // Attempt to clean up the auth user if profile creation fails
            await supabase.auth.admin.deleteUser(authData.user.id).catch(() => {});
            return res.status(500).json({ error: "Profile setup failed. Please try registering again." });
        }

        res.status(201).json({ message: "User created", user: authData.user });

        // Audit log: record registration event (fire and forget)
        writeAuditLog(getSupabaseClient(), {
            user_id: authData.user.id,
            user_email: email.trim(),
            action: "REGISTER",
            resource: "auth",
            ip_address: req.headers["x-forwarded-for"]?.split(",")[0] || req.ip || null,
            detail: { role: "site_officer" },
        }).catch(() => {});
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});


// GOAL: Refresh an expired access token using the refresh token
router.post("/refresh", async (req, res) => {
    try {
        const { refresh_token } = req.body;
        if (!refresh_token) {
            return res.status(400).json({ error: "refresh_token is required" });
        }

        const authClient = getEphemeralAuthClient();
        const { data, error } = await authClient.auth.refreshSession({ refresh_token });

        if (error || !data?.session) {
            return res.status(401).json({ error: "Session expired. Please log in again." });
        }

        // Return both new tokens so the frontend can update localStorage
        res.json({
            token: data.session.access_token,
            refresh_token: data.session.refresh_token,
        });
    } catch (e) {
        console.error("Token refresh error:", e.message);
        res.status(500).json({ error: e.message });
    }
});

// GOAL: Authenticate user and return a JWT Session Token
router.post("/login", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { email, password } = req.body;

        const authClient = getEphemeralAuthClient();

        // Step 1: Verify credentials via Ephemeral Supabase Auth Client
        const { data: authData, error: authError } = await authClient.auth.signInWithPassword({
            email: email.trim(),
            password,
        });

        if (authError) return res.status(401).json({ error: "Invalid email or password" });

        // Step 2: Fetch the user's role from the 'profiles' table
        // Roles control what the user can see/do in the frontend.
        const { data: profile } = await supabase
            .from("profiles").select("*").eq("id", authData.user.id).single();

        // Step 3: Return the Access Token (JWT) and Refresh Token
        // The frontend will send the access token in 'Authorization' for every request,
        // and use the refresh_token to silently renew it when it expires.
        res.json({
            token: authData.session.access_token,
            refresh_token: authData.session.refresh_token,
            user: { ...profile, email: email.trim() },
        });

        // Audit log: record login event (fire and forget)
        writeAuditLog(getSupabaseClient(), {
            user_id: authData.user.id,
            user_email: email.trim(),
            action: "LOGIN",
            resource: "auth",
            ip_address: req.headers["x-forwarded-for"]?.split(",")[0] || req.ip || null,
            detail: { role: profile?.role },
        }).catch(() => {});
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});


//  List All Users
router.get("/users", requireAuth, requireRole("admin"), async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { data: profiles, error: profileError } = await supabase
            .from("profiles").select("*").order("full_name");

        if (profileError) {
            console.error("Profiles fetch error:", profileError);
            const { data: authList, error: authError } = await supabase.auth.admin.listUsers();
            if (authError) return res.status(400).json({ error: authError.message });
            const users = (authList.users || []).map((u) => ({
                id: u.id, email: u.email,
                full_name: u.user_metadata?.full_name || "",
                phone: u.user_metadata?.phone || "",
                role: u.user_metadata?.role || "site_officer",
                created_at: u.created_at,
            }));
            return res.json(users);
        }
        res.json(profiles);
    } catch (e) {
        console.error("List users error:", e);
        res.status(500).json({ error: e.message });
    }
});

//  Update User Role
router.put("/users/:id/role", requireAuth, requireRole("admin"), async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const { role } = req.body;
        const userId = req.params.id;

        if (!role) return res.status(400).json({ error: "Role is required" });
        const validRoles = ["admin", "project_manager", "site_officer", "finance_officer", "company_owner"];
        if (!validRoles.includes(role)) {
            return res.status(400).json({ error: `Invalid role. Must be one of: ${validRoles.join(", ")}` });
        }

        console.log(`Updating role for user ${userId} to ${role}`);

        const { error: profileError } = await supabase.from("profiles").upsert({ id: userId, role: role });
        if (profileError) console.error("Profile update error:", profileError);

        const { error: authError } = await supabase.auth.admin.updateUserById(userId, {
            user_metadata: { role: role },
        });
        if (authError) {
            console.error("Auth metadata update error:", authError);
            return res.status(400).json({ error: authError.message });
        }

        res.json({ message: "Role updated", id: userId, role: role });
    } catch (e) {
        console.error("Role update error:", e);
        res.status(500).json({ error: e.message });
    }
});

//  Update Profile
router.put("/profile", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const token = req.headers.authorization?.replace("Bearer ", "");
        if (!token) return res.status(401).json({ error: "No token provided" });

        const { data: { user }, error: authErr } = await supabase.auth.getUser(token);
        if (authErr || !user) return res.status(401).json({ error: "Invalid or expired token" });

        const { full_name, phone } = req.body;

        if (!full_name || full_name.trim().length < 3) {
            return res.status(400).json({ error: "Full name must be at least 3 characters" });
        }
        if (/[0-9]/.test(full_name)) {
            return res.status(400).json({ error: "Full name should not contain numbers" });
        }
        if (phone && phone.trim() && !/^[0-9]{10}$/.test(phone.replace(/[\s\-()]/g, ""))) {
            return res.status(400).json({ error: "Invalid phone number format" });
        }

        const { error } = await supabase.from("profiles").upsert({
            id: user.id,
            full_name: full_name.trim(),
            phone: (phone || "").trim(),
        });
        if (error) return res.status(400).json({ error: error.message });

        await supabase.auth.admin.updateUserById(user.id, {
            user_metadata: { full_name: full_name.trim(), phone: (phone || "").trim() },
        });

        res.json({ message: "Profile updated", full_name: full_name.trim(), phone: (phone || "").trim() });
    } catch (e) {
        console.error("Profile update error:", e);
        res.status(500).json({ error: e.message });
    }
});

//  Upload Profile Picture
router.post("/profile-pic", upload.single("profile_pic"), async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const token = req.headers.authorization?.replace("Bearer ", "");
        if (!token) return res.status(401).json({ error: "No token provided" });

        const { data: { user }, error: authErr } = await supabase.auth.getUser(token);
        if (authErr || !user) return res.status(401).json({ error: "Invalid or expired token" });

        if (!req.file) return res.status(400).json({ error: "No image uploaded" });

        const ext = req.file.originalname.split(".").pop() || "png";
        const fileName = `${user.id}_${Date.now()}.${ext}`;
        const filePath = `${fileName}`; // In 'avatars' bucket

        // 1. Upload to Supabase Storage
        const { error: uploadError } = await supabase.storage
            .from("avatars")
            .upload(filePath, req.file.buffer, {
                contentType: req.file.mimetype,
                upsert: true,
            });

        if (uploadError) return res.status(500).json({ error: uploadError.message });

        // 2. Get Public URL
        const { data: urlData } = supabase.storage.from("avatars").getPublicUrl(filePath);
        const publicUrl = urlData.publicUrl;

        // 3. Update profiles table
        const { error: dbError } = await supabase.from("profiles").update({ avatar_url: publicUrl }).eq("id", user.id);
        if (dbError) console.error("DB update error:", dbError);

        // 4. Update user metadata
        await supabase.auth.admin.updateUserById(user.id, {
            user_metadata: { avatar_url: publicUrl },
        });

        res.json({ message: "Profile picture updated", avatar_url: publicUrl });
    } catch (e) {
        console.error("Profile pic upload error:", e);
        res.status(500).json({ error: e.message });
    }
});

//  Change Password
router.put("/change-password", async (req, res) => {
    try {
        const supabase = getSupabaseClient();
        const token = req.headers.authorization?.replace("Bearer ", "");
        if (!token) return res.status(401).json({ error: "No token provided" });

        const { data: { user }, error: authErr } = await supabase.auth.getUser(token);
        if (authErr || !user) return res.status(401).json({ error: "Invalid or expired token" });

        const { current_password, new_password } = req.body;

        if (!current_password || !new_password) {
            return res.status(400).json({ error: "Current and new password are required" });
        }
        if (!isValidPassword(new_password)) {
            return res.status(400).json({ error: "New password must be at least 8 characters with uppercase, lowercase, and a number" });
        }
        if (current_password === new_password) {
            return res.status(400).json({ error: "New password must be different from current password" });
        }

        const authClient = getEphemeralAuthClient();
        const { error: signInErr } = await authClient.auth.signInWithPassword({
            email: user.email,
            password: current_password,
        });
        if (signInErr) {
            return res.status(400).json({ error: "Current password is incorrect" });
        }

        const { error: updateErr } = await supabase.auth.admin.updateUserById(user.id, {
            password: new_password,
        });
        if (updateErr) return res.status(400).json({ error: updateErr.message });

        res.json({ message: "Password changed successfully" });
    } catch (e) {
        console.error("Change password error:", e);
        res.status(500).json({ error: e.message });
    }
});

export default router;
