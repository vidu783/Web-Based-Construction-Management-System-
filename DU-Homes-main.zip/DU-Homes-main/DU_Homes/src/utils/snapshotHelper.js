import { getSupabaseClient } from "../supabaseClient.js";

/**
 * TECHNICAL SPECIFICATION: The Entity Snapshot System
 * 
 * DESIGN RATIONALE: To maintain referential integrity in historical reports. 
 * When a worker or site is hard-deleted from the primary tables, their 
 * identity is preserved in this lookup table.
 * 
 * IMPLEMENTATION: Creates a serialized snapshot of the record state
 * prior to deletion, allowing resolvers to reconstruct display names 
 * for payroll and attendance logs.
 * 
 * @param {string} entity_id   - The primary key (UUID) of the record.
 * @param {string} entity_type - Discriminator for the entity (worker/site).
 * @param {string} entity_name - Human-readable identifier for reporting.
 * @param {object} entity_data - JSON payload containing auxiliary metadata.
 */
export async function snapshotBeforeDelete(entity_id, entity_type, entity_name, entity_data = {}) {
    try {
        const supabase = getSupabaseClient();
        
        // Persist the state to the 'deleted_entities' archival table.
        const { error } = await supabase.from("deleted_entities").insert({
            entity_id:   String(entity_id),
            entity_type: String(entity_type),
            entity_name: String(entity_name || "Unknown"),
            entity_data: entity_data || {},
        });

        // Fail-safe logging: Prevents deletion failure if snapshotting fails.
        if (error) {
            console.error(`[System:Snapshot] Failed for ${entity_type}:`, error.message);
        }
    } catch (e) {
        console.error(`[System:Snapshot] Internal Error:`, e.message);
    }
}
