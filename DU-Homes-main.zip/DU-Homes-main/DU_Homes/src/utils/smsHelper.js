
// Load the dotenv package so we can read values from the .env file
import dotenv from "dotenv";

// Actually read and apply the .env file values into process.env
dotenv.config();

/**
 * Helper function to send an SMS via the Text.lk API.
 * 
 * @param {string} phone   - The recipient's phone number (any common Sri Lanka format)
 * @param {string} message - The text message content to send
 * @returns {boolean}      - Returns true if SMS sent successfully, false otherwise
 */
export const sendSms = async (phone, message) => {
    try {
        // Read the Text.lk API key from the environment variables (.env file)
        const apiKey = process.env.TEXT_LK_API_KEY;

        // If no API key is found, skip sending and warn in the console
        if (!apiKey) {
            console.warn("SMS skipped: TEXT_LK_API_KEY is not defined in .env");
            return false; // Exit early, return false to signal failure
        }

        // Remove any extra spaces from the phone number
        let formattedPhone = phone.trim();

        // If the number starts with "0" (e.g. 071...), replace "0" with country code "94"
        if (formattedPhone.startsWith("0")) {
            formattedPhone = "94" + formattedPhone.substring(1); // e.g. "0712345678" → "94712345678"

        // If the number starts with "+94" (international format), remove the "+" sign
        } else if (formattedPhone.startsWith("+94")) {
            formattedPhone = formattedPhone.substring(1); // e.g. "+94712345678" → "94712345678"

        // If neither format matched, just prepend "94" as a fallback
        } else if (!formattedPhone.startsWith("94")) {
            formattedPhone = "94" + formattedPhone; // Fallback for unknown formats
        }

        // Build the data object (payload) that the Text.lk API expects
        const payload = {
            recipient: formattedPhone,                               // The formatted phone number
            sender_id: process.env.TEXT_LK_SENDER_ID || "Text.lk",  // Sender name shown on phone (from .env or default)
            type: "plain",                                           // Message type is plain text
            message: message                                         // The actual message text
        };

        // Send an HTTP POST request to the Text.lk API with the payload
        const response = await fetch("https://app.text.lk/api/v3/sms/send", {
            method: "POST",                          // Use POST method to send data
            headers: {
                "Authorization": `Bearer ${apiKey}`, // Authenticate with the API key
                "Content-Type": "application/json",  // Tell the API we're sending JSON
                "Accept": "application/json"          // Tell the API we expect JSON back
            },
            body: JSON.stringify(payload)            // Convert the payload object to a JSON string
        });

        // Parse the JSON response body returned by the API
        const result = await response.json();

        // If the HTTP response status is not OK (e.g. 400, 401, 500), log the error and return false
        if (!response.ok) {
            console.error("Text.lk API Error:", result);
            return false;
        }

        // If we reach here, the SMS was sent successfully — log a success message
        console.log(`SMS sent successfully to ${formattedPhone}`);
        return true; // Return true to signal success

    } catch (error) {
        // If any unexpected error occurred (e.g. network failure), log it and return false
        console.error("Failed to send SMS:", error.message);
        return false;
    }
};
