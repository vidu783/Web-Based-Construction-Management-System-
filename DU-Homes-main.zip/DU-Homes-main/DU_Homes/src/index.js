import express from "express";
import dotenv from "dotenv";

dotenv.config();

import cors from "cors";
import { requireAuth } from "./middleware/auth.js";

const app = express();
const PORT = process.env.PORT || 8080;

// Trust the first proxy (e.g. Render/Nginx) so req.ip returns the real client IP
app.set('trust proxy', 1);

// ════════════════════════════════════════════════════════
//  EXPLICIT CORS — allows all origins, all methods incl. PATCH
// ════════════════════════════════════════════════════════
const corsOptions = {
  origin: "*",
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
  credentials: false,
};
app.use(cors(corsOptions));
// Respond OK to all OPTIONS preflight requests immediately
app.options("*", cors(corsOptions));

app.use(express.json({ limit: "1mb" }));


if (process.env.NODE_ENV !== "production") {
  console.log("SUPABASE_URL:", process.env.SUPABASE_URL ? "loaded" : "MISSING");
  console.log("SUPABASE_SERVICE_KEY:", process.env.SUPABASE_SERVICE_KEY ? "loaded" : "MISSING");
  console.log("SUPABASE_ANON_KEY:", process.env.SUPABASE_ANON_KEY ? "loaded" : "MISSING");
}

// ---- request logger ----
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
  next();
});

// ---- import routes ----
import authRoutes from "./routes/auth.routes.js";
import fieldsRoutes from "./routes/fields.routes.js";
import workerRoutes from "./routes/workers.routes.js";
import deploymentRoutes from "./routes/deployments.routes.js";
import toolAllocationRoutes from "./routes/tool-allocations.routes.js";
import payrollRoutes from "./routes/payroll.routes.js";
import assignmentRoutes from "./routes/assignments.routes.js";
import attendanceRoutes from "./routes/attendance.routes.js";
import officerRoutes from "./routes/officers.routes.js";
import paymentRoutes from "./routes/payments.routes.js";
import toolsRoutes from "./routes/tools.routes.js";
import otRequestRoutes from "./routes/ot-requests.routes.js";
import aiRoutes from "./routes/ai.routes.js";
import toolBillRoutes from "./routes/tool-bills.routes.js";
import toolBillRecordRoutes from "./routes/tool-bill-records.routes.js";
import notificationsRoutes from "./routes/notifications.routes.js";
import auditLogsRoutes from "./routes/audit-logs.routes.js";
import deletedEntitiesRoutes from "./routes/deleted-entities.routes.js";

// ---- public routes ----
app.use("/auth", authRoutes);

// ---- data routes ----
app.use("/fields", requireAuth, fieldsRoutes);
app.use("/workers", requireAuth, workerRoutes);
app.use("/deployments", requireAuth, deploymentRoutes);
app.use("/tool-allocations", requireAuth, toolAllocationRoutes);
app.use("/payroll", requireAuth, payrollRoutes);
app.use("/assignments", requireAuth, assignmentRoutes);
app.use("/payments", requireAuth, paymentRoutes);
app.use("/officers", requireAuth, officerRoutes);
app.use("/attendance", requireAuth, attendanceRoutes);
app.use("/tools", requireAuth, toolsRoutes);
app.use("/ot-requests", requireAuth, otRequestRoutes);
app.use("/ai", requireAuth, aiRoutes);
app.use("/tool-bills", requireAuth, toolBillRoutes);
app.use("/tool-bill-payments", requireAuth, toolBillRecordRoutes);
app.use("/notifications", requireAuth, notificationsRoutes);
app.use("/audit-logs", requireAuth, auditLogsRoutes);
app.use("/deleted-entities", requireAuth, deletedEntitiesRoutes);

// ---- health check ----
app.get("/", (req, res) => {
  res.json({ message: "DU Homes API is running", timestamp: new Date().toISOString() });
});

// ---- 404 handler ----
app.use((req, res) => {
  console.warn(`[404] ${req.method} ${req.url} — route not found`);
  res.status(404).json({ error: `Route not found: ${req.method} ${req.url}` });
});

// ---- global error handler ----
app.use((err, req, res, next) => {
  console.error(`[ERROR] ${req.method} ${req.url}`, err.message);
  res.status(500).json({ error: "Internal server error", detail: err.message });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
