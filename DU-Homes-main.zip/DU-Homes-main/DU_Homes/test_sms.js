(async () => {
    try {
        const payload = {
            recipient: "94770000000",
            sender_id: "TextLKDemo",
            type: "plain",
            message: "Test from DU Homes backend"
        };
        const response = await fetch("https://app.text.lk/api/v3/sms/send", {
            method: "POST",
            headers: {
                "Authorization": "Bearer 4478|VXDgIUcQlbu9hwdALuQl6UDlWkHisuzkNBd26M6777e06375",
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            body: JSON.stringify(payload)
        });
        const text = await response.text();
        console.log("Status:", response.status);
        console.log("Response:", text);
    } catch (e) {
        console.error(e);
    }
})();
