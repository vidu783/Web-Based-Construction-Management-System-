import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
dotenv.config();

const supabaseUrl = process.env.SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_KEY;

if (!supabaseUrl || !serviceKey) {
  console.error("Missing SUPABASE_URL or SUPABASE_SERVICE_KEY in .env");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, serviceKey);

async function checkColumnExists() {
  const { data, error } = await supabase.from('profiles').select('avatar_url').limit(1);
  if (error) {
    if (error.code === '42703') { // undefined column
       console.log("Column 'avatar_url' does NOT exist.");
    } else {
       console.error("Error checking column:", error);
    }
  } else {
    console.log("Column 'avatar_url' exists.");
  }
}

checkColumnExists();
