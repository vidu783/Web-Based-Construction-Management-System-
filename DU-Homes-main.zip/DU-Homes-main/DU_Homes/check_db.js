import { createClient } from "@supabase/supabase-js";
import 'dotenv/config';

const supabase = createClient(
    process.env.SUPABASE_URL,
    process.env.SUPABASE_SERVICE_KEY
);

async function look() {
    const { data: profiles } = await supabase.from('profiles').select('id, full_name, role');
    console.log(profiles);
}

look();
