import dotenv from "dotenv";
dotenv.config();
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

const { error } = await supabase
  .from("notifications")
  .delete()
  .eq("type", "low_stock");

if (error) {
  console.error("❌ Error:", error.message);
} else {
  console.log("✅ All stale low_stock notifications deleted.");
}
process.exit(0);
