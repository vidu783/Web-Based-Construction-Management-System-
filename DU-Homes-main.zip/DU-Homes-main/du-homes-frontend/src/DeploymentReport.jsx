import { useState, useMemo } from "react";
import PrintHeader, { PrintButton, NoPrint } from "./PrintHeader";

// --- Professional SVG Icons (Replacing Emojis) ---
const IconCalendar = () => (
    <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
        <line x1="16" y1="2" x2="16" y2="6"></line>
        <line x1="8" y1="2" x2="8" y2="6"></line>
        <line x1="3" y1="10" x2="21" y2="10"></line>
    </svg>
);
const IconWorker = () => (
    <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
        <circle cx="9" cy="7" r="4"></circle>
        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
    </svg>
);
const IconSite = () => (
    <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path d="M3 21h18"></path>
        <path d="M5 21V7l8-4v18"></path>
        <path d="M13 7l8 4v10"></path>
        <path d="M9 17v1"></path>
        <path d="M9 13v1"></path>
        <path d="M17 17v1"></path>
        <path d="M17 13v1"></path>
    </svg>
);
const IconClock = () => (
    <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="10"></circle>
        <polyline points="12 6 12 12 16 14"></polyline>
    </svg>
);
const IconEnergy = () => (
    <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
    </svg>
);
const IconSearch = () => (
    <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <circle cx="11" cy="11" r="8"></circle>
        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
    </svg>
);
const IconWarning = () => (
    <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
        <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
        <line x1="12" y1="9" x2="12" y2="13"></line>
        <line x1="12" y1="17" x2="12.01" y2="17"></line>
    </svg>
);
const IconNotes = () => (
    <svg width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
        <polyline points="14 2 14 8 20 8"></polyline>
        <line x1="16" y1="13" x2="8" y2="13"></line>
        <line x1="16" y1="17" x2="8" y2="17"></line>
        <polyline points="10 9 9 9 8 9"></polyline>
    </svg>
);
const IconChart = () => (
    <svg width="48" height="48" fill="none" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24">
        <path d="M18 20V10"></path>
        <path d="M12 20V4"></path>
        <path d="M6 20v-6"></path>
    </svg>
);

const API = import.meta.env.VITE_API_URL || "http://localhost:8080";

/**
 * Enhanced Deployment Report
 * Features:
 * - Professional Print/PDF support
 * - Summary analytics with glassmorphism
 * - Real-time filtering by site/worker
 * - Toggle for archived (deleted) data
 * - Responsive, premium UI using CSS variables
 */
export default function DeploymentReport() {
    const [{ today, weekAgo }] = useState(() => {
        const t = new Date();
        return {
            today: t.toISOString().slice(0, 10),
            weekAgo: new Date(t.getTime() - 7 * 86400000).toISOString().slice(0, 10)
        };
    });

    const [from, setFrom] = useState(weekAgo);
    const [to, setTo] = useState(today);
    const [report, setReport] = useState(null);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [showArchived, setShowArchived] = useState(true);

    const generate = async () => {
        setError("");
        setLoading(true);
        try {
            const token = localStorage.getItem("access_token") || localStorage.getItem("token") || "";
            const r = await fetch(`${API}/deployments/report?from=${from}&to=${to}`, {
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                }
            });
            const d = await r.json();
            if (!r.ok) {
                if (r.status === 401) {
                    setError("Authentication required. Please log in again.");
                } else {
                    setError(d.error || "Failed to generate report");
                }
                setLoading(false);
                return;
            }
            setReport(d);
        } catch (err) {
            setError("Connection failed. Please check your internet.");
        }
        setLoading(false);
    };

    // Filtered data based on search term and archived status
    const filteredDeployments = useMemo(() => {
        if (!report?.deployments) return [];

        return report.deployments.filter(dep => {
            // Site filter
            const siteMatch = dep.site_name?.toLowerCase().includes(searchTerm.toLowerCase());

            // Worker filter (if any worker matches)
            const workerMatch = dep.workers?.some(w =>
                w.worker_name?.toLowerCase().includes(searchTerm.toLowerCase())
            );

            // Archived filter
            const isSiteArchived = dep.site_archived || !dep.site_name;
            if (!showArchived && isSiteArchived) return false;

            return siteMatch || workerMatch;
        }).map(dep => {
            // Further filter workers within the deployment
            const filteredWorkers = dep.workers?.filter(w => {
                const nameMatch = w.worker_name?.toLowerCase().includes(searchTerm.toLowerCase());
                const isWorkerArchived = w.is_archived || !w.worker_name;

                if (!showArchived && isWorkerArchived) return false;
                return searchTerm ? nameMatch : true;
            });

            return { ...dep, workers: filteredWorkers };
        }).filter(dep => dep.workers?.length > 0 || searchTerm === ""); // Keep if workers match or search is empty
    }, [report, searchTerm, showArchived]);

    // Summary calculation based on filtered view
    const filteredStats = useMemo(() => {
        if (!filteredDeployments.length) return null;

        let totalWorkers = 0;
        let totalNhrs = 0;
        let totalOthrs = 0;
        const uniqueSites = new Set();

        filteredDeployments.forEach(dep => {
            uniqueSites.add(dep.site_name || "Unknown");
            dep.workers?.forEach(w => {
                if (w.status === 'present') {
                    totalWorkers++;
                    totalNhrs += parseFloat(w.normal_hours || 0);
                    totalOthrs += parseFloat(w.ot_hours || 0);
                }
            });
        });

        return {
            count: filteredDeployments.length,
            workers: totalWorkers,
            nhrs: totalNhrs,
            othrs: totalOthrs,
            sites: uniqueSites.size
        };
    }, [filteredDeployments]);

    return (
        <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 20px 60px" }}>

            <PrintHeader
                title="Deployment Performance Report"
                subtitle={`Period: ${from} to ${to}`}
            />

            <NoPrint>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24, flexWrap: 'wrap', gap: 16 }}>
                    <div>
                        <h1 style={{ fontSize: 32, fontWeight: 900, color: 'var(--text-primary)', margin: 0, letterSpacing: '-0.5px' }}>
                            Deployments <span style={{ color: 'var(--primary)', fontWeight: 300 }}>Report</span>
                        </h1>
                        <p style={{ color: 'var(--text-muted)', fontSize: 14, marginTop: 4 }}>Analyze workforce efficiency and site coverage.</p>
                    </div>
                    <div style={{ display: 'flex', gap: 12 }}>
                        {report && <PrintButton />}
                    </div>
                </div>

                {/* Filter Controls */}
                <div style={{
                    background: 'var(--bg-surface)',
                    borderRadius: 16,
                    padding: 24,
                    marginBottom: 32,
                    border: '1px solid var(--border-subtle)',
                    boxShadow: 'var(--shadow-md)',
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                    gap: 20,
                    alignItems: 'end'
                }}>
                    <div>
                        <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', marginBottom: 8, textTransform: 'uppercase' }}>Date From</label>
                        <input type="date" value={from} onChange={e => setFrom(e.target.value)} className="modern-input" style={{ width: '100%', padding: '10px 14px', borderRadius: 8, border: '1px solid var(--border-medium)', background: 'var(--input-bg)', color: 'var(--input-text)' }} />
                    </div>
                    <div>
                        <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: 'var(--text-muted)', marginBottom: 8, textTransform: 'uppercase' }}>Date To</label>
                        <input type="date" value={to} onChange={e => setTo(e.target.value)} className="modern-input" style={{ width: '100%', padding: '10px 14px', borderRadius: 8, border: '1px solid var(--border-medium)', background: 'var(--input-bg)', color: 'var(--input-text)' }} />
                    </div>
                    <div style={{ display: 'flex', gap: 12 }}>
                        <button
                            onClick={generate}
                            disabled={loading}
                            style={{
                                flex: 1,
                                height: 44,
                                padding: "0 24px",
                                borderRadius: 10,
                                border: "none",
                                background: "var(--primary-gradient)",
                                color: "#fff",
                                fontSize: 14,
                                fontWeight: 700,
                                cursor: "pointer",
                                opacity: loading ? 0.7 : 1,
                                transition: 'transform 0.2s',
                                boxShadow: '0 4px 12px rgba(200, 16, 46, 0.3)'
                            }}
                        >
                            {loading ? "Fetching..." : "Generate Report"}
                        </button>
                    </div>
                </div>

                {report && (
                    <div style={{
                        display: 'flex',
                        gap: 12,
                        marginBottom: 24,
                        background: 'var(--bg-surface-elevated)',
                        padding: '12px 20px',
                        borderRadius: 12,
                        alignItems: 'center',
                        flexWrap: 'wrap'
                    }}>
                        <div style={{ position: 'relative', flex: 1, minWidth: 250 }}>
                            <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', opacity: 0.5, display: 'flex' }}><IconSearch /></span>
                            <input
                                type="text"
                                placeholder="Search site or worker name..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                style={{
                                    width: '100%',
                                    padding: '10px 14px 10px 40px',
                                    borderRadius: 10,
                                    border: '1px solid var(--border-medium)',
                                    background: 'var(--bg-body)',
                                    color: 'var(--text-primary)',
                                    fontSize: 14
                                }}
                            />
                        </div>
                        <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer', color: 'var(--text-secondary)' }}>
                            <input
                                type="checkbox"
                                checked={showArchived}
                                onChange={e => setShowArchived(e.target.checked)}
                                style={{ accentColor: 'var(--primary)' }}
                            />
                            Show Deleted Entities
                        </label>
                    </div>
                )}
            </NoPrint>

            {error && (
                <div style={{ background: 'var(--glass-rose)', border: '1px solid var(--error)', color: 'var(--error)', padding: '16px 20px', borderRadius: 12, marginBottom: 24, fontWeight: 600 }}>
                    <span style={{ display: 'inline-flex', marginRight: 8, verticalAlign: 'middle' }}><IconWarning /></span> {error}
                </div>
            )}

            {!report && !loading && (
                <div style={{ textAlign: 'center', padding: '100px 20px', background: 'var(--bg-surface)', borderRadius: 20, border: '1px dashed var(--border-medium)' }}>
                    <div style={{ color: 'var(--text-soft)', marginBottom: 16, display: 'flex', justifyContent: 'center' }}><IconChart /></div>
                    <h3 style={{ color: 'var(--text-secondary)', margin: 0 }}>No report generated yet</h3>
                    <p style={{ color: 'var(--text-muted)', fontSize: 14 }}>Select a date range and click "Generate Report" to see analytics.</p>
                </div>
            )}

            {report && (
                <>
                    {/* Summary Analytics Cards */}
                    <div style={{
                        display: "grid",
                        gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
                        gap: 16,
                        marginBottom: 32
                    }}>
                        <SummaryCard label="Total Deployments" value={filteredStats?.count || 0} icon={<IconCalendar />} gradient="var(--glass-blue)" color="#2563eb" />
                        <SummaryCard label="Workers Deployed" value={filteredStats?.workers || 0} icon={<IconWorker />} gradient="var(--glass-green)" color="#16a34a" />
                        <SummaryCard label="Sites Covered" value={filteredStats?.sites || 0} icon={<IconSite />} gradient="var(--glass-purple)" color="#7c3aed" />

                    </div>

                    {/* Report Data List */}
                    <div className="print-break-before">
                        {filteredDeployments.length === 0 ? (
                            <div style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>
                                No results match your search filters.
                            </div>
                        ) : (
                            filteredDeployments.map((dep, idx) => (
                                <DeploymentBlock key={idx} dep={dep} />
                            ))
                        )}
                    </div>

                    {/* Signatures for Print */}
                    <div className="print-only" style={{ marginTop: 60, display: 'flex', justifyContent: 'space-between' }}>
                        <div style={{ borderTop: '1px solid #333', width: 200, textAlign: 'center', paddingTop: 8 }}>
                            <div style={{ fontSize: 10, fontWeight: 700 }}>Prepared By</div>
                            <div style={{ fontSize: 8, color: '#666' }}>System Administrator</div>
                        </div>
                        <div style={{ borderTop: '1px solid #333', width: 200, textAlign: 'center', paddingTop: 8 }}>
                            <div style={{ fontSize: 10, fontWeight: 700 }}>Authorized Signature</div>
                            <div style={{ fontSize: 8, color: '#666' }}>Managing Director</div>
                        </div>
                    </div>
                </>
            )}
        </div>
    );
}

/**
 * Summary Card Component
 */
function SummaryCard({ label, value, icon, gradient, color }) {
    return (
        <div style={{
            background: gradient,
            borderRadius: 16,
            padding: '24px 20px',
            border: '1px solid var(--border-subtle)',
            boxShadow: 'var(--shadow-sm)',
            position: 'relative',
            overflow: 'hidden'
        }}>
            <div style={{ fontSize: 24, marginBottom: 12 }}>{icon}</div>
            <div style={{ fontSize: 11, fontWeight: 800, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>{label}</div>
            <div style={{ fontSize: 32, fontWeight: 900, color: color, marginTop: 4 }}>{value}</div>
            <div style={{ position: 'absolute', right: -10, bottom: -10, fontSize: 60, opacity: 0.05 }}>{icon}</div>
        </div>
    );
}

/**
 * Deployment Block Component
 */
function DeploymentBlock({ dep }) {
    return (
        <div style={{
            background: 'var(--bg-surface)',
            borderRadius: 16,
            padding: 24,
            marginBottom: 20,
            border: '1px solid var(--border-subtle)',
            boxShadow: 'var(--shadow-sm)',
            breakInside: 'avoid'
        }}>
            <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginBottom: 16,
                paddingBottom: 12,
                borderBottom: '1px solid var(--border-subtle)'
            }}>
                <div>
                    <h4 style={{ margin: 0, fontSize: 18, fontWeight: 800, color: 'var(--text-primary)' }}>
                        {dep.site_name ? (
                            <>
                                {dep.site_name}
                                {dep.site_archived && <span className="archived-badge">Deleted Site</span>}
                            </>
                        ) : (
                            <span style={{ color: 'var(--text-muted)' }}>[Unknown Site] <span className="archived-badge">Deleted</span></span>
                        )}
                    </h4>
                    <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4, display: 'flex', alignItems: 'center', gap: 10 }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><IconCalendar /> {dep.date}</span>
                        {dep.notes && <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>• <IconNotes /> {dep.notes}</span>}
                    </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-soft)' }}>TOTAL WORKERS</div>
                    <div style={{ fontSize: 20, fontWeight: 900, color: 'var(--primary)' }}>{dep.workers?.length || 0}</div>
                </div>
            </div>

            {dep.workers?.length > 0 ? (
                <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                        <thead>
                            <tr style={{ background: 'var(--table-header-bg)' }}>
                                <th style={thStyle}>Worker Name</th>
                                <th style={thStyle}>Type</th>
                                <th style={thStyle}>Hours</th>
                                <th style={thStyle}>Task Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            {dep.workers.map((w, idx) => {
                                const isPresent = w.status === 'present';
                                return (
                                    <tr key={idx} style={{ borderBottom: '1px solid var(--border-subtle)' }}>
                                        <td style={{ ...tdStyle, fontWeight: 700, color: 'var(--text-primary)' }}>
                                            {w.worker_name && !w.worker_name.startsWith("Unknown") ? (
                                                <span style={{ display: 'inline-flex', alignItems: 'center' }}>
                                                    {w.worker_name}
                                                    {w.is_archived && <span className="archived-badge">Deleted</span>}
                                                </span>
                                            ) : (
                                                <span style={{ color: 'var(--text-muted)', display: 'inline-flex', alignItems: 'center' }}>
                                                    {w.worker_name || "Unknown Worker"}
                                                    {" "}<span className="archived-badge">Deleted</span>
                                                </span>
                                            )}
                                        </td>
                                        <td style={tdStyle}>{w.worker_type || "-"}</td>
                                        <td style={{ ...tdStyle, color: isPresent ? 'var(--text-primary)' : 'var(--text-soft)' }}>{w.normal_hours || 0}</td>
                                        <td style={{ ...tdStyle, color: 'var(--text-secondary)', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={w.task_description}>
                                            {w.task_description || "-"}
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            ) : (
                <div style={{ fontSize: 13, fontStyle: 'italic', color: 'var(--text-soft)', padding: '10px 0' }}>
                    No workers assigned for this deployment.
                </div>
            )}
        </div>
    );
}

/**
 * Status Badge Component
 */
function StatusBadge({ status }) {
    let colors = { bg: 'var(--bg-body)', text: 'var(--text-muted)' };

    if (status === 'present') colors = { bg: '#dcfce7', text: '#166534', border: '#bbf7d0' };
    else if (status === 'absent') colors = { bg: '#fee2e2', text: '#991b1b', border: '#fecaca' };
    else if (status === 'half-day') colors = { bg: '#fef3c7', text: '#92400e', border: '#fde68a' };

    return (
        <span style={{
            padding: "4px 10px",
            borderRadius: 20,
            fontSize: 10,
            fontWeight: 800,
            background: colors.bg,
            color: colors.text,
            border: `1px solid ${colors.border || 'transparent'}`,
            textTransform: 'uppercase',
            letterSpacing: '0.3px'
        }}>
            {status}
        </span>
    );
}

const thStyle = {
    padding: "14px 14px",
    textAlign: "left",
    color: "var(--text-secondary)",
    fontSize: 12,
    fontWeight: 800,
    textTransform: "uppercase",
    letterSpacing: '0.8px',
    borderBottom: '2px solid var(--border-subtle)'
};

const tdStyle = {
    padding: "16px 14px",
    color: "var(--text-primary)",
    verticalAlign: 'middle',
    fontSize: 14
};
