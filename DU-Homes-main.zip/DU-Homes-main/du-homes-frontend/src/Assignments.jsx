import { useState, useEffect, useCallback, useMemo } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8080";
const hdr = () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("access_token") || localStorage.getItem("token") || ""}`,
});

export default function Assignments() {
    const today = new Date().toISOString().slice(0, 10);

    const [officers, setOfficers] = useState([]);
    const [users, setUsers] = useState([]);
    const [sites, setSites] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [msg, setMsg] = useState({ text: "", type: "" });
    const [search, setSearch] = useState("");

    // Form
    const [showForm, setShowForm] = useState(false);
    const [editId, setEditId] = useState(null);
    const [form, setForm] = useState({ officer_id: "", site_id: "", from_date: today, to_date: "" });

    const flash = (text, type = "ok") => {
        setMsg({ text, type });
        setTimeout(() => setMsg({ text: "", type: "" }), 5000);
    };

    /* ═══════════════════ FETCHERS ═══════════════════ */
    const fetchOfficers = useCallback(async () => {
        try {
            const r = await fetch(`${API}/officers`, { headers: hdr() });
            if (r.ok) {
                const data = await r.json();
                setOfficers(Array.isArray(data) ? data : []);
                return Array.isArray(data) ? data : [];
            }
        } catch (e) { console.error(e); }
        return [];
    }, []);

    const fetchUsers = useCallback(async () => {
        try {
            const r = await fetch(`${API}/auth/users`, { headers: hdr() });
            if (r.ok) {
                const data = await r.json();
                setUsers(Array.isArray(data) ? data : []);
            }
        } catch (e) { console.error(e); }
    }, []);

    const fetchSites = useCallback(async () => {
        try {
            const r = await fetch(`${API}/fields`, { headers: hdr() });
            if (r.ok) setSites(await r.json());
        } catch (e) { console.error(e); }
    }, []);

    const fetchAssignments = useCallback(async () => {
        try {
            const r = await fetch(`${API}/assignments`, { headers: hdr() });
            if (r.ok) setAssignments(await r.json());
        } catch (e) { console.error(e); }
    }, []);

    const loadAll = useCallback(async () => {
        setLoading(true);
        await Promise.all([fetchOfficers(), fetchUsers(), fetchSites(), fetchAssignments()]);
        setLoading(false);
    }, [fetchOfficers, fetchUsers, fetchSites, fetchAssignments]);

    useEffect(() => {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        loadAll();
    }, [loadAll]);

    /* ═══════════════════ DERIVED DATA ═══════════════════ */
    const siteOfficerUsers = useMemo(() => users.filter((u) => u.role === "site_officer"), [users]);

    const linkedUserIds = useMemo(() => officers.filter((o) => o.user_id).map((o) => o.user_id), [officers]);

    const unlinkedSiteOfficers = useMemo(
        () => siteOfficerUsers.filter((u) => !linkedUserIds.includes(u.id)),
        [siteOfficerUsers, linkedUserIds]
    );

    const activeAssignments = useMemo(
        () => assignments.filter((a) => !a.to_date || a.to_date >= today),
        [assignments, today]
    );

    const expiredAssignments = useMemo(
        () => assignments.filter((a) => a.to_date && a.to_date < today),
        [assignments, today]
    );

    const getOfficerName = (id) => officers.find((x) => x.id === id)?.full_name || "Unknown";

    const getOfficerEmail = (id) => {
        const o = officers.find((x) => x.id === id);
        if (!o) return "";
        if (o.user_id) {
            const u = users.find((x) => x.id === o.user_id);
            if (u?.email) return u.email;
        }
        return o.email || "";
    };

    const getSiteName = (id) => sites.find((s) => s.id === id)?.name || "Unknown";

    const unassignedSites = useMemo(() => {
        const assignedIds = activeAssignments.map((a) => a.site_id);
        return sites.filter((s) => !assignedIds.includes(s.id));
    }, [sites, activeAssignments]);

    const stats = useMemo(() => ({
        totalAssignments: activeAssignments.length,
        activeSites: [...new Set(activeAssignments.map((a) => a.site_id))].length,
        officersAssigned: [...new Set(activeAssignments.map((a) => a.officer_id))].length,
        totalOfficers: officers.length,
    }), [activeAssignments, officers]);

    const filteredAssignments = useMemo(() => {
        if (!search.trim()) return activeAssignments;
        const q = search.toLowerCase();
        return activeAssignments.filter((a) => {
            const officerName = officers.find((x) => x.id === a.officer_id)?.full_name || "Unknown";
            const siteName = sites.find((s) => s.id === a.site_id)?.name || "Unknown";
            return officerName.toLowerCase().includes(q) || siteName.toLowerCase().includes(q);
        });
    }, [activeAssignments, search, officers, sites]);

    /* ═══════════════════ ADD OFFICERS FROM USERS ═══════════════════ */
    const addOfficerFromUser = async (user) => {
        try {
            const r = await fetch(`${API}/officers`, {
                method: "POST",
                headers: hdr(),
                body: JSON.stringify({
                    full_name: user.full_name || user.email?.split("@")[0] || "Officer",
                    phone: user.phone || "",
                    email: user.email || "",
                    role: "site_officer",
                    nic: "",
                    user_id: user.id,
                }),
            });
            if (!r.ok) {
                const err = await r.json();
                flash(`Failed: ${err.error}`, "err");
                return false;
            }
            return true;
        } catch (e) {
            flash(e.message, "err");
            return false;
        }
    };

    const handleAddSingle = async (user) => {
        const hadNoOfficers = officers.length === 0;
        const ok = await addOfficerFromUser(user);
        if (ok) {
            const updated = await fetchOfficers();
            flash(`${user.full_name || user.email} added as officer`);
            // Auto-open form if we just got our first officer
            if (hadNoOfficers && updated.length > 0) {
                setShowForm(true);
                setForm({ officer_id: updated[0].id, site_id: "", from_date: today, to_date: "" });
            }
        }
    };

    const handleAddAll = async () => {
        if (unlinkedSiteOfficers.length === 0) return;
        const hadNoOfficers = officers.length === 0;
        let added = 0;
        for (const u of unlinkedSiteOfficers) {
            const ok = await addOfficerFromUser(u);
            if (ok) added++;
        }
        const updated = await fetchOfficers();
        flash(`${added} officer${added !== 1 ? "s" : ""} added`);
        if (hadNoOfficers && updated.length > 0) {
            setShowForm(true);
        }
    };

    /* ═══════════════════ ASSIGNMENT CRUD ═══════════════════ */
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!form.officer_id || !form.site_id) return flash("Select both officer and site", "err");

        // Validate: each site can only have one active officer
        const existingForSite = activeAssignments.find((a) => a.site_id === form.site_id && a.id !== editId);
        if (existingForSite) {
            return flash(`This site already has an assigned officer (${getOfficerName(existingForSite.officer_id)}). Remove the current assignment first, or choose a different site.`, "err");
        }

        // Validate: dates
        if (form.to_date && form.from_date && form.to_date < form.from_date) {
            return flash("To Date cannot be before From Date", "err");
        }

        try {
            const url = editId ? `${API}/assignments/${editId}` : `${API}/assignments`;
            const method = editId ? "PUT" : "POST";
            const r = await fetch(url, {
                method,
                headers: hdr(),
                body: JSON.stringify({
                    officer_id: form.officer_id,
                    site_id: form.site_id,
                    from_date: form.from_date || today,
                    to_date: form.to_date || null,
                }),
            });
            if (!r.ok) {
                const err = await r.json();
                return flash(err.error || "Failed to save", "err");
            }
            flash(editId ? "Assignment updated" : "Officer assigned to site successfully");
            resetForm();
            fetchAssignments();
        } catch (e) {
            flash(e.message, "err");
        }
    };

    const handleEdit = (a) => {
        setForm({
            officer_id: a.officer_id,
            site_id: a.site_id,
            from_date: a.from_date || today,
            to_date: a.to_date || "",
        });
        setEditId(a.id);
        setShowForm(true);
    };

    const handleDelete = async (id) => {
        if (!confirm("Remove this assignment?")) return;
        try {
            await fetch(`${API}/assignments/${id}`, { method: "DELETE", headers: hdr() });
            flash("Assignment removed");
            fetchAssignments();
        } catch (e) {
            flash(e.message, "err");
        }
    };

    const resetForm = () => {
        setShowForm(false);
        setEditId(null);
        setForm({ officer_id: "", site_id: "", from_date: today, to_date: "" });
    };

    /* ═══════════════════ STYLES ═══════════════════ */
    const glassCard = {
        background: "var(--bg-surface)",
        borderRadius: 14,
        padding: 16,
        textAlign: "center",
        border: "1px solid var(--border-subtle)",
        boxShadow: "var(--shadow-sm)",
        flex: "1 1 140px",
        minWidth: 130,
        color: "var(--text-primary)",
    };
    const card = {
        background: "var(--bg-surface)",
        borderRadius: 14,
        padding: 24,
        border: "1px solid var(--border-subtle)",
        boxShadow: "var(--shadow-sm)",
        marginBottom: 24,
        color: "var(--text-primary)",
    };
    const inp = {
        width: "100%",
        padding: "9px 14px",
        border: "1px solid var(--input-border)",
        background: "var(--input-bg)",
        color: "var(--input-text)",
        borderRadius: 10,
        fontSize: 13,
        outline: "none",
        boxSizing: "border-box",
    };
    const btnPrimary = {
        background: "linear-gradient(135deg, #C8102E, #e8334a)",
        color: "#fff",
        border: "none",
        padding: "9px 22px",
        borderRadius: 10,
        fontSize: 13,
        fontWeight: 600,
        cursor: "pointer",
        boxShadow: "0 2px 8px rgba(200,16,46,0.25)",
    };
    const btnSecondary = {
        background: "#f1f5f9",
        color: "#334155",
        border: "1px solid #e2e8f0",
        padding: "8px 16px",
        borderRadius: 10,
        fontSize: 13,
        cursor: "pointer",
        fontWeight: 500,
    };
    const btnDanger = {
        background: "var(--glass-rose)",
        color: "#dc2626",
        border: "none",
        borderRadius: 8,
        padding: "6px 14px",
        cursor: "pointer",
        fontSize: 12,
        fontWeight: 500,
    };
    const btnGhost = {
        background: "var(--bg-body)",
        color: "var(--text-soft)",
        border: "1px solid var(--border-subtle)",
        borderRadius: 8,
        padding: "6px 14px",
        cursor: "pointer",
        fontSize: 12,
        fontWeight: 500,
    };
    const thStyle = {
        padding: "12px 16px",
        textAlign: "left",
        fontSize: 12,
        fontWeight: 600,
        color: "var(--text-soft)",
        textTransform: "uppercase",
        letterSpacing: 0.5,
        borderBottom: "2px solid var(--border-subtle)",
        background: "var(--table-header-bg)",
    };
    const tdStyle = {
        padding: "12px 14px",
        fontSize: 13,
        borderBottom: "1px solid var(--border-subtle)",
        color: "var(--text-primary)",
    };

    /* ═══════════════════ LOADING ═══════════════════ */
    if (loading && officers.length === 0 && users.length === 0) {
        return (
            <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", height: 400, gap: 16 }}>
                <div style={{ width: 44, height: 44, border: "4px solid var(--border-subtle)", borderTopColor: "var(--brand-primary)", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
                <span style={{ fontSize: 14, color: "var(--text-soft)" }}>Loading assignments...</span>
                <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
            </div>
        );
    }

    return (
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
            {/* Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20, flexWrap: "wrap", gap: 12 }}>
                <div>
                    <h2 style={{ fontSize: 22, fontWeight: 800, margin: 0, color: "var(--text-primary)" }}>Officer Assignments</h2>
                    <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--text-soft)" }}>
                        Assign site officers to construction sites
                    </p>
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                    <button style={btnSecondary} onClick={loadAll}>Refresh</button>
                    <button
                        style={btnPrimary}
                        onClick={() => {
                            setShowForm(!showForm);
                            setEditId(null);
                            setForm({ officer_id: "", site_id: "", from_date: today, to_date: "" });
                        }}
                    >
                        {showForm ? "Cancel" : "+ New Assignment"}
                    </button>
                </div>
            </div>

            {/* Flash */}
            {msg.text && (
                <div style={{
                    padding: "10px 16px", marginBottom: 14, borderRadius: 10, fontSize: 13, fontWeight: 500,
                    background: msg.type === "err" ? "var(--glass-rose)" : "var(--glass-green)",
                    color: msg.type === "err" ? "#dc2626" : "#166534",
                    border: `1px solid ${msg.type === "err" ? "#dc262633" : "#16653433"}`,
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                }}>
                    {msg.text}
                    <button onClick={() => setMsg({ text: "", type: "" })} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 16, color: "inherit" }}>×</button>
                </div>
            )}

            {/* Unlinked site officers banner */}
            {unlinkedSiteOfficers.length > 0 && (
                <div style={{
                    padding: "14px 18px", marginBottom: 16, borderRadius: 12, fontSize: 13,
                    background: "var(--glass-yellow, rgba(254,243,199,0.2))",
                    border: "1px solid var(--border-subtle)", color: "var(--text-primary)",
                }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 10 }}>
                        <div>
                            <strong style={{ color: "var(--brand-primary)" }}>{unlinkedSiteOfficers.length} site officer{unlinkedSiteOfficers.length > 1 ? "s" : ""}</strong> from
                            User Management not yet added:
                            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 8 }}>
                                {unlinkedSiteOfficers.map((u) => (
                                    <div key={u.id} style={{
                                        display: "flex", alignItems: "center", gap: 6, padding: "4px 10px 4px 4px",
                                        borderRadius: 8, background: "var(--bg-surface)", border: "1px solid var(--border-subtle)",
                                    }}>
                                        <div style={{
                                            width: 26, height: 26, borderRadius: 6,
                                            background: "var(--brand-primary)",
                                            display: "flex", alignItems: "center", justifyContent: "center",
                                            fontSize: 11, fontWeight: 700, color: "#fff",
                                        }}>
                                            {(u.full_name || u.email || "?")[0].toUpperCase()}
                                        </div>
                                        <div>
                                            <div style={{ fontSize: 12, fontWeight: 600, color: "var(--text-primary)" }}>{u.full_name || "Unnamed"}</div>
                                            <div style={{ fontSize: 10, color: "var(--text-soft)" }}>{u.email}</div>
                                        </div>
                                        <button
                                            style={{
                                                background: "var(--bg-body)", border: "1px solid var(--border-subtle)", borderRadius: 6,
                                                padding: "2px 8px", fontSize: 11, fontWeight: 600, color: "var(--text-primary)",
                                                cursor: "pointer", marginLeft: 4,
                                            }}
                                            onClick={() => handleAddSingle(u)}
                                        >
                                            Add
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <button
                            style={{ ...btnPrimary, padding: "8px 18px", fontSize: 12, flexShrink: 0 }}
                            onClick={handleAddAll}
                        >
                            Add All ({unlinkedSiteOfficers.length})
                        </button>
                    </div>
                </div>
            )}

            {/* Stats */}
            <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 24 }}>
                {[
                    { label: "Total Assignments", value: stats.totalAssignments, color: "var(--brand-primary)" },
                    { label: "Active Sites", value: stats.activeSites, color: "var(--success)" },
                    { label: "Officers Assigned", value: stats.officersAssigned, color: "var(--brand-purple)" },
                    { label: "Total Officers", value: stats.totalOfficers, color: "var(--brand-primary)" },
                    { label: "Unassigned Sites", value: unassignedSites.length, color: "var(--warning)" },
                ].map((s) => (
                    <div key={s.label} style={{ ...glassCard, borderTop: `3px solid ${s.color}` }}>
                        <div style={{ fontSize: 28, fontWeight: 800, color: s.color }}>{s.value}</div>
                        <div style={{ fontSize: 11, color: "var(--text-soft)", marginTop: 2, fontWeight: 500 }}>{s.label}</div>
                    </div>
                ))}
            </div>

            {/* Assignment Form */}
            {showForm && (
                <div style={card}>
                    <h3 style={{ margin: "0 0 16px", fontSize: 15, fontWeight: 700, color: "var(--text-primary)" }}>
                        {editId ? "Edit Assignment" : "Assign Officer to Site"}
                    </h3>

                    {officers.length === 0 ? (
                        <div style={{
                            padding: "16px 24px",
                            background: "var(--glass-rose)",
                            color: "var(--error, #991b1b)",
                            borderRadius: 12,
                            marginBottom: 24,
                            border: "1px solid var(--error-border, #fecaca)",
                            display: "flex",
                            alignItems: "center",
                            gap: 12,
                        }}>
                            <div style={{ fontWeight: 600, marginBottom: 6 }}>No officers available yet</div>
                            <div style={{ color: "#64748b" }}>
                                {unlinkedSiteOfficers.length > 0
                                    ? `Click "Add" on the ${unlinkedSiteOfficers.length} site officer${unlinkedSiteOfficers.length > 1 ? "s" : ""} shown in the yellow banner above to register them as officers first.`
                                    : 'Go to User Management and create users with the "Site Officer" role, then return here.'}
                            </div>
                        </div>
                    ) : (
                        <form onSubmit={handleSubmit}>
                            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                                <div>
                                    <label style={{ fontSize: 12, fontWeight: 600, color: "var(--text-soft)", display: "block", marginBottom: 4 }}>Officer *</label>
                                    <select
                                        style={{ ...inp, cursor: "pointer" }}
                                        value={form.officer_id}
                                        onChange={(e) => setForm({ ...form, officer_id: e.target.value })}
                                        required
                                    >
                                        <option value="">Select officer...</option>
                                        {officers.map((o) => {
                                            const email = getOfficerEmail(o.id);
                                            const assignedCount = activeAssignments.filter((a) => a.officer_id === o.id).length;
                                            return (
                                                <option key={o.id} value={o.id}>
                                                    {o.full_name || "Unnamed"} {email ? `(${email})` : ""} {assignedCount > 0 ? `[${assignedCount} site${assignedCount > 1 ? "s" : ""}]` : ""}
                                                </option>
                                            );
                                        })}
                                    </select>
                                </div>
                                <div>
                                    <label style={{ fontSize: 12, fontWeight: 600, color: "var(--text-soft)", display: "block", marginBottom: 4 }}>Site *</label>
                                    <select
                                        style={{ ...inp, cursor: "pointer" }}
                                        value={form.site_id}
                                        onChange={(e) => setForm({ ...form, site_id: e.target.value })}
                                        required
                                    >
                                        <option value="">Select site...</option>
                                        {sites.map((s) => {
                                            const assigned = activeAssignments.find((a) => a.site_id === s.id && a.id !== editId);
                                            return (
                                                <option key={s.id} value={s.id} disabled={!!assigned}>
                                                    {s.name} {assigned ? `(✖ Assigned to ${getOfficerName(assigned.officer_id)})` : '✓ Available'}
                                                </option>
                                            );
                                        })}
                                    </select>
                                    {form.site_id && activeAssignments.find((a) => a.site_id === form.site_id && a.id !== editId) && (
                                        <div style={{ fontSize: 11, color: "var(--error)", marginTop: 4, fontWeight: 600 }}>
                                            [!] This site already has an assigned officer. Remove the existing assignment first.
                                        </div>
                                    )}
                                </div>
                                <div>
                                    <label style={{ fontSize: 12, fontWeight: 600, color: "var(--text-soft)", display: "block", marginBottom: 4 }}>From Date</label>
                                    <input type="date" style={inp} value={form.from_date} onChange={(e) => setForm({ ...form, from_date: e.target.value })} />
                                </div>
                                <div>
                                    <label style={{ fontSize: 12, fontWeight: 600, color: "var(--text-soft)", display: "block", marginBottom: 4 }}>To Date (optional)</label>
                                    <input type="date" style={inp} value={form.to_date} onChange={(e) => setForm({ ...form, to_date: e.target.value })} />
                                </div>
                            </div>

                            {/* Preview */}
                            {form.officer_id && form.site_id && (
                                (() => {
                                    const isInvalidDate = form.to_date && form.from_date && form.to_date < form.from_date;
                                    return (
                                        <div style={{
                                            marginTop: 14, padding: 12, borderRadius: 10, 
                                            background: isInvalidDate ? "var(--glass-rose)" : "var(--glass-green)",
                                            border: `1px solid ${isInvalidDate ? "var(--error)" : "var(--border-subtle)"}`, 
                                            fontSize: 13, 
                                            color: isInvalidDate ? "var(--error)" : "var(--success)",
                                            display: "flex", alignItems: "center", gap: 8,
                                        }}>
                                            <div style={{
                                                width: 28, height: 28, borderRadius: 7,
                                                background: isInvalidDate ? "var(--error)" : "var(--brand-primary)",
                                                display: "flex", alignItems: "center", justifyContent: "center",
                                                fontSize: 12, fontWeight: 700, color: "#fff",
                                            }}>
                                                {isInvalidDate ? "!" : (getOfficerName(form.officer_id)[0]?.toUpperCase() || "?")}
                                            </div>
                                            <span style={{ color: isInvalidDate ? "var(--error)" : "var(--text-primary)" }}>
                                                {isInvalidDate ? (
                                                    <strong>Invalid Date Range: To Date must be after From Date</strong>
                                                ) : (
                                                    <>
                                                        <strong style={{ color: "var(--brand-primary)" }}>{getOfficerName(form.officer_id)}</strong> → <strong style={{ color: "var(--brand-primary)" }}>{getSiteName(form.site_id)}</strong>
                                                        {form.from_date && <> from {form.from_date}</>}
                                                        {form.to_date ? <> until {form.to_date}</> : <> (ongoing)</>}
                                                    </>
                                                )}
                                            </span>
                                        </div>
                                    );
                                })()
                            )}

                            <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
                                <button type="submit" style={btnPrimary}>{editId ? "Update" : "Assign"}</button>
                                <button type="button" style={btnSecondary} onClick={resetForm}>Cancel</button>
                            </div>
                        </form>
                    )}
                </div>
            )}

            {/* Search */}
            {activeAssignments.length > 3 && (
                <div style={{ marginBottom: 16 }}>
                    <input
                        style={{ ...inp, maxWidth: 340 }}
                        placeholder="Search by officer or site..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
            )}

            {/* Assignments Table */}
            {filteredAssignments.length === 0 ? (
                <div style={{
                    background: "var(--bg-surface)", borderRadius: 14, padding: 50, textAlign: "center",
                    border: "1px solid var(--border-subtle)", color: "var(--text-muted)",
                }}>
                    <div style={{ fontSize: 36, marginBottom: 10, opacity: 0.3 }}>📋</div>
                    <div style={{ fontSize: 14, fontWeight: 500 }}>
                        {search
                            ? "No assignments match your search."
                            : officers.length === 0
                                ? "Add site officer users first, then create assignments."
                                : 'No active assignments. Click "+ New Assignment" to get started.'}
                    </div>
                </div>
            ) : (
                <div style={{ borderRadius: 14, border: "1px solid var(--border-subtle)", overflow: "hidden", background: "var(--bg-surface)" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                        <thead>
                            <tr>
                                <th style={thStyle}>#</th>
                                <th style={thStyle}>Officer</th>
                                <th style={thStyle}>Site</th>
                                <th style={thStyle}>From</th>
                                <th style={thStyle}>To</th>
                                <th style={thStyle}>Status</th>
                                <th style={{ ...thStyle, textAlign: "right" }}>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredAssignments.map((a, i) => {
                                const isActive = !a.to_date || a.to_date >= today;
                                const email = getOfficerEmail(a.officer_id);
                                return (
                                    <tr
                                        key={a.id}
                                        style={{
                                            background: i % 2 === 0 ? "var(--bg-surface)" : "var(--bg-body, #fafbfc)",
                                            transition: "background 0.15s",
                                        }}
                                        onMouseEnter={(e) => (e.currentTarget.style.background = "var(--table-row-hover, #f1f5f9)")}
                                        onMouseLeave={(e) => (e.currentTarget.style.background = i % 2 === 0 ? "var(--bg-surface)" : "var(--bg-body, #fafbfc)")}
                                    >
                                        <td style={{ ...tdStyle, color: "#94a3b8", fontSize: 12 }}>{i + 1}</td>
                                        <td style={tdStyle}>
                                            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                                <div style={{
                                                    width: 32, height: 32, borderRadius: 8,
                                                    background: "linear-gradient(135deg, #eff6ff, #dbeafe)",
                                                    display: "flex", alignItems: "center", justifyContent: "center",
                                                    fontSize: 13, fontWeight: 700, color: "#2563eb",
                                                }}>
                                                    {getOfficerName(a.officer_id)[0]?.toUpperCase() || "?"}
                                                </div>
                                                <div>
                                                    <div style={{ fontWeight: 600, color: "var(--text-primary)", fontSize: 13 }}>{getOfficerName(a.officer_id)}</div>
                                                    {email && <div style={{ fontSize: 11, color: "var(--text-muted)" }}>{email}</div>}
                                                </div>
                                            </div>
                                        </td>
                                        <td style={{ ...tdStyle, fontWeight: 600 }}>{getSiteName(a.site_id)}</td>
                                        <td style={{ ...tdStyle, fontSize: 12 }}>{a.from_date || "—"}</td>
                                        <td style={{ ...tdStyle, fontSize: 12 }}>{a.to_date || "Ongoing"}</td>
                                        <td style={tdStyle}>
                                            <span style={{
                                                padding: "3px 12px", borderRadius: 20, fontSize: 11, fontWeight: 600,
                                                background: isActive ? "var(--glass-green)" : "var(--glass-rose)",
                                                color: isActive ? "var(--success)" : "var(--error)",
                                            }}>
                                                {isActive ? "Active" : "Expired"}
                                            </span>
                                        </td>
                                        <td style={{ ...tdStyle, textAlign: "right" }}>
                                            <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                                                <button style={btnGhost} onClick={() => handleEdit(a)}>Edit</button>
                                                <button style={btnDanger} onClick={() => handleDelete(a.id)}>Remove</button>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            )}

            {/* Unassigned sites */}
            {unassignedSites.length > 0 && (
                <div style={{ marginTop: 20 }}>
                    <h4 style={{ fontSize: 13, fontWeight: 600, color: "var(--text-muted)", marginBottom: 8 }}>
                        Unassigned Sites ({unassignedSites.length})
                    </h4>
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                        {unassignedSites.map((s) => (
                            <button
                                key={s.id}
                                style={{
                                    padding: "6px 14px", borderRadius: 20, fontSize: 12, fontWeight: 500,
                                    background: "var(--glass-yellow)", color: "var(--warningCustom, #a16207)", border: "1px solid var(--border-subtle)",
                                    cursor: officers.length > 0 ? "pointer" : "default",
                                    opacity: officers.length > 0 ? 1 : 0.6,
                                }}
                                onClick={() => {
                                    if (officers.length === 0) return flash("Add officers first", "err");
                                    setForm({ officer_id: "", site_id: s.id, from_date: today, to_date: "" });
                                    setShowForm(true);
                                    setEditId(null);
                                }}
                                title={officers.length > 0 ? `Assign an officer to ${s.name}` : "Add officers first"}
                            >
                                {s.name}
                            </button>
                        ))}
                    </div>
                </div>
            )}

            {/* Expired */}
            {expiredAssignments.length > 0 && (
                <div style={{ marginTop: 24 }}>
                    <details>
                        <summary style={{ fontSize: 13, fontWeight: 600, color: "#94a3b8", cursor: "pointer", marginBottom: 8 }}>
                            Expired Assignments ({expiredAssignments.length})
                        </summary>
                        <div style={{ borderRadius: 12, border: "1px solid #f1f5f9", overflow: "hidden", marginTop: 8 }}>
                            <table style={{ width: "100%", borderCollapse: "collapse" }}>
                                <thead>
                                    <tr>
                                        <th style={{ ...thStyle, color: "#94a3b8" }}>Officer</th>
                                        <th style={{ ...thStyle, color: "#94a3b8" }}>Site</th>
                                        <th style={{ ...thStyle, color: "#94a3b8" }}>Period</th>
                                        <th style={{ ...thStyle, color: "#94a3b8", textAlign: "right" }}>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {expiredAssignments.map((a) => (
                                        <tr key={a.id} style={{ background: "#fafbfc" }}>
                                            <td style={{ ...tdStyle, color: "#94a3b8" }}>{getOfficerName(a.officer_id)}</td>
                                            <td style={{ ...tdStyle, color: "#94a3b8" }}>{getSiteName(a.site_id)}</td>
                                            <td style={{ ...tdStyle, color: "#94a3b8", fontSize: 12 }}>{a.from_date || "?"} → {a.to_date}</td>
                                            <td style={{ ...tdStyle, textAlign: "right" }}>
                                                <button style={{ ...btnDanger, fontSize: 11, padding: "4px 10px" }} onClick={() => handleDelete(a.id)}>Delete</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </details>
                </div>
            )}

            {/* Footer */}
            <div style={{ marginTop: 16, fontSize: 12, color: "var(--text-soft)", display: "flex", justifyContent: "space-between", flexWrap: "wrap" }}>
                <span>{activeAssignments.length} active assignment{activeAssignments.length !== 1 ? "s" : ""} across {stats.activeSites} site{stats.activeSites !== 1 ? "s" : ""}</span>
                <span>{officers.length} officers, {unlinkedSiteOfficers.length} pending from User Management</span>
            </div>
        </div>
    );
}
