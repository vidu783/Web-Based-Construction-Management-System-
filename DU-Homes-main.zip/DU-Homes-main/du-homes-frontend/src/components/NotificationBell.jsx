import { useState, useEffect, useCallback, useRef } from "react";
import { apiFetch } from "../apiFetch";

const API = (import.meta.env.VITE_API_URL || "http://localhost:8080").replace(/\/+$/, "");

const TYPE_ICONS = {
    salary_paid: "[PAY]",
    low_stock: "[LOW]",
    info: "[INFO]",
    warning: "[WARN]",
    error: "[ERR]",
};

export default function NotificationBell() {
    const [notifications, setNotifications] = useState([]);
    const [unread, setUnread] = useState(0);
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const dropRef = useRef(null);
    const autoReadTimerRef = useRef(null);

    const fetchCount = useCallback(async () => {
        try {
            const r = await apiFetch(`${API}/notifications/unread-count`);
            if (r.ok) { const d = await r.json(); setUnread(d.count || 0); }
            else { console.error("[fetchCount] HTTP", r.status, await r.text().catch(() => "")); }
        } catch (e) { console.error("[fetchCount] Error:", e); }
    }, []);

    const fetchNotifications = useCallback(async () => {
        setLoading(true);
        try {
            const r = await apiFetch(`${API}/notifications`);
            if (r.ok) {
                const data = await r.json();
                console.log("[fetchNotifications] Got", data.length, "notifications");
                setNotifications(data);
                const unreadCount = data.filter(n => !n.is_read).length;
                setUnread(unreadCount);
            } else {
                const txt = await r.text().catch(() => "");
                console.error("[fetchNotifications] HTTP", r.status, txt);
            }
        } catch (e) { console.error("[fetchNotifications] Error:", e); }
        setLoading(false);
    }, []);

    const markRead = async (id) => {
        // Optimistic UI update — mark as read visually instead of removing
        setNotifications((prev) =>
            prev.map((n) => (n.id === id ? { ...n, is_read: true } : n))
        );
        setUnread((prev) => Math.max(0, prev - 1));

        try {
            const r = await apiFetch(`${API}/notifications/${id}/read`, { method: "PATCH" });
            if (!r.ok) {
                // Revert on failure
                setNotifications((prev) =>
                    prev.map((n) => (n.id === id ? { ...n, is_read: false } : n))
                );
                setUnread((prev) => prev + 1);
            }
        } catch (e) {
            // Revert on network error
            setNotifications((prev) =>
                prev.map((n) => (n.id === id ? { ...n, is_read: false } : n))
            );
            setUnread((prev) => prev + 1);
            console.error("Failed to mark read:", e);
        }
    };

    const markAllRead = useCallback(async () => {
        setUnread(0);
        setNotifications((prev) => prev.map(n => ({ ...n, is_read: true })));
        try {
            await apiFetch(`${API}/notifications/mark-all-read`, { method: "PATCH" });
        } catch (e) {
            console.error("Failed to mark all read:", e);
        }
    }, []);

    // Poll unread count every 60s
    useEffect(() => {
        fetchCount();
        const interval = setInterval(fetchCount, 60_000);
        return () => clearInterval(interval);
    }, [fetchCount]);

    // When panel opens: fetch notifications then auto-mark-all-read after 1.5s
    // The DB update ensures the red dot won't reappear after a page refresh
    useEffect(() => {
        if (autoReadTimerRef.current) {
            clearTimeout(autoReadTimerRef.current);
            autoReadTimerRef.current = null;
        }
        if (!open) return;
        fetchNotifications().then(() => {
            autoReadTimerRef.current = setTimeout(() => {
                markAllRead();
            }, 1500);
        });
        return () => {
            if (autoReadTimerRef.current) {
                clearTimeout(autoReadTimerRef.current);
                autoReadTimerRef.current = null;
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [open]);

    // Click outside to close
    useEffect(() => {
        const handler = (e) => {
            if (dropRef.current && !dropRef.current.contains(e.target)) setOpen(false);
        };
        document.addEventListener("mousedown", handler);
        return () => document.removeEventListener("mousedown", handler);
    }, []);

    const timeAgo = (ts) => {
        if (!ts) return "";
        const diff = Date.now() - new Date(ts).getTime();
        const mins = Math.floor(diff / 60000);
        if (mins < 1) return "just now";
        if (mins < 60) return `${mins}m ago`;
        const hrs = Math.floor(mins / 60);
        if (hrs < 24) return `${hrs}h ago`;
        return `${Math.floor(hrs / 24)}d ago`;
    };

    // For low_stock notifications, rebuild the message from metadata (ground truth)
    // This prevents stale/wrong stored messages from misleading the user
    const sanitizeMessage = (n) => {
        if (n.type === "low_stock" && n.metadata) {
            const available = Math.max(0, n.metadata.available ?? 0);
            const toolName = n.metadata.tool_name || "Unknown Tool";
            const threshold = n.metadata.threshold ?? 2;
            return `Low Stock Alert: "${toolName}" has only ${available} unit(s) remaining (threshold: ${threshold})`;
        }
        return n.message;
    };

    return (
        <div ref={dropRef} style={{ position: "relative", display: "inline-block" }}>
            {/* Bell button */}
            <button
                id="notification-bell-btn"
                onClick={() => setOpen((o) => !o)}
                title="Notifications"
                style={{
                    position: "relative", background: "none", border: "none",
                    cursor: "pointer", padding: "6px 8px", borderRadius: 10,
                    color: "var(--text-soft)",
                    transition: "background 0.15s",
                    display: "flex", alignItems: "center",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "var(--bg-body)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "none")}
            >
                <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
                    <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
                </svg>
                {unread > 0 && (
                    <span style={{
                        position: "absolute", top: 2, right: 2,
                        minWidth: 16, height: 16, padding: "0 4px",
                        background: "#dc2626", color: "#fff",
                        borderRadius: 99, fontSize: 10, fontWeight: 700,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        lineHeight: 1,
                    }}>
                        {unread > 99 ? "99+" : unread}
                    </span>
                )}
            </button>

            {/* Dropdown panel */}
            {open && (
                <div style={{
                    position: "absolute", top: "calc(100% + 8px)", right: 0,
                    width: 360, maxHeight: 480, zIndex: 9999,
                    background: "var(--bg-surface)",
                    border: "1px solid var(--border-subtle)",
                    borderRadius: 14,
                    boxShadow: "0 8px 32px rgba(0,0,0,0.18)",
                    display: "flex", flexDirection: "column",
                    overflow: "hidden",
                }}>
                    {/* Header */}
                    <div style={{
                        display: "flex", justifyContent: "space-between", alignItems: "center",
                        padding: "12px 16px",
                        borderBottom: "1px solid var(--border-subtle)",
                        background: "var(--bg-body)",
                    }}>
                        <span style={{ fontWeight: 700, fontSize: 14, color: "var(--text-primary)" }}>
                            Notifications {unread > 0 && <span style={{ color: "var(--brand-primary, #2563eb)" }}>({unread} new)</span>}
                        </span>
                        {unread > 0 && (
                            <button onClick={markAllRead} style={{
                                background: "none", border: "none", cursor: "pointer",
                                fontSize: 12, color: "var(--brand-primary, #2563eb)",
                                fontWeight: 600, padding: "2px 6px",
                            }}>
                                Mark all read
                            </button>
                        )}
                    </div>

                    {/* List */}
                    <div style={{ overflowY: "auto", flex: 1 }}>
                        {loading ? (
                            <div style={{ padding: 32, textAlign: "center", color: "var(--text-soft)", fontSize: 13 }}>
                                Loading…
                            </div>
                        ) : notifications.length === 0 ? (
                            <div style={{ padding: 40, textAlign: "center", color: "var(--text-soft)" }}>
                                <div style={{ fontSize: 13, fontWeight: 700 }}>No notifications yet</div>
                            </div>
                        ) : (
                            notifications.map((n) => (
                                <div
                                    key={n.id}
                                    onClick={() => { if (!n.is_read) markRead(n.id); }}
                                    style={{
                                        padding: "12px 16px",
                                        display: "flex", gap: 10, alignItems: "flex-start",
                                        borderBottom: "1px solid var(--border-subtle)",
                                        background: n.is_read ? "transparent" : "rgba(37,99,235,0.05)",
                                        cursor: n.is_read ? "default" : "pointer",
                                        transition: "background 0.15s",
                                    }}
                                    onMouseEnter={(e) => { if (!n.is_read) e.currentTarget.style.background = "rgba(37,99,235,0.09)"; }}
                                    onMouseLeave={(e) => { e.currentTarget.style.background = n.is_read ? "transparent" : "rgba(37,99,235,0.05)"; }}
                                >
                                    <span style={{ fontSize: 10, fontWeight: 800, flexShrink: 0, marginTop: 4, color: "var(--text-soft)" }}>
                                        {TYPE_ICONS[n.type] || "[MSG]"}
                                    </span>
                                    <div style={{ flex: 1, minWidth: 0 }}>
                                        <div style={{
                                            fontSize: 13, color: "var(--text-primary)",
                                            fontWeight: n.is_read ? 400 : 600,
                                            wordBreak: "break-word", lineHeight: 1.4,
                                        }}>
                                            {sanitizeMessage(n)}
                                        </div>
                                        <div style={{ fontSize: 11, color: "var(--text-soft)", marginTop: 3 }}>
                                            {timeAgo(n.created_at)}
                                        </div>
                                    </div>
                                    {!n.is_read && (
                                        <div style={{
                                            width: 8, height: 8, borderRadius: "50%",
                                            background: "var(--brand-primary, #2563eb)",
                                            flexShrink: 0, marginTop: 4,
                                        }} />
                                    )}
                                </div>
                            ))
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}
