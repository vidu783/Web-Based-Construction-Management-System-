import React from "react";

const IconClose = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>;

const formatKey = (key) => {
    return key.replace(/_/g, ' ')
              .replace(/\b\w/g, c => c.toUpperCase());
};

const getRoleLabel = (role, name) => {
    const roles = {
        'admin': 'Admin',
        'project_manager': 'Project Manager',
        'site_officer': 'Site Officer',
        'finance_officer': 'Finance Officer'
    };
    const roleLabel = roles[role?.toLowerCase()] || role || 'Admin';
    if (name && name.trim()) return `${roleLabel} (${name})`;
    return roleLabel;
};

const SmartDetailModal = ({ record, recordType, onClose, getWorkerName, getSiteName, getToolName, officers, assignments, selectedSiteId }) => {
    if (!record) return null;

    return (
        <div style={{
            position: "fixed", top: 0, left: 0, right: 0, bottom: 0,
            background: "rgba(15, 23, 42, 0.6)", backdropFilter: "blur(4px)",
            display: "flex", alignItems: "center", justifyContent: "center", zIndex: 9999, padding: 20
        }} onClick={onClose}>
            <div style={{
                background: "#ffffff", borderRadius: 24, width: "100%", maxWidth: 650,
                maxHeight: "90vh", overflowY: "auto", boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
                display: "flex", flexDirection: "column"
            }} onClick={e => e.stopPropagation()}>
                
                <div style={{ padding: "24px 32px", borderBottom: "1px solid #f1f5f9", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, background: "#ffffff", zIndex: 10, borderRadius: "24px 24px 0 0" }}>
                    <div>
                        <span style={{ fontSize: 12, fontWeight: 800, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.1em" }}>Record Inspector</span>
                        <h2 style={{ margin: 0, fontSize: 24, fontWeight: 800, color: "#0f172a", textTransform: "capitalize" }}>{recordType} Details</h2>
                    </div>
                    <button onClick={onClose} style={{ background: "transparent", border: "none", cursor: "pointer", color: "#94a3b8", padding: 8, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.2s" }} onMouseOver={e => e.currentTarget.style.backgroundColor = "#f1f5f9"} onMouseOut={e => e.currentTarget.style.backgroundColor = "transparent"}>
                        <IconClose />
                    </button>
                </div>

                <div style={{ padding: "8px 32px 32px 32px" }}>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 16, marginTop: 24 }}>
                        {Object.entries(record).map(([key, value]) => {
                            // Smart transformations
                            let displayValue = value;
                            let keyToDisplay = key;
                            if (value === null || value === undefined || value === "") {
                                displayValue = <span style={{ color: "#94a3b8", fontStyle: "italic" }}>Not provided</span>;
                            } else if (typeof value === 'object') {
                                if (Array.isArray(value)) {
                                    if (value.length === 0) {
                                        displayValue = <span style={{ color: "#94a3b8", fontStyle: "italic" }}>Empty List</span>;
                                    } else {
                                        displayValue = (
                                            <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 8 }}>
                                                {value.map((item, idx) => (
                                                    <div key={idx} style={{ background: "#f8fafc", padding: 12, borderRadius: 8, border: "1px solid #e2e8f0" }}>
                                                        {typeof item === 'object' && item !== null ? Object.entries(item).map(([k, v]) => {
                                                            if (k === 'id' || k.includes('_id')) return null;
                                                            let vStr = String(v);
                                                            if (typeof v === 'object' && v !== null) {
                                                                vStr = v.full_name || v.name || v.site_name || "Linked Record";
                                                            }
                                                            return (
                                                                <div key={k} style={{ marginBottom: 4 }}>
                                                                    <span style={{ fontSize: 12, color: "#64748b", fontWeight: 700, textTransform: "uppercase" }}>{k.replace(/_/g, ' ')}:</span>
                                                                    <span style={{ marginLeft: 6, fontSize: 13, color: "#0f172a", fontWeight: 600 }}>{vStr}</span>
                                                                </div>
                                                            );
                                                        }) : <span style={{ fontSize: 13, color: "#0f172a", fontWeight: 600 }}>{String(item)}</span>}
                                                    </div>
                                                ))}
                                            </div>
                                        );
                                    }
                                } else {
                                    // Single object
                                    displayValue = (
                                        <div style={{ background: "#f8fafc", padding: 12, borderRadius: 8, border: "1px solid #e2e8f0", marginTop: 8 }}>
                                            {Object.entries(value).map(([k, v]) => {
                                                if (k === 'id' || k.includes('_id')) return null;
                                                let vStr = String(v);
                                                if (typeof v === 'object' && v !== null) {
                                                    vStr = v.full_name || v.name || v.site_name || "Linked Record";
                                                }
                                                return (
                                                    <div key={k} style={{ marginBottom: 4 }}>
                                                        <span style={{ fontSize: 12, color: "#64748b", fontWeight: 700, textTransform: "uppercase" }}>{k.replace(/_/g, ' ')}:</span>
                                                        <span style={{ marginLeft: 6, fontSize: 13, color: "#0f172a", fontWeight: 600 }}>{vStr}</span>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    );
                                }
                            } else if (key === 'recorded_by_name' || key === 'uploader_name') {
                                return null; // Skip raw name, we'll combine it with the role
                            } else if (key === 'recorded_by_role' || key === 'uploader_role' || key === 'authorized_by') {
                                let label = "Recorded By";
                                if (recordType.toLowerCase().includes('payroll') || recordType.toLowerCase().includes('bill')) {
                                    label = "Paid By";
                                }
                                keyToDisplay = label;
                                displayValue = <span className="status-badge badge-blue" style={{ background: (value||'admin')?.toLowerCase() === 'admin' ? '#f1f5f9' : '#dbeafe', color: (value||'admin')?.toLowerCase() === 'admin' ? '#0f172a' : '#1e40af', border: (value||'admin')?.toLowerCase() === 'admin' ? '1px solid #cbd5e1' : 'none' }}>
                                    {getRoleLabel(value || 'admin', record.recorded_by_name || record.uploader_name)}
                                </span>;
                            } else if (key === 'worker_id' && typeof value === 'number') {
                                displayValue = getWorkerName(value);
                            } else if (key === 'site_id' && typeof value === 'number') {
                                displayValue = getSiteName(value);
                            } else if (key === 'tool_id' && typeof value === 'number') {
                                displayValue = getToolName(value);
                            } else if (key.includes('status')) {
                                displayValue = <span className={`status-badge ${value?.toLowerCase() === 'paid' ? 'badge-green' : 'badge-blue'}`}>{value}</span>;
                            } else if (key.includes('date') || key === 'created_at') {
                                const parsedDate = new Date(value);
                                displayValue = isNaN(parsedDate) ? value : parsedDate.toLocaleString();
                            } else if (typeof value === 'boolean') {
                                displayValue = value ? "Yes" : "No";
                            }

                            return (
                                <div key={key} style={{ display: "flex", flexDirection: "column", paddingBottom: 16, borderBottom: "1px solid #f1f5f9" }}>
                                    <span style={{ fontSize: 13, fontWeight: 700, color: "#64748b", marginBottom: 4 }}>
                                        {keyToDisplay === key ? formatKey(key) : keyToDisplay}
                                    </span>
                                    <div style={{ fontSize: 15, color: "#0f172a", fontWeight: 500, wordBreak: "break-word" }}>{displayValue}</div>
                                </div>
                            );
                        })}
                    </div>
                    
                    {(() => {
                        const todayStr = new Date().toLocaleDateString("en-CA");

                        // Site-specific assignment lookup
                        const siteAssignments = selectedSiteId && assignments
                            ? assignments.filter(a => {
                                if (String(a.site_id) !== String(selectedSiteId)) return false;
                                return !a.to_date || a.to_date >= todayStr;
                              })
                            : [];

                        const siteOfficerIds = siteAssignments.map(a => a.officer_id);
                        const siteOfficers = officers.filter(o => siteOfficerIds.includes(o.id));

                        const byRole = (role) => siteOfficers.find(o => (o.role || "").toLowerCase() === role);
                        const pm = byRole('project_manager');
                        const so = byRole('site_officer');

                        // Finance officer — look for site-specific ONLY.
                        const fo = byRole('finance_officer');

                        const contacts = [
                            pm && { label: 'Project Manager', officer: pm },
                            so && { label: 'Site Officer', officer: so },
                            fo && { label: 'Finance Officer', officer: fo },
                        ].filter(Boolean);

                        if (contacts.length === 0) {
                            return (
                                <div style={{ marginTop: 24, padding: "16px", background: "#f8fafc", borderRadius: 12, border: "1px dashed #e2e8f0", textAlign: "center", color: "#94a3b8", fontSize: 13 }}>
                                    No officer is currently assigned to this record's site.
                                </div>
                            );
                        }

                        return (
                            <div style={{ marginTop: 32, paddingTop: 24, borderTop: "1px solid #f1f5f9" }}>
                                <h3 style={{ margin: "0 0 16px 0", fontSize: 13, fontWeight: 800, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.1em" }}>
                                    Executive Quick Dial
                                    {selectedSiteId && <span style={{ marginLeft: 8, fontSize: 11, fontWeight: 600, color: "#3b82f6", textTransform: "none" }}>— {getSiteName(selectedSiteId)}</span>}
                                </h3>
                                <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                                    {contacts.map(({ label, officer }) => (
                                        <a key={label} href={`tel:${officer.phone || ""}`} style={{
                                            flex: "1 1 calc(33.333% - 12px)", minWidth: 160,
                                            textDecoration: "none", display: "flex", flexDirection: "column", gap: 6,
                                            background: "#f8fafc", padding: "14px 16px", borderRadius: 12,
                                            border: "1px solid #e2e8f0", transition: "all 0.2s", color: "inherit", cursor: "pointer"
                                        }} onMouseOver={e => { e.currentTarget.style.borderColor = "#3b82f6"; e.currentTarget.style.background = "#eff6ff"; }}
                                           onMouseOut={e => { e.currentTarget.style.borderColor = "#e2e8f0"; e.currentTarget.style.background = "#f8fafc"; }}>
                                            <span style={{ fontSize: 11, fontWeight: 800, color: "#64748b", textTransform: "uppercase" }}>CALL {label}</span>
                                            <span style={{ fontSize: 14, fontWeight: 700, color: "#0f172a" }}>{officer.full_name || officer.name}</span>
                                            <span style={{ fontSize: 13, color: "#3b82f6", fontWeight: 600, display: "flex", alignItems: "center", gap: 6 }}>
                                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                                                {officer.phone || "No Direct Line"}
                                            </span>
                                        </a>
                                    ))}
                                </div>
                            </div>
                        );
                    })()}
                </div>
            </div>
        </div>
    );
};

export default SmartDetailModal;
