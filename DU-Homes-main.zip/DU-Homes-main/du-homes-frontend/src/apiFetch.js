// ============================================================================
// apiFetch.js — Smart API Fetch Utility with Auto Token Refresh
//
// PROBLEM: Supabase JWT access tokens expire after 1 hour. Without refresh
// logic, the app shows 401 errors on every API call after expiry.
//
// SOLUTION: This utility wraps fetch() to:
//   1. Attach the current JWT token to every request automatically
//   2. Detect 401 responses (expired token)
//   3. Silently call /auth/refresh to get a new token
//   4. Retry the original failed request with the new token
//   5. If refresh also fails → fire a global "session-expired" event
//      which App.jsx listens to and logs the user out gracefully
//
// USAGE: Replace `fetch(url, { headers: hdr() })` with `apiFetch(url)`
//        Replace `fetch(url, { method:"POST", headers: hdr(), body })` with
//               `apiFetch(url, { method:"POST", body })`
// ============================================================================

const API_URL = (import.meta.env.VITE_API_URL || "http://localhost:8080").replace(/\/+$/, "");

// Flag to prevent multiple concurrent refresh attempts
let _isRefreshing = false;

// Queue of callbacks waiting for the refresh to complete
let _refreshQueue = [];

// Notify all queued requests once the new token is available (or failed)
function _processQueue(newToken, error) {
    _refreshQueue.forEach((cb) => (error ? cb.reject(error) : cb.resolve(newToken)));
    _refreshQueue = [];
}

/**
 * Attempt a silent token refresh using the stored refresh_token.
 * Returns the new access token on success, or throws on failure.
 */
async function _refreshToken() {
    const refreshToken = localStorage.getItem("refresh_token");
    if (!refreshToken) {
        throw new Error("No refresh token available");
    }

    const res = await fetch(`${API_URL}/auth/refresh`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: refreshToken }),
    });

    if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Token refresh failed");
    }

    const data = await res.json();

    // Persist the new tokens
    localStorage.setItem("token", data.token);
    localStorage.setItem("access_token", data.token);
    if (data.refresh_token) {
        localStorage.setItem("refresh_token", data.refresh_token);
    }

    return data.token;
}

/**
 * Build default headers, always picking the latest token from localStorage.
 */
function _buildHeaders(extra = {}) {
    const token = localStorage.getItem("token") || localStorage.getItem("access_token") || "";
    return {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...extra,
    };
}

/**
 * apiFetch — drop-in replacement for fetch() that handles auth automatically.
 *
 * @param {string} url        - Full URL or path (e.g., `${API}/workers`)
 * @param {object} options    - Standard fetch options (method, body, headers, etc.)
 *                              Do NOT include Authorization — it is added automatically.
 * @returns {Promise<Response>}
 */
export async function apiFetch(url, options = {}) {
    const { headers: extraHeaders, ...restOptions } = options;

    // Build the request with current token
    const makeRequest = (token) => {
        const headers = {
            "Content-Type": "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
            ...(extraHeaders || {}),
        };
        return fetch(url, { ...restOptions, headers });
    };

    const currentToken = localStorage.getItem("token") || localStorage.getItem("access_token") || "";
    let response = await makeRequest(currentToken);

    // If not 401, return the response as-is
    if (response.status !== 401) {
        return response;
    }

    // ── 401 detected ── try to refresh the token silently ──

    // If a refresh is already in progress, queue this request
    if (_isRefreshing) {
        return new Promise((resolve, reject) => {
            _refreshQueue.push({
                resolve: (newToken) => resolve(makeRequest(newToken)),
                reject,
            });
        }).then((retriedResponse) => retriedResponse);
    }

    _isRefreshing = true;

    try {
        const newToken = await _refreshToken();
        _processQueue(newToken, null);
        // Retry the original request with the new token
        return await makeRequest(newToken);
    } catch (err) {
        _processQueue(null, err);
        // Refresh failed — session is truly expired, log the user out
        console.warn("[apiFetch] Token refresh failed, firing session-expired event:", err.message);
        window.dispatchEvent(new CustomEvent("session-expired", { detail: { message: err.message } }));
        // Return the original 401 response so callers don't hang
        return response;
    } finally {
        _isRefreshing = false;
    }
}

/**
 * Convenience helper — same as `apiFetch` but always returns parsed JSON.
 * Throws if the response is not ok.
 */
export async function apiFetchJSON(url, options = {}) {
    const res = await apiFetch(url, options);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Request failed: ${res.status}`);
    return data;
}

/**
 * Pre-built header builder for components that still use raw fetch()
 * and want to stay compatible without a full rewrite.
 */
export const hdr = () => {
    const t = localStorage.getItem("token") || localStorage.getItem("access_token") || "";
    return {
        "Content-Type": "application/json",
        ...(t ? { Authorization: `Bearer ${t}` } : {}),
    };
};

export { API_URL as API };
