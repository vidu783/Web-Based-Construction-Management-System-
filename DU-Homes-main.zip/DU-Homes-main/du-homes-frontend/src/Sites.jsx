// ============================================================================
// FEATURE: Sites.jsx — Construction Site Management Module
// Implemented by: IT24102845
// This component provides full CRUD (Create, Read, Update, Delete) operations
// for managing construction sites in the DU Homes system.
//
// FLOW: Complete user journey:
//   1. Component mounts → fetches all sites from the API (GET /fields)
//   2. Sites are displayed in a searchable, sortable table
//   3. User can add a new site by filling out the form and clicking "Add Site"
//   4. User can edit an existing site by clicking "Edit" → form populates → "Update Site"
//   5. User can delete a site by clicking "Delete" → confirmation dialog → removed
//   6. User can search/filter sites by name, location, nature of work, or owner
//
// DB: Integrates with Supabase 'sites' table via Express backend endpoints:
//   - GET    /fields      → Fetch all sites
//   - POST   /fields      → Create a new site
//   - PUT    /fields/:id  → Update an existing site
//   - DELETE /fields/:id  → Delete a site
// ============================================================================

/* ── du-homes-frontend/src/Sites.jsx ── */
import { useState, useEffect, useCallback } from "react";

// DB: API base URL — connects to Express backend which queries Supabase 'sites' table
const API = import.meta.env.VITE_API_URL || "http://localhost:8080";

// DB: Authorization header builder — attaches JWT token for authenticated API requests
const hdr = () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("access_token") || localStorage.getItem("token") || ""}`,
});

export default function Sites() {
    // DB: State holding all sites fetched from the Supabase 'sites' table
    const [sites, setSites] = useState([]);

    // UI: Search query for filtering the sites table
    const [search, setSearch] = useState("");

    // UI: Loading state — disables form buttons during API operations
    const [loading, setLoading] = useState(false);

    // VALIDATION: Message state for displaying success (✓) or error feedback to the user
    const [msg, setMsg] = useState("");

    const [form, setForm] = useState({ name: "", address: "", nature_of_work: "", owner_name: "", owner_prefix: "", owner_contact: "" });

    // FLOW: Tracks which site is being edited (null = creating new, id = editing existing)
    const [editId, setEditId] = useState(null);
    const [fieldErrors, setFieldErrors] = useState({});

    // ========================================================================
    // DB: Fetch All Sites
    // Sends GET request to /fields endpoint which queries Supabase 'sites' table.
    // Called on component mount and after every create/update/delete operation
    // to keep the table in sync with the database.
    // FLOW: Step 1 — Load all sites on initial render
    // ========================================================================
    const fetchSites = useCallback(async () => {
        setLoading(true);
        try {
            const r = await fetch(`${API}/fields`, { headers: hdr() }); // DB: GET all sites from Supabase
            if (r.ok) setSites(await r.json());
        } catch { /* ignore */ } // VALIDATION: Silently handle network errors
        setLoading(false);
    }, []);

    // FLOW: Trigger initial data fetch when component mounts
    useEffect(() => {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        fetchSites();
    }, [fetchSites]);

    // ========================================================================
    // FEATURE: Create / Update Site Handler
    // DB: Sends POST (create) or PUT (update) request to the backend.
    //   - POST /fields — inserts a new row into Supabase 'sites' table
    //   - PUT /fields/:id — updates an existing row in Supabase 'sites' table
    // VALIDATION: Checks that the site name (required field) is not empty.
    // FLOW: Step 3 (create) or Step 4 (update) — Save site data to database
    // ========================================================================
    const validate = () => {
        const errs = {};
        if (!form.name.trim()) errs.name = "Site name is required";
        else if (form.name.trim().length < 3) errs.name = "Name must be at least 3 characters";
        
        if (!form.address.trim()) errs.address = "Address is required";
        else if (form.address.trim().length < 5) errs.address = "Address must be at least 5 characters";

        if (!form.owner_contact.trim()) errs.contact = "Contact number is required";
        else if (!/^[0-9]{10}$/.test(form.owner_contact.trim())) errs.contact = "Enter a valid 10-digit number";

        setFieldErrors(errs);
        return Object.keys(errs).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;
        setLoading(true); setMsg("");

        try {
            const finalOwner = form.owner_prefix ? `${form.owner_prefix} ${form.owner_name}` : form.owner_name;
            if (editId) {
                // DB: UPDATE existing site — PUT /fields/:id → updates row in Supabase 'sites' table
                const r = await fetch(`${API}/fields/${editId}`, {
                    method: "PUT",
                    headers: hdr(),
                    body: JSON.stringify({ ...form, owner_name: finalOwner }),
                });
                if (r.ok) { setMsg("Site updated ✓"); setEditId(null); }
                else { const d = await r.json(); setMsg(d.error || "Update failed"); } // VALIDATION: Display server error
            } else {
                // DB: CREATE new site — POST /fields → inserts new row into Supabase 'sites' table
                const r = await fetch(`${API}/fields`, {
                    method: "POST",
                    headers: hdr(),
                    body: JSON.stringify({ ...form, owner_name: finalOwner }),
                });
                if (r.ok) setMsg("Site added ✓");
                else { const d = await r.json(); setMsg(d.error || "Create failed"); } // VALIDATION: Display server error
            }
            // FLOW: Reset form after successful operation and refresh the sites list
            setForm({ name: "", address: "", nature_of_work: "", owner_name: "", owner_prefix: "", owner_contact: "" });
            setFieldErrors({});
            fetchSites(); // DB: Re-fetch all sites to reflect the change
        } catch (err) { setMsg(err.message); } // VALIDATION: Handle network/connection errors
        setLoading(false);
    };

    // ========================================================================
    // FLOW: Step 4a — Edit Site
    // Populates the form with the selected site's data and scrolls to top.
    // The form switches from "Add Site" to "Update Site" mode.
    // ========================================================================
    const handleEdit = (site) => {
        setEditId(site.id); // FLOW: Set edit mode with the site's ID
        
        // UI: Parse prefix from owner_name if it exists (Mr. / Mrs. / Miss.)
        const prefixes = ["Mr.", "Mrs.", "Miss."];
        let prefix = "";
        let name = site.owner_name || "";
        for (const p of prefixes) {
            if (name.startsWith(p + " ")) {
                prefix = p;
                name = name.replace(p + " ", "");
                break;
            }
        }

        setForm({
            name: site.name || "",
            address: site.address || "",
            nature_of_work: site.nature_of_work || "",
            owner_name: name,
            owner_prefix: prefix,
            owner_contact: site.owner_contact || ""
        });
        setMsg("");
        window.scrollTo({ top: 0, behavior: "smooth" }); // UI: Scroll to form for better UX
    };

    // FLOW: Cancel edit — resets form back to "Add New Site" mode
    const handleCancelEdit = () => {
        setEditId(null);
        setForm({ name: "", address: "", nature_of_work: "", owner_name: "", owner_prefix: "", owner_contact: "" });
        setFieldErrors({});
        setMsg("");
    };

    // ========================================================================
    // FEATURE: Delete Site
    // DB: Sends DELETE request to /fields/:id → removes the row from Supabase 'sites' table.
    // VALIDATION: Shows a browser confirmation dialog before deletion to prevent
    // accidental data loss. Displays success or error message after the operation.
    // FLOW: Step 5 — Delete a site after user confirmation
    // ========================================================================
    const handleDelete = async (id, siteName) => {
        // VALIDATION: Explain the 3 possible outcomes before user confirms
        const confirmed = confirm(
            `Remove "${siteName}" from the active sites list?\n\n` +
            `• If this site has no past records → permanently deleted.\n` +
            `• If this site has past records (deployments, payments, etc.) → archived (records preserved).\n` +
            `• If this site has a current/upcoming deployment → blocked.`
        );
        if (!confirmed) return;
        try {
            const r = await fetch(`${API}/fields/${id}`, { method: "DELETE", headers: hdr() });
            const d = await r.json();
            if (r.ok) {
                // Show archived vs deleted message from server
                setMsg(d.archived ? `Archived ✓ — ${d.detail}` : `Deleted ✓`);
                fetchSites();
            } else {
                setMsg(d.detail || d.error || "Delete failed");
            }
        } catch (err) { setMsg(err.message); }
    };

    // ========================================================================
    // FEATURE: Client-side Search / Filter
    // FLOW: Step 6 — Filters the sites table in real-time as the user types.
    // Searches across all four visible columns: name, location, nature_of_work, owner_name.
    // UI: No API call needed — filtering happens on the already-fetched data.
    // ========================================================================
    const filtered = sites.filter((s) => {
        const q = search.toLowerCase();
        return (
            (s.name || "").toLowerCase().includes(q) ||
            (s.address || "").toLowerCase().includes(q) ||
            (s.nature_of_work || "").toLowerCase().includes(q) ||
            (s.owner_name || "").toLowerCase().includes(q) ||
            (s.owner_contact || "").toLowerCase().includes(q)
        );
    });

    // UI: Reusable inline style definitions for cards, inputs, table headers, and cells
    const card = { background: "var(--bg-surface)", border: "1px solid var(--border-subtle)", borderRadius: 12, padding: 20, marginBottom: 20 };
    const inp = { width: "100%", padding: "10px 12px", borderRadius: 8, border: "1px solid var(--input-border)", background: "var(--input-bg)", color: "var(--input-text)", fontSize: 14, boxSizing: "border-box" };
    const inpErr = (field) => ({ ...inp, border: fieldErrors[field] ? "1px solid var(--error)" : "1px solid var(--input-border)", background: fieldErrors[field] ? "var(--glass-rose)" : "var(--input-bg)" });
    const errText = { color: "var(--error)", fontSize: 11, marginTop: 2, fontWeight: 500 };
    const th = { padding: "10px 12px", borderBottom: "2px solid var(--border-subtle)", textAlign: "left", fontSize: 13, fontWeight: 700, background: "var(--table-header-bg)", color: "var(--text-primary)" };
    const td = { padding: "10px 12px", borderBottom: "1px solid var(--border-subtle)", fontSize: 13, color: "var(--text-primary)" };

    return (
        <div style={{ padding: 20 }}>
            {/* UI: Page title */}
            <h2 style={{ margin: "0 0 20px", fontWeight: 800 }}>Sites</h2>

            {/* ================================================================
                VALIDATION: Feedback Message Banner
                Displays success messages (green, contains ✓) or error messages (red).
                Automatically distinguishes between success and error by checking
                for the ✓ character in the message string.
            ================================================================ */}
            {msg && (
                <div style={{
                    padding: "10px 16px", marginBottom: 16, borderRadius: 8,
                    background: msg.includes("✓") ? "var(--glass-green)" : "var(--glass-rose)",
                    color: msg.includes("✓") ? "var(--success)" : "var(--error)",
                    fontWeight: 600, fontSize: 14,
                    border: `1px solid var(--border-subtle)`
                }}>{msg}</div>
            )}

            {/* ================================================================
                FEATURE: Add / Edit Site Form
                UI: Two-column grid layout with fields for name, location,
                nature of work, and owner name.
                VALIDATION: Site name is required (HTML5 required + custom check).
                FLOW: Form dynamically switches between "Add" and "Edit" modes
                based on whether editId is set. Edit mode shows an amber "Update"
                button and a "Cancel" button to return to add mode.
                DB: On submit, sends POST (create) or PUT (update) to the backend.
            ================================================================ */}
            <div style={card}>
                <h3 style={{ margin: "0 0 16px", fontWeight: 700 }}>
                    {editId ? "Edit Site" : "Add New Site"}
                </h3>
                <form onSubmit={handleSubmit}>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                        {/* VALIDATION: Site name — required field, marked with placeholder text */}
                        <input
                            type="text"
                            placeholder="Site name (required)"
                            value={form.name}
                            onChange={(e) => {
                                setForm((f) => ({ ...f, name: e.target.value }));
                                if (fieldErrors.name) setFieldErrors((p) => ({ ...p, name: undefined }));
                            }}
                            style={inpErr("name")}
                        />
                        {fieldErrors.name && <span style={errText}>{fieldErrors.name}</span>}
                        {/* UI: Address — renamed from Location */}
                        <div style={{ flex: 1 }}>
                            <input
                                type="text"
                                placeholder="Address"
                                value={form.address}
                                onChange={(e) => {
                                    setForm((f) => ({ ...f, address: e.target.value }));
                                    if (fieldErrors.address) setFieldErrors((p) => ({ ...p, address: undefined }));
                                }}
                                style={inpErr("address")}
                            />
                            {fieldErrors.address && <span style={errText}>{fieldErrors.address}</span>}
                        </div>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
                        {/* UI: Nature of work — optional descriptive field */}
                        <input
                            type="text"
                            placeholder="Nature of work"
                            value={form.nature_of_work}
                            onChange={(e) => setForm((f) => ({ ...f, nature_of_work: e.target.value }))}
                            style={inp}
                        />
                        {/* UI: Owner name — with prefix dropdown */}
                        <div style={{ display: "flex", gap: 6 }}>
                            <select
                                value={form.owner_prefix}
                                onChange={(e) => setForm((f) => ({ ...f, owner_prefix: e.target.value }))}
                                style={{ ...inp, width: 85 }}
                            >
                                <option value="">Title</option>
                                <option value="Mr.">Mr.</option>
                                <option value="Mrs.">Mrs.</option>
                                <option value="Miss.">Miss.</option>
                            </select>
                            <input
                                type="text"
                                placeholder="Owner name"
                                value={form.owner_name}
                                onChange={(e) => setForm((f) => ({ ...f, owner_name: e.target.value }))}
                                style={inp}
                            />
                        </div>
                    </div>
                    {/* UI: Owner Contact — new field */}
                    <div style={{ marginBottom: 12 }}>
                        <input
                            type="text"
                            placeholder="Owner contact number"
                            value={form.owner_contact}
                            onChange={(e) => {
                                setForm((f) => ({ ...f, owner_contact: e.target.value }));
                                if (fieldErrors.contact) setFieldErrors((p) => ({ ...p, contact: undefined }));
                            }}
                            style={inpErr("contact")}
                        />
                        {fieldErrors.contact && <span style={errText}>{fieldErrors.contact}</span>}
                    </div>
                    {/* UI: Action buttons — submit and cancel (cancel only in edit mode) */}
                    <div style={{ display: "flex", gap: 8 }}>
                        {/* UI: Submit button — changes color and label based on add/edit mode */}
                        <button
                            type="submit"
                            disabled={loading}
                            style={{
                                padding: "10px 28px",
                                background: editId ? "var(--warning, #f59e0b)" : "var(--primary-gradient, linear-gradient(135deg, #991b1b, #c8102e))",
                                color: "#fff",
                                border: "none",
                                borderRadius: 8,
                                fontWeight: 700,
                                fontSize: 14,
                                cursor: "pointer",
                            }}
                        >
                            {editId ? "Update Site" : "Add Site"}
                        </button>
                        {/* FLOW: Cancel button — only visible in edit mode, resets to add mode */}
                        {editId && (
                            <button
                                type="button"
                                onClick={handleCancelEdit}
                                style={{
                                    padding: "10px 28px",
                                    background: "var(--border-subtle)",
                                    color: "var(--text-soft)",
                                    border: "none",
                                    borderRadius: 8,
                                    fontWeight: 700,
                                    fontSize: 14,
                                    cursor: "pointer",
                                }}
                            >
                                Cancel
                            </button>
                        )}
                    </div>
                </form>
            </div>

            {/* ================================================================
                FEATURE: Sites Data Table
                UI: Displays all sites in a table with columns for Name, Location,
                Nature of Work, Owner, and Actions (Edit/Delete).
                FEATURE: Real-time search bar filters sites across all columns.
                UI: Shows count of filtered results vs total sites.
                VALIDATION: Displays "No sites found" when search yields no results.
                DB: Data is sourced from the Supabase 'sites' table.
            ================================================================ */}
            <div style={card}>
                {/* UI: Search bar and result count header */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                    {/* FLOW: Step 6 — Search input filters the table in real-time */}
                    <input
                        type="text"
                        placeholder="Search sites..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        style={{ ...inp, width: 280 }}
                    />
                    {/* UI: Display count of filtered results vs total */}
                    <span style={{ fontSize: 13, color: "var(--text-muted)" }}>{filtered.length} of {sites.length} sites</span>
                </div>

                {/* UI: Horizontally scrollable table wrapper for responsive display */}
                <div style={{ overflowX: "auto" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                        <thead>
                        <tr>
                            <th style={th}>Name</th>
                            <th style={th}>Address</th>
                            <th style={th}>Nature of Work</th>
                            <th style={th}>Owner</th>
                            <th style={th}>Contact</th>
                            <th style={th}>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        {/* VALIDATION: Empty state message when no sites match the search */}
                        {filtered.length === 0 && (
                            <tr>
                                <td colSpan={6} style={{ ...td, textAlign: "center", color: "var(--text-soft)", padding: 30 }}>
                                    No sites found
                                </td>
                            </tr>
                        )}
                        {/* DB: Render each site row from the filtered Supabase data */}
                        {filtered.map((s) => (
                            <tr key={s.id}>
                                <td style={{ ...td, fontWeight: 700 }}>{s.name}</td>
                                <td style={td}>{s.address || "—"}</td>
                                <td style={td}>{s.nature_of_work || "—"}</td>
                                <td style={td}>{s.owner_name || "—"}</td>
                                <td style={td}>{s.owner_contact || "—"}</td>
                                <td style={td}>
                                    {/* UI: Action buttons — Edit (outline) and Delete (filled) */}
                                    <div style={{ display: "flex", gap: 6 }}>
                                        {/* FLOW: Edit button — populates form with this site's data */}
                                        <button
                                            onClick={() => handleEdit(s)}
                                            style={{
                                                padding: "4px 14px",
                                                background: "var(--glass-blue)",
                                                color: "var(--primary-light, #2563eb)",
                                                border: "1px solid var(--border-subtle)",
                                                borderRadius: 6,
                                                fontSize: 12,
                                                fontWeight: 600,
                                                cursor: "pointer",
                                            }}
                                        >
                                            Edit
                                        </button>
                                        {/* FLOW: Delete button — triggers confirmation dialog then removes site */}
                                        <button
                                            onClick={() => handleDelete(s.id, s.name)}
                                            style={{
                                                padding: "4px 14px",
                                                background: "var(--glass-rose)",
                                                color: "var(--error, #991b1b)",
                                                border: "1px solid var(--border-subtle)",
                                                borderRadius: 6,
                                                fontSize: 12,
                                                fontWeight: 600,
                                                cursor: "pointer",
                                            }}
                                        >
                                            Delete
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
