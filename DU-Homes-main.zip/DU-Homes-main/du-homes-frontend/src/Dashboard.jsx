// ============================================================================
// FEATURE: Dashboard.jsx — Analytics & Overview Dashboard
// Implemented by: IT24102845
// This component provides a comprehensive real-time overview of the entire
// construction management system, aggregating data from all modules into
// visual cards, charts, tables, and statistics.
//
// FLOW: Complete dashboard journey:
//   1. Component mounts → fetches data from 8 API endpoints simultaneously
//   2. Data is processed into statistics (financial, attendance, tools, workforce)
//   3. Statistics are rendered as interactive cards, sparklines, donuts, and tables
//   4. User can filter by time range (Today / 7 Days / 30 Days)
//   5. User can manually refresh data with the refresh button
//   6. All cards have hover effects for interactive visual feedback
//
// DB: Integrates with Supabase tables: sites, workers, deployments,
//     deployment_workers, tools, tool_allocations, payments, attendance
// ============================================================================

import { useState, useEffect, useCallback, useRef } from "react";
import { apiFetch, API } from "./apiFetch";

// UI: Currency formatter — formats numbers as Sri Lankan Rupees (Rs)
const currency = (v) =>
    `Rs ${Number(v || 0).toLocaleString("en-LK", { minimumFractionDigits: 2 })}`;


// UI: Donut Chart Component
// Renders a circular progress indicator using SVG stroke-dasharray technique.
// Used for attendance rate and tool utilization percentages.
// VALIDATION: Handles zero total gracefully (shows empty ring instead of NaN)
// ============================================================================
function Donut({ value, total, color = "var(--primary, #C8102E)", trackColor = "var(--border-subtle)", size = 80, strokeWidth = 8 }) {
    const radius = (size - strokeWidth) / 2;
    const circumference = 2 * Math.PI * radius;
    const pct = total > 0 ? Math.min(Math.max(value / total, 0), 1) : 0; // VALIDATION: Prevent division by zero and clamp 0-100%
    const offset = circumference * (1 - pct);
    return (
        <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
            <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={trackColor} strokeWidth={strokeWidth} />
            <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={color} strokeWidth={strokeWidth}
                strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round"
                style={{ transition: "stroke-dashoffset 0.8s cubic-bezier(0.4,0,0.2,1)" }} />
        </svg>
    );
}

// ============================================================================
// UI: Progress Bar Component
// Horizontal bar showing proportional fill with smooth animation.
// Used throughout the dashboard for site workers, workforce breakdown, etc.
// VALIDATION: Clamps percentage to 0-100 range to prevent overflow
// ============================================================================
function ProgressBar({ value, max, color = "var(--primary, #C8102E)", height = 4, animated = false }) {
    const pct = max > 0 ? Math.min((value / max) * 100, 100) : 0; // VALIDATION: Clamp 0-100%
    return (
        <div style={{ width: "100%", height, background: "var(--border-subtle)", borderRadius: height, overflow: "hidden" }}>
            <div style={{
                width: `${pct}%`, height: "100%", background: animated
                    ? `linear-gradient(90deg, ${color}, ${color}cc, ${color})`
                    : color,
                borderRadius: height, transition: "width 0.8s cubic-bezier(0.4,0,0.2,1)",
            }} />
        </div>
    );
}

// ============================================================================
// UI: Animated Counter Hook
// Smoothly animates a number from 0 to the target value over a duration.
// Creates a counting-up effect when dashboard cards first appear.
// ============================================================================
function useAnimatedCount(target, duration = 600) {
    const [count, setCount] = useState(0);
    useEffect(() => {
        if (target === 0) {
            // eslint-disable-next-line react-hooks/set-state-in-effect
            setCount(0);
            return;
        }
        let start = 0;
        const step = target / (duration / 16);
        const timer = setInterval(() => {
            start += step;
            if (start >= target) { setCount(target); clearInterval(timer); }
            else setCount(Math.floor(start));
        }, 16);
        return () => clearInterval(timer);
    }, [target, duration]);
    return count;
}

// UI: Animated Number Display — renders a smoothly counting number with optional prefix/suffix
function AnimatedNumber({ value, prefix = "", suffix = "", color, size = 28 }) {
    const animated = useAnimatedCount(value);
    return (
        <span style={{ fontSize: size, fontWeight: 800, color, lineHeight: 1.1, fontVariantNumeric: "tabular-nums" }}>
            {prefix}{typeof value === "number" && value >= 1000
                ? currency(animated).replace("Rs ", prefix === "" ? "Rs " : "")
                : animated}{suffix}
        </span>
    );
}

// ============================================================================
// FEATURE: Main Dashboard Component
// DB: Fetches and aggregates data from 8 Supabase-backed API endpoints:
//   - /fields (sites), /workers, /deployments, /tools, /tool-allocations,
//   - /payments (today + month range), /attendance
// UI: Renders 6 rows of visual analytics:
//   Row 1: Financial summary cards with sparklines
//   Row 2: Quick stat counters (sites, workers, deployed, attendance, tools)
//   Row 3: Glass panels (attendance donut, monthly overview sparkline)
//   Row 4: Data tables (workers by site, top workers)
//   Row 5: Tool glass panels (utilization donut, low stock alerts)
//   Row 6: Workforce breakdown + active tool allocations table
// ============================================================================
export default function Dashboard() {
    // DB: Date calculations for API query parameters
    const today = new Date().toISOString().slice(0, 10);
    const monthStart = today.slice(0, 7) + "-01";
    const [year, mon] = today.slice(0, 7).split("-").map(Number);
    const monthEnd = `${today.slice(0, 7)}-${String(new Date(year, mon, 0).getDate()).padStart(2, "0")}`;

    // DB: State for data fetched from Supabase via API endpoints
    const [sites, setSites] = useState([]);           // DB: From 'sites' table via /fields
    const [workers, setWorkers] = useState([]);       // DB: From 'workers' table via /workers
    const [todayDeps, setTodayDeps] = useState([]);   // DB: From 'deployments' table, filtered by today
    const [tools, setTools] = useState([]);           // DB: From 'tools' table via /tools
    const [allocations, setAllocations] = useState([]); // DB: From 'tool_allocations' table
    const [todayPayments, setTodayPayments] = useState([]); // DB: From 'payments' table, today only
    const [monthPayments, setMonthPayments] = useState([]); // DB: From 'payments' table, current month range
    const [attendance, setAttendance] = useState([]);  // DB: From 'attendance' table, today only
    const [officers, setOfficers] = useState([]);      // DB: From 'officers' table
    const [assignments, setAssignments] = useState([]); // DB: From 'assignments' table
    const [deletedWorkers, setDeletedWorkers] = useState([]); // DB: From 'deleted_entities' table

    // UI: AI Chat refs & formatting
    const chatEndRef = useRef(null);
    function formatAIMessage(text) {
        if (!text) return "";
        
        let html = text
            // Remove robotic labels first
            .replace(/Actionable follow-up suggestion:\s*/gi, '')
            .replace(/Recommendation:\s*/gi, '')
            
            // Format headers
            .replace(/###\s+(.+)/g, '<h4 style="color:var(--text-primary); margin: 12px 0 6px 0; font-size: 14px; font-weight: 700;">$1</h4>')
            
            // 1. Highlight names in quotes
            .replace(/"([^"]+)"/g, '<span style="color:var(--primary-light, #2563eb);font-weight:600;background:var(--glass-blue);padding:2px 6px;border-radius:4px;">$1</span>')
            
            // 2. Bold text
            .replace(/\*\*(.*?)\*\*/g, '<b style="color:var(--text-primary); font-weight: 700;">$1</b>')
            
            // 3. Highlight currency (green for positive context)
            .replace(/(Rs[\s]?[\d,]+\.?\d*)/g, '<span style="color:var(--success, #16a34a);font-weight:700;background:var(--glass-green);padding:2px 6px;border-radius:4px;">$1</span>')
            
            // 4. Beautiful alert boxes
            .replace(/⚠️\s*(.*?)(?:\n|$)/g, '<div style="background:var(--glass-amber); border-left:4px solid var(--warning, #f59e0b); padding:12px 16px; border-radius:8px; margin:10px 0; font-size:13px; color:var(--warning, #92400e);"><b>[ALERT]</b> $1</div>')
            
            // 5. Success messages
            .replace(/✅\s*(.+?)(?:\n|$)/g, '<div style="background:var(--glass-green); border-left:4px solid var(--success, #16a34a); padding:12px 16px; border-radius:8px; margin:10px 0; font-size:13px; color:var(--success, #166534);"><b>[OK]</b> $1</div>')
            
            // 6. Line breaks
            .replace(/\n/g, '<br/>');

        // Handle bullet points with proper structure
        if (/^[*\-+]\s+/m.test(text)) {
            html = html.replace(/^[*\-+]\s+(.+)$/gm, '<li style="margin-left:20px; margin-bottom:8px; padding:4px 0; border-left:2px solid var(--border-subtle); padding-left:12px; color:var(--text-soft);">$1</li>');
        }

        return html;
    }


    // UI: Loading and interaction state
    const [loading, setLoading] = useState(true);
    const [timeRange, setTimeRange] = useState("today"); // UI: Time range filter selection
    const [hoveredCard, setHoveredCard] = useState(null); // UI: Tracks which card is hovered for elevation effect

    // FEATURE: AI Report Analyst State
    const [isAIChatOpen, setIsAIChatOpen] = useState(false);
    const [aiInput, setAiInput] = useState("");
    const [isAiLoading, setIsAiLoading] = useState(false);
    const [aiChatLog, setAiChatLog] = useState([
        { role: "assistant", text: "Hi! I'm your AI Dashboard Analyst. I have access to all your current construction stats (attendance, payroll, tools). What would you like to know?" }
    ]);

    // UI: Auto-scroll chat to bottom when new messages arrive
    useEffect(() => {
        if (chatEndRef.current) {
            chatEndRef.current.scrollIntoView({ behavior: "smooth" });
        }
    }, [aiChatLog, isAiLoading]);


    // ========================================================================
    // SYSTEM LOGIC: Master Data Fetcher (Performance Optimization)
    // FLOW: Instead of fetching one by one, we use Promise.all to trigger
    // all 10 API requests simultaneously.
    // 1. Trigger all -> 2. Wait for all -> 3. Success checks -> 4. Loading off.
    // ========================================================================
    const fetchAll = useCallback(async () => {
        setLoading(true);
        try {
            // GOAL: Fetch data from 10 different database tables in parallel.
            const [rS, rW, rD, rT, rA, rTP, rMP, rAtt, rOff, rAss, rDelW] = await Promise.all([
                apiFetch(`${API}/fields`),
                apiFetch(`${API}/workers`),
                apiFetch(`${API}/deployments?date=${today}`),
                apiFetch(`${API}/tools`),
                apiFetch(`${API}/tool-allocations`),
                apiFetch(`${API}/payments?date=${today}`),
                apiFetch(`${API}/payments?from=${monthStart}&to=${monthEnd}`),
                apiFetch(`${API}/attendance?date=${today}`),
                apiFetch(`${API}/officers`),
                apiFetch(`${API}/assignments`),
                apiFetch(`${API}/deleted-entities?type=worker`),
            ]);
            
            // GOAL: Individual Response Validation
            // We check if (rS.ok) before saving to state. This prevents one failed
            // API call from breaking the entire dashboard.
            if (rS.ok) setSites(await rS.json());
            if (rW.ok) setWorkers(await rW.json());
            if (rD.ok) setTodayDeps(await rD.json());
            if (rT.ok) setTools(await rT.json());
            if (rA.ok) setAllocations(await rA.json());
            if (rTP.ok) setTodayPayments(await rTP.json());
            if (rMP.ok) setMonthPayments(await rMP.json());
            if (rAtt.ok) setAttendance(await rAtt.json());
            if (rOff.ok) setOfficers(await rOff.json());
            if (rAss.ok) setAssignments(await rAss.json());
            if (rDelW && rDelW.ok) setDeletedWorkers(await rDelW.json());
        } catch (err) {
            console.error("Dashboard fetch error:", err);
        }
        setLoading(false);
    }, [today, monthStart, monthEnd]);

    // FLOW: Trigger initial data fetch when component mounts
    useEffect(() => {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        fetchAll();
    }, [fetchAll]);

    // ========================================================================
    // FEATURE: Statistics Computation
    // FLOW: Step 2 — Process raw API data into meaningful dashboard metrics
    // ========================================================================

    // DB: Extract unique workers deployed today from deployment_workers join data
    const todayWorkersList = [];
    todayDeps.forEach((d) => {
        (d.deployment_workers || []).forEach((dw) => {
            if (!todayWorkersList.find((w) => w.worker_id === dw.worker_id)) todayWorkersList.push(dw);
        });
    });

    // DB: Attendance statistics from today's attendance records
    const presentToday = attendance.filter((a) => a.status === "present").length;
    const absentToday = attendance.filter((a) => a.status === "absent").length;
    const totalDeployed = todayWorkersList.length;

    // DB: Today's payment statistics — split by paid/pending status
    const todayPaid = todayPayments.filter((p) => p.status === "paid");
    const todayPending = todayPayments.filter((p) => p.status === "pending");
    const todayNetPaid = todayPaid.reduce((s, p) => s + Number(p.net_pay || 0), 0);
    const todayNetPending = todayPending.reduce((s, p) => s + Number(p.net_pay || 0), 0);
    const todayTotal = todayNetPaid + todayNetPending;

    // DB: Monthly payment aggregation — total, paid, pending, unique days and workers
    const monthPaid = monthPayments.filter((p) => p.status === "paid");
    const monthTotalNet = monthPayments.reduce((s, p) => s + Number(p.net_pay || 0), 0);
    const monthPaidNet = monthPaid.reduce((s, p) => s + Number(p.net_pay || 0), 0);
    const monthPendingNet = monthTotalNet - monthPaidNet;
    const monthUniqueDays = new Set(monthPayments.map((p) => p.date)).size;
    const monthUniqueWorkers = new Set(monthPayments.map((p) => p.worker_id)).size;

    // DB: Tool inventory statistics from tools and tool_allocations tables
    const totalToolQty = tools.reduce((s, t) => s + (t.total_qty || 0), 0);
    const totalToolAvail = tools.reduce((s, t) => s + (t.available || 0), 0);
    const toolsInUse = totalToolQty - totalToolAvail;
    const activeAllocations = allocations.filter((a) => a.status === "allocated" || !a.returned_date);
    const lowStockTools = tools.filter((t) => Number(t.available || 0) <= 2); // VALIDATION: Flag tools with 2 or fewer available
    const activeWorkers = workers.filter((w) => !w.status || w.status === "active").length;

    // DB: Aggregate workers per site from today's deployments for the site breakdown chart
    const siteDeployments = {};
    todayDeps.forEach((d) => {
        const sName = d.sites?.name || sites.find((s) => s.id === d.site_id)?.name || "Unknown";
        if (!siteDeployments[d.site_id]) siteDeployments[d.site_id] = { name: sName, count: 0 };
        siteDeployments[d.site_id].count += (d.deployment_workers || []).length;
    });
    const siteBreakdown = Object.values(siteDeployments).sort((a, b) => b.count - a.count);

    // DB: Calculate top workers by total monthly pay from payments table
    const workerPayTotals = {};
    monthPayments.forEach((p) => {
        const wid = p.worker_id;
        if (!workerPayTotals[wid]) workerPayTotals[wid] = {
            name: p.workers?.full_name || workers.find((w) => w.id === wid)?.full_name || deletedWorkers.find((d) => d.entity_id === wid)?.entity_name || "Unknown",
            total: 0, days: 0,
        };
        workerPayTotals[wid].total += Number(p.net_pay || 0);
        workerPayTotals[wid].days++;
    });
    const topWorkers = Object.values(workerPayTotals).sort((a, b) => b.total - a.total).slice(0, 5);

    // DB: Build daily payment data array for sparkline chart visualization
    const dailyPayMap = {};
    monthPayments.forEach((p) => {
        const d = p.date || "";
        dailyPayMap[d] = (dailyPayMap[d] || 0) + Number(p.net_pay || 0);
    });
    const dailyPayData = Object.keys(dailyPayMap).sort().map((k) => dailyPayMap[k]);
    if (dailyPayData.length < 2) dailyPayData.push(0, 0); // VALIDATION: Ensure minimum 2 points for sparkline

    // DB: Worker type breakdown from workers table (e.g., mason, laborer, carpenter)
    const workerTypes = {};
    workers.forEach((w) => {
        const t = w.worker_type || "other";
        workerTypes[t] = (workerTypes[t] || 0) + 1;
    });
    const workerTypeEntries = Object.entries(workerTypes).sort((a, b) => b[1] - a[1]);

    // ========================================================================
    // UI: User Greeting
    // DB: Reads user data from localStorage (stored during login) to
    // personalize the greeting with the user's first name.
    // ========================================================================
    const user = (() => {
        try { return JSON.parse(localStorage.getItem("user") || "{}"); } catch { return {}; }
    })();
    const greeting = (() => {
        const h = new Date().getHours();
        if (h < 12) return "Good Morning";
        if (h < 17) return "Good Afternoon";
        return "Good Evening";
    })();
    const dateStr = new Date().toLocaleDateString("en-US", {
        weekday: "long", year: "numeric", month: "long", day: "numeric",
    });

    // ========================================================================
    // UI: Style Definitions
    // Reusable style objects for cards, glass panels, tables, badges, etc.
    // Cards have hover effects (elevation + shadow) for interactive feedback.
    // ========================================================================
    const makeCard = (key) => ({
        background: "var(--bg-surface-elevated)",
        borderRadius: 16,
        padding: "20px 22px",
        border: "1px solid var(--border-subtle)",
        position: "relative",
        overflow: "hidden",
        boxShadow: hoveredCard === key ? "var(--shadow-lg)" : "var(--shadow-md)",
        transition: "all 0.3s ease",
        transform: hoveredCard === key ? "translateY(-2px)" : "none",
        cursor: "default",
    });

    // UI: Glass morphism panel styles — semi-transparent with blur backdrop
    const glassPanel = {
        borderRadius: 20, padding: "26px 30px", position: "relative", overflow: "hidden",
        border: "1px solid var(--border-subtle)",
        boxShadow: "var(--shadow-md)",
        backdropFilter: "blur(24px)", WebkitBackdropFilter: "blur(24px)",
    };

    // UI: Color-themed glass panels for different data sections
    const glassGreen = { ...glassPanel, background: "var(--glass-green)" };
    const glassBlue = { ...glassPanel, background: "var(--glass-blue)" };
    const glassPurple = { ...glassPanel, background: "var(--glass-purple)" };
    const glassRose = { ...glassPanel, background: "var(--glass-rose)" };

    // UI: Reusable typography and component styles
    const metricLabel = { 
        fontSize: 12, 
        color: "var(--text-muted)", 
        fontWeight: 500, 
        marginBottom: 8, 
        letterSpacing: 0.3 
    };
    const metricValue = { fontSize: 28, fontWeight: 800, lineHeight: 1.1 };
    const sectionTitle = { 
        fontSize: 15, 
        fontWeight: 700, 
        color: "var(--text-primary)", 
        margin: "0 0 16px" 
    };
    const pillBtn = (active) => ({
        padding: "7px 18px",
        borderRadius: 20,
        border: active ? "none" : "1px solid var(--border-subtle)",
        background: active ? "var(--primary, #C8102E)" : "var(--bg-surface)",
        color: active ? "#fff" : "var(--text-muted)",
        fontSize: 12,
        fontWeight: 600,
        cursor: "pointer",
        transition: "all 0.25s ease",
        boxShadow: active ? "0 2px 8px rgba(200,16,46,0.25)" : "none",
    });
    const th = {
        padding: "10px 12px", textAlign: "left", fontSize: 11, fontWeight: 600,
        color: "var(--text-soft)", borderBottom: "1px solid var(--border-subtle)", textTransform: "uppercase", letterSpacing: 0.5,
    };
    const td = { padding: "10px 12px", fontSize: 13, borderBottom: "1px solid var(--border-subtle)", color: "var(--text-primary)" };
    const badge = (bg, color) => ({
        display: "inline-block", padding: "3px 10px", borderRadius: 20,
        fontSize: 11, fontWeight: 600, background: bg, color,
    });

    // ========================================================================
    // UI: Loading State
    // FLOW: Shown while all 8 API endpoints are being fetched.
    // Displays a spinning loader with "Loading dashboard..." text.
    // ========================================================================
    if (loading) {
        return (
            <div style={{ padding: 80, textAlign: "center" }}>
                <div style={{ position: "relative", width: 56, height: 56, margin: "0 auto" }}>
                    <div style={{
                        width: 56, height: 56, border: "4px solid #f1f5f9", borderTopColor: "#C8102E",
                        borderRadius: "50%", animation: "spin 0.8s linear infinite",
                    }} />
                </div>
                <p style={{ color: "var(--text-muted)", marginTop: 20, fontSize: 14, fontWeight: 500 }}>Loading dashboard...</p>
            </div>
        );
    }

    // ========================================================================
    // FEATURE: AI Chatbot Handler
    // Compiles stats into context and hits the Gemini API
    // ========================================================================
    const handleAiSubmit = async (e, textOverride) => {
        if (e && e.preventDefault) e.preventDefault();
        const userAsk = (textOverride || aiInput).trim();
        if (!userAsk) return;

        setAiInput("");
        setAiChatLog((prev) => [...prev, { role: "user", text: userAsk }]);
        setIsAiLoading(true);

        // ========================================================================
        // SYSTEM LOGIC: AI Context Injections (RAG Concept)
        // FLOW: 1. Read local state -> 2. Summarize into 'dashboardContext' ->
        // 3. Send to AI. This allows the AI to "see" the exact numbers on screen.
        // ========================================================================
        const dashboardContext = {
            currentDate: new Date().toLocaleDateString(),
            workers: workers.map(w => ({ id: w.id, full_name: w.full_name, type: w.worker_type })),
            stats: {
                totalSites: sites.length,
                totalWorkers: workers.length,
                deployedToday: totalDeployed,
                presentToday: presentToday,
                absentToday: absentToday,
                attendanceRate: totalDeployed > 0 ? Math.round((presentToday / totalDeployed) * 100) : 0
            },
            
            // GOAL: Smart insights - preemptively calculating trends for the AI
            insights: {
                isAttendancePerfect: absentToday === 0 && totalDeployed > 0,
                hasAbsenceIssues: absentToday > 0,
                hasPendingPayments: todayPending.length > 0 || monthPendingNet > 0,
                criticalLowStock: lowStockTools.length,
                topSite: siteBreakdown.length > 0 ? siteBreakdown[0] : null,
                generalStatus: absentToday === 0 && lowStockTools.length === 0 && monthPendingNet < 10000 ? "Excellent" : "Needs Attention"
            },

            todayDeployments: siteBreakdown.map(site => {
                const siteWorkers = todayDeps
                    .filter(d => sites.find(s => s.id === d.site_id)?.name === site.name || (d.sites?.name === site.name))
                    .flatMap(d => (d.deployment_workers || []).map(dw => {
                        const worker = workers.find(w => w.id === dw.worker_id);
                        const deletedWorker = !worker ? deletedWorkers.find(d => d.entity_id === dw.worker_id) : null;
                        return {
                            name: worker?.full_name || deletedWorker?.entity_name || null,
                            type: worker?.worker_type || "unspecified",
                            task: dw.task || null,
                            isPresent: attendance.some(a => a.worker_id === dw.worker_id && a.status === "present")
                        };
                    }));

                return {
                    siteName: site.name,
                    workerCount: site.count,
                    workerDetails: siteWorkers, 
                    hasIssues: siteWorkers.some(w => !w.isPresent || !w.task)
                };
            }).slice(0, 5), 
            finances: {
                todayTotal: currency(todayTotal),
                monthlyPayroll: currency(monthTotalNet),
                paidThisMonth: currency(monthPaidNet),
                pendingPayments: currency(monthPendingNet)
            },
            toolAlerts: lowStockTools.map(t => `${t.name} (${t.available} left)`).slice(0, 5)
        };

        try {
            const res = await apiFetch(`${API}/ai/chat`, {
                method: "POST",
                body: JSON.stringify({
                    message: userAsk,
                    userName: user.full_name,
                    history: aiChatLog.slice(-10),
                    context: dashboardContext,
                    currentPage: "dashboard"
                })
            });

            const data = await res.json();
            if (!res.ok) throw new Error(data.error || "Failed to reach backend Agent.");
            const aiReply = data.text || "I couldn't analyze that right now.";
            setAiChatLog((prev) => [...prev, { role: "assistant", text: aiReply }]);
        } catch (error) {
            setAiChatLog((prev) => [...prev, {
                role: "assistant",
                text: `**Connection Error:** ${error.message}\n\nPlease check your internet connection and try again.`,
                isError: true
            }]);
        } finally {
            setIsAiLoading(false);
        }
    };

    const getSmartQuickReplies = () => {
        const replies = [];
        
        // Always available
        replies.push({ label: "Today's Overview", text: "Give me a comprehensive overview of today's operations" });
        
        // Context-aware suggestions
        if (absentToday > 0) {
            replies.push({ label: `${absentToday} Absent`, text: `Who are the ${absentToday} workers that didn't show up today?` });
        }
        
        if (siteBreakdown.length > 0) {
            replies.push({ label: siteBreakdown[0].name, text: `How are things going at ${siteBreakdown[0].name}?` });
        }
        
        if (lowStockTools.length > 0) {
            replies.push({ label: `${lowStockTools.length} Low Stock`, text: `Which tools are running low and need restocking?` });
        }
        
        if (monthPendingNet > 0) {
            replies.push({ label: "Pending Payments", text: "Show me the breakdown of pending payments this month" });
        }
        
        replies.push({ label: "Issues", text: "What are the top 3 issues that need my immediate attention?" });
        
        return replies.slice(0, 6);
    };

    // ========================================================================
    // FLOW: Step 3 — Render the complete dashboard with all computed statistics
    // UI: Layout uses CSS Grid for responsive multi-column arrangements
    // ========================================================================
    return (
        <div style={{ 
            maxWidth: 1400, 
            margin: "0 auto", 
            position: "relative", 
            minHeight: "100vh",
            background: "var(--bg-body)",
            color: "var(--text-primary)",
            transition: "all 0.3s ease",
            padding: 20
        }}>

            {/* ================================================================
                UI: Dashboard Header with Personalized Greeting
                DB: Displays user's name from localStorage session data.
                FEATURE: Time range filter pills (Today / 7 Days / 30 Days)
                and a manual refresh button for real-time data updates.
            ================================================================ */}
            <div style={{
                display: "flex", justifyContent: "space-between", alignItems: "flex-start",
                marginBottom: 30, flexWrap: "wrap", gap: 16,
            }}>
                <div>
                    <h2 style={{ margin: 0, fontWeight: 800, fontSize: 28, color: "var(--text-primary)", letterSpacing: -0.5 }}>
                        Hello, {user.full_name?.split(" ")[0] || user.email?.split("@")[0] || "there"}
                    </h2>
                    <p style={{ margin: "6px 0 0", color: "var(--text-muted)", fontSize: 14 }}>
                        {greeting} — {dateStr}
                    </p>
                </div>
                {/* UI: Time range filter pills and refresh button */}
                <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                    <div style={{ display: "flex", gap: 6, background: "var(--bg-surface-elevated)", padding: 4, borderRadius: 24, border: "1px solid var(--border-subtle)" }}>
                        {["today", "7days", "30days"].map((range) => (
                            <button key={range} style={pillBtn(timeRange === range)} onClick={() => setTimeRange(range)}>
                                {range === "today" ? "Today" : range === "7days" ? "7D" : "30D"}
                            </button>
                        ))}
                    </div>
                    {/* FLOW: Step 5 — Manual refresh re-fetches all 8 API endpoints */}
                    <button onClick={fetchAll} style={{
                        width: 36, height: 36, borderRadius: "50%", border: "1px solid var(--border-subtle)",
                        background: "var(--bg-surface-elevated)", cursor: "pointer", display: "flex", alignItems: "center",
                        justifyContent: "center", fontSize: 16, color: "var(--text-muted)", transition: "all 0.2s",
                    }} title="Refresh">&#x21bb;</button>
                </div>
            </div>

            {/* ================================================================
                FEATURE: Row 1 — Financial Summary Cards
                DB: Data sourced from 'payments' table (today + monthly range).
                UI: Each card shows a currency value, sparkline trend chart,
                and a progress bar indicating paid vs total ratio.
                Shows: Total Payroll, Paid Amount, Pending Amount, Today's Payments
            ================================================================ */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16, marginBottom: 22 }}>
                {[
                    { key: "payroll", label: "Total Payroll (Month)", value: monthTotalNet, color: "#C8102E", pv: monthPaidNet, pm: monthTotalNet },
                    { key: "paid", label: "Paid Amount", value: monthPaidNet, color: "#16a34a", pv: monthPaidNet, pm: monthTotalNet },
                    { key: "pending", label: "Pending Amount", value: monthPendingNet, color: "#f59e0b", pv: monthPendingNet, pm: monthTotalNet },
                    { key: "today_pay", label: "Today's Payments", value: todayTotal, color: "#2563eb", pv: todayNetPaid, pm: todayTotal },
                ].map((item) => (
                    <div key={item.key} style={makeCard(item.key)}
                        onMouseEnter={() => setHoveredCard(item.key)} onMouseLeave={() => setHoveredCard(null)}>
                        {/* UI: Colored accent line at the top of each card */}
                        <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, background: `linear-gradient(90deg, ${item.color}, ${item.color}44)` }} />
                        <div style={metricLabel}>{item.label}</div>
                        <div style={{ ...metricValue, color: item.color }}>{currency(item.value)}</div>

                        {/* UI: Today's payment card shows paid/pending count badges */}
                        {item.key === "today_pay" && (
                            <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
                                <span style={badge("#dcfce7", "#166534")}>{todayPaid.length} Paid</span>
                                <span style={badge("#fef3c7", "#92400e")}>{todayPending.length} Pending</span>
                            </div>
                        )}
                        {/* UI: Progress bar showing proportion of paid vs total */}
                        <div style={{ marginTop: 10 }}>
                            <ProgressBar value={item.pv} max={item.pm} color={item.color} height={3} animated />
                        </div>
                    </div>
                ))}
            </div>

            {/* ================================================================
                FEATURE: Row 2 — Quick Statistics Counters
                DB: Aggregated from sites, workers, deployments, attendance, tools tables.
                UI: Compact cards showing key numbers with contextual subtitles.
                Shows: Active Sites, Total Workers, Deployed Today, Present Today,
                       Tool Types, Tools In Use
            ================================================================ */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 14, marginBottom: 22 }}>
                {[
                    { key: "sites", label: "Active Sites", value: sites.length, sub: `${siteBreakdown.length} with deployments`, color: "#C8102E" },
                    { key: "workers", label: "Total Workers", value: workers.length, sub: `${activeWorkers} active`, color: "#16a34a" },
                    { key: "deployed", label: "Deployed Today", value: totalDeployed, sub: `${todayDeps.length} deployments`, color: "#2563eb" },
                    { key: "present", label: "Present Today", value: presentToday, sub: `${absentToday} absent`, color: "#16a34a", subColor: "#dc2626" },
                    { key: "toolTypes", label: "Tool Types", value: tools.length, sub: `${totalToolQty} total items`, color: "#7c3aed" },
                    { key: "toolsUse", label: "Tools In Use", value: toolsInUse, sub: `${activeAllocations.length} allocations`, color: "#ea580c" },
                ].map((item) => (
                    <div key={item.key} style={makeCard(item.key)}
                        onMouseEnter={() => setHoveredCard(item.key)} onMouseLeave={() => setHoveredCard(null)}>
                        <div style={{ 
                            fontSize: 11, 
                            color: "var(--text-soft)", 
                            fontWeight: 600, 
                            marginBottom: 6, 
                            textTransform: "uppercase", 
                            letterSpacing: 0.5 
                        }}>{item.label}</div>
                        <div style={{ fontSize: 30, fontWeight: 800, color: item.color, lineHeight: 1 }}>{item.value}</div>
                        <div style={{ fontSize: 12, color: item.subColor || "var(--text-muted)", marginTop: 6, fontWeight: 500 }}>{item.sub}</div>
                    </div>
                ))}
            </div>

            {/* ================================================================
                FEATURE: Row 3 — Glass Morphism Analytics Panels
                Two side-by-side panels with frosted glass visual effect:
                Left: Today's Attendance with donut chart and present/absent/total
                Right: Monthly Overview with sparkline and active days/workers/records
            ================================================================ */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 22 }}>

                {/* ============================================================
                    FEATURE: Attendance Summary Panel
                    DB: Data from 'attendance' table filtered by today's date.
                    UI: Donut chart shows attendance rate percentage, with
                    present/absent/total counters alongside.
                ============================================================ */}
                <div style={glassGreen}>
                    <div style={{ fontSize: 16, fontWeight: 700, color: "var(--text-primary)", marginBottom: 22 }}>Today's Attendance</div>
                    <div style={{ display: "flex", alignItems: "center", gap: 28 }}>
                        {/* UI: Donut chart with attendance percentage in the center */}
                        <div style={{ position: "relative", width: 110, height: 110, flexShrink: 0 }}>
                            <Donut value={presentToday} total={presentToday + absentToday || 1} color="#16a34a" trackColor="rgba(22,163,74,0.12)" size={110} strokeWidth={12} />
                            <div style={{
                                position: "absolute", top: "50%", left: "50%",
                                transform: "translate(-50%, -50%)", textAlign: "center",
                            }}>
                                <div style={{ fontSize: 24, fontWeight: 800, color: "var(--text-primary)" }}>
                                    {/* VALIDATION: Handle zero total to prevent NaN display */}
                                    {presentToday + absentToday > 0 ? Math.round((presentToday / (presentToday + absentToday)) * 100) : 0}%
                                </div>
                                <div style={{ fontSize: 9, color: "var(--text-muted)", fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.5 }}>Rate</div>
                            </div>
                        </div>
                        {/* UI: Present / Absent / Total counters */}
                        <div style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                            {[
                                { label: "Present", val: presentToday, color: "#166534" },
                                { label: "Absent", val: absentToday, color: "#dc2626" },
                                { label: "Total", val: presentToday + absentToday, color: "var(--text-primary)" },
                            ].map((item) => (
                                <div key={item.label} style={{ textAlign: "center" }}>
                                    <div style={{ fontSize: 10, color: item.color, fontWeight: 600, opacity: 0.65, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 4 }}>{item.label}</div>
                                    <div style={{ fontSize: 30, fontWeight: 800, color: item.color, lineHeight: 1 }}>{item.val}</div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* ============================================================
                    FEATURE: Monthly Overview Panel
                    DB: Data from 'payments' table for the current month range.
                    UI: Sparkline chart showing daily payment trends, with
                    days active, workers paid, and total records counters.
                ============================================================ */}
                <div style={glassBlue}>
                    <div style={{ fontSize: 16, fontWeight: 700, color: "var(--text-primary)", marginBottom: 22 }}>Monthly Overview</div>
                    <div style={{ display: "flex", alignItems: "center", gap: 24 }}>

                        {/* UI: Monthly summary counters */}
                        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                            {[
                                { label: "Days Active", val: monthUniqueDays },
                                { label: "Workers Paid", val: monthUniqueWorkers },
                                { label: "Records", val: monthPayments.length },
                            ].map((item) => (
                                <div key={item.label}>
                                    <div style={{ fontSize: 10, color: "var(--text-muted)", fontWeight: 600, opacity: 0.6, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 2 }}>{item.label}</div>
                                    <div style={{ fontSize: 24, fontWeight: 800, color: "var(--text-primary)", lineHeight: 1 }}>{item.val}</div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            {/* ================================================================
                FEATURE: Row 4 — Data Tables
                Left: Workers by Site — shows worker count per site with progress bars
                Right: Top Workers This Month — ranked table of highest-paid workers
            ================================================================ */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 22 }}>

                {/* ============================================================
                    FEATURE: Workers by Site Breakdown
                    DB: Derived from 'deployments' + 'deployment_workers' +
                    'sites' tables. Shows how many workers are at each site today.
                    VALIDATION: Shows "No deployments today" if no data exists.
                ============================================================ */}
                <div style={makeCard("site_workers")} onMouseEnter={() => setHoveredCard("site_workers")} onMouseLeave={() => setHoveredCard(null)}>
                    <div style={sectionTitle}>Workers by Site</div>
                    {siteBreakdown.length === 0 ? (
                        <p style={{ color: "#94a3b8", fontSize: 13, margin: 0 }}>No deployments today</p>
                    ) : (
                        <div>
                            {siteBreakdown.map((site, i) => {
                                const colors = ["#C8102E", "#2563eb", "#16a34a", "#ca8a04", "#7c3aed"];
                                const bgs = ["#fef2f2", "#eff6ff", "#f0fdf4", "#fefce8", "#faf5ff"];
                                const c = colors[i % 5];
                                const bg = bgs[i % 5];
                                return (
                                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
                                        <div style={{
                                            width: 40, height: 40, borderRadius: 12, background: bg,
                                            display: "flex", alignItems: "center", justifyContent: "center",
                                            fontSize: 15, fontWeight: 800, color: c, flexShrink: 0,
                                        }}>{site.count}</div>
                                        <div style={{ flex: 1, minWidth: 0 }}>
                                            <div style={{ fontSize: 13, fontWeight: 600, color: "var(--text-primary)", marginBottom: 5, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{site.name}</div>
                                            <ProgressBar value={site.count} max={Math.max(...siteBreakdown.map((s) => s.count))} color={c} height={4} animated />
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </div>

                {/* ============================================================
                    FEATURE: Top Workers Leaderboard
                    DB: Aggregated from 'payments' table — ranks workers by total
                    monthly pay with day count. Top 3 get colored rank badges.
                    VALIDATION: Shows "No payment data yet" if no payments exist.
                ============================================================ */}
                <div style={makeCard("top_workers")} onMouseEnter={() => setHoveredCard("top_workers")} onMouseLeave={() => setHoveredCard(null)}>
                    <div style={sectionTitle}>Top Workers This Month</div>
                    {topWorkers.length === 0 ? (
                        <p style={{ color: "#94a3b8", fontSize: 13, margin: 0 }}>No payment data yet</p>
                    ) : (
                        <table style={{ width: "100%", borderCollapse: "collapse" }}>
                            <thead>
                                <tr>
                                    <th style={th}>#</th>
                                    <th style={th}>Worker</th>
                                    <th style={th}>Days</th>
                                    <th style={{ ...th, textAlign: "right" }}>Total Pay</th>
                                </tr>
                            </thead>
                            <tbody>
                                {topWorkers.map((w, i) => (
                                    <tr key={i}>
                                        <td style={td}>
                                            {/* UI: Rank badges — gold/blue/amber for top 3, grey for rest */}
                                            <div style={{
                                                width: 26, height: 26, borderRadius: "50%",
                                                background: i === 0 ? "var(--primary-gradient)" : i === 1 ? "var(--blue-gradient, linear-gradient(135deg, #2563eb, #60a5fa))" : i === 2 ? "var(--warning-gradient, linear-gradient(135deg, #f59e0b, #fbbf24))" : "var(--border-subtle)",
                                                color: i < 3 ? "#fff" : "var(--text-soft)",
                                                display: "flex", alignItems: "center", justifyContent: "center",
                                                fontSize: 11, fontWeight: 700,
                                                boxShadow: i < 3 ? "0 2px 6px rgba(0,0,0,0.15)" : "none",
                                            }}>{i + 1}</div>
                                        </td>
                                        <td style={{ ...td, fontWeight: 600 }}>{w.name}</td>
                                        <td style={td}>
                                            <span style={badge("var(--table-header-bg)", "var(--text-soft)")}>{w.days}d</span>
                                        </td>
                                        <td style={{ ...td, textAlign: "right", fontWeight: 700, color: "var(--primary, #C8102E)" }}>{currency(w.total)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            </div>

            {/* ================================================================
                FEATURE: Row 5 — Tool Analytics Glass Panels
                Left: Tool Utilization — donut chart + in-use/available/total/allocations
                Right: Low Stock Alerts — flags tools with 2 or fewer items available
            ================================================================ */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 22 }}>

                {/* ============================================================
                    FEATURE: Tool Utilization Panel
                    DB: Data from 'tools' and 'tool_allocations' tables.
                    UI: Donut chart showing usage percentage with detailed breakdown.
                    VALIDATION: Handles zero total_qty to prevent division by zero.
                ============================================================ */}
                <div style={glassPurple}>
                    <div style={{ fontSize: 16, fontWeight: 700, color: "var(--text-primary)", marginBottom: 18 }}>Tool Utilization</div>
                    <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
                        <div style={{ position: "relative", width: 100, height: 100, flexShrink: 0 }}>
                            <Donut value={toolsInUse} total={totalToolQty || 1} color="var(--primary-purple, #7c3aed)" trackColor="var(--glass-purple-border, rgba(124,58,237,0.1))" size={100} strokeWidth={11} />
                            <div style={{
                                position: "absolute", top: "50%", left: "50%",
                                transform: "translate(-50%, -50%)", textAlign: "center",
                            }}>
                                <div style={{ fontSize: 20, fontWeight: 800, color: "var(--text-primary)" }}>
                                    {totalToolQty > 0 ? Math.round((toolsInUse / totalToolQty) * 100) : 0}%
                                </div>
                                <div style={{ fontSize: 9, color: "var(--text-muted)", fontWeight: 600, textTransform: "uppercase" }}>Used</div>
                            </div>
                        </div>
                        {/* UI: Tool statistics breakdown list */}
                        <div style={{ flex: 1 }}>
                            {[
                                { label: "In Use", val: toolsInUse, color: "#7c3aed" },
                                { label: "Available", val: totalToolAvail, color: "#16a34a" },
                                { label: "Total Items", val: totalToolQty, color: "var(--text-primary)" },
                                { label: "Active Alloc.", val: activeAllocations.length, color: "#6b21a8" },
                            ].map((item, i) => (
                                <div key={item.label} style={{
                                    display: "flex", justifyContent: "space-between", alignItems: "center",
                                    padding: "7px 0", borderBottom: i < 3 ? "1px solid rgba(124,58,237,0.08)" : "none",
                                }}>
                                    <span style={{ fontSize: 13, color: "var(--text-muted)", fontWeight: 500 }}>{item.label}</span>
                                    <span style={{ fontSize: 15, fontWeight: 700, color: item.color }}>{item.val}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* ============================================================
                    FEATURE: Low Stock Alerts Panel
                    DB: Filters 'tools' table for items where available <= 2.
                    UI: Red-themed panel listing tools that need restocking.
                    Each tool shows a mini progress bar of remaining stock.
                    VALIDATION: Shows "All tools well stocked" checkmark if none are low.
                ============================================================ */}
                <div style={glassRose}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
                        <div style={{ fontSize: 16, fontWeight: 700, color: "var(--text-primary)" }}>Low Stock Alerts</div>
                        {lowStockTools.length > 0 && (
                            <span style={badge("var(--glass-rose)", "var(--error, #dc2626)")}>{lowStockTools.length} items</span>
                        )}
                    </div>
                        {lowStockTools.length === 0 ? (
                        <div style={{ textAlign: "center", padding: "20px 0" }}>
                            <div style={{ fontSize: 32, marginBottom: 8, opacity: 0.3, color: "#16a34a" }}>OK</div>
                            <p style={{ color: "#16a34a", fontSize: 14, margin: 0, fontWeight: 600 }}>All tools well stocked</p>
                        </div>
                    ) : (
                        <div>
                            {lowStockTools.slice(0, 5).map((tool, i) => (
                                <div key={tool.id} style={{
                                    display: "flex", justifyContent: "space-between", alignItems: "center",
                                    padding: "10px 0", borderBottom: i < Math.min(lowStockTools.length, 5) - 1 ? "1px solid rgba(244,63,94,0.1)" : "none",
                                }}>
                                    <div>
                                        <div style={{ fontSize: 13, fontWeight: 600, color: "var(--text-primary)" }}>{tool.name}</div>
                                        <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>{tool.tool_code || "No code"}</div>
                                    </div>
                                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                        {/* UI: Mini stock level bar — red if 0, amber if low */}
                                        <div style={{ width: 40, height: 4, background: "rgba(0,0,0,0.06)", borderRadius: 2, overflow: "hidden" }}>
                                            <div style={{
                                                width: `${(tool.total_qty || 1) > 0 ? ((tool.available || 0) / (tool.total_qty || 1)) * 100 : 0}%`,
                                                height: "100%", borderRadius: 2,
                                                background: Number(tool.available) === 0 ? "var(--error, #dc2626)" : "var(--warning, #f59e0b)",
                                            }} />
                                        </div>
                                        <span style={badge(
                                            Number(tool.available) === 0 ? "rgba(220,38,38,0.1)" : "rgba(245,158,11,0.1)",
                                            Number(tool.available) === 0 ? "#dc2626" : "#92400e"
                                        )}>{tool.available}/{tool.total_qty || 0}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            {/* ================================================================
                FEATURE: Row 6 — Workforce Breakdown + Active Tool Allocations
                Left: Worker type distribution (mason, laborer, etc.) with progress bars
                Right: Table of currently active tool allocations with tool/site/worker details
            ================================================================ */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 20, marginBottom: 22 }}>

                {/* ============================================================
                    FEATURE: Workforce Type Breakdown
                    DB: Groups workers from 'workers' table by worker_type field.
                    UI: Shows each type with count, percentage, and colored progress bar.
                    VALIDATION: Shows "No workers" if the workers array is empty.
                ============================================================ */}
                <div style={makeCard("worker_types")} onMouseEnter={() => setHoveredCard("worker_types")} onMouseLeave={() => setHoveredCard(null)}>
                    <div style={sectionTitle}>Workforce Breakdown</div>
                    {workerTypeEntries.length === 0 ? (
                        <p style={{ color: "#94a3b8", fontSize: 13, margin: 0 }}>No workers</p>
                    ) : (
                        <div>
                            {workerTypeEntries.map(([type, count], i) => {
                                const colors = ["#C8102E", "#2563eb", "#16a34a", "#f59e0b", "#7c3aed", "#ea580c"];
                                const c = colors[i % colors.length];
                                const pct = workers.length > 0 ? Math.round((count / workers.length) * 100) : 0;
                                return (
                                    <div key={type} style={{ marginBottom: 14 }}>
                                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                                            <span style={{ fontSize: 13, fontWeight: 600, color: "var(--text-primary)", textTransform: "capitalize" }}>{type}</span>
                                            <span style={{ fontSize: 12, fontWeight: 700, color: c }}>{count} ({pct}%)</span>
                                        </div>
                                        <ProgressBar value={count} max={workers.length} color={c} height={6} animated />
                                    </div>
                                );
                            })}
                            <div style={{ marginTop: 16, padding: "10px 0", borderTop: "1px solid var(--border-subtle)", display: "flex", justifyContent: "space-between" }}>
                                <span style={{ fontSize: 13, fontWeight: 700, color: "var(--text-primary)" }}>Total</span>
                                <span style={{ fontSize: 13, fontWeight: 800, color: "var(--text-primary)" }}>{workers.length}</span>
                            </div>
                        </div>
                    )}
                </div>

                {/* ============================================================
                    FEATURE: Active Tool Allocations Table
                    DB: Data from 'tool_allocations' table joined with tools,
                    sites, and workers tables. Filtered to show only active
                    allocations (status = "allocated" or no returned_date).
                    UI: Scrollable table showing tool, site, worker, qty, date, status.
                    VALIDATION: Shows "No active allocations" if none exist.
                    Limited to 8 rows with a "+N more" indicator for overflow.
                ============================================================ */}
                <div style={makeCard("alloc_table")} onMouseEnter={() => setHoveredCard("alloc_table")} onMouseLeave={() => setHoveredCard(null)}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                        <div style={sectionTitle}>Active Tool Allocations</div>
                        <span style={badge("var(--glass-blue)", "var(--primary-light, #2563eb)")}>{activeAllocations.length} active</span>
                    </div>
                    {activeAllocations.length === 0 ? (
                        <p style={{ color: "#94a3b8", fontSize: 13, margin: 0 }}>No active allocations</p>
                    ) : (
                        <div style={{ overflowX: "auto" }}>
                            <table style={{ width: "100%", borderCollapse: "collapse" }}>
                                <thead>
                                    <tr>
                                        <th style={th}>Tool</th>
                                    <th style={th}>Site</th>
                                        <th style={th}>Worker</th>
                                        <th style={th}>Qty</th>
                                        <th style={th}>Date</th>
                                        <th style={th}>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {activeAllocations.slice(0, 8).map((alloc, i) => {
                                        const toolName = tools.find(t => t.id === alloc.tool_id)?.name || "—";
                                        const siteName = sites.find(s => s.id === alloc.site_id)?.name || "—";
                                        const workerName = workers.find(w => w.id === alloc.worker_id)?.full_name || "—";
                                        return (
                                            <tr key={alloc.id} style={{ background: i % 2 === 0 ? "transparent" : "var(--bg-body)" }}>
                                                <td style={{ ...td, fontWeight: 600 }}>{toolName}</td>
                                                <td style={td}>{siteName}</td>
                                                <td style={td}>{workerName}</td>
                                                <td style={{ ...td, fontWeight: 700 }}>{alloc.qty || 1}</td>
                                                <td style={{ ...td, fontSize: 12, color: "var(--text-muted)" }}>{alloc.allocated_date || "—"}</td>
                                                <td style={td}>
                                                    <span style={badge("#dbeafe", "#1e40af")}>ALLOCATED</span>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                            {/* VALIDATION: Show overflow indicator if more than 8 active allocations */}
                            {activeAllocations.length > 8 && (
                                <div style={{ textAlign: "center", padding: "10px 0", fontSize: 12, color: "#94a3b8" }}>
                                    +{activeAllocations.length - 8} more allocations
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>

            {/* ================================================================
                FEATURE: AI Report Analyst Floating UI (Redesigned)
            ================================================================ */}
            {/* Chat Icon (FAB) */}
            <button
                onClick={() => setIsAIChatOpen(!isAIChatOpen)}
                style={{
                    position: "fixed", bottom: 30, right: 30, zIndex: 100,
                    width: 60, height: 60, borderRadius: "50%",
                    background: "#4f46e5",
                    color: "#fff", border: "none", boxShadow: "0 8px 25px rgba(79, 70, 229, 0.4)",
                    cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center",
                    fontSize: 24, transition: "transform 0.2s cubic-bezier(0.4, 0, 0.2, 1)",
                    transform: isAIChatOpen ? "rotate(90deg) scale(0)" : "rotate(0) scale(1)",
                }}
                title="AI Report Analyst"
            >
                <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
            </button>

            {/* Chat Window */}
            <div style={{
                position: "fixed", bottom: 40, right: 40, zIndex: 101,
                width: 380, height: 600, borderRadius: 20,
                background: "var(--bg-surface)",
                boxShadow: "var(--shadow-xl)",
                display: "flex", flexDirection: "column", overflow: "hidden",
                border: "1px solid var(--border-subtle)",
                transformOrigin: "bottom right",
                transition: "all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)",
                transform: isAIChatOpen ? "scale(1)" : "scale(0)",
                opacity: isAIChatOpen ? 1 : 0,
                pointerEvents: isAIChatOpen ? "auto" : "none",
            }}>
                {/* Header */}
                <div style={{
                    padding: "16px 20px", background: "#4f46e5",
                    color: "#fff", display: "flex", justifyContent: "space-between", alignItems: "center",
                    borderBottom: "1px solid var(--border-subtle)"
                }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <button 
                            onClick={() => setIsAIChatOpen(false)}
                            style={{
                                background: "rgba(255,255,255,0.15)", border: "none", color: "#fff",
                                padding: "4px 10px", borderRadius: 8, cursor: "pointer",
                                fontSize: 12, fontWeight: 600, display: "flex", alignItems: "center", gap: 5,
                                transition: "all 0.2s"
                            }}
                            onMouseEnter={e => e.target.style.background = "rgba(255,255,255,0.25)"}
                            onMouseLeave={e => e.target.style.background = "rgba(255,255,255,0.15)"}
                        >
                            ← Back
                        </button>
                        <div style={{ fontWeight: 600, fontSize: 16 }}>
                            Analyst Bot
                        </div>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        {/* Clear Chat Button */}
                        <button 
                            onClick={() => setAiChatLog([{ role: "assistant", text: "Hi! I'm your AI Dashboard Analyst. I have access to all your current construction stats (attendance, payroll, tools). What would you like to know?" }])}
                            style={{
                                background: "transparent", border: "none", color: "#fff",
                                fontSize: 11, cursor: "pointer", opacity: 0.7, textDecoration: "underline"
                            }}
                        >
                            Clear
                        </button>
                        <button onClick={() => setIsAIChatOpen(false)} style={{
                            background: "transparent", border: "none", color: "#fff",
                            width: 28, height: 28, borderRadius: "50%", cursor: "pointer",
                            display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, opacity: 0.8
                        }}>✕</button>
                    </div>
                </div>

                {/* Messages Log */}
                <div style={{ 
                    flex: 1, padding: 20, overflowY: "auto", 
                    display: "flex", flexDirection: "column", gap: 12, 
                    background: "var(--bg-surface)" 
                }}>
                    {aiChatLog.map((msg, idx) => (
                        <div key={idx} style={{
                            display: "flex", gap: 8,
                            alignSelf: msg.role === "user" ? "flex-end" : "flex-start",
                            maxWidth: "85%",
                        }}>
                            {msg.role !== "user" && (
                                <div style={{
                                    width: 28, height: 28, borderRadius: "50%", 
                                    background: "var(--border-subtle)",
                                    display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 800, flexShrink: 0, marginTop: 4,
                                    color: "var(--text-soft)"
                                }}>AI</div>
                            )}
                            <div style={{
                                padding: "12px 16px", fontSize: 14, lineHeight: 1.5,
                                background: msg.isError 
                                    ? "#fef2f2" 
                                    : msg.role === "user" 
                                        ? "#4f46e5" 
                                        : "var(--border-subtle)",
                                color: msg.isError 
                                    ? "#dc2626" 
                                    : msg.role === "user" 
                                        ? "#fff" 
                                        : "var(--text-primary)",
                                borderRadius: 12,
                                borderBottomRightRadius: msg.role === "user" ? 4 : 12,
                                borderTopLeftRadius: msg.role === "assistant" ? 4 : 12,
                                whiteSpace: "pre-wrap",
                            }} dangerouslySetInnerHTML={{ __html: formatAIMessage(msg.text) }} />
                        </div>
                    ))}

                    {/* Smart Context-Aware Quick Replies */}
                    {aiChatLog.length === 1 && !isAiLoading && (
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, alignSelf: "flex-end", width: "90%", marginTop: 10 }}>
                            {getSmartQuickReplies().map((reply, i) => (
                                <button
                                    key={i}
                                    onClick={() => handleAiSubmit(null, reply.text)}
                                    style={{
                                        background: "var(--bg-surface-elevated)", 
                                        border: "1px solid var(--border-subtle)", 
                                        borderRadius: 10,
                                        padding: "8px 10px", color: "#4f46e5", fontSize: 12, textAlign: "left",
                                        cursor: "pointer", transition: "all 0.2s", overflow: "hidden", 
                                        textOverflow: "ellipsis", whiteSpace: "nowrap"
                                    }}
                                    onMouseEnter={e => { e.target.style.background = "var(--bg-body)"; e.target.style.borderColor = "#4f46e5"; }}
                                    onMouseLeave={e => { e.target.style.background = "var(--bg-surface-elevated)"; e.target.style.borderColor = "var(--border-subtle)"; }}
                                >
                                    {reply.label}
                                </button>
                            ))}
                        </div>
                    )}


                    {isAiLoading && (
                        <div style={{ display: "flex", gap: 8, alignSelf: "flex-start", maxWidth: "85%" }}>
                            <div style={{ width: 28, height: 28, borderRadius: "50%", background: "#f0f4f8", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 800, flexShrink: 0, marginTop: 4, color: "#94a3b8" }}>AI</div>
                            <div style={{ padding: "12px 16px", background: "#f4f5f7", borderRadius: 12, borderTopLeftRadius: 4 }}>
                                <div style={{ display: "flex", gap: 4 }}>
                                    {[0, 1, 2].map(i => (
                                        <div key={i} style={{
                                            width: 8, height: 8, borderRadius: "50%", background: "#94a3b8",
                                            animation: `pulse 1.2s ease-in-out ${i * 0.2}s infinite`,
                                        }} />
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                    <div ref={chatEndRef} />

                </div>

                {/* Input Area */}
                <div style={{ 
                    padding: "12px 16px", 
                    borderTop: "1px solid var(--border-subtle)", 
                    background: "var(--bg-surface-elevated)", 
                    display: "flex", alignItems: "center", gap: 10 
                }}>
                    <button 
                        onClick={() => setIsAIChatOpen(false)}
                        title="Close Chat"
                        style={{
                            width: 36, height: 36, borderRadius: "50%", 
                            background: "var(--border-subtle)",
                            color: "var(--text-soft)", border: "none", cursor: "pointer",
                            display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18,
                            transition: "all 0.2s",
                        }}
                    >
                        ✕
                    </button>
                    <input
                        type="text"
                        value={aiInput}
                        onChange={(e) => setAiInput(e.target.value)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleAiSubmit(e);
                            }
                        }}
                        placeholder="Type here to chat..."
                        disabled={isAiLoading}
                        style={{
                            flex: 1, padding: "8px 0", border: "none", 
                            background: "transparent",
                            fontSize: 14, outline: "none", 
                            color: "var(--text-primary)",
                        }}
                    />
                    <button onClick={handleAiSubmit} disabled={isAiLoading || !aiInput.trim()} style={{
                        width: 36, height: 36, borderRadius: "50%", background: "#a5b4fc",
                        color: "#fff", border: "none", cursor: isAiLoading || !aiInput.trim() ? "default" : "pointer",
                        display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16,
                        transition: "all 0.2s",
                    }}
                        onMouseEnter={e => { if (!isAiLoading && aiInput.trim()) e.target.style.background = "#818cf8"; }}
                        onMouseLeave={e => { if (!isAiLoading && aiInput.trim()) e.target.style.background = "#a5b4fc"; }}
                    >
                        <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24" style={{ transform: "rotate(45deg)", marginLeft: -2 }}>
                            <line x1="22" y1="2" x2="11" y2="13"></line>
                            <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    );
}
