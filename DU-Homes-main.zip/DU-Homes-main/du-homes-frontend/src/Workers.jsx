// Workers module - implemented by IT24100144
import { useState, useEffect, useCallback, useRef } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8080";
const hdr = () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("access_token") || localStorage.getItem("token") || ""}`,
});

export default function Workers() {
    const [workers, setWorkers] = useState([]);
    const [search, setSearch] = useState("");
    const [loading, setLoading] = useState(false);
    const [msg, setMsg] = useState("");
    const msgTimeout = useRef(null);
    const flash = (text) => {
        if (msgTimeout.current) clearTimeout(msgTimeout.current);
        setMsg(text);
        msgTimeout.current = setTimeout(() => setMsg(""), 5000);
    };
    const [editing, setEditing] = useState(null);
    const [fieldErrors, setFieldErrors] = useState({});
    const [form, setForm] = useState({
        full_name: "",
        nic: "",
        phone: "",
        worker_type: "labour",
        daily_rate: "",
        emergency_contact: "",
        address: "",
    });

    // Role check
    const currentUser = (() => { try { return JSON.parse(localStorage.getItem("user") || "{}"); } catch { return {}; } })();
    const role = currentUser.role || "";
    const isViewOnly = role === "finance_officer";

    const fetchWorkers = useCallback(async () => {
        setLoading(true);
        try {
            const r = await fetch(`${API}/workers`, { headers: hdr() });
            if (r.ok) setWorkers(await r.json());
        } catch { /* ignore */ }
        setLoading(false);
    }, []);

    useEffect(() => {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        fetchWorkers();
    }, [fetchWorkers]);

    const resetForm = () => {
        setForm({
            full_name: "",
            nic: "",
            phone: "",
            worker_type: "labour",
            daily_rate: "",
            emergency_contact: "",
            address: "",
        });
        setEditing(null);
        setFieldErrors({});
    };

    const validate = () => {
        const errs = {};
        if (!form.full_name.trim()) errs.full_name = "Full name is required";
        else if (form.full_name.trim().length < 2) errs.full_name = "Name must be at least 2 characters";
        if (form.nic.trim()) {
            const nic = form.nic.trim();
            if (!/^(\d{9}[vVxX]|\d{12})$/.test(nic)) errs.nic = "Invalid NIC (9 digits + V/X or 12 digits)";
        }
        if (form.phone.trim()) {
            if (!/^\d{10}$/.test(form.phone.trim())) errs.phone = "Phone must be 10 digits";
        }
        if (form.daily_rate !== "" && Number(form.daily_rate) < 0) errs.daily_rate = "Daily rate cannot be negative";
        if (form.emergency_contact.trim()) {
            if (!/^\d{10}$/.test(form.emergency_contact.trim())) errs.emergency_contact = "Must be 10 digits";
        }
        setFieldErrors(errs);
        return Object.keys(errs).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;
        setLoading(true);
        setMsg("");
        try {
            const payload = {
                ...form,
                full_name: form.full_name.trim(),
                daily_rate: Number(form.daily_rate) || 0,
            };
            let r;
            if (editing) {
                r = await fetch(`${API}/workers/${editing}`, {
                    method: "PUT",
                    headers: hdr(),
                    body: JSON.stringify(payload),
                });
            } else {
                r = await fetch(`${API}/workers`, {
                    method: "POST",
                    headers: hdr(),
                    body: JSON.stringify(payload),
                });
            }
            if (r.ok) {
                flash(editing ? "Worker updated ✓" : "Worker added ✓");
                resetForm();
                fetchWorkers();
            } else {
                const d = await r.json();
                flash(d.error || "Save failed");
            }
        } catch (err) {
            flash(err.message);
        }
        setLoading(false);
    };

    const handleEdit = (w) => {
        setEditing(w.id);
        setForm({
            full_name: w.full_name || "",
            nic: w.nic || "",
            phone: w.phone || "",
            worker_type: w.worker_type || "labour",
            daily_rate: w.daily_rate || "",
            emergency_contact: w.emergency_contact || "",
            address: w.address || "",
        });
        window.scrollTo({ top: 0, behavior: "smooth" });
    };

    const handleDelete = async (id, workerName) => {
        // Confirmation dialog — explain what will happen
        const confirmed = confirm(
            `Remove "${workerName}" from the active workers list?\n\n` +
            `• If this worker has no past records → permanently deleted.\n` +
            `• If this worker has past records (payments, attendance, etc.) → archived (records preserved).\n` +
            `• If this worker is in a current/upcoming deployment → blocked.`
        );
        if (!confirmed) return;
        setLoading(true);
        try {
            const r = await fetch(`${API}/workers/${id}`, {
                method: "DELETE",
                headers: hdr(),
            });
            const d = await r.json();
            if (r.ok) {
                // Show archived vs deleted message
                flash(d.archived ? `Archived ✓ — ${d.detail}` : `Deleted ✓`);
                fetchWorkers();
            } else {
                flash(d.detail || d.error || "Delete failed");
            }
        } catch (err) {
            flash(err.message);
        }
        setLoading(false);
    };

    const filtered = workers.filter((w) => {
        const q = search.toLowerCase();
        return (
            (w.full_name || "").toLowerCase().includes(q) ||
            (w.nic || "").toLowerCase().includes(q) ||
            (w.phone || "").toLowerCase().includes(q) ||
            (w.worker_type || "").toLowerCase().includes(q)
        );
    });

    /* ---- STATS (Average Daily Salary card REMOVED) ---- */
    const totalWorkers = workers.length;
    const workerTypes = {};
    workers.forEach((w) => {
        const t = w.worker_type || "other";
        workerTypes[t] = (workerTypes[t] || 0) + 1;
    });

    const card = {
        background: "var(--bg-surface)",
        borderRadius: 12,
        padding: "18px 24px",
        textAlign: "center",
        border: "1px solid var(--border-subtle)",
        minWidth: 160,
        boxShadow: "var(--shadow-sm)",
        color: "var(--text-primary)",
    };
    const th = {
        padding: "10px 10px",
        borderBottom: "2px solid var(--border-subtle)",
        textAlign: "left",
        fontSize: 13,
        fontWeight: 700,
        background: "var(--table-header-bg)",
        color: "var(--text-primary)",
        whiteSpace: "nowrap",
    };
    const td = {
        padding: "10px 10px",
        borderBottom: "1px solid var(--border-subtle)",
        fontSize: 13,
        color: "var(--text-primary)",
        verticalAlign: "middle",
    };
    const inp = {
        width: "100%",
        padding: "9px 12px",
        borderRadius: 8,
        border: "1px solid var(--input-border)",
        background: "var(--input-bg)",
        color: "var(--input-text)",
        fontSize: 14,
        boxSizing: "border-box",
    };
    const inpErr = (field) => ({
        ...inp,
        border: fieldErrors[field] ? "1px solid var(--error-border, #dc2626)" : "1px solid var(--input-border)",
        background: fieldErrors[field] ? "var(--glass-rose)" : "var(--input-bg)",
    });
    const errText = { color: "var(--error, #dc2626)", fontSize: 11, marginTop: 2, fontWeight: 500 };
    const btnPrimary = {
        background: "var(--primary-gradient, linear-gradient(135deg, #991b1b, #c8102e))",
        color: "#fff",
        border: "none",
        padding: "10px 28px",
        borderRadius: 8,
        fontWeight: 700,
        fontSize: 14,
        cursor: "pointer",
        transition: "opacity 0.2s",
    };
    const btnSecondary = {
        background: "var(--border-subtle)",
        color: "var(--text-primary)",
        border: "none",
        padding: "10px 20px",
        borderRadius: 8,
        fontWeight: 600,
        fontSize: 14,
        cursor: "pointer",
    };

    return (
        <div>
            <h2 style={{ fontSize: 22, fontWeight: 800, marginBottom: 20 }}>
                {isViewOnly ? "Workers Directory" : "Workers Management"}
            </h2>

                {msg && (
                <div
                    style={{
                        padding: "10px 16px",
                        borderRadius: 8,
                        marginBottom: 16,
                        background: msg.includes("✓") ? "var(--glass-green)" : "var(--glass-rose)",
                        color: msg.includes("✓") ? "var(--success, #166534)" : "var(--error, #991b1b)",
                        border: `1px solid ${msg.includes("✓") ? "var(--success-border, #16653433)" : "var(--error-border, #dc262633)"}`,
                        fontWeight: 600,
                        fontSize: 14,
                    }}
                >
                    {msg}
                </div>
                )}

            {/* ---- Stats: Only Total Workers + Worker Types (NO average daily salary) ---- */}
            <div
                style={{
                    display: "flex",
                    gap: 16,
                    flexWrap: "wrap",
                    marginBottom: 24,
                }}
            >
                <div style={card}>
                    <div style={{ fontSize: 28, fontWeight: 800, color: "var(--primary, #991b1b)" }}>
                        {totalWorkers}
                    </div>
                    <div style={{ fontSize: 13, color: "var(--text-muted)", marginTop: 4 }}>
                        Total Workers
                    </div>
                </div>
                <div style={card}>
                    <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 6 }}>
                        Worker Types
                    </div>
                    {Object.entries(workerTypes).map(([type, count]) => (
                        <div
                            key={type}
                            style={{
                                display: "flex",
                                justifyContent: "space-between",
                                gap: 12,
                                fontSize: 13,
                                padding: "2px 0",
                            }}
                        >
                            <span
                                style={{
                                    textTransform: "capitalize",
                                    color: "var(--text-muted)",
                                }}
                            >
                                {type}
                            </span>
                            <span style={{ fontWeight: 700, color: "var(--text-primary)" }}>{count}</span>
                        </div>
                    ))}
                </div>
            </div>

            {/* ---- Add / Edit Form (hidden for view-only roles) ---- */}
            {!isViewOnly && (
            <div
                style={{
                    background: "var(--bg-surface)",
                    borderRadius: 12,
                    padding: 24,
                    marginBottom: 24,
                    border: "1px solid var(--border-subtle)",
                    boxShadow: "var(--shadow-sm)",
                    color: "var(--text-primary)",
                }}
            >
                <h3
                    style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}
                >
                    {editing ? "Edit Worker" : "Add New Worker"}
                </h3>
                <form onSubmit={handleSubmit}>
                    <div
                        style={{
                            display: "grid",
                            gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))",
                            gap: 14,
                            marginBottom: 16,
                        }}
                    >
                        <div>
                            <label
                                style={{
                                    fontSize: 12,
                                    fontWeight: 600,
                                    color: "var(--text-soft)",
                                    display: "block",
                                    marginBottom: 4,
                                }}
                            >
                                Full Name *
                            </label>
                            <input
                                style={inpErr("full_name")}
                                value={form.full_name}
                                onChange={(e) => {
                                    setForm({ ...form, full_name: e.target.value });
                                    if (fieldErrors.full_name) setFieldErrors((p) => ({ ...p, full_name: undefined }));
                                }}
                                placeholder="Enter full name"
                            />
                            {fieldErrors.full_name && <span style={errText}>{fieldErrors.full_name}</span>}
                        </div>
                        <div>
                            <label
                                style={{
                                    fontSize: 12,
                                    fontWeight: 600,
                                    color: "var(--text-soft)",
                                    display: "block",
                                    marginBottom: 4,
                                }}
                            >
                                NIC
                            </label>
                            <input
                                style={inpErr("nic")}
                                value={form.nic}
                                onChange={(e) => {
                                    setForm({ ...form, nic: e.target.value });
                                    if (fieldErrors.nic) setFieldErrors((p) => ({ ...p, nic: undefined }));
                                }}
                                placeholder="NIC number"
                            />
                            {fieldErrors.nic && <span style={errText}>{fieldErrors.nic}</span>}
                        </div>
                        <div>
                            <label
                                style={{
                                    fontSize: 12,
                                    fontWeight: 600,
                                    color: "var(--text-soft)",
                                    display: "block",
                                    marginBottom: 4,
                                }}
                            >
                                Phone
                            </label>
                            <input
                                style={inpErr("phone")}
                                value={form.phone}
                                onChange={(e) => {
                                    setForm({ ...form, phone: e.target.value });
                                    if (fieldErrors.phone) setFieldErrors((p) => ({ ...p, phone: undefined }));
                                }}
                                placeholder="Phone number"
                            />
                            {fieldErrors.phone && <span style={errText}>{fieldErrors.phone}</span>}
                        </div>
                        <div>
                            <label
                                style={{
                                    fontSize: 12,
                                    fontWeight: 600,
                                    color: "var(--text-soft)",
                                    display: "block",
                                    marginBottom: 4,
                                }}
                            >
                                Worker Type
                            </label>
                            <select
                                style={inp}
                                value={form.worker_type}
                                onChange={(e) =>
                                    setForm({ ...form, worker_type: e.target.value })
                                }
                            >
                                <option value="labour">Labour</option>
                                <option value="mason">Mason</option>
                                <option value="carpenter">Carpenter</option>
                                <option value="electrician">Electrician</option>
                                <option value="plumber">Plumber</option>
                                <option value="painter">Painter</option>
                                <option value="welder">Welder</option>
                                <option value="helper">Helper</option>
                                <option value="supervisor">Supervisor</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div>
                            <label
                                style={{
                                    fontSize: 12,
                                    fontWeight: 600,
                                    color: "var(--text-soft)",
                                    display: "block",
                                    marginBottom: 4,
                                }}
                            >
                                Daily Rate (Rs)
                            </label>
                            <input
                                type="number"
                                min="0"
                                style={inpErr("daily_rate")}
                                value={form.daily_rate}
                                onChange={(e) => {
                                    setForm({ ...form, daily_rate: e.target.value });
                                    if (fieldErrors.daily_rate) setFieldErrors((p) => ({ ...p, daily_rate: undefined }));
                                }}
                                placeholder="e.g. 3500"
                            />
                            {fieldErrors.daily_rate && <span style={errText}>{fieldErrors.daily_rate}</span>}
                        </div>
                        <div>
                            <label
                                style={{
                                    fontSize: 12,
                                    fontWeight: 600,
                                    color: "var(--text-soft)",
                                    display: "block",
                                    marginBottom: 4,
                                }}
                            >
                                Emergency Contact
                            </label>
                            <input
                                style={inpErr("emergency_contact")}
                                value={form.emergency_contact}
                                onChange={(e) => {
                                    setForm({ ...form, emergency_contact: e.target.value });
                                    if (fieldErrors.emergency_contact) setFieldErrors((p) => ({ ...p, emergency_contact: undefined }));
                                }}
                                placeholder="Emergency contact"
                            />
                            {fieldErrors.emergency_contact && <span style={errText}>{fieldErrors.emergency_contact}</span>}
                        </div>
                        <div>
                            <label
                                style={{
                                    fontSize: 12,
                                    fontWeight: 600,
                                    color: "var(--text-soft)",
                                    display: "block",
                                    marginBottom: 4,
                                }}
                            >
                                Address
                            </label>
                            <input
                                style={inp}
                                value={form.address}
                                onChange={(e) =>
                                    setForm({ ...form, address: e.target.value })
                                }
                                placeholder="Address"
                            />
                        </div>

                    </div>
                    <div style={{ display: "flex", gap: 10 }}>
                        <button type="submit" style={btnPrimary} disabled={loading}>
                            {loading
                                ? "Saving..."
                                : editing
                                    ? "Update Worker"
                                    : "Add Worker"}
                        </button>
                        {editing && (
                            <button
                                type="button"
                                style={btnSecondary}
                                onClick={resetForm}
                            >
                                Cancel
                            </button>
                        )}
                    </div>
                </form>
            </div>
            )}

            {/* ---- Search ---- */}
            <div style={{ marginBottom: 16 }}>
                <input
                    style={{
                        ...inp,
                        maxWidth: 350,
                    }}
                    placeholder="Search workers by name, NIC, phone, type..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
            </div>

            {/* ---- Table ---- */}
            <div
                style={{
                    background: "var(--bg-surface)",
                    borderRadius: 12,
                    border: "1px solid var(--border-subtle)",
                    overflow: "auto",
                    boxShadow: "var(--shadow-sm)",
                }}
            >
                <table
                    style={{
                        width: "100%",
                        borderCollapse: "collapse",
                    }}
                >
                    <thead>
                        <tr>
                            <th style={th}>#</th>
                            <th style={th}>Name</th>
                            <th style={th}>NIC</th>
                            <th style={th}>Phone</th>
                            <th style={th}>Type</th>
                            <th style={th}>Daily Rate</th>

                            {!isViewOnly && <th style={th}>Actions</th>}
                        </tr>
                    </thead>
                    <tbody>
                        {filtered.length === 0 ? (
                            <tr>
                                <td
                                    colSpan={7}
                                    style={{
                                        ...td,
                                        textAlign: "center",
                                        color: "#94a3b8",
                                        padding: 30,
                                    }}
                                >
                                    {loading ? "Loading..." : "No workers found"}
                                </td>
                            </tr>
                        ) : (
                            filtered.map((w, i) => (
                                <tr
                                    key={w.id}
                                    style={{
                                        background: i % 2 === 0 ? "var(--bg-surface)" : "var(--bg-body)",
                                    }}
                                    onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "var(--table-row-hover)")}
                                    onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = i % 2 === 0 ? "var(--bg-surface)" : "var(--bg-body)")}
                                >
                                    <td style={{ ...td, color: "var(--text-soft)", fontSize: 12 }}>{i + 1}</td>
                                    <td style={{ ...td, fontWeight: 600 }}>
                                        {w.full_name || "—"}
                                    </td>
                                    <td style={td}>{w.nic || "—"}</td>
                                    <td style={td}>{w.phone || "—"}</td>
                                    <td style={td}>
                                        <span
                                            style={{
                                                background: "var(--table-header-bg)",
                                                color: "var(--text-primary)",
                                                padding: "3px 10px",
                                                borderRadius: 12,
                                                fontSize: 12,
                                                fontWeight: 600,
                                                textTransform: "capitalize",
                                                border: "1px solid var(--border-subtle)",
                                            }}
                                        >
                                            {w.worker_type || "—"}
                                        </span>
                                    </td>
                                    <td style={td}>
                                        Rs{" "}
                                        {Number(w.daily_rate || 0).toLocaleString("en-LK", {
                                            minimumFractionDigits: 2,
                                        })}
                                    </td>

                                    {!isViewOnly && (
                                    <td style={td}>
                                        <div style={{ display: "flex", gap: 6 }}>
                                            <button
                                                onClick={() => handleEdit(w)}
                                                style={{
                                                    background: "var(--glass-blue)",
                                                    color: "var(--primary-light, #2563eb)",
                                                    border: "1px solid var(--border-subtle)",
                                                    padding: "5px 12px",
                                                    borderRadius: 6,
                                                    fontSize: 12,
                                                    fontWeight: 600,
                                                    cursor: "pointer",
                                                }}
                                            >
                                                Edit
                                            </button>
                                            <button
                                                onClick={() => handleDelete(w.id, w.full_name)}
                                                style={{
                                                    background: "var(--glass-rose)",
                                                    color: "var(--error, #991b1b)",
                                                    border: "1px solid var(--border-subtle)",
                                                    padding: "5px 12px",
                                                    borderRadius: 6,
                                                    fontSize: 12,
                                                    fontWeight: 600,
                                                    cursor: "pointer",
                                                }}
                                            >
                                                Delete
                                            </button>
                                        </div>
                                    </td>
                                    )}
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            <div
                style={{
                    textAlign: "center",
                    padding: 16,
                    color: "var(--text-muted)",
                    fontSize: 13,
                }}
            >
                Showing {filtered.length} of {workers.length} workers
            </div>
        </div>
    );
}
