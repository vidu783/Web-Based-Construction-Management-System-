import { useState, useEffect, useCallback, useMemo, useRef } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8080";
const hdr = () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("access_token") || localStorage.getItem("token") || ""}`,
});

const CONDITION_OPTIONS = ["new", "good", "fair", "poor"];
const CONDITION_LABELS = { new: "New", good: "Good", fair: "Fair", poor: "Poor" };

export default function ToolsAndEquipment() {
    /* ─── STATE ─── */
    const [tab, setTab] = useState("inventory");
    const [tools, setTools] = useState([]);
    const [sites, setSites] = useState([]);
    const [allocations, setAllocations] = useState([]);
    const [officers, setOfficers] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [workers, setWorkers] = useState([]);
    const [deletedEntities, setDeletedEntities] = useState([]);
    const [loading, setLoading] = useState(true);
    const [msg, setMsg] = useState({ text: "", type: "" });
    const [search, setSearch] = useState("");
    const [filterCondition, setFilterCondition] = useState("all");
    const [showForm, setShowForm] = useState(false);
    const [editId, setEditId] = useState(null);
    const [form, setForm] = useState({ name: "", tool_code: "", total_qty: 1, available: 1, condition: "new", notes: "" });
    const [showAllocForm, setShowAllocForm] = useState(false);
    const [editAllocId, setEditAllocId] = useState(null);
    const [allocForm, setAllocForm] = useState({ tool_id: "", site_id: "", worker_id: "", qty: 1, allocated_date: new Date().toISOString().slice(0, 10), returned_date: "", status: "allocated", notes: "" });
    const [reportMonth, setReportMonth] = useState(new Date().toISOString().slice(0, 7));
    const [siteFilter, setSiteFilter] = useState("all");
    const [toolErrors, setToolErrors] = useState({});
    const [allocErrors, setAllocErrors] = useState({});

    /* ─── BILL UPLOAD ─── */
    const [billFile, setBillFile] = useState(null);
    const [billToolId, setBillToolId] = useState("");
    const [billNote, setBillNote] = useState("");
    const [billUploading, setBillUploading] = useState(false);
    const [showUploadCard, setShowUploadCard] = useState(false);
    const [myBills, setMyBills] = useState([]);

    /* ─── CURRENT USER ─── */
    const currentUser = useMemo(() => {
        try { return JSON.parse(localStorage.getItem("user") || "{}"); } catch { return {}; }
    }, []);
    const userRole = currentUser.role || "admin";
    const userId = currentUser.id || currentUser.user_id || "";
    const isAdmin = ["admin", "project_manager"].includes(userRole);
    const isSiteOfficer = userRole === "site_officer";

    /* ─── FLASH ─── */
    const flashTimeout = useRef(null);
    const flash = (text, type = "ok") => {
        if (flashTimeout.current) clearTimeout(flashTimeout.current);
        setMsg({ text, type });
        flashTimeout.current = setTimeout(() => setMsg({ text: "", type: "" }), 5000);
    };

    /* ─── FETCHERS ─── */
    const fetchTools = useCallback(async () => {
        try {
            const r = await fetch(`${API}/tools`, { headers: hdr() });
            if (r.ok) { const d = await r.json(); setTools(Array.isArray(d) ? d : []); }
        } catch (e) { console.error("fetchTools", e); }
    }, []);

    const fetchSites = useCallback(async () => {
        try {
            const r = await fetch(`${API}/fields?archived=true`, { headers: hdr() });
            if (r.ok) { const d = await r.json(); setSites(Array.isArray(d) ? d : []); }
        } catch (e) { console.error("fetchSites", e); }
    }, []);

    const fetchAllocations = useCallback(async () => {
        try {
            const r = await fetch(`${API}/tool-allocations`, { headers: hdr() });
            if (r.ok) { const d = await r.json(); setAllocations(Array.isArray(d) ? d : []); }
        } catch (e) { console.error("fetchAllocations", e); }
    }, []);

    const fetchOfficers = useCallback(async () => {
        try {
            const r = await fetch(`${API}/officers`, { headers: hdr() });
            if (r.ok) { const d = await r.json(); setOfficers(Array.isArray(d) ? d : []); }
        } catch (e) { console.error("fetchOfficers", e); }
    }, []);

    const fetchAssignments = useCallback(async () => {
        try {
            const r = await fetch(`${API}/assignments`, { headers: hdr() });
            if (r.ok) { const d = await r.json(); setAssignments(Array.isArray(d) ? d : []); }
        } catch (e) { console.error("fetchAssignments", e); }
    }, []);

    const fetchWorkers = useCallback(async () => {
        try {
            const r = await fetch(`${API}/workers?archived=true`, { headers: hdr() });
            if (r.ok) { const d = await r.json(); setWorkers(Array.isArray(d) ? d : []); }
        } catch (e) { console.error("fetchWorkers", e); }
    }, []);

    const loadAll = useCallback(async () => {
        setLoading(true);
        await Promise.all([fetchTools(), fetchSites(), fetchAllocations(), fetchOfficers(), fetchAssignments(), fetchWorkers()]);
        fetch(`${API}/deleted-entities?type=worker,site,tool`, { headers: hdr() })
            .then(r => r.json()).then(d => setDeletedEntities(Array.isArray(d) ? d : [])).catch(() => {});
        setLoading(false);
    }, [fetchTools, fetchSites, fetchAllocations, fetchOfficers, fetchAssignments, fetchWorkers]);

    /* ─── FETCH MY BILLS ─── */
    const fetchMyBills = useCallback(async () => {
        if (!isAdmin && !isSiteOfficer) return;
        try {
            const r = await fetch(`${API}/tool-bills`, { headers: hdr() });
            if (r.ok) {
                const d = await r.json();
                setMyBills(Array.isArray(d) ? d.filter(b => b.uploaded_by === userId).slice(0, 5) : []);
            }
        } catch { /* ignore */ }
    }, [isAdmin, userId]);

    useEffect(() => {
        loadAll();
        fetchMyBills();
    }, [loadAll, fetchMyBills]);

    /* ─── BILL UPLOAD HANDLER ─── */
    const handleBillUpload = async (e) => {
        e.preventDefault();
        if (!billFile) { flash("Please select a file", "err"); return; }
        if (billFile.size > 5 * 1024 * 1024) { flash("File size must be under 5MB", "err"); return; }
        const allowed = ["image/jpeg", "image/png", "application/pdf"];
        if (!allowed.includes(billFile.type)) { flash("Only JPG, PNG, and PDF files are allowed", "err"); return; }

        setBillUploading(true);
        try {
            const formData = new FormData();
            formData.append("bill_image", billFile);
            formData.append("uploaded_by", userId);
            formData.append("uploader_role", userRole);
            formData.append("recorded_by_name", currentUser.full_name || currentUser.name || "Admin");
            formData.append("recorded_by_role", userRole);
            if (billToolId) formData.append("tool_id", billToolId);
            if (billNote.trim()) formData.append("note", billNote.trim());

            const token = localStorage.getItem("access_token") || localStorage.getItem("token") || "";
            const r = await fetch(`${API}/tool-bills/upload`, {
                method: "POST",
                headers: token ? { Authorization: `Bearer ${token}` } : {},
                body: formData,
            });

            if (!r.ok) {
                const d = await r.json().catch(() => ({}));
                throw new Error(d.error || "Upload failed");
            }

            flash("Bill uploaded successfully! Finance team will be notified.", "ok");
            setBillFile(null);
            setBillToolId("");
            setBillNote("");
            setShowUploadCard(false);
            fetchMyBills();
            // Reset file input
            const fileInput = document.getElementById("bill-file-input");
            if (fileInput) fileInput.value = "";
        } catch (e) { flash(e.message, "err"); }
        setBillUploading(false);
    };

    /* ─── SITE-OFFICER SITE FILTERING ─── */
    const allowedSiteIds = useMemo(() => {
        if (isAdmin) return sites.map((s) => s.id);
        if (!isSiteOfficer) return [];
        const today = new Date().toISOString().slice(0, 10);
        const myOfficer = officers.find((o) => o.user_id === userId);
        if (!myOfficer) {
            const uName = (currentUser.full_name || "").toLowerCase().trim();
            const uPhone = (currentUser.phone || "").trim();
            const fallback = officers.find((o) => {
                const oName = (o.full_name || o.name || "").toLowerCase().trim();
                const oPhone = (o.phone || "").trim();
                return (uName && oName && oName === uName) || (uPhone && oPhone && oPhone === uPhone);
            });
            if (!fallback) return [];
            return assignments.filter((a) => a.officer_id === fallback.id && (!a.to_date || a.to_date >= today)).map((a) => a.site_id);
        }
        return assignments.filter((a) => a.officer_id === myOfficer.id && (!a.to_date || a.to_date >= today)).map((a) => a.site_id);
    }, [isAdmin, isSiteOfficer, userId, currentUser, officers, assignments, sites]);

    const allowedSites = useMemo(() => sites.filter((s) => allowedSiteIds.includes(s.id)), [sites, allowedSiteIds]);

    /* ─── LOOKUPS ─── */
    const toolMap = useMemo(() => Object.fromEntries(tools.map((t) => [t.id, t])), [tools]);
    const siteMap = useMemo(() => Object.fromEntries(sites.map((s) => [s.id, s])), [sites]);
    const workerMap = useMemo(() => Object.fromEntries(workers.map((w) => [w.id, w])), [workers]);

    /* ─── TOOLS WITH CALCULATED AVAILABILITY ─── */
    const toolsWithAvailable = useMemo(() => {
        return tools.map(t => {
            const allocatedQty = allocations
                .filter(a => a.tool_id === t.id && !a.returned_date && a.status !== "returned")
                .reduce((sum, a) => sum + (parseInt(a.qty) || 0), 0);
            return {
                ...t,
                // Clamp to 0 — available can never be negative
                computed_available: Math.max(0, (parseInt(t.total_qty) || 0) - allocatedQty),
                allocated_qty: allocatedQty
            };
        });
    }, [tools, allocations]);

    /* ─── FILTERED TOOLS ─── */
    const filteredTools = useMemo(() => {
        return toolsWithAvailable.filter((t) => {
            const q = search.toLowerCase();
            const matchesSearch = !q || (t.name || "").toLowerCase().includes(q) || (t.tool_code || "").toLowerCase().includes(q) || (t.notes || "").toLowerCase().includes(q);
            const matchesCond = filterCondition === "all" || t.condition === filterCondition;
            return matchesSearch && matchesCond;
        });
    }, [tools, search, filterCondition]);

    /* ─── FILTERED ALLOCATIONS (by allowed sites) ─── */
    const filteredAllocations = useMemo(() => {
        return allocations.filter((a) => {
            const siteOk = allowedSiteIds.includes(a.site_id);
            const siteFilterOk = siteFilter === "all" || a.site_id === siteFilter;
            return siteOk && siteFilterOk;
        });
    }, [allocations, allowedSiteIds, siteFilter]);

    /* ─── STATS ─── */
    const stats = useMemo(() => {
        const totalTools = tools.length;
        const totalQty = tools.reduce((s, t) => s + (parseInt(t.total_qty) || 0), 0);
        const totalAvailable = toolsWithAvailable.reduce((s, t) => s + t.computed_available, 0);
        const allocated = filteredAllocations.filter((a) => !a.returned_date && a.status !== "returned").reduce((s, a) => s + (parseInt(a.qty) || 0), 0);
        const needsRepair = tools.filter((t) => t.condition === "poor").length;
        return { totalTools, totalQty, totalAvailable, allocated, needsRepair };
    }, [tools, filteredAllocations]);

    /* ─── TOOL CRUD ─── */
    const validateTool = () => {
        const errs = {};
        if (!form.name.trim()) errs.name = "Tool name is required";
        const tq = parseInt(form.total_qty);
        if (isNaN(tq) || tq < 0) errs.total_qty = "Quantity cannot be negative";
        setToolErrors(errs);
        return Object.keys(errs).length === 0;
    };

    const handleToolSubmit = async (e) => {
        e.preventDefault();
        if (!validateTool()) return;
        try {
            const payload = {
                name: form.name.trim(),
                tool_code: form.tool_code.trim(),
                total_qty: parseInt(form.total_qty) || 0,
                available: parseInt(form.available) || 0,
                condition: form.condition || "good",
                notes: form.notes.trim(),
            };
            const url = editId ? `${API}/tools/${editId}` : `${API}/tools`;
            const method = editId ? "PUT" : "POST";
            const r = await fetch(url, { method, headers: hdr(), body: JSON.stringify(payload) });
            if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d.error || "Failed"); }
            flash(editId ? "Tool updated" : "Tool added", "ok");
            resetToolForm();
            fetchTools();
        } catch (e) { flash(e.message, "err"); }
    };

    const handleDeleteTool = async (id) => {
        if (!window.confirm("Delete this tool?")) return;
        try {
            const r = await fetch(`${API}/tools/${id}`, { method: "DELETE", headers: hdr() });
            if (!r.ok) throw new Error("Delete failed");
            flash("Tool deleted", "ok");
            fetchTools();
        } catch (e) { flash(e.message, "err"); }
    };

    const handleEditTool = (t) => {
        setForm({
            name: t.name || "",
            tool_code: t.tool_code || "",
            total_qty: t.total_qty ?? 1,
            available: t.available ?? 1,
            condition: t.condition || "good",
            notes: t.notes || "",
        });
        setEditId(t.id);
        setShowForm(true);
        setTab("inventory");
    };

    const resetToolForm = () => {
        setForm({ name: "", tool_code: "", total_qty: 1, available: 1, condition: "new", notes: "" });
        setEditId(null);
        setShowForm(false);
        setToolErrors({});
    };

    /* ─── ALLOCATION CRUD ─── */
    const validateAlloc = () => {
        const errs = {};
        if (!allocForm.tool_id) errs.tool_id = "Please select a tool";
        if (!allocForm.site_id) errs.site_id = "Please select a site";
        if (!allocForm.worker_id) errs.worker_id = "Please select a worker";
        const q = parseInt(allocForm.qty);
        if (isNaN(q) || q < 1) {
            errs.qty = "Quantity must be at least 1";
        } else if (allocForm.tool_id) {
            const t = toolsWithAvailable.find(x => x.id === allocForm.tool_id);
            if (t) {
                const currentAlloc = editAllocId ? allocations.find(a => a.id === editAllocId) : null;
                const oldQty = (currentAlloc && currentAlloc.status !== "returned" && !currentAlloc.returned_date) ? (parseInt(currentAlloc.qty) || 0) : 0;
                const maxAvail = t.computed_available + oldQty;
                const isReturned = allocForm.status === "returned" || !!allocForm.returned_date;
                if (!isReturned && q > maxAvail) {
                    errs.qty = `Cannot allocate > ${maxAvail} (max available)`;
                }
            }
        }
        setAllocErrors(errs);
        return Object.keys(errs).length === 0;
    };

    const handleAllocSubmit = async (e) => {
        e.preventDefault();
        if (!validateAlloc()) return;
        try {
            const finalData = {
                ...allocForm,
                recorded_by_name: currentUser.full_name || currentUser.name || "Admin",
                recorded_by_role: userRole
            };
            const r = await fetch(editAllocId ? `${API}/tool-allocations/${editAllocId}` : `${API}/tool-allocations`, {
                method: editAllocId ? "PUT" : "POST",
                headers: hdr(),
                body: JSON.stringify(finalData),
            });
            if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d.error || "Failed"); }
            flash(editAllocId ? "Allocation updated" : "Tool allocated", "ok");
            resetAllocForm();
            fetchAllocations();
            fetchTools();
        } catch (e) { flash(e.message, "err"); }
    };

    const handleReturnAlloc = async (id) => {
        try {
            const r = await fetch(`${API}/tool-allocations/${id}`, {
                method: "PUT", headers: hdr(),
                body: JSON.stringify({ returned_date: new Date().toISOString().slice(0, 10), status: "returned" }),
            });
            if (!r.ok) throw new Error("Return failed");
            flash("Tool returned", "ok");
            fetchAllocations();
            fetchTools();
        } catch (e) { flash(e.message, "err"); }
    };

    const handleDeleteAlloc = async (id) => {
        if (!window.confirm("Delete this allocation?")) return;
        try {
            const r = await fetch(`${API}/tool-allocations/${id}`, { method: "DELETE", headers: hdr() });
            if (!r.ok) throw new Error("Delete failed");
            flash("Allocation deleted", "ok");
            fetchAllocations();
        } catch (e) { flash(e.message, "err"); }
    };

    const handleEditAlloc = (a) => {
        setAllocForm({
            tool_id: a.tool_id || "",
            site_id: a.site_id || "",
            worker_id: a.worker_id || "",
            qty: a.qty || 1,
            allocated_date: (a.allocated_date || "").slice(0, 10),
            returned_date: (a.returned_date || "").slice(0, 10),
            status: a.status || "allocated",
            notes: a.notes || "",
        });
        setEditAllocId(a.id);
        setShowAllocForm(true);
        setTab("allocations");
    };

    const resetAllocForm = () => {
        setAllocForm({ tool_id: "", site_id: "", worker_id: "", qty: 1, allocated_date: new Date().toISOString().slice(0, 10), returned_date: "", status: "allocated", notes: "" });
        setEditAllocId(null);
        setShowAllocForm(false);
        setAllocErrors({});
    };

    /* ─── REPORT DATA ─── */
    const reportData = useMemo(() => {
        const monthStr = reportMonth;
        const monthAllocs = filteredAllocations.filter((a) => (a.allocated_date || "").startsWith(monthStr));
        const bysite = {};
        monthAllocs.forEach((a) => {
            if (!bysite[a.site_id]) bysite[a.site_id] = { site_id: a.site_id, siteName: siteMap[a.site_id]?.name || "Unknown", tools: [], totalQty: 0, returned: 0 };
            const tool = toolMap[a.tool_id];
            bysite[a.site_id].tools.push({ ...a, toolName: tool?.name || "Unknown", toolCode: tool?.tool_code || "" });
            bysite[a.site_id].totalQty += parseInt(a.qty) || 0;
            if (a.returned_date || a.status === "returned") bysite[a.site_id].returned += parseInt(a.qty) || 0;
        });
        return Object.values(bysite).sort((a, b) => b.totalQty - a.totalQty);
    }, [filteredAllocations, reportMonth, siteMap, toolMap]);

    /* ─── CSV EXPORT ─── */
    const exportCSV = () => {
        const rows = [["Site", "Tool", "Tool Code", "Qty", "Allocated", "Returned", "Status", "Notes"]];
        reportData.forEach((s) => {
            s.tools.forEach((t) => {
                rows.push([s.siteName, t.toolName, t.toolCode, t.qty, t.allocated_date || "", t.returned_date || "", t.status || "", (t.notes || "").replace(/,/g, ";")]);
            });
        });
        const csv = rows.map((r) => r.join(",")).join("\n");
        const blob = new Blob([csv], { type: "text/csv" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url; a.download = `tools_report_${reportMonth}.csv`; a.click();
        URL.revokeObjectURL(url);
    };

    /* ─── HELPER: get worker / site display nodes with deleted badge ─── */
    const deletedMap = useMemo(() => Object.fromEntries(deletedEntities.map(e => [e.entity_id, e])), [deletedEntities]);
    const workerNode = (id) => {
        const w = workerMap[id];
        if (!w) { const snap = deletedMap[id]; return (<>{snap?.entity_name || "Deleted Worker"} <span className="archived-badge">deleted</span></>); }
        return (<>{w.full_name || w.name}{w.is_archived && <span className="archived-badge">deleted</span>}</>);
    };
    const siteNode = (id) => {
        const s = siteMap[id];
        if (!s) { const snap = deletedMap[id]; return (<>{snap?.entity_name || "Deleted Site"} <span className="archived-badge">deleted</span></>); }
        return (<>{s.name}{s.is_archived && <span className="archived-badge">deleted</span>}</>);
    };
    const getWorkerDisplayName = (workerId) => {
        const w = workerMap[workerId];
        if (!w) return deletedMap[workerId]?.entity_name || "—";
        return w.full_name || w.name || "Unknown";
    };

    /* ─── HELPER: get allocation status label (FIX: no more 'in_use' which violates DB constraint) ─── */
    const getStatusLabel = (status) => {
        const map = { allocated: "Allocated", returned: "Returned", lost: "Lost", damaged: "Damaged" };
        return map[status] || status || "—";
    };

    const getStatusStyle = (status) => {
        if (status === "allocated") return { background: "var(--glass-amber)", color: "var(--warning, #d97706)" };
        if (status === "returned") return { background: "var(--glass-green)", color: "var(--success, #16a34a)" };
        if (status === "lost") return { background: "var(--glass-rose)", color: "var(--error, #dc2626)" };
        if (status === "damaged") return { background: "var(--glass-amber)", color: "var(--warning, #ea580c)" };
        return { background: "var(--table-header-bg)", color: "var(--text-soft)" };
    };

    /* ─── STYLES ─── */
    const glassCard = { background: "var(--bg-surface)", borderRadius: 14, border: "1px solid var(--border-subtle)", padding: 20, boxShadow: "var(--shadow-sm)", marginBottom: 16 };
    const btnPrimary = { background: "var(--primary-gradient)", color: "#fff", border: "none", borderRadius: 8, padding: "8px 18px", fontSize: 13, fontWeight: 600, cursor: "pointer" };
    const btnSecondary = { background: "var(--bg-body)", color: "var(--text-soft)", border: "1px solid var(--border-subtle)", borderRadius: 8, padding: "8px 18px", fontSize: 13, fontWeight: 500, cursor: "pointer" };
    const btnDanger = { background: "var(--glass-rose)", color: "var(--error, #dc2626)", border: "1px solid var(--error-border, #fecaca)", borderRadius: 8, padding: "6px 14px", fontSize: 12, fontWeight: 500, cursor: "pointer" };
    const btnSuccess = { background: "var(--glass-green)", color: "var(--success, #16a34a)", border: "1px solid var(--success-border, #bbf7d0)", borderRadius: 8, padding: "6px 14px", fontSize: 12, fontWeight: 500, cursor: "pointer" };
    const inputStyle = { width: "100%", padding: "10px 14px", border: "1px solid var(--input-border)", background: "var(--input-bg)", color: "var(--input-text)", borderRadius: 8, fontSize: 14, outline: "none", transition: "border 0.2s", boxSizing: "border-box" };
    const selectStyle = { ...inputStyle, background: "var(--input-bg)" };
    const toolInpErr = (field) => ({ ...inputStyle, border: toolErrors[field] ? "1px solid var(--error, #dc2626)" : "1px solid var(--input-border)", background: toolErrors[field] ? "var(--glass-rose)" : "var(--input-bg)" });
    const allocInpErr = (field) => ({ ...inputStyle, border: allocErrors[field] ? "1px solid var(--error, #dc2626)" : "1px solid var(--input-border)", background: allocErrors[field] ? "var(--glass-rose)" : "var(--input-bg)" });
    const allocSelErr = (field) => ({ ...selectStyle, border: allocErrors[field] ? "1px solid var(--error, #dc2626)" : "1px solid var(--input-border)", background: allocErrors[field] ? "var(--glass-rose)" : "var(--input-bg)" });
    const errText = { color: "var(--error, #dc2626)", fontSize: 11, marginTop: 2, fontWeight: 500 };
    const labelStyle = { display: "block", fontSize: 12, fontWeight: 600, color: "var(--text-soft)", marginBottom: 4 };
    const thStyle = { padding: "10px 14px", textAlign: "left", fontSize: 12, fontWeight: 600, color: "var(--text-soft)", borderBottom: "2px solid var(--border-subtle)", background: "var(--table-header-bg)" };
    const tdStyle = { padding: "10px 14px", fontSize: 13, color: "var(--text-primary)", borderBottom: "1px solid var(--border-subtle)" };

    const condColor = (c) => {
        const map = { new: "#16a34a", good: "#2563eb", fair: "#d97706", poor: "#dc2626" };
        return map[c] || "#6b7280";
    };

    /* ─── LOADING ─── */
    if (loading) {
        return (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: 80 }}>
                <div style={{ textAlign: "center", color: "var(--text-soft)" }}>
                    <div style={{ width: 40, height: 40, border: "3px solid var(--border-subtle)", borderTopColor: "var(--primary)", borderRadius: "50%", animation: "spin 1s linear infinite", margin: "0 auto 12px" }} />
                    <p>Loading tools & equipment...</p>
                    <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
                </div>
            </div>
        );
    }

    /* ════════════════════════════════════════════ */
    return (
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
            {/* Flash */}
            {msg.text && (
                <div style={{
                    padding: "12px 20px", borderRadius: 10, marginBottom: 16, fontSize: 14, fontWeight: 500,
                    background: msg.type === "ok" ? "#f0fdf4" : "#fef2f2",
                    color: msg.type === "ok" ? "#16a34a" : "#dc2626",
                    border: `1px solid ${msg.type === "ok" ? "#bbf7d0" : "#fecaca"}`,
                }}>
                    {msg.text}
                </div>
            )}

            {/* Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20, flexWrap: "wrap", gap: 12 }}>
                <div>
                    <h1 style={{ fontSize: 24, fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>Tools & Equipment</h1>
                    <p style={{ fontSize: 14, color: "var(--text-soft)", margin: "4px 0 0" }}>
                        {isSiteOfficer ? `Viewing ${allowedSites.length} assigned site(s)` : `Managing ${tools.length} tools across ${sites.length} sites`}
                    </p>
                </div>
                {(isAdmin || isSiteOfficer) && (
                    <div style={{ display: "flex", gap: 8 }} className="no-print">
                        {isAdmin && <button onClick={() => { resetToolForm(); setShowForm(true); setTab("inventory"); }} style={btnPrimary}>+ Add Tool</button>}
                        {isAdmin && <button onClick={() => { resetAllocForm(); setShowAllocForm(true); setTab("allocations"); }} style={btnSecondary}>+ Allocate</button>}
                        <button onClick={() => setShowUploadCard(!showUploadCard)} style={{ background: "linear-gradient(135deg,#f59e0b,#d97706)", color: "#fff", border: "none", borderRadius: 8, padding: "8px 18px", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>📄 Upload Bill</button>
                    </div>
                )}
            </div>

            {/* Stats */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12, marginBottom: 20 }} className="no-print">
                {[
                    { label: "Total Tools", value: stats.totalTools, color: "#3b82f6", bg: "#eff6ff" },
                    { label: "Total Quantity", value: stats.totalQty, color: "#8b5cf6", bg: "#f5f3ff" },
                    { label: "Available", value: stats.totalAvailable, color: "#16a34a", bg: "#f0fdf4" },
                    { label: "Allocated Out", value: stats.allocated, color: "#d97706", bg: "#fffbeb" },
                    { label: "Poor Condition", value: stats.needsRepair, color: "#dc2626", bg: "#fef2f2" },
                ].map((s, i) => (
                    <div key={i} style={{ ...glassCard, padding: 16, display: "flex", alignItems: "center", gap: 14 }}>
                        <div style={{ width: 44, height: 44, borderRadius: 12, background: s.bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, fontWeight: 700, color: s.color }}>
                            {s.value}
                        </div>
                        <div style={{ fontSize: 12, color: "#64748b", fontWeight: 500 }}>{s.label}</div>
                    </div>
                ))}
            </div>

            {/* ═══════════ UPLOAD YOUR BILL ═══════════ */}
            {showUploadCard && (isAdmin || isSiteOfficer) && (
                <div style={{ ...glassCard, border: "1px solid var(--warning-border, #fde68a)", background: "var(--glass-amber)", marginBottom: 20 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                        <h3 style={{ fontSize: 16, fontWeight: 700, color: "var(--warning, #92400e)", margin: 0 }}>📄 Upload Your Bill</h3>
                        <button onClick={() => setShowUploadCard(false)} style={{ background: "none", border: "none", fontSize: 18, cursor: "pointer", color: "var(--warning, #92400e)" }}>✕</button>
                    </div>
                    <p style={{ fontSize: 12, color: "var(--text-soft)", marginBottom: 14 }}>Upload a tool purchase bill (JPG, PNG, or PDF — max 5MB). Finance team will enter the details.</p>
                    <form onSubmit={handleBillUpload}>
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14 }}>
                            <div>
                                <label style={labelStyle}>Bill Image / PDF *</label>
                                <input
                                    id="bill-file-input"
                                    type="file"
                                    accept=".jpg,.jpeg,.png,.pdf"
                                    onChange={e => setBillFile(e.target.files?.[0] || null)}
                                    style={{ ...inputStyle, padding: 8 }}
                                />
                                {billFile && <span style={{ fontSize: 11, color: "#16a34a", marginTop: 4, display: "block" }}>✓ {billFile.name} ({(billFile.size / 1024 / 1024).toFixed(1)} MB)</span>}
                            </div>
                            <div>
                                <label style={labelStyle}>Tool (Optional)</label>
                                <select style={selectStyle} value={billToolId} onChange={e => setBillToolId(e.target.value)}>
                                    <option value="">— Select tool —</option>
                                    {tools.map(t => <option key={t.id} value={t.id}>{t.name} {t.tool_code ? `(${t.tool_code})` : ""}</option>)}
                                </select>
                            </div>
                            <div>
                                <label style={labelStyle}>Note (Optional)</label>
                                <input style={inputStyle} value={billNote} onChange={e => setBillNote(e.target.value)} placeholder="Short description..." />
                            </div>
                        </div>
                        <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
                            <button type="submit" disabled={billUploading || !billFile}
                                style={{ ...btnPrimary, background: billUploading || !billFile ? "#94a3b8" : "linear-gradient(135deg,#f59e0b,#d97706)", cursor: billUploading || !billFile ? "not-allowed" : "pointer" }}>
                                {billUploading ? "Uploading..." : "Upload Your Bill"}
                            </button>
                            <button type="button" onClick={() => setShowUploadCard(false)} style={btnSecondary}>Cancel</button>
                        </div>
                    </form>

                    {/* My Recent Uploads */}
                    {myBills.length > 0 && (
                        <div style={{ marginTop: 16, paddingTop: 14, borderTop: "1px solid #fde68a" }}>
                            <div style={{ fontSize: 12, fontWeight: 600, color: "#92400e", marginBottom: 8 }}>Your Recent Uploads</div>
                            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                                {myBills.map(b => {
                                    const statusMap = {
                                        Pending: { bg: "#fffbeb", color: "#d97706" },
                                        "In Progress": { bg: "#eff6ff", color: "#2563eb" },
                                        Processed: { bg: "#f0fdf4", color: "#16a34a" },
                                        Rejected: { bg: "#fef2f2", color: "#dc2626" },
                                    };
                                    const sc = statusMap[b.status] || statusMap.Pending;
                                    return (
                                        <div key={b.id} style={{ background: "var(--bg-body)", borderRadius: 8, padding: "8px 12px", border: "1px solid var(--border-subtle)", fontSize: 12 }}>
                                            <div style={{ fontWeight: 600, color: "var(--text-primary)" }}>{b.tools?.name || b.file_name || "Bill"}</div>
                                            <div style={{ display: "flex", gap: 8, marginTop: 4, alignItems: "center" }}>
                                                <span style={{ color: "var(--text-soft)" }}>{b.created_at ? new Date(b.created_at).toLocaleDateString() : ""}</span>
                                                <span style={{ padding: "2px 6px", borderRadius: 4, fontSize: 10, fontWeight: 600, background: sc.bg, color: sc.color }}>{b.status}</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>
            )}

            {/* Tabs */}
            <div style={{ display: "flex", gap: 4, marginBottom: 20, background: "var(--bg-body, #f1f5f9)", borderRadius: 10, padding: 4 }} className="no-print">
                {["inventory", "allocations", "report"].map((t) => (
                    <button
                        key={t}
                        onClick={() => setTab(t)}
                        style={{
                            flex: 1, padding: "10px 16px", border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer",
                            background: tab === t ? "var(--bg-surface)" : "transparent",
                            color: tab === t ? "var(--text-primary)" : "var(--text-soft)",
                            boxShadow: tab === t ? "var(--shadow-sm)" : "none",
                        }}
                    >
                        {t === "inventory" ? "Inventory" : t === "allocations" ? "Allocations" : "Report"}
                    </button>
                ))}
            </div>

            {/* ═══════════ INVENTORY TAB ═══════════ */}
            {tab === "inventory" && (
                <div>
                    {showForm && isAdmin && (
                        <div style={{ ...glassCard, border: "1px solid var(--primary-light, #bfdbfe)" }}>
                            <h3 style={{ fontSize: 16, fontWeight: 600, color: "var(--text-primary)", marginBottom: 16 }}>
                                {editId ? "Edit Tool" : "Add New Tool"}
                            </h3>
                            <form onSubmit={handleToolSubmit}>
                                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14 }}>
                                    <div>
                                        <label style={labelStyle}>Tool Name *</label>
                                        <input style={toolInpErr("name")} value={form.name} onChange={(e) => { setForm({ ...form, name: e.target.value }); if (toolErrors.name) setToolErrors((p) => ({ ...p, name: undefined })); }} placeholder="e.g., Cordless Drill" />
                                        {toolErrors.name && <span style={errText}>{toolErrors.name}</span>}
                                    </div>
                                    <div>
                                        <label style={labelStyle}>Tool Code</label>
                                        <input style={inputStyle} value={form.tool_code} onChange={(e) => setForm({ ...form, tool_code: e.target.value })} placeholder="e.g., TL-001" />
                                    </div>
                                    <div>
                                        <label style={labelStyle}>Total Quantity</label>
                                        <input style={toolInpErr("total_qty")} type="number" min="0" value={form.total_qty} onChange={(e) => { setForm({ ...form, total_qty: parseInt(e.target.value) || 0 }); if (toolErrors.total_qty) setToolErrors((p) => ({ ...p, total_qty: undefined })); }} />
                                        {toolErrors.total_qty && <span style={errText}>{toolErrors.total_qty}</span>}
                                    </div>
                                    <div>
                                        <label style={labelStyle}>Notes</label>
                                        <input style={inputStyle} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Optional" />
                                    </div>
                                </div>
                                <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
                                    <button type="submit" style={btnPrimary}>{editId ? "Update" : "Add Tool"}</button>
                                    <button type="button" onClick={resetToolForm} style={btnSecondary}>Cancel</button>
                                </div>
                            </form>
                        </div>
                    )}

                    {/* Filters */}
                    <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" }} className="no-print">
                        <input
                            style={{ ...inputStyle, maxWidth: 280 }}
                            placeholder="Search by name, code, or notes..."
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>

                    {/* Tools table */}
                    <div style={{ ...glassCard, padding: 0, overflow: "hidden" }}>
                        <div style={{ overflowX: "auto" }}>
                            <table style={{ width: "100%", borderCollapse: "collapse" }}>
                                <thead>
                                    <tr>
                                        <th style={thStyle}>Tool Name</th>
                                        <th style={thStyle}>Tool Code</th>
                                        <th style={thStyle}>Total Qty</th>
                                        <th style={thStyle}>Notes</th>
                                        {isAdmin && <th style={{ ...thStyle, textAlign: "right" }} className="no-print">Actions</th>}
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredTools.length === 0 ? (
                                        <tr><td colSpan={isAdmin ? 5 : 4} style={{ ...tdStyle, textAlign: "center", color: "#94a3b8", padding: 40 }}>No tools found</td></tr>
                                    ) : filteredTools.map((t) => (
                                        <tr key={t.id} style={{ transition: "background 0.15s" }}
                                            onMouseEnter={(e) => e.currentTarget.style.background = "var(--table-row-hover, #f8fafc)"}
                                            onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}>
                                            <td style={{ ...tdStyle, fontWeight: 600 }}>{t.name || "—"}</td>
                                            <td style={tdStyle}>
                                                <span style={{ background: "var(--table-header-bg)", color: "var(--text-primary)", border: "1px solid var(--border-subtle)", padding: "3px 10px", borderRadius: 6, fontSize: 12, fontWeight: 500, fontFamily: "monospace" }}>
                                                    {t.tool_code || "—"}
                                                </span>
                                            </td>
                                            <td style={{ ...tdStyle, fontWeight: 600 }}>{t.total_qty ?? "—"}</td>
                                            <td style={{ ...tdStyle, fontSize: 12, color: "#64748b", maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.notes || "—"}</td>
                                            {isAdmin && (
                                                <td style={{ ...tdStyle, textAlign: "right" }} className="no-print">
                                                    <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                                                        <button onClick={() => handleEditTool(t)} style={btnSecondary}>Edit</button>
                                                        <button onClick={() => handleDeleteTool(t.id)} style={btnDanger}>Delete</button>
                                                    </div>
                                                </td>
                                            )}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}

            {/* ═══════════ ALLOCATIONS TAB ═══════════ */}
            {tab === "allocations" && (
                <div>
                    {showAllocForm && isAdmin && (
                        <div style={{ ...glassCard, border: "1px solid #bfdbfe" }}>
                            <h3 style={{ fontSize: 16, fontWeight: 600, color: "#1e293b", marginBottom: 16 }}>
                                {editAllocId ? "Edit Allocation" : "Allocate Tool to Site"}
                            </h3>
                            <form onSubmit={handleAllocSubmit}>
                                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14 }}>
                                    <div>
                                        <label style={labelStyle}>Tool *</label>
                                        <select style={allocSelErr("tool_id")} value={allocForm.tool_id} onChange={(e) => { setAllocForm({ ...allocForm, tool_id: e.target.value }); if (allocErrors.tool_id) setAllocErrors((p) => ({ ...p, tool_id: undefined })); }}>
                                            <option value="">Select tool...</option>
                                            {toolsWithAvailable.map((t) => <option key={t.id} value={t.id}>{t.name} {t.tool_code ? `(${t.tool_code})` : ""} – Avail: {t.computed_available}</option>)}
                                        </select>
                                        {allocErrors.tool_id && <span style={errText}>{allocErrors.tool_id}</span>}
                                    </div>
                                    <div>
                                        <label style={labelStyle}>Site *</label>
                                        <select style={allocSelErr("site_id")} value={allocForm.site_id} onChange={(e) => { setAllocForm({ ...allocForm, site_id: e.target.value }); if (allocErrors.site_id) setAllocErrors((p) => ({ ...p, site_id: undefined })); }}>
                                            <option value="">Select site...</option>
                                            {(isAdmin ? sites : allowedSites).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                                        </select>
                                        {allocErrors.site_id && <span style={errText}>{allocErrors.site_id}</span>}
                                    </div>
                                    <div>
                                        <label style={labelStyle}>Worker *</label>
                                        <select style={allocSelErr("worker_id")} value={allocForm.worker_id} onChange={(e) => { setAllocForm({ ...allocForm, worker_id: e.target.value }); if (allocErrors.worker_id) setAllocErrors((p) => ({ ...p, worker_id: undefined })); }}>
                                            <option value="">Select worker...</option>
                                            {workers.filter(w => !w.status || w.status === "active").map((w) => (
                                                <option key={w.id} value={w.id}>{w.full_name || w.name || "Unknown"}</option>
                                            ))}
                                        </select>
                                        {allocErrors.worker_id && <span style={errText}>{allocErrors.worker_id}</span>}
                                    </div>
                                    <div>
                                        <label style={labelStyle}>Quantity</label>
                                        <input style={allocInpErr("qty")} type="number" min="1" value={allocForm.qty} onChange={(e) => { setAllocForm({ ...allocForm, qty: parseInt(e.target.value) || 1 }); if (allocErrors.qty) setAllocErrors((p) => ({ ...p, qty: undefined })); }} />
                                        {allocErrors.qty && <span style={errText}>{allocErrors.qty}</span>}
                                    </div>
                                    <div>
                                        <label style={labelStyle}>Allocated Date</label>
                                        <input style={inputStyle} type="date" value={allocForm.allocated_date} onChange={(e) => setAllocForm({ ...allocForm, allocated_date: e.target.value })} />
                                    </div>
                                    <div>
                                        <label style={labelStyle}>Status</label>
                                        {/* FIX: removed 'in_use' which violates DB constraint. Only DB-valid statuses now */}
                                        <select style={selectStyle} value={allocForm.status} onChange={(e) => setAllocForm({ ...allocForm, status: e.target.value })}>
                                            <option value="allocated">Allocated</option>
                                            <option value="lost">Lost</option>
                                            <option value="damaged">Damaged</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label style={labelStyle}>Notes</label>
                                        <input style={inputStyle} value={allocForm.notes} onChange={(e) => setAllocForm({ ...allocForm, notes: e.target.value })} placeholder="Optional" />
                                    </div>
                                </div>
                                <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
                                    <button type="submit" style={btnPrimary}>{editAllocId ? "Update" : "Allocate"}</button>
                                    <button type="button" onClick={resetAllocForm} style={btnSecondary}>Cancel</button>
                                </div>
                            </form>
                        </div>
                    )}

                    {/* Site Filter & Stats */}
                    {(() => {
                        const activeList = filteredAllocations.filter(a => a.status === 'allocated' && !a.returned_date);
                        const damagedList = filteredAllocations.filter(a => a.status === 'damaged' && !a.returned_date);
                        const lostList = filteredAllocations.filter(a => a.status === 'lost' && !a.returned_date);
                        const returnedList = filteredAllocations.filter(a => a.status === 'returned' || !!a.returned_date);

                        const TableSection = ({ title, list, color, bg, border }) => (
                            <div style={{ ...glassCard, padding: 0, overflow: "hidden", marginTop: 16 }}>
                                <div style={{ padding: "14px 20px", background: bg, borderBottom: `1px solid ${border}` }}>
                                    <h3 style={{ fontSize: 15, fontWeight: 700, color: color, margin: 0 }}>{title} ({list.length})</h3>
                                </div>
                                <div style={{ overflowX: "auto" }}>
                                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                                        <thead>
                                            <tr>
                                                <th style={thStyle}>Tool</th>
                                                <th style={thStyle}>Site</th>
                                                <th style={thStyle}>Worker</th>
                                                <th style={thStyle}>Qty</th>
                                                <th style={thStyle}>Allocated</th>
                                                {title === "Returned" && <th style={thStyle}>Returned</th>}
                                                <th style={thStyle}>Status</th>
                                                <th style={thStyle}>Notes</th>
                                                <th style={{ ...thStyle, textAlign: "right" }} className="no-print">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {list.length === 0 ? (
                                                <tr><td colSpan={title === "Returned" ? 9 : 8} style={{ ...tdStyle, textAlign: "center", color: "#94a3b8", padding: 30 }}>No {title.toLowerCase()} recorded</td></tr>
                                            ) : list.map((a) => (
                                                <tr key={a.id} onMouseEnter={(e) => e.currentTarget.style.background = "#f8fafc"} onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}>
                                                    <td style={{ ...tdStyle, fontWeight: 600 }}>{toolMap[a.tool_id]?.name || <><span style={{color:'var(--text-muted)'}}>Deleted Tool</span> <span className="archived-badge">deleted</span></>}</td>
                                                    <td style={tdStyle}>{siteNode(a.site_id)}</td>
                                                    <td style={tdStyle}>{workerNode(a.worker_id)}</td>
                                                    <td style={{ ...tdStyle, fontWeight: 600 }}>{a.qty}</td>
                                                    <td style={{ ...tdStyle, fontSize: 12 }}>{a.allocated_date || "—"}</td>
                                                    {title === "Returned" && <td style={{ ...tdStyle, fontSize: 12, fontWeight: 600 }}>{a.returned_date || "—"}</td>}
                                                    <td style={tdStyle}>
                                                        <span style={{ ...getStatusStyle(a.status), padding: "3px 10px", borderRadius: 6, fontSize: 11, fontWeight: 700 }}>
                                                            {getStatusLabel(a.status)}
                                                        </span>
                                                    </td>
                                                    <td style={{ ...tdStyle, fontSize: 12, color: "#64748b", maxWidth: 140, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{a.notes || "—"}</td>
                                                    <td style={{ ...tdStyle, textAlign: "right" }} className="no-print">
                                                        <div style={{ display: "flex", gap: 6, justifyContent: "flex-end" }}>
                                                            {title !== "Returned" && <button onClick={() => handleReturnAlloc(a.id)} style={btnSuccess}>Return</button>}
                                                            {isAdmin && (
                                                                <>
                                                                    <button onClick={() => handleEditAlloc(a)} style={btnSecondary}>Edit</button>
                                                                    <button onClick={() => handleDeleteAlloc(a.id)} style={btnDanger}>Delete</button>
                                                                </>
                                                            )}
                                                            {title === "Returned" && !isAdmin && <button onClick={() => handleDeleteAlloc(a.id)} style={btnDanger}>Delete</button>}
                                                        </div>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        );

                        return (
                            <>
                                <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap", alignItems: "center" }}>
                                    <select style={{ ...selectStyle, maxWidth: 240 }} value={siteFilter} onChange={(e) => setSiteFilter(e.target.value)}>
                                        <option value="all">All Sites</option>
                                        {allowedSites.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                                    </select>
                                    <span style={{ fontSize: 13, color: "#64748b" }}>{filteredAllocations.length} total assignment(s)</span>
                                </div>

                                <TableSection title="Active Allocations" list={activeList} color="#1e293b" bg="#f8fafc" border="#e2e8f0" />
                                <TableSection title="Damaged Tools" list={damagedList} color="#9a3412" bg="#fff7ed" border="#ffedd5" />
                                <TableSection title="Lost Tools" list={lostList} color="#991b1b" bg="#fef2f2" border="#fee2e2" />
                                {returnedList.length > 0 && <TableSection title="Returned" list={returnedList} color="#16a34a" bg="#f0fdf4" border="#bbf7d0" />}
                            </>
                        );
                    })()}
                </div>

            )}

            {/* ═══════════ REPORT TAB ═══════════ */}
            {tab === "report" && (
                <div>
                    <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap", alignItems: "center" }}>
                        <input style={{ ...inputStyle, maxWidth: 200 }} type="month" value={reportMonth} onChange={(e) => setReportMonth(e.target.value)} />
                        <select style={{ ...selectStyle, maxWidth: 240 }} value={siteFilter} onChange={(e) => setSiteFilter(e.target.value)}>
                            <option value="all">All Sites</option>
                            {allowedSites.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                        </select>
                        <button onClick={exportCSV} style={btnSecondary}>Export CSV</button>
                    </div>

                    {reportData.length === 0 ? (
                        <div style={{ ...glassCard, textAlign: "center", color: "#94a3b8", padding: 60 }}>
                            <div style={{ color: "var(--text-soft)", marginBottom: 16, display: 'flex', justifyContent: 'center' }}>
                                <svg width="48" height="48" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                                    <path d="M18 20V10M12 20V4M6 20v-6"></path>
                                </svg>
                            </div>
                            <p style={{ fontSize: 15 }}>No allocation data for {reportMonth}</p>
                        </div>
                    ) : (
                        reportData.map((site) => (
                            <div key={site.site_id} style={{ ...glassCard, padding: 0, overflow: "hidden", marginBottom: 16 }}>
                                <div style={{ padding: "14px 20px", background: "#f8fafc", borderBottom: "1px solid #e2e8f0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                                    <h3 style={{ fontSize: 15, fontWeight: 600, color: "#1e293b", margin: 0 }}>{site.siteName}</h3>
                                    <div style={{ display: "flex", gap: 12, fontSize: 12 }}>
                                        <span style={{ color: "#3b82f6", fontWeight: 600 }}>{site.totalQty} allocated</span>
                                        <span style={{ color: "#16a34a", fontWeight: 600 }}>{site.returned} returned</span>
                                        <span style={{ color: "#d97706", fontWeight: 600 }}>{site.totalQty - site.returned} active</span>
                                    </div>
                                </div>
                                <div style={{ height: 4, background: "#e2e8f0" }}>
                                    <div style={{ height: 4, width: `${site.totalQty > 0 ? (site.returned / site.totalQty) * 100 : 0}%`, background: "linear-gradient(90deg,#16a34a,#22c55e)", borderRadius: 2, transition: "width 0.5s" }} />
                                </div>
                                <div style={{ overflowX: "auto" }}>
                                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                                        <thead>
                                            <tr>
                                                <th style={thStyle}>Tool</th>
                                                <th style={thStyle}>Code</th>
                                                <th style={thStyle}>Qty</th>
                                                <th style={thStyle}>Allocated</th>
                                                <th style={thStyle}>Returned</th>
                                                <th style={thStyle}>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {site.tools.map((t, i) => {
                                                const isReturned = t.returned_date || t.status === "returned";
                                                return (
                                                    <tr key={i}>
                                                        <td style={{ ...tdStyle, fontWeight: 500 }}>{t.toolName}</td>
                                                        <td style={tdStyle}><span style={{ background: "#f1f5f9", padding: "2px 8px", borderRadius: 4, fontSize: 11, fontFamily: "monospace" }}>{t.toolCode || "—"}</span></td>
                                                        <td style={tdStyle}>{t.qty}</td>
                                                        <td style={{ ...tdStyle, fontSize: 12 }}>{t.allocated_date || "—"}</td>
                                                        <td style={{ ...tdStyle, fontSize: 12 }}>{t.returned_date || "—"}</td>
                                                        <td style={tdStyle}>
                                                            {/* FIX: uses proper DB-valid status labels */}
                                                            <span style={{
                                                                padding: "3px 10px", borderRadius: 6, fontSize: 11, fontWeight: 600,
                                                                ...(isReturned
                                                                    ? { background: "#f0fdf4", color: "#16a34a" }
                                                                    : getStatusStyle(t.status)),
                                                            }}>
                                                                {isReturned ? "Returned" : getStatusLabel(t.status)}
                                                            </span>
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        ))
                    )}
                </div>
            )}
        </div>
    );
}
