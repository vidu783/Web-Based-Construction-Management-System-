// ============================================================================
// FEATURE: UserProfile.jsx — User Profile Management
// Allows users to view/edit their profile, change password, upload photo
// FIX: Profile pictures are now stored per-user using user-specific keys
// ============================================================================

import { useState, useEffect, useRef } from "react";

const API = (import.meta.env.VITE_API_URL || "http://localhost:8080").replace(/\/+$/, "");
const hdr = () => {
    const token = localStorage.getItem("access_token") || localStorage.getItem("token") || "";
    return {
        "Content-Type": "application/json",
        Authorization: token ? `Bearer ${token}` : "",
    };
};

const ROLE_LABELS = {
    admin: "System Administrator",
    project_manager: "Project Manager",
    site_officer: "Site Officer",
    finance_officer: "Finance Officer",
};

const ROLE_COLORS = {
    admin: "#C8102E",
    project_manager: "#2563eb",
    site_officer: "#16a34a",
    finance_officer: "#f59e0b",
};

// Helper: get user-specific localStorage key for profile pic
const getPicKey = (user) => {
    const uid = user?.id || user?.email || "default";
    return `profile_pic_${uid}`;
};

export default function UserProfile({ user, onUserUpdate }) {
    // ── State ──
    const [tab, setTab] = useState("profile");
    const [loading, setLoading] = useState(false);
    const [msg, setMsg] = useState({ text: "", type: "" });

    // Profile fields
    const [fullName, setFullName] = useState(user?.full_name || "");
    const [phone, setPhone] = useState(user?.phone || "");
    const [previewUrl, setPreviewUrl] = useState(null);
    const fileInputRef = useRef(null);

    // Password fields
    const [currentPassword, setCurrentPassword] = useState("");
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [showCurrentPw, setShowCurrentPw] = useState(false);
    const [showNewPw, setShowNewPw] = useState(false);
    const [showConfirmPw, setShowConfirmPw] = useState(false);

    // Field errors
    const [fieldErrors, setFieldErrors] = useState({});

    // Load saved profile picture — Prioritize URL from DB, fallback to localStorage
    useEffect(() => {
        if (user?.avatar_url) {
            setPreviewUrl(user.avatar_url);
        } else {
            const savedPic = localStorage.getItem(getPicKey(user));
            setPreviewUrl(savedPic || null);
        }
    }, [user]);

    const msgTimeout = useRef(null);
    const flash = (text, type = "ok") => {
        if (msgTimeout.current) clearTimeout(msgTimeout.current);
        setMsg({ text, type });
        msgTimeout.current = setTimeout(() => setMsg({ text: "", type: "" }), 5000);
    };

    const clearFieldErrors = () => setFieldErrors({});

    // ── Validation Helpers ──
    const validatePhone = (p) => {
        if (!p || !p.trim()) return true;
        const digits = p.replace(/[^0-9]/g, "");
        return digits.length === 10;
    };
    
    const formatPhone = (p) => {
        if (!p) return "";
        const digits = p.replace(/[^0-9]/g, "");
        if (digits.length === 10) {
            return digits; // Keep as 10-digit number for backend compatibility
        }
        return p;
    };

    const validateName = (name) => {
        if (name.trim().length < 3) return "Name must be at least 3 characters";
        if (/[0-9]/.test(name)) return "Name should not contain numbers";
        return "";
    };

    const validatePassword = (pw) => {
        const errors = [];
        if (pw.length < 8) errors.push("at least 8 characters");
        if (!/[A-Z]/.test(pw)) errors.push("one uppercase letter");
        if (!/[a-z]/.test(pw)) errors.push("one lowercase letter");
        if (!/[0-9]/.test(pw)) errors.push("one number");
        return errors;
    };

    const getPasswordStrength = (pw) => {
        if (!pw) return null;
        const errors = validatePassword(pw);
        const score = 4 - errors.length;
        if (score <= 1) return { label: "Weak", color: "#dc2626", width: "25%" };
        if (score === 2) return { label: "Fair", color: "#f59e0b", width: "50%" };
        if (score === 3) return { label: "Good", color: "#2563eb", width: "75%" };
        return { label: "Strong", color: "#16a34a", width: "100%" };
    };

    // Helper: compress image using canvas
    const compressImage = (base64Str, maxWidth = 400, maxHeight = 400) => {
        return new Promise((resolve) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement("canvas");
                let { width, height } = img;
                if (width > height) {
                    if (width > maxWidth) {
                        height *= maxWidth / width;
                        width = maxWidth;
                    }
                } else {
                    if (height > maxHeight) {
                        width *= maxHeight / height;
                        height = maxHeight;
                    }
                }
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext("2d");
                ctx.drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL("image/jpeg", 0.7)); // 0.7 quality
            };
            img.onerror = () => resolve(base64Str); // Fallback to original if compression fails
            img.src = base64Str; // Set source AFTER attaching listeners to avoid race condition
        });
    };

    // ── Profile Picture Handler — SAVES TO CLOUD STORAGE ──
    const handlePicChange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        // Validate file
        const validTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
        if (!validTypes.includes(file.type)) {
            flash("Please upload a valid image (JPG, PNG, GIF, or WebP)", "err");
            return;
        }
        if (file.size > 5 * 1024 * 1024) {
            flash("Image must be less than 5MB", "err");
            return;
        }

        const formData = new FormData();
        formData.append("profile_pic", file);

        setLoading(true);
        try {
            const r = await fetch(`${API}/auth/profile-pic`, {
                method: "POST",
                headers: {
                    Authorization: hdr().Authorization,
                },
                body: formData,
            });

            if (r.ok) {
                const data = await r.json();
                setPreviewUrl(data.avatar_url);
                // Also update localStorage for quick access
                localStorage.setItem(getPicKey(user), data.avatar_url);
                
                if (onUserUpdate) {
                    onUserUpdate({ ...user, avatar_url: data.avatar_url });
                }
                flash("Profile picture updated successfully! ✓", "ok");
            } else {
                const d = await r.json();
                flash(d.error || "Upload failed", "err");
            }
        } catch (err) {
            console.error("Upload error:", err);
            flash("Connection error. Make sure the server is running.", "err");
        }
        setLoading(false);
    };

    const handleRemovePic = () => {
        setPreviewUrl(null);
        // FIXED: Remove user-specific key instead of generic "profile_pic"
        localStorage.removeItem(getPicKey(user));
        if (fileInputRef.current) fileInputRef.current.value = "";
        if (onUserUpdate) {
            onUserUpdate({ ...user, profilePic: null });
        }
        flash("Profile picture removed");
    };

    // ── Save Profile ──
    const handleSaveProfile = async (e) => {
        e.preventDefault();
        setMsg({ text: "", type: "" }); // Clear previous messages
        clearFieldErrors();
        const errors = {};

        if (!fullName.trim()) {
            errors.fullName = "Full name is required";
        } else {
            const nameErr = validateName(fullName);
            if (nameErr) errors.fullName = nameErr;
        }

        if (phone.trim() && !validatePhone(phone)) {
            errors.phone = "Enter a valid 10-digit phone number";
        }

        if (Object.keys(errors).length > 0) {
            setFieldErrors(errors);
            return;
        }

        setLoading(true);
        try {
            const r = await fetch(`${API}/auth/profile`, {
                method: "PUT",
                headers: hdr(),
                body: JSON.stringify({
                    full_name: fullName.trim(),
                    phone: phone.trim(),
                }),
            });

            // ADD THIS TOKEN EXPIRATION HANDLING:
            if (r.status === 401 || r.status === 403) {
                // Clear expired session data
                localStorage.removeItem("token");
                localStorage.removeItem("access_token");
                localStorage.removeItem("user");
                
                // Show user-friendly message
                flash("Your session has expired. Redirecting to login...", "err");
                
                // Redirect to login after brief delay
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
                return;
            }

            if (r.ok) {
                await r.json();
                // FIXED: Save profile pic under user-specific key
                if (previewUrl) {
                    localStorage.setItem(getPicKey(user), previewUrl);
                }
                // Update user in localStorage
                const storedUser = JSON.parse(localStorage.getItem("user") || "{}");
                const updatedUser = {
                    ...storedUser,
                    full_name: fullName.trim(),
                    phone: phone.trim(),
                };
                localStorage.setItem("user", JSON.stringify(updatedUser));
                if (onUserUpdate) onUserUpdate(updatedUser);
                flash("Profile updated successfully");
            } else {
                const d = await r.json();
                flash(d.error || "Update failed", "err");
            }
        } catch {
            // If the endpoint doesn't exist yet, save locally
            if (previewUrl) {
                localStorage.setItem(getPicKey(user), previewUrl);
            }
            const storedUser = JSON.parse(localStorage.getItem("user") || "{}");
            const updatedUser = {
                ...storedUser,
                full_name: fullName.trim(),
                phone: phone.trim(),
            };
            localStorage.setItem("user", JSON.stringify(updatedUser));
            if (onUserUpdate) onUserUpdate(updatedUser);
            flash("Profile updated locally");
        }
        setLoading(false);
    };

    // ── Change Password ──
    const handleChangePassword = async (e) => {
        e.preventDefault();
        clearFieldErrors();
        const errors = {};

        if (!currentPassword) {
            errors.currentPassword = "Current password is required";
        }

        if (!newPassword) {
            errors.newPassword = "New password is required";
        } else {
            const pwErrors = validatePassword(newPassword);
            if (pwErrors.length > 0) {
                errors.newPassword = `Password needs: ${pwErrors.join(", ")}`;
            }
        }

        if (!confirmPassword) {
            errors.confirmPassword = "Please confirm your new password";
        } else if (newPassword !== confirmPassword) {
            errors.confirmPassword = "Passwords do not match";
        }

        if (currentPassword && newPassword && currentPassword === newPassword) {
            errors.newPassword = "New password must be different from current password";
        }

        if (Object.keys(errors).length > 0) {
            setFieldErrors(errors);
            return;
        }

        setLoading(true);
        try {
            const r = await fetch(`${API}/auth/change-password`, {
                method: "PUT",
                headers: hdr(),
                body: JSON.stringify({
                    current_password: currentPassword,
                    new_password: newPassword,
                }),
            });

            // ADD SAME TOKEN HANDLING HERE:
            if (r.status === 401 || r.status === 403) {
                localStorage.removeItem("token");
                localStorage.removeItem("access_token");
                localStorage.removeItem("user");
                flash("Your session has expired. Redirecting to login...", "err");
                setTimeout(() => window.location.reload(), 2000);
                return;
            }

            if (r.ok) {
                flash("Password changed successfully! Please log in again with your new password.");
                setCurrentPassword("");
                setNewPassword("");
                setConfirmPassword("");
            } else {
                const d = await r.json();
                flash(d.error || "Password change failed", "err");
            }
        } catch {
            flash("Connection error. Make sure the server is running.", "err");
        }
        setLoading(false);
    };

    // ── Styles ──
    const cardStyle = {
        background: "var(--bg-surface)",
        borderRadius: 16,
        padding: 28,
        border: "1px solid var(--border-subtle)",
        boxShadow: "var(--shadow-sm)",
        marginBottom: 20,
    };
    const inputStyle = {
        width: "100%",
        padding: "12px 14px",
        border: "1px solid var(--border-subtle)",
        borderRadius: 10,
        fontSize: 14,
        boxSizing: "border-box",
        outline: "none",
        transition: "border-color 0.2s, box-shadow 0.2s",
        background: "var(--input-bg)",
        color: "var(--text-primary)",
    };
    const inputErrorStyle = {
        ...inputStyle,
        border: "1px solid var(--error)",
        boxShadow: "0 0 0 3px rgba(220,38,38,0.1)",
    };
    const labelStyle = {
        display: "block",
        fontSize: 13,
        fontWeight: 600,
        color: "var(--text-primary)",
        marginBottom: 6,
    };
    const fieldErrStyle = {
        fontSize: 12,
        color: "var(--error)",
        marginTop: 4,
        display: "flex",
        alignItems: "center",
        gap: 4,
    };
    const btnPrimary = {
        background: "var(--brand-primary, linear-gradient(135deg, #C8102E, #a00d24))",
        color: "#fff",
        border: "none",
        padding: "12px 28px",
        borderRadius: 10,
        fontSize: 14,
        fontWeight: 700,
        cursor: "pointer",
        transition: "all 0.2s",
    };
    const btnSecondary = {
        background: "var(--bg-body)",
        color: "var(--text-soft)",
        border: "1px solid var(--border-subtle)",
        padding: "10px 20px",
        borderRadius: 10,
        fontSize: 13,
        fontWeight: 600,
        cursor: "pointer",
    };
    const tabBtnStyle = (active) => ({
        padding: "12px 28px",
        border: "none",
        borderRadius: "12px 12px 0 0",
        fontSize: 14,
        fontWeight: 600,
        cursor: "pointer",
        background: active ? "var(--bg-surface)" : "var(--bg-body)",
        color: active ? "var(--brand-primary, #C8102E)" : "var(--text-soft)",
        borderBottom: active ? "3px solid var(--brand-primary, #C8102E)" : "3px solid transparent",
        transition: "all 0.2s",
    });

    const roleColor = ROLE_COLORS[user?.role] || "var(--text-soft)";
    const roleLabel = ROLE_LABELS[user?.role] || user?.role || "User";
    const initials = (user?.full_name || user?.email || "U")
        .split(" ")
        .map((w) => w[0])
        .join("")
        .toUpperCase()
        .slice(0, 2);

    const pwStrength = getPasswordStrength(newPassword);

    return (
        <div style={{ maxWidth: 800, margin: "0 auto" }}>
            <style>{`
                .profile-input:focus {
                    border-color: var(--brand-primary, #C8102E) !important;
                    box-shadow: 0 0 0 3px rgba(200,16,46,0.1) !important;
                }
                .profile-input-error:focus {
                    border-color: var(--error) !important;
                    box-shadow: 0 0 0 3px rgba(220,38,38,0.1) !important;
                }
                .profile-pic-overlay:hover {
                    opacity: 1 !important;
                }
            `}</style>

            {/* Header Card */}
            <div style={{
                ...cardStyle,
                background: `linear-gradient(135deg, ${roleColor}08, ${roleColor}03)`,
                border: `1px solid ${roleColor}20`,
                display: "flex",
                alignItems: "center",
                gap: 24,
                flexWrap: "wrap",
            }}>
                {/* Profile Picture */}
                <div style={{ position: "relative" }}>
                    <div style={{
                        width: 90, height: 90, borderRadius: 20, overflow: "hidden",
                        background: previewUrl
                            ? "transparent"
                            : `linear-gradient(135deg, ${roleColor}, ${roleColor}99)`,
                        display: "flex", alignItems: "center", justifyContent: "center",
                        boxShadow: `0 4px 16px ${roleColor}30`,
                        border: `3px solid ${roleColor}30`,
                    }}>
                        {previewUrl ? (
                            <img src={previewUrl} alt="Profile" style={{
                                width: "100%", height: "100%", objectFit: "cover",
                            }} />
                        ) : (
                            <span style={{ fontSize: 32, fontWeight: 800, color: "#fff" }}>{initials}</span>
                        )}
                    </div>
                    {/* Camera overlay */}
                    <div
                        className="profile-pic-overlay"
                        onClick={() => fileInputRef.current?.click()}
                        style={{
                            position: "absolute", bottom: -4, right: -4,
                            width: 32, height: 32, borderRadius: 10,
                            background: "#C8102E", display: "flex",
                            alignItems: "center", justifyContent: "center",
                            cursor: "pointer", border: "3px solid #fff",
                            boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
                            transition: "transform 0.2s",
                        }}
                        title="Change photo"
                    >
                        <svg width="14" height="14" fill="none" stroke="#fff" strokeWidth="2.5" viewBox="0 0 24 24">
                            <path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z" />
                            <circle cx="12" cy="13" r="4" />
                        </svg>
                    </div>
                    <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/jpeg,image/png,image/gif,image/webp"
                        style={{ display: "none" }}
                        onChange={handlePicChange}
                    />
                </div>

                {/* User Info */}
                <div style={{ flex: 1 }}>
                    <h2 style={{ fontSize: 24, fontWeight: 800, color: "var(--text-primary)", margin: 0 }}>
                        {user?.full_name || "User"}
                    </h2>
                    <p style={{ fontSize: 14, color: "var(--text-soft)", margin: "4px 0 0" }}>{user?.email}</p>
                    <div style={{ display: "flex", gap: 10, marginTop: 10, flexWrap: "wrap", alignItems: "center" }}>
                        <span style={{
                            padding: "5px 16px", borderRadius: 20, fontSize: 12, fontWeight: 700,
                            background: `rgba(0,0,0,0.05)`, color: "var(--text-primary)",
                            border: `1px solid var(--border-subtle)`,
                            display: "flex", alignItems: "center", gap: 6,
                        }}>
                            <span style={{ width: 7, height: 7, borderRadius: "50%", background: roleColor }} />
                            {roleLabel}
                        </span>
                        {user?.phone && (
                            <span style={{ fontSize: 13, color: "var(--text-soft)", fontFamily: "monospace" }}>
                                {user.phone}
                            </span>
                        )}
                    </div>
                </div>
            </div>

            {/* Flash Message */}
            {msg.text && (
                <div style={{
                    padding: "12px 18px", borderRadius: 10, marginBottom: 16, fontSize: 13, fontWeight: 500,
                    background: msg.type === "err" ? "#fef2f2" : "#f0fdf4",
                    color: msg.type === "err" ? "#dc2626" : "#166534",
                    border: `1px solid ${msg.type === "err" ? "#fecaca" : "#bbf7d0"}`,
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                }}>
                    {msg.text}
                    <button onClick={() => setMsg({ text: "", type: "" })} style={{
                        background: "none", border: "none", cursor: "pointer", fontSize: 16, color: "inherit",
                    }}>×</button>
                </div>
            )}

            {/* Tabs */}
            <div style={{ display: "flex", gap: 4, marginBottom: 0 }}>
                <button style={tabBtnStyle(tab === "profile")} onClick={() => { setTab("profile"); clearFieldErrors(); }}>
                    Edit Profile
                </button>
                <button style={tabBtnStyle(tab === "password")} onClick={() => { setTab("password"); clearFieldErrors(); }}>
                    Change Password
                </button>
                <button style={tabBtnStyle(tab === "activity")} onClick={() => { setTab("activity"); clearFieldErrors(); }}>
                    Account Info
                </button>
            </div>

            <div style={{
                ...cardStyle,
                borderRadius: "0 16px 16px 16px",
                marginTop: 0,
                borderTop: "1px solid var(--border-subtle)",
            }}>
                {/* ═══════════ EDIT PROFILE TAB ═══════════ */}
                {tab === "profile" && (
                    <form onSubmit={handleSaveProfile}>
                        <h3 style={{ fontSize: 18, fontWeight: 700, color: "#1e293b", margin: "0 0 20px" }}>
                            Edit Profile
                        </h3>

                        {/* Profile Picture Section */}
                        <div style={{ marginBottom: 24 }}>
                            <label style={labelStyle}>Profile Picture</label>
                            <div style={{ display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
                                <div style={{
                                    width: 72, height: 72, borderRadius: 16, overflow: "hidden",
                                    background: previewUrl ? "transparent" : "var(--bg-body)",
                                    display: "flex", alignItems: "center", justifyContent: "center",
                                    border: "2px dashed var(--border-subtle)",
                                }}>
                                    {previewUrl ? (
                                        <img src={previewUrl} alt="Preview" style={{
                                            width: "100%", height: "100%", objectFit: "cover",
                                        }} />
                                    ) : (
                                        <svg width="24" height="24" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24">
                                            <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
                                            <circle cx="12" cy="7" r="4" />
                                        </svg>
                                    )}
                                </div>
                                <div style={{ display: "flex", gap: 8 }}>
                                    <button type="button" onClick={() => fileInputRef.current?.click()} style={btnSecondary}>
                                        Upload Photo
                                    </button>
                                    {previewUrl && (
                                        <button type="button" onClick={handleRemovePic} style={{
                                            ...btnSecondary, color: "var(--error)", border: "1px solid var(--error)40",
                                        }}>
                                            Remove
                                        </button>
                                    )}
                                </div>
                                <span style={{ fontSize: 12, color: "#94a3b8" }}>
                                    JPG, PNG, GIF or WebP. Max 10MB.
                                </span>
                            </div>
                        </div>

                        {/* Full Name */}
                        <div style={{ marginBottom: 20 }}>
                            <label style={labelStyle}>Full Name *</label>
                            <input
                                className={fieldErrors.fullName ? "profile-input-error" : "profile-input"}
                                style={fieldErrors.fullName ? inputErrorStyle : inputStyle}
                                value={fullName}
                                onChange={(e) => {
                                    setFullName(e.target.value);
                                    if (fieldErrors.fullName) setFieldErrors((p) => { const n = { ...p }; delete n.fullName; return n; });
                                }}
                                placeholder="Enter your full name"
                            />
                            {fieldErrors.fullName && (
                                <div style={fieldErrStyle}>
                                    <svg width="12" height="12" fill="none" stroke="#dc2626" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
                                    {fieldErrors.fullName}
                                </div>
                            )}
                        </div>

                        {/* Email (read-only) */}
                        <div style={{ marginBottom: 20 }}>
                            <label style={labelStyle}>Email</label>
                            <input
                                style={{ ...inputStyle, background: "var(--bg-body)", color: "var(--text-soft)", cursor: "not-allowed" }}
                                value={user?.email || ""}
                                disabled
                            />
                            <span style={{ fontSize: 11, color: "var(--text-soft)", marginTop: 4, display: "block" }}>
                                Email cannot be changed. Contact admin if needed.
                            </span>
                        </div>

                        {/* Phone */}
                        <div style={{ marginBottom: 20 }}>
                            <label style={labelStyle}>Phone Number</label>
                            <input
                                className={fieldErrors.phone ? "profile-input-error" : "profile-input"}
                                style={fieldErrors.phone ? inputErrorStyle : inputStyle}
                                value={phone}
                                onChange={(e) => {
                                    const cleaned = e.target.value.replace(/[^0-9\s\-()+]/g, "");
                                    setPhone(cleaned);
                                    if (fieldErrors.phone) setFieldErrors((p) => { const n = { ...p }; delete n.phone; return n; });
                                }}
                                placeholder="e.g. 0712345678"
                                maxLength={15}
                            />
                            {fieldErrors.phone && (
                                <div style={fieldErrStyle}>
                                    <svg width="12" height="12" fill="none" stroke="#dc2626" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
                                    {fieldErrors.phone}
                                </div>
                            )}
                        </div>

                        {/* Role (read-only) */}
                        <div style={{ marginBottom: 24 }}>
                            <label style={labelStyle}>Role</label>
                            <div style={{
                                padding: "12px 14px", borderRadius: 10, background: "var(--bg-body)",
                                border: "1px solid var(--border-subtle)", display: "flex", alignItems: "center", gap: 10,
                            }}>
                                <span style={{
                                    width: 10, height: 10, borderRadius: "50%", background: roleColor,
                                }} />
                                <span style={{ fontSize: 14, fontWeight: 600, color: "var(--text-primary)" }}>{roleLabel}</span>
                            </div>
                            <span style={{ fontSize: 11, color: "var(--text-soft)", marginTop: 4, display: "block" }}>
                                Role can only be changed by an administrator.
                            </span>
                        </div>

                        <button type="submit" disabled={loading} style={{
                            ...btnPrimary, opacity: loading ? 0.7 : 1, cursor: loading ? "not-allowed" : "pointer",
                        }}>
                            {loading ? "Saving..." : "Save Changes"}
                        </button>
                    </form>
                )}

                {/* ═══════════ CHANGE PASSWORD TAB ═══════════ */}
                {tab === "password" && (
                    <form onSubmit={handleChangePassword}>
                        <h3 style={{ fontSize: 18, fontWeight: 700, color: "#1e293b", margin: "0 0 8px" }}>
                            Change Password
                        </h3>
                        <p style={{ fontSize: 13, color: "#64748b", margin: "0 0 24px" }}>
                            Choose a strong password with at least 8 characters, including uppercase, lowercase, and a number.
                        </p>

                        {/* Current Password */}
                        <div style={{ marginBottom: 20 }}>
                            <label style={labelStyle}>Current Password *</label>
                            <div style={{ position: "relative" }}>
                                <input
                                    className={fieldErrors.currentPassword ? "profile-input-error" : "profile-input"}
                                    type={showCurrentPw ? "text" : "password"}
                                    style={{ ...(fieldErrors.currentPassword ? inputErrorStyle : inputStyle), paddingRight: 44 }}
                                    value={currentPassword}
                                    onChange={(e) => {
                                        setCurrentPassword(e.target.value);
                                        if (fieldErrors.currentPassword) setFieldErrors((p) => { const n = { ...p }; delete n.currentPassword; return n; });
                                    }}
                                    placeholder="Enter current password"
                                />
                                <button type="button" onClick={() => setShowCurrentPw(!showCurrentPw)} style={{
                                    position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)",
                                    background: "none", border: "none", cursor: "pointer", color: "#94a3b8", padding: 4,
                                }}>
                                    {showCurrentPw ? "Hide" : "Show"}
                                </button>
                            </div>
                            {fieldErrors.currentPassword && <div style={fieldErrStyle}>{fieldErrors.currentPassword}</div>}
                        </div>

                        {/* New Password */}
                        <div style={{ marginBottom: 20 }}>
                            <label style={labelStyle}>New Password *</label>
                            <div style={{ position: "relative" }}>
                                <input
                                    className={fieldErrors.newPassword ? "profile-input-error" : "profile-input"}
                                    type={showNewPw ? "text" : "password"}
                                    style={{ ...(fieldErrors.newPassword ? inputErrorStyle : inputStyle), paddingRight: 44 }}
                                    value={newPassword}
                                    onChange={(e) => {
                                        setNewPassword(e.target.value);
                                        if (fieldErrors.newPassword) setFieldErrors((p) => { const n = { ...p }; delete n.newPassword; return n; });
                                    }}
                                    placeholder="Min 8 chars, uppercase, lowercase, number"
                                />
                                <button type="button" onClick={() => setShowNewPw(!showNewPw)} style={{
                                    position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)",
                                    background: "none", border: "none", cursor: "pointer", color: "#94a3b8", padding: 4,
                                }}>
                                    {showNewPw ? "Hide" : "Show"}
                                </button>
                            </div>
                            {fieldErrors.newPassword && <div style={fieldErrStyle}>{fieldErrors.newPassword}</div>}
                            {/* Strength Bar */}
                            {newPassword && pwStrength && (
                                <div style={{ marginTop: 8 }}>
                                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                                        <span style={{ fontSize: 11, color: "#64748b" }}>Strength</span>
                                        <span style={{ fontSize: 11, fontWeight: 700, color: pwStrength.color }}>{pwStrength.label}</span>
                                    </div>
                                    <div style={{ width: "100%", height: 4, background: "#e2e8f0", borderRadius: 2 }}>
                                        <div style={{
                                            width: pwStrength.width, height: "100%", background: pwStrength.color,
                                            borderRadius: 2, transition: "all 0.3s",
                                        }} />
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Confirm Password */}
                        <div style={{ marginBottom: 24 }}>
                            <label style={labelStyle}>Confirm New Password *</label>
                            <div style={{ position: "relative" }}>
                                <input
                                    className={fieldErrors.confirmPassword ? "profile-input-error" : "profile-input"}
                                    type={showConfirmPw ? "text" : "password"}
                                    style={{ ...(fieldErrors.confirmPassword ? inputErrorStyle : inputStyle), paddingRight: 44 }}
                                    value={confirmPassword}
                                    onChange={(e) => {
                                        setConfirmPassword(e.target.value);
                                        if (fieldErrors.confirmPassword) setFieldErrors((p) => { const n = { ...p }; delete n.confirmPassword; return n; });
                                    }}
                                    placeholder="Re-enter new password"
                                />
                                <button type="button" onClick={() => setShowConfirmPw(!showConfirmPw)} style={{
                                    position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)",
                                    background: "none", border: "none", cursor: "pointer", color: "#94a3b8", padding: 4,
                                }}>
                                    {showConfirmPw ? "Hide" : "Show"}
                                </button>
                            </div>
                            {fieldErrors.confirmPassword && <div style={fieldErrStyle}>{fieldErrors.confirmPassword}</div>}
                            {/* Match indicator */}
                            {confirmPassword && newPassword && !fieldErrors.confirmPassword && (
                                <div style={{ fontSize: 12, marginTop: 4, color: newPassword === confirmPassword ? "#16a34a" : "#dc2626", display: "flex", alignItems: "center", gap: 4 }}>
                                    {newPassword === confirmPassword ? "✓ Passwords match" : "✗ Passwords do not match"}
                                </div>
                            )}
                        </div>

                        <button type="submit" disabled={loading} style={{
                            ...btnPrimary, opacity: loading ? 0.7 : 1, cursor: loading ? "not-allowed" : "pointer",
                        }}>
                            {loading ? "Changing..." : "Change Password"}
                        </button>
                    </form>
                )}

                {/* ═══════════ ACCOUNT INFO TAB ═══════════ */}
                {tab === "activity" && (
                    <div>
                        <h3 style={{ fontSize: 18, fontWeight: 700, color: "#1e293b", margin: "0 0 20px" }}>
                            Account Information
                        </h3>

                        <div style={{ display: "grid", gap: 16 }}>
                            {[
                                { label: "User ID", value: user?.id || "—", mono: true },
                                { label: "Email", value: user?.email || "—" },
                                { label: "Full Name", value: user?.full_name || "—" },
                                { label: "Phone", value: user?.phone || "Not provided" },
                                { label: "Role", value: roleLabel, color: roleColor },
                                { label: "Account Status", value: "Active", color: "#16a34a" },
                            ].map((item, i) => (
                                <div key={i} style={{
                                    display: "flex", justifyContent: "space-between", alignItems: "center",
                                    padding: "14px 18px", borderRadius: 10, background: "#f8fafc",
                                    border: "1px solid #f1f5f9",
                                }}>
                                    <span style={{ fontSize: 13, color: "#64748b", fontWeight: 500 }}>{item.label}</span>
                                    <span style={{
                                        fontSize: 13, fontWeight: 600,
                                        color: item.color || "#1e293b",
                                        fontFamily: item.mono ? "monospace" : "inherit",
                                    }}>
                                        {item.value}
                                    </span>
                                </div>
                            ))}
                        </div>

                        <div style={{
                            marginTop: 24, padding: "16px 20px", borderRadius: 10,
                            background: "#fffbeb", border: "1px solid #fde68a",
                        }}>
                            <div style={{ fontSize: 13, fontWeight: 600, color: "#92400e", marginBottom: 4 }}>
                                Security Tip
                            </div>
                            <div style={{ fontSize: 12, color: "#a16207", lineHeight: 1.5 }}>
                                Keep your password secure and never share it with anyone.
                                If you suspect unauthorized access, change your password immediately
                                from the "Change Password" tab.
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
