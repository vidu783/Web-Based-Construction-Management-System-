import { useState, useEffect, useCallback, useMemo, useRef } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8080";
const hdr = () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("access_token") || localStorage.getItem("token") || ""}`,
});

/* ════════════════════════════════════════════════════════════
   ATTENDANCE – enhanced
   ════════════════════════════════════════════════════════════ */
export default function Attendance() {
    const today = new Date().toISOString().slice(0, 10);

    /* ── state ── */
    const [tab, setTab] = useState("mark");
    const [date, setDate] = useState(today);
    const [workers, setWorkers] = useState([]);
    const [sites, setSites] = useState([]);
    const [deletedEntities, setDeletedEntities] = useState([]);
    const [deployments, setDeployments] = useState([]);
    const [attendance, setAttendance] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [officers, setOfficers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [msg, setMsg] = useState({ text: "", type: "" });
    const [markingIds, setMarkingIds] = useState(new Set());
    const [collapsedSites, setCollapsedSites] = useState(new Set());
    const [siteSearch, setSiteSearch] = useState("");

    // Report state
    const [reportMonth, setReportMonth] = useState(today.slice(0, 7));
    const [reportData, setReportData] = useState([]);
    const [reportLoading, setReportLoading] = useState(false);
    const [reportSiteFilter, setReportSiteFilter] = useState("all");
    const [reportSort, setReportSort] = useState("name");

    // Current user
    const currentUser = useMemo(() => {
        try {
            return JSON.parse(localStorage.getItem("user") || "{}");
        } catch {
            return {};
        }
    }, []);
    const userRole = currentUser.role || "admin";
    const userId = currentUser.id || currentUser.user_id || "";
    const isSiteOfficer = userRole === "site_officer";
    const isAdmin = userRole === "admin" || userRole === "project_manager";

    /* ── flash message ── */
    const msgTimeout = useRef(null);
    const flash = (text, type = "ok") => {
        if (msgTimeout.current) clearTimeout(msgTimeout.current);
        setMsg({ text, type });
        msgTimeout.current = setTimeout(() => setMsg({ text: "", type: "" }), 4000);
    };

    /* ═══════════════════ FETCHERS ═══════════════════ */
    const fetchWorkers = useCallback(async () => {
        try {
            const r = await fetch(`${API}/workers?archived=true`, { headers: hdr() });
            if (r.ok) setWorkers(await r.json());
        } catch (e) {
            console.error(e);
        }
    }, []);

    const fetchSites = useCallback(async () => {
        try {
            const r = await fetch(`${API}/fields?archived=true`, { headers: hdr() });
            if (r.ok) setSites(await r.json());
        } catch (e) {
            console.error(e);
        }
    }, []);

    const fetchDeployments = useCallback(async () => {
        try {
            const r = await fetch(`${API}/deployments?date=${date}`, { headers: hdr() });
            if (r.ok) setDeployments(await r.json());
        } catch (e) {
            console.error(e);
        }
    }, [date]);

    const fetchAttendance = useCallback(async () => {
        try {
            const r = await fetch(`${API}/attendance?date=${date}`, { headers: hdr() });
            if (r.ok) setAttendance(await r.json());
        } catch (e) {
            console.error(e);
        }
    }, [date]);

    const fetchAssignments = useCallback(async () => {
        try {
            const r = await fetch(`${API}/assignments`, { headers: hdr() });
            if (r.ok) setAssignments(await r.json());
        } catch (e) {
            console.error(e);
        }
    }, []);

    const fetchOfficers = useCallback(async () => {
        try {
            const r = await fetch(`${API}/officers`, { headers: hdr() });
            if (r.ok) setOfficers(await r.json());
        } catch (e) {
            console.error(e);
        }
    }, []);

    const loadAll = useCallback(async () => {
        setLoading(true);
        await Promise.all([
            fetchWorkers(),
            fetchSites(),
            fetchDeployments(),
            fetchAttendance(),
            fetchAssignments(),
            fetchOfficers(),
        ]);
        fetch(`${API}/deleted-entities?type=worker,site`, { headers: hdr() })
            .then(r => r.json()).then(d => setDeletedEntities(Array.isArray(d) ? d : [])).catch(() => {});
        setLoading(false);
    }, [fetchWorkers, fetchSites, fetchDeployments, fetchAttendance, fetchAssignments, fetchOfficers]);

    useEffect(() => {
        loadAll();
    }, [loadAll]);

    /* ═══════════════════ OFFICER SITE MATCHING ═══════════════════ */
    const allowedSiteIds = useMemo(() => {
        if (isAdmin) return null; // null = all sites
        let matchedOfficer = officers.find((o) => o.user_id === userId);
        if (!matchedOfficer) {
            matchedOfficer = officers.find((o) => {
                const nameMatch = o.full_name && currentUser.full_name && o.full_name.toLowerCase().trim() === currentUser.full_name.toLowerCase().trim();
                const phoneMatch = o.phone && currentUser.phone && o.phone.replace(/\s/g, "") === currentUser.phone?.replace(/\s/g, "");
                return nameMatch || phoneMatch;
            });
        }
        if (!matchedOfficer) return [];
        const ids = assignments
            .filter((a) => a.officer_id === matchedOfficer.id)
            .filter((a) => !a.to_date || a.to_date >= today)
            .map((a) => a.site_id);
        return [...new Set(ids)];
    }, [isAdmin, officers, userId, currentUser, assignments, today]);

    /* ═══════════════════ HELPERS ═══════════════════ */
    const workerMap = useMemo(() => {
        const m = {};
        workers.forEach((w) => (m[w.id] = w));
        return m;
    }, [workers]);

    const siteMap = useMemo(() => {
        const m = {};
        sites.forEach((s) => (m[s.id] = s));
        return m;
    }, [sites]);

    const getWorkerName = (id) => workerMap[id]?.full_name || deletedEntities.find(e => e.entity_id === id)?.entity_name || "Unknown";
    const getWorkerType = (id) => workerMap[id]?.worker_type || "—";
    const getSiteName = (id) => siteMap[id]?.name || deletedEntities.find(e => e.entity_id === id)?.entity_name || "Unknown";
    const deletedMap = Object.fromEntries((deletedEntities || []).map(e => [e.entity_id, e]));
    const workerNode = (id) => { if (!workerMap[id]) { const snap = deletedMap[id]; return (<>{snap?.entity_name || "Deleted Worker"} <span className="archived-badge">deleted</span></>); } return (<>{workerMap[id].full_name}{workerMap[id].is_archived && <span className="archived-badge">deleted</span>}</>); };
    const siteNode = (id) => { if (!siteMap[id]) { const snap = deletedMap[id]; return (<>{snap?.entity_name || "Deleted Site"} <span className="archived-badge">deleted</span></>); } return (<>{siteMap[id].name}{siteMap[id].is_archived && <span className="archived-badge">deleted</span>}</>); };

    const attendanceMap = useMemo(() => {
        const m = {};
        attendance.forEach((a) => {
            if (a.date === date) m[`${a.worker_id}_${a.site_id}`] = a.status;
        });
        return m;
    }, [attendance, date]);

    const getStatus = (workerId, siteId) => attendanceMap[`${workerId}_${siteId}`] || null;

    const siteGroups = useMemo(() => {
        const groups = {};
        deployments.forEach((dep) => {
            const sid = dep.site_id;
            if (allowedSiteIds !== null && !allowedSiteIds.includes(sid)) return;
            if (!groups[sid]) groups[sid] = { name: siteMap[sid]?.name || "Unknown", workers: [] };
            (dep.deployment_workers || []).forEach((dw) => {
                if (!groups[sid].workers.find((w) => w.worker_id === dw.worker_id)) {
                    groups[sid].workers.push(dw);
                }
            });
        });
        return groups;
    }, [deployments, allowedSiteIds, siteMap]);

    const siteGroupEntries = useMemo(() => {
        let entries = Object.entries(siteGroups);
        if (siteSearch.trim()) {
            const q = siteSearch.toLowerCase();
            entries = entries.filter(
                ([, g]) =>
                    g.name.toLowerCase().includes(q) ||
                    g.workers.some((w) => (workerMap[w.worker_id]?.full_name || "Unknown").toLowerCase().includes(q))
            );
        }
        return entries;
    }, [siteGroups, siteSearch, workerMap]);

    const stats = useMemo(() => {
        let deployed = 0, present = 0, absent = 0;
        siteGroupEntries.forEach(([siteId, g]) => {
            deployed += g.workers.length;
            g.workers.forEach((w) => {
                const s = attendanceMap[`${w.worker_id}_${siteId}`] || null;
                if (s === "present") present++;
                else if (s === "absent") absent++;
            });
        });
        return {
            deployed, present, absent,
            unmarked: deployed - present - absent,
            sites: siteGroupEntries.length,
            rate: deployed > 0 ? Math.round((present / deployed) * 100) : 0,
        };
    }, [siteGroupEntries, attendanceMap]);

    const getAssignedOfficer = (siteId) => {
        const a = assignments.find((a) => a.site_id === siteId && (!a.to_date || a.to_date >= today));
        if (!a) return null;
        const o = officers.find((o) => o.id === a.officer_id);
        return o ? o.full_name : null;
    };

    /* ═══════════════════ MARK ATTENDANCE ═══════════════════ */
    const markAttendance = async (workerId, siteId, status) => {
        const key = `${workerId}_${siteId}`;
        setMarkingIds((prev) => new Set(prev).add(key));
        try {
            const r = await fetch(`${API}/attendance`, {
                method: "POST",
                headers: hdr(),
                body: JSON.stringify({ worker_id: workerId, site_id: siteId, date, status }),
            });
            if (r.ok) {
                await fetchAttendance();
            } else {
                const d = await r.json();
                flash(d.error || "Failed to mark attendance", "err");
            }
        } catch (e) {
            flash(e.message, "err");
        }
        setMarkingIds((prev) => {
            const n = new Set(prev);
            n.delete(key);
            return n;
        });
    };

    const toggleCollapse = (siteId) => {
        setCollapsedSites((prev) => {
            const n = new Set(prev);
            if (n.has(siteId)) n.delete(siteId);
            else n.add(siteId);
            return n;
        });
    };

    /* ═══════════════════ REPORT ═══════════════════ */
    const fetchReport = async () => {
        setReportLoading(true);
        try {
            const [yearR, monthR] = reportMonth.split("-").map(Number);
            const daysInMonth = new Date(yearR, monthR, 0).getDate();
            const from = `${reportMonth}-01`;
            const to = `${reportMonth}-${String(daysInMonth).padStart(2, "0")}`;
            const r = await fetch(`${API}/attendance?from=${from}&to=${to}`, { headers: hdr() });
            if (r.ok) {
                const data = await r.json();
                const filtered = allowedSiteIds !== null ? data.filter((a) => allowedSiteIds.includes(a.site_id)) : data;
                setReportData(filtered);
            }
        } catch (e) {
            console.error(e);
        }
        setReportLoading(false);
    };

    const reportSummary = useMemo(() => {
        const filtered = reportSiteFilter === "all" ? reportData : reportData.filter((r) => r.site_id === reportSiteFilter);
        const wMap = {};
        filtered.forEach((r) => {
            const wid = r.worker_id;
            if (!wMap[wid]) wMap[wid] = { name: workerMap[wid]?.full_name || "Unknown", type: workerMap[wid]?.worker_type || "—", present: 0, absent: 0 };
            if (r.status === "present") wMap[wid].present++;
            else if (r.status === "absent") wMap[wid].absent++;
        });
        let list = Object.values(wMap);
        if (reportSort === "name") list.sort((a, b) => a.name.localeCompare(b.name));
        else if (reportSort === "present") list.sort((a, b) => b.present - a.present);
        else if (reportSort === "rate") {
            list.sort((a, b) => {
                const ra = a.present + a.absent > 0 ? a.present / (a.present + a.absent) : 0;
                const rb = b.present + b.absent > 0 ? b.present / (b.present + b.absent) : 0;
                return rb - ra;
            });
        }
        const totalP = filtered.filter((r) => r.status === "present").length;
        const totalA = filtered.filter((r) => r.status === "absent").length;
        return { workers: list, totalP, totalA, totalRecords: filtered.length, workerCount: list.length };
    }, [reportData, reportSiteFilter, reportSort, workerMap]);

    const exportCSV = () => {
        if (reportSummary.workers.length === 0) return;
        const header = "Worker,Type,Present,Absent,Total,Rate%\n";
        const rows = reportSummary.workers.map((w) => {
            const total = w.present + w.absent;
            const pct = total > 0 ? Math.round((w.present / total) * 100) : 0;
            return `"${w.name}","${w.type}",${w.present},${w.absent},${total},${pct}`;
        }).join("\n");
        const blob = new Blob([header + rows], { type: "text/csv" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `attendance-report-${reportMonth}.csv`;
        a.click();
        URL.revokeObjectURL(url);
    };

    const shiftDate = (days) => {
        const d = new Date(date);
        d.setDate(d.getDate() + days);
        setDate(d.toISOString().slice(0, 10));
    };

    /* ─── STYLES ─── */
    const glassCard = {
        background: "var(--bg-surface)", borderRadius: 14, padding: 16, textAlign: "center", border: "1px solid var(--border-subtle)",
        boxShadow: "var(--shadow-sm)", color: "var(--text-primary)", flex: "1 1 140px", minWidth: 130,
    };
    const tabBtn = (active) => ({
        padding: "10px 24px", border: "none", fontWeight: 700, fontSize: 13, cursor: "pointer",
        borderRadius: "10px 10px 0 0", background: active ? "#C8102E" : "var(--border-subtle)", color: active ? "#fff" : "var(--text-soft)",
        transition: "all 0.2s",
    });
    const inp = {
        width: "100%", padding: "9px 12px", border: "1px solid var(--input-border)", background: "var(--input-bg)", color: "var(--input-text)",
        borderRadius: 10, fontSize: 13, outline: "none", boxSizing: "border-box",
    };
    const btnPrimary = { background: "#C8102E", color: "#fff", border: "none", padding: "10px 24px", borderRadius: 10, fontWeight: 700, fontSize: 13, cursor: "pointer" };
    const th = { padding: "10px 14px", borderBottom: "2px solid var(--border-subtle)", textAlign: "left", fontSize: 11, fontWeight: 700, background: "var(--table-header-bg)", color: "var(--text-soft)", textTransform: "uppercase", letterSpacing: 0.5 };
    const td = { padding: "12px 14px", borderBottom: "1px solid var(--border-subtle)", fontSize: 13, color: "var(--text-primary)", verticalAlign: "middle" };

    if (loading && workers.length === 0) {
        return (
            <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", height: 400, gap: 16 }}>
                <div style={{ width: 44, height: 44, border: "4px solid var(--border-subtle)", borderTopColor: "#C8102E", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
                <span style={{ fontSize: 14, color: "var(--text-muted)", fontWeight: 500 }}>Loading attendance...</span>
                <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
            </div>
        );
    }

    return (
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20, flexWrap: "wrap", gap: 12 }}>
                <div>
                    <h2 style={{ fontSize: 22, fontWeight: 800, margin: 0, color: "var(--text-primary)" }}>Attendance Tracking</h2>
                    <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--text-muted)" }}>Daily records for construction sites</p>
                </div>
                {stats.deployed > 0 && (
                    <div style={{
                        display: "flex", alignItems: "center", gap: 6, padding: "8px 16px", borderRadius: 12,
                        background: stats.rate >= 80 ? "rgba(22,163,74,0.08)" : stats.rate >= 50 ? "rgba(245,158,11,0.08)" : "rgba(220,38,38,0.08)",
                        border: `1px solid ${stats.rate >= 80 ? "rgba(22,163,74,0.2)" : stats.rate >= 50 ? "rgba(245,158,11,0.2)" : "rgba(220,38,38,0.2)"}`
                    }}>
                        <span style={{ fontSize: 22, fontWeight: 800, color: stats.rate >= 80 ? "#16a34a" : stats.rate >= 50 ? "#f59e0b" : "#dc2626" }}>{stats.rate}%</span>
                        <span style={{ fontSize: 12, color: "var(--text-soft)" }}>attendance</span>
                    </div>
                )}
            </div>

            {msg.text && (
                <div style={{
                    padding: "10px 16px", marginBottom: 16, borderRadius: 10, fontSize: 14, fontWeight: 600,
                    background: msg.type === "err" ? "var(--glass-rose)" : "var(--glass-green)",
                    color: msg.type === "err" ? "#dc2626" : "#166534",
                    border: `1px solid ${msg.type === "err" ? "#dc262633" : "#16653433"}`
                }}>{msg.text}</div>
            )}

            <div style={{ display: "flex", gap: 4, marginBottom: 0 }} className="no-print">
                <button style={tabBtn(tab === "mark")} onClick={() => setTab("mark")}>Mark Attendance</button>
                <button style={tabBtn(tab === "report")} onClick={() => setTab("report")}>Monthly Report</button>
            </div>

            <div style={{
                background: "var(--bg-surface)", borderRadius: "0 14px 14px 14px", border: "1px solid var(--border-subtle)",
                padding: 24, marginBottom: 24, boxShadow: "var(--shadow-sm)",
            }}>
                {tab === "mark" && (
                    <div>
                        <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 22, flexWrap: "wrap" }}>
                            <button style={{ ...btnPrimary, padding: '8px 12px' }} onClick={() => shiftDate(-1)}>‹</button>
                            <input type="date" style={{ ...inp, width: "auto", fontWeight: 600 }} value={date} onChange={(e) => setDate(e.target.value)} />
                            <button style={{ ...btnPrimary, padding: '8px 12px' }} onClick={() => shiftDate(1)}>›</button>
                            <button 
                                style={{ ...btnPrimary, opacity: loading ? 0.7 : 1 }} 
                                disabled={loading}
                                onClick={async () => {
                                    await loadAll();
                                    flash("Data refreshed successfully");
                                }}
                            >
                                {loading ? "Refreshing..." : "Refresh"}
                            </button>
                            <div style={{ flex: 1 }} />
                            <input type="text" placeholder="Search..." style={{ ...inp, width: 220 }} value={siteSearch} onChange={(e) => setSiteSearch(e.target.value)} />
                        </div>

                        <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 24 }}>
                            {[
                                { label: "Deployed", value: stats.deployed, color: "#2563eb", accent: "var(--glass-blue)" },
                                { label: "Present", value: stats.present, color: "#16a34a", accent: "var(--glass-green)" },
                                { label: "Absent", value: stats.absent, color: "#dc2626", accent: "var(--glass-rose)" },
                                { label: "Unmarked", value: stats.unmarked, color: "#f59e0b", accent: "var(--glass-amber)" },
                                { label: "Sites", value: stats.sites, color: "#7c3aed", accent: "var(--glass-purple)" },
                            ].map((s) => (
                                <div key={s.label} style={{ ...glassCard, borderTop: `3px solid ${s.color}`, background: s.accent }}>
                                    <div style={{ fontSize: 28, fontWeight: 800, color: s.color }}>{s.value}</div>
                                    <div style={{ fontSize: 11, color: "var(--text-soft)", marginTop: 2, fontWeight: 500 }}>{s.label}</div>
                                </div>
                            ))}
                        </div>

                        {siteGroupEntries.length === 0 && <div style={{ textAlign: 'center', padding: 40, color: 'var(--text-muted)' }}>No deployments found.</div>}

                        {siteGroupEntries.map(([siteId, g]) => {
                            const curPresent = g.workers.filter(w => getStatus(w.worker_id, siteId) === 'present').length;
                            const collapsed = collapsedSites.has(siteId);
                            const officer = getAssignedOfficer(siteId);
                            return (
                                <div key={siteId} style={{ marginBottom: 16, border: "1px solid var(--border-subtle)", borderRadius: 12, overflow: "hidden" }}>
                                    <div onClick={() => toggleCollapse(siteId)} style={{ padding: "12px 16px", background: "var(--table-header-bg)", display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer" }}>
                                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                                            <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#C8102E" }} />
                                            <span style={{ fontSize: 14, fontWeight: 700, color: "var(--text-primary)" }}>{g.name}</span>
                                            {officer && <span style={{ fontSize: 11, color: "var(--text-muted)" }}>• {officer}</span>}
                                        </div>
                                        <div style={{ fontSize: 13, color: "var(--text-soft)" }}>{curPresent}/{g.workers.length} present {collapsed ? "▼" : "▲"}</div>
                                    </div>
                                    {!collapsed && (
                                        <table style={{ width: "100%", borderCollapse: "collapse" }}>
                                            <thead><tr><th style={th}>Worker</th><th style={th}>Type</th><th style={th}>Action</th></tr></thead>
                                            <tbody>
                                                {g.workers.map((w) => {
                                                    const cur = getStatus(w.worker_id, siteId);
                                                    return (
                                                        <tr key={w.worker_id}>
                                                            <td style={td}>{workerNode(w.worker_id)}</td>
                                                            <td style={td}>{getWorkerType(w.worker_id)}</td>
                                                            <td style={{ ...td, display: "flex", gap: 8 }}>
                                                                <button onClick={() => markAttendance(w.worker_id, siteId, "present")} style={{ flex: 1, padding: "6px", border: "1px solid var(--border-subtle)", borderRadius: 6, background: cur === "present" ? "var(--glass-green)" : "var(--bg-surface)", color: cur === "present" ? "#166534" : "var(--text-soft)", fontSize: 11, fontWeight: 700 }}>PRESENT</button>
                                                                <button onClick={() => markAttendance(w.worker_id, siteId, "absent")} style={{ flex: 1, padding: "6px", border: "1px solid var(--border-subtle)", borderRadius: 6, background: cur === "absent" ? "var(--glass-rose)" : "var(--bg-surface)", color: cur === "absent" ? "#991b1b" : "var(--text-soft)", fontSize: 11, fontWeight: 700 }}>ABSENT</button>
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                )}

                {tab === "report" && (
                    <div>
                        <div style={{ display: "flex", gap: 10, alignItems: "flex-end", marginBottom: 22, flexWrap: "wrap" }}>
                            <input type="month" style={{ ...inp, width: "auto" }} value={reportMonth} onChange={(e) => setReportMonth(e.target.value)} />
                            <button style={btnPrimary} onClick={fetchReport}>Generate</button>
                            {reportData.length > 0 && <button style={{ ...btnPrimary, background: 'var(--bg-body)', color: 'var(--text-soft)' }} onClick={exportCSV}>Export</button>}
                        </div>
                        {reportData.length > 0 && (
                            <table style={{ width: "100%", borderCollapse: "collapse" }}>
                                <thead><tr><th style={th}>Worker</th><th style={th}>Type</th><th style={th}>P</th><th style={th}>A</th><th style={th}>%</th></tr></thead>
                                <tbody>
                                    {reportSummary.workers.map((w, i) => {
                                        const pct = (w.present + w.absent) > 0 ? Math.round((w.present / (w.present + w.absent)) * 100) : 0;
                                        return (
                                            <tr key={i}>
                                                <td style={td}>{w.name}</td>
                                                <td style={td}>{w.type}</td>
                                                <td style={td}>{w.present}</td>
                                                <td style={td}>{w.absent}</td>
                                                <td style={{ ...td, color: pct >= 80 ? "#16a34a" : "#dc2626", fontWeight: 700 }}>{pct}%</td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}
