// ============================================================================
// FEATURE: Login.jsx — Authentication Module (Login & Registration)
// Implemented by: IT24102845
// ============================================================================

import { useState } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8080";

// ============================================================================
// SYSTEM LOGIC: Validation Helpers
// These functions use Regular Expressions (Regex) to ensure data quality before
// sending it to the server. This prevents "Garbage In, Garbage Out".
// ============================================================================

// GOAL: Verify the email format (e.g., name@domain.com)
const validateEmail = (email) => {
    const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return re.test(email);
};

// GOAL: Ensure phone numbers are exactly 10 digits
const validatePhone = (phone) => {
    if (!phone.trim()) return true; // optional field
    const re = /^[0-9]{10}$/;
    return re.test(phone.replace(/[\s\-()]/g, ""));
};

// GOAL: Enforce security policy: 8+ chars, Upper, Lower, and Number
const validatePassword = (password) => {
    const errors = [];
    if (password.length < 8) errors.push("at least 8 characters");
    if (!/[A-Z]/.test(password)) errors.push("one uppercase letter");
    if (!/[a-z]/.test(password)) errors.push("one lowercase letter");
    if (!/[0-9]/.test(password)) errors.push("one number");
    return errors;
};

// GOAL: Prevent symbols/numbers in names for data integrity
const validateFullName = (name) => {
    if (name.trim().length < 3) return "Full name must be at least 3 characters";
    if (/[0-9]/.test(name)) return "Full name should not contain numbers";
    if (/[^a-zA-Z\s.'"-]/.test(name)) return "Full name contains invalid characters";
    return "";
};

export default function Login({ onLogin, sessionExpiredMsg = "" }) {
    const [mode, setMode] = useState("login");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [fullName, setFullName] = useState("");
    const [phone, setPhone] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [success, setSuccess] = useState("");
    const [showPassword, setShowPassword] = useState(false);

    // ── Field-level error state ──
    const [fieldErrors, setFieldErrors] = useState({});

    const setFieldError = (field, msg) => {
        setFieldErrors((prev) => ({ ...prev, [field]: msg }));
    };
    const clearFieldError = (field) => {
        setFieldErrors((prev) => {
            const next = { ...prev };
            delete next[field];
            return next;
        });
    };

    // ── Real-time field validation ──
    const handleEmailChange = (val) => {
        setEmail(val);
        if (val.trim() && !validateEmail(val.trim())) {
            setFieldError("email", "Enter a valid email address (e.g., name@example.com)");
        } else {
            clearFieldError("email");
        }
    };

    const handlePasswordChange = (val) => {
        setPassword(val);
        if (mode === "register" && val) {
            const pwErrors = validatePassword(val);
            if (pwErrors.length > 0) {
                setFieldError("password", `Password needs: ${pwErrors.join(", ")}`);
            } else {
                clearFieldError("password");
            }
        } else {
            clearFieldError("password");
        }
    };

    const handleFullNameChange = (val) => {
        setFullName(val);
        if (val.trim()) {
            const nameErr = validateFullName(val);
            if (nameErr) setFieldError("fullName", nameErr);
            else clearFieldError("fullName");
        } else {
            clearFieldError("fullName");
        }
    };

    const handlePhoneChange = (val) => {
        // Only allow digits, spaces, dashes, parens
        const cleaned = val.replace(/[^0-9\s\-()+]/g, "");
        setPhone(cleaned);
        if (cleaned.trim() && !validatePhone(cleaned)) {
            setFieldError("phone", "Enter a valid 10-digit phone number (e.g., 0712345678)");
        } else {
            clearFieldError("phone");
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        setSuccess("");
        setFieldErrors({});

        // ── Full validation before submit ──
        const errors = {};

        if (!email.trim()) {
            errors.email = "Email is required";
        } else if (!validateEmail(email.trim())) {
            errors.email = "Enter a valid email address (e.g., name@example.com)";
        }

        if (!password.trim()) {
            errors.password = "Password is required";
        } else if (mode === "register") {
            const pwErrors = validatePassword(password);
            if (pwErrors.length > 0) {
                errors.password = `Password needs: ${pwErrors.join(", ")}`;
            }
        } else if (password.length < 6) {
            errors.password = "Password must be at least 6 characters";
        }

        if (mode === "register") {
            if (!fullName.trim()) {
                errors.fullName = "Full name is required";
            } else {
                const nameErr = validateFullName(fullName);
                if (nameErr) errors.fullName = nameErr;
            }

            if (phone.trim() && !validatePhone(phone)) {
                errors.phone = "Enter a valid 10-digit phone number";
            }
        }

        if (Object.keys(errors).length > 0) {
            setFieldErrors(errors);
            setError("Please fix the errors below before submitting");
            return;
        }

        setLoading(true);

        // ========================================================================
        // SYSTEM LOGIC: Authentication Handlers
        // FLOW: 1. Request sent to Backend API -> 2. Backend talks to Supabase
        // -> 3. Success returns a JWT "Access Token".
        // ========================================================================
        try {
            if (mode === "login") {
                // GOAL: Verify credentials and retrieve session token
                const r = await fetch(`${API}/auth/login`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email: email.trim(), password }),
                });
                const data = await r.json();

                if (r.ok && data.token && data.user) {
                    // GOAL: Session Persistence
                    // We store the access token, refresh token, and user object.
                    // The refresh_token allows silent renewal of the access token when it expires.
                    localStorage.setItem("token", data.token);
                    localStorage.setItem("access_token", data.token);
                    if (data.refresh_token) {
                        localStorage.setItem("refresh_token", data.refresh_token);
                    }
                    localStorage.setItem("user", JSON.stringify(data.user));
                    onLogin(data.user); // Notify App.jsx about successful login
                } else {
                    setError(data.error || "Login failed. Check your credentials.");
                }
            } else {
                // GOAL: Create new user entry in Supabase Auth & Profiles table
                const r = await fetch(`${API}/auth/register`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        email: email.trim(),
                        password,
                        full_name: fullName.trim(),
                        phone: phone.trim(),
                        role: "site_officer", // New users start as Site Officers by default
                    }),
                });
                const data = await r.json();

                if (r.ok) {
                    setSuccess("Account created. You can now log in. An admin will assign your role.");
                    setMode("login"); // Auto-switch to login mode after registration
                    setPassword("");
                    setFullName("");
                    setPhone("");
                    setFieldErrors({});
                } else {
                    setError(data.error || "Registration failed");
                }
            }
        } catch (err) {
            console.error("Auth error:", err);
            setError("Connection error. Make sure the server is running.");
        }

        setLoading(false);
    };

    const inputStyle = {
        width: "100%",
        padding: "12px 14px",
        border: "1px solid #d1d5db",
        borderRadius: 8,
        fontSize: 14,
        boxSizing: "border-box",
        outline: "none",
        transition: "border-color 0.2s, box-shadow 0.2s",
        background: "#fff",
        color: "#1e293b",
    };

    const inputErrorStyle = {
        ...inputStyle,
        border: "1px solid #dc2626",
        boxShadow: "0 0 0 3px rgba(220, 38, 38, 0.1)",
    };

    const labelStyle = {
        display: "block",
        fontSize: 13,
        fontWeight: 600,
        color: "#374151",
        marginBottom: 6,
    };

    const fieldErrorStyle = {
        fontSize: 12,
        color: "#dc2626",
        marginTop: 4,
        display: "flex",
        alignItems: "center",
        gap: 4,
    };

    // ── Password strength indicator ──
    const getPasswordStrength = () => {
        if (!password || mode !== "register") return null;
        const errors = validatePassword(password);
        const score = 4 - errors.length;
        if (score <= 1) return { label: "Weak", color: "#dc2626", width: "25%" };
        if (score === 2) return { label: "Fair", color: "#f59e0b", width: "50%" };
        if (score === 3) return { label: "Good", color: "#2563eb", width: "75%" };
        return { label: "Strong", color: "#16a34a", width: "100%" };
    };

    const pwStrength = getPasswordStrength();

    return (
        <div
            style={{
                minHeight: "100vh",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: "linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%)",
                padding: 20,
            }}
        >
            <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(16px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          20%, 60% { transform: translateX(-6px); }
          40%, 80% { transform: translateX(6px); }
        }
        .login-input:focus {
          border-color: #C8102E !important;
          box-shadow: 0 0 0 3px rgba(200, 16, 46, 0.1) !important;
        }
        .login-input-error:focus {
          border-color: #dc2626 !important;
          box-shadow: 0 0 0 3px rgba(220, 38, 38, 0.1) !important;
        }
        .login-btn:hover:not(:disabled) {
          opacity: 0.92;
          transform: translateY(-1px);
          box-shadow: 0 4px 12px rgba(200, 16, 46, 0.3);
        }
        .login-btn:active:not(:disabled) {
          transform: translateY(0);
        }
        .tab-btn:hover {
          opacity: 0.85;
        }
        .toggle-pw:hover {
          color: #C8102E !important;
        }
      `}</style>

            <div
                style={{
                    width: "100%",
                    maxWidth: 420,
                    background: "#fff",
                    borderRadius: 16,
                    padding: "40px 36px",
                    boxShadow: "0 4px 24px rgba(0,0,0,0.08)",
                    animation: "fadeUp 0.4s ease-out",
                }}
            >
                {/* Logo */}
                <div style={{ textAlign: "center", marginBottom: 32 }}>
                    <img
                        src="/logo.jpg"
                        alt="DU Homes"
                        style={{
                            width: 64, height: 64, borderRadius: 16, objectFit: "cover",
                            margin: "0 auto 16px", display: "block",
                            boxShadow: "0 4px 12px rgba(0,0,0,0.12)",
                        }}
                        onError={(e) => {
                            e.target.style.display = "none";
                            if (e.target.nextSibling?.classList?.contains("logo-fallback")) return;
                            const fb = document.createElement("div");
                            fb.className = "logo-fallback";
                            fb.textContent = "DU";
                            Object.assign(fb.style, {
                                width: "64px", height: "64px", borderRadius: "16px",
                                background: "linear-gradient(135deg, #C8102E, #a00d24)",
                                display: "flex", alignItems: "center", justifyContent: "center",
                                margin: "0 auto 16px", color: "#fff", fontSize: "24px",
                                fontWeight: "800", boxShadow: "0 4px 12px rgba(200,16,46,0.3)",
                            });
                            e.target.parentNode.insertBefore(fb, e.target.nextSibling);
                        }}
                    />
                    <h1 style={{ margin: 0, fontSize: 24, fontWeight: 800, color: "#1e293b" }}>DU Homes</h1>
                    <p style={{ margin: "4px 0 0", fontSize: 13, color: "#8094ae", letterSpacing: "0.02em" }}>
                        Construction Management System
                    </p>
                </div>

                {/* Tabs */}
                <div style={{ display: "flex", marginBottom: 24, borderRadius: 8, overflow: "hidden", border: "1px solid #e2e8f0" }}>
                    <button className="tab-btn" onClick={() => { setMode("login"); setError(""); setSuccess(""); setFieldErrors({}); }}
                        style={{ flex: 1, padding: "10px 0", border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer",
                            background: mode === "login" ? "#C8102E" : "#f8fafc", color: mode === "login" ? "#fff" : "#64748b", transition: "all 0.2s ease" }}>
                        Sign In
                    </button>
                    <button className="tab-btn" onClick={() => { setMode("register"); setError(""); setSuccess(""); setFieldErrors({}); }}
                        style={{ flex: 1, padding: "10px 0", border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer",
                            background: mode === "register" ? "#C8102E" : "#f8fafc", color: mode === "register" ? "#fff" : "#64748b", transition: "all 0.2s ease" }}>
                        Register
                    </button>
                </div>

                {/* Session Expired Banner */}
                {sessionExpiredMsg && (
                    <div style={{
                        padding: "10px 14px", marginBottom: 16, borderRadius: 8,
                        background: "#fef3c7", color: "#92400e",
                        fontSize: 13, fontWeight: 500,
                        display: "flex", alignItems: "center", gap: 8,
                        border: "1px solid #f59e0b",
                    }}>
                        <svg width="16" height="16" fill="none" stroke="#92400e" strokeWidth="2" viewBox="0 0 24 24">
                            <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
                            <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
                        </svg>
                        {sessionExpiredMsg}
                    </div>
                )}

                {/* Error Banner */}
                {error && (
                    <div style={{
                        padding: "10px 14px", marginBottom: 16, borderRadius: 8, background: "#fee2e2", color: "#dc2626",
                        fontSize: 13, fontWeight: 500, animation: "shake 0.4s ease", display: "flex", alignItems: "center", gap: 8,
                    }}>
                        <svg width="16" height="16" fill="none" stroke="#dc2626" strokeWidth="2" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="10" /><path d="M12 8v4M12 16h.01" />
                        </svg>
                        {error}
                    </div>
                )}

                {/* Success Banner */}
                {success && (
                    <div style={{
                        padding: "10px 14px", marginBottom: 16, borderRadius: 8, background: "#dcfce7", color: "#166534",
                        fontSize: 13, fontWeight: 500, display: "flex", alignItems: "center", gap: 8,
                    }}>
                        <svg width="16" height="16" fill="none" stroke="#166534" strokeWidth="2" viewBox="0 0 24 24">
                            <path d="M22 11.08V12a10 10 0 11-5.93-9.14" /><path d="M22 4L12 14.01l-3-3" />
                        </svg>
                        {success}
                    </div>
                )}

                {/* Form */}
                <form onSubmit={handleSubmit} noValidate>
                    {mode === "register" && (
                        <>
                            {/* Full Name */}
                            <div style={{ marginBottom: 16 }}>
                                <label style={labelStyle}>Full Name *</label>
                                <input
                                    className={fieldErrors.fullName ? "login-input-error" : "login-input"}
                                    style={fieldErrors.fullName ? inputErrorStyle : inputStyle}
                                    placeholder="Enter your full name"
                                    value={fullName}
                                    onChange={(e) => handleFullNameChange(e.target.value)}
                                    autoComplete="name"
                                />
                                {fieldErrors.fullName && (
                                    <div style={fieldErrorStyle}>
                                        <svg width="12" height="12" fill="none" stroke="#dc2626" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
                                        {fieldErrors.fullName}
                                    </div>
                                )}
                            </div>

                            {/* Phone */}
                            <div style={{ marginBottom: 16 }}>
                                <label style={labelStyle}>Phone</label>
                                <input
                                    className={fieldErrors.phone ? "login-input-error" : "login-input"}
                                    style={fieldErrors.phone ? inputErrorStyle : inputStyle}
                                    placeholder="e.g. 0712345678"
                                    value={phone}
                                    onChange={(e) => handlePhoneChange(e.target.value)}
                                    autoComplete="tel"
                                    maxLength={15}
                                />
                                {fieldErrors.phone && (
                                    <div style={fieldErrorStyle}>
                                        <svg width="12" height="12" fill="none" stroke="#dc2626" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
                                        {fieldErrors.phone}
                                    </div>
                                )}
                            </div>
                        </>
                    )}

                    {/* Email */}
                    <div style={{ marginBottom: 16 }}>
                        <label style={labelStyle}>Email *</label>
                        <input
                            className={fieldErrors.email ? "login-input-error" : "login-input"}
                            type="email"
                            style={fieldErrors.email ? inputErrorStyle : inputStyle}
                            placeholder="your@email.com"
                            value={email}
                            onChange={(e) => handleEmailChange(e.target.value)}
                            autoComplete="email"
                        />
                        {fieldErrors.email && (
                            <div style={fieldErrorStyle}>
                                <svg width="12" height="12" fill="none" stroke="#dc2626" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
                                {fieldErrors.email}
                            </div>
                        )}
                    </div>

                    {/* Password */}
                    <div style={{ marginBottom: 24 }}>
                        <label style={labelStyle}>Password *</label>
                        <div style={{ position: "relative" }}>
                            <input
                                className={fieldErrors.password ? "login-input-error" : "login-input"}
                                type={showPassword ? "text" : "password"}
                                style={{ ...(fieldErrors.password ? inputErrorStyle : inputStyle), paddingRight: 44 }}
                                placeholder={mode === "register" ? "Min 8 chars, uppercase, number" : "Enter your password"}
                                value={password}
                                onChange={(e) => handlePasswordChange(e.target.value)}
                                autoComplete={mode === "login" ? "current-password" : "new-password"}
                            />
                            <button type="button" className="toggle-pw" onClick={() => setShowPassword(!showPassword)}
                                style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)",
                                    background: "none", border: "none", cursor: "pointer", color: "#94a3b8", padding: 4,
                                    display: "flex", alignItems: "center", transition: "color 0.2s" }}
                                title={showPassword ? "Hide password" : "Show password"}>
                                {showPassword ? (
                                    <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                                        <path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24" />
                                        <line x1="1" y1="1" x2="23" y2="23" />
                                    </svg>
                                ) : (
                                    <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                        <circle cx="12" cy="12" r="3" />
                                    </svg>
                                )}
                            </button>
                        </div>
                        {fieldErrors.password && (
                            <div style={fieldErrorStyle}>
                                <svg width="12" height="12" fill="none" stroke="#dc2626" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
                                {fieldErrors.password}
                            </div>
                        )}
                        {/* Password strength bar */}
                        {mode === "register" && password && pwStrength && (
                            <div style={{ marginTop: 8 }}>
                                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                                    <span style={{ fontSize: 11, color: "#64748b" }}>Password strength</span>
                                    <span style={{ fontSize: 11, fontWeight: 700, color: pwStrength.color }}>{pwStrength.label}</span>
                                </div>
                                <div style={{ width: "100%", height: 4, background: "#e2e8f0", borderRadius: 2, overflow: "hidden" }}>
                                    <div style={{
                                        width: pwStrength.width, height: "100%", background: pwStrength.color,
                                        borderRadius: 2, transition: "all 0.3s ease",
                                    }} />
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Submit */}
                    <button className="login-btn" type="submit" disabled={loading}
                        style={{
                            width: "100%", padding: "13px 0", border: "none", borderRadius: 8, fontSize: 14, fontWeight: 700,
                            cursor: loading ? "not-allowed" : "pointer",
                            background: loading ? "#94a3b8" : "linear-gradient(135deg, #C8102E, #a00d24)",
                            color: "#fff", transition: "all 0.2s ease", display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
                        }}>
                        {loading && (
                            <svg width="18" height="18" viewBox="0 0 24 24" style={{ animation: "spin 1s linear infinite" }}>
                                <circle cx="12" cy="12" r="10" stroke="#fff" strokeWidth="3" fill="none" strokeDasharray="31.4" strokeLinecap="round" />
                            </svg>
                        )}
                        {loading ? "Please wait..." : mode === "login" ? "Sign In" : "Create Account"}
                    </button>
                </form>

                {/* Footer links */}
                {mode === "register" && (
                    <p style={{ marginTop: 16, fontSize: 12, color: "#94a3b8", textAlign: "center", lineHeight: 1.5 }}>
                        After registration, an admin will assign your role and permissions.
                    </p>
                )}
                {mode === "login" && (
                    <p style={{ marginTop: 20, fontSize: 12, color: "#94a3b8", textAlign: "center" }}>
                        Don't have an account?{" "}
                        <span onClick={() => { setMode("register"); setError(""); setSuccess(""); setFieldErrors({}); }}
                            style={{ color: "#C8102E", fontWeight: 600, cursor: "pointer" }}>
                            Register here
                        </span>
                    </p>
                )}
                {mode === "register" && (
                    <p style={{ marginTop: 8, fontSize: 12, color: "#94a3b8", textAlign: "center" }}>
                        Already have an account?{" "}
                        <span onClick={() => { setMode("login"); setError(""); setSuccess(""); setFieldErrors({}); }}
                            style={{ color: "#C8102E", fontWeight: 600, cursor: "pointer" }}>
                            Sign in here
                        </span>
                    </p>
                )}
            </div>

            <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
    );
}
