import { useState, useEffect, useCallback, useMemo } from "react";

const API = (import.meta.env.VITE_API_URL || "http://localhost:8080").replace(/\/+$/, "");
const hdr = () => {
    const t = localStorage.getItem("token") || localStorage.getItem("access_token") || "";
    return { "Content-Type": "application/json", ...(t ? { Authorization: `Bearer ${t}` } : {}) };
};
const getCurrentUser = () => {
    try { return JSON.parse(localStorage.getItem("user") || "{}"); } catch { return {}; }
};
const currency = (v) => `Rs ${Number(v || 0).toLocaleString("en-LK", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const PAYMENT_METHODS = ["Cash", "Bank Transfer", "Cheque", "Online"];
const PAYMENT_STATUSES = ["Unpaid", "Partial", "Paid"];
const METHOD_CHIP = {
    Cash: { bg: "var(--glass-green)", color: "#16a34a" },
    "Bank Transfer": { bg: "var(--glass-blue)", color: "#2563eb" },
    Cheque: { bg: "var(--glass-amber)", color: "#d97706" },
    Online: { bg: "var(--glass-purple)", color: "#7c3aed" }
};
const PAY_CHIP = {
    Paid: { bg: "var(--glass-green)", color: "#16a34a" },
    Partial: { bg: "var(--glass-amber)", color: "#d97706" },
    Unpaid: { bg: "var(--glass-rose)", color: "#dc2626" }
};
const STATUS_CHIP = {
    Pending: { bg: "var(--glass-amber)", color: "#d97706", border: "var(--border-subtle)" },
    "In Progress": { bg: "var(--glass-blue)", color: "#2563eb", border: "var(--border-subtle)" },
    Processed: { bg: "var(--glass-green)", color: "#16a34a", border: "var(--border-subtle)" },
    Rejected: { bg: "var(--glass-rose)", color: "#dc2626", border: "var(--border-subtle)" },
};

/* ═══════════════════════════════════════════════════════════════
   MAIN EXPORT: ToolBills
   ═══════════════════════════════════════════════════════════════ */
export default function ToolBills() {
    const [view, setView] = useState("list");
    const [selectedBill, setSelectedBill] = useState(null);
    const [bills, setBills] = useState([]);
    const [summaries, setSummaries] = useState({});
    const [loading, setLoading] = useState(true);
    const [msg, setMsg] = useState({ text: "", type: "" });
    const [filterStatus, setFilterStatus] = useState("");
    const [searchTool, setSearchTool] = useState("");
    const [deleteBillConfirm, setDeleteBillConfirm] = useState(null);

    const flash = useCallback((text, type = "ok") => {
        setMsg({ text, type });
        setTimeout(() => setMsg({ text: "", type: "" }), 4000);
    }, []);

    /* ── Fetch bills + summaries ── */
    const fetchBills = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (filterStatus) params.append("status", filterStatus);
            const [billsRes, summaryRes] = await Promise.all([
                fetch(`${API}/tool-bills?${params}`, { headers: hdr() }),
                fetch(`${API}/tool-bill-payments/summary`, { headers: hdr() }),
            ]);
            if (billsRes.ok) setBills(await billsRes.json());
            if (summaryRes.ok) setSummaries(await summaryRes.json());
        } catch (e) { console.error("fetchBills", e); }
        setLoading(false);
    }, [filterStatus]);

    useEffect(() => { fetchBills(); }, [fetchBills]);

    const handleOpenBill = async (bill) => {
        if (!bill.is_read) {
            try { await fetch(`${API}/tool-bills/${bill.id}/mark-read`, { method: "PATCH", headers: hdr() }); } catch { /* */ }
        }
        setSelectedBill(bill);
        setView("detail");
    };

    const handleBack = () => { setView("list"); setSelectedBill(null); fetchBills(); };

    const handleDeleteBill = async (id) => {
        try {
            const r = await fetch(`${API}/tool-bills/${id}`, { method: "DELETE", headers: hdr() });
            if (!r.ok) throw new Error("Delete failed");
            flash("Bill deleted successfully", "ok");
            setDeleteBillConfirm(null);
            fetchBills();
        } catch (e) { flash(e.message, "err"); }
    };

    const filtered = useMemo(() => {
        if (!searchTool.trim()) return bills;
        const q = searchTool.toLowerCase();
        return bills.filter(b => {
            const sm = summaries[b.id] || {};
            const linkedName = b.tools?.name || sm.tool_names || "";
            return linkedName.toLowerCase().includes(q) || (b.file_name || "").toLowerCase().includes(q);
        });
    }, [bills, searchTool, summaries]);

    /* ── Detail split-screen ── */
    if (view === "detail" && selectedBill) {
        return <BillDetailView bill={selectedBill} onBack={handleBack} flash={flash} msg={msg} />;
    }

    /* ── BILL LIST VIEW ── */
    return (
        <div>
            {msg.text && <Flash text={msg.text} type={msg.type} />}

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 10 }}>
                <div>
                    <h2 style={{ fontSize: 20, fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>Tool Bill Records</h2>
                    <p style={{ fontSize: 13, color: "var(--text-soft)", margin: "4px 0 0" }}>{bills.length} bill{bills.length !== 1 ? "s" : ""} uploaded</p>
                </div>
            </div>

            {/* Filters */}
            <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap", alignItems: "center" }}>
                <input
                    style={filterInput}
                    placeholder="Search by tool name or file..."
                    value={searchTool}
                    onChange={e => setSearchTool(e.target.value)}
                />
                <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} style={filterSelect}>
                    <option value="">All Statuses</option>
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Processed">Processed</option>
                    <option value="Rejected">Rejected</option>
                </select>
                <button onClick={fetchBills} disabled={loading} style={refreshBtn}>
                    {loading ? "Loading..." : "↻ Refresh"}
                </button>
            </div>

            {/* Table */}
            <div style={tableCard}>
                <div style={{ overflowX: "auto" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                        <thead>
                            <tr>
                                {["#", "Tool Name", "File", "Upload Date", "Records", "Total Amount", "Status", "Actions"].map(h => (
                                    <th key={h} style={thStyle}>{h}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {loading ? (
                                <tr><td colSpan={8} style={emptyTd}>Loading...</td></tr>
                            ) : filtered.length === 0 ? (
                                <tr><td colSpan={8} style={emptyTd}>No bills found</td></tr>
                            ) : filtered.map((b, i) => {
                                const sc = STATUS_CHIP[b.status] || STATUS_CHIP.Pending;
                                const sm = summaries[b.id] || { count: 0, total: 0 };
                                return (
                                    <tr key={b.id}
                                        style={{ background: !b.is_read ? "var(--glass-blue)" : i % 2 === 0 ? "var(--bg-surface)" : "var(--bg-body)", cursor: "pointer", transition: "background 0.15s" }}
                                        onMouseEnter={e => e.currentTarget.style.background = "var(--bg-body)"}
                                        onMouseLeave={e => e.currentTarget.style.background = !b.is_read ? "var(--glass-blue)" : i % 2 === 0 ? "var(--bg-surface)" : "var(--bg-body)"}
                                        onClick={() => handleOpenBill(b)}>
                                        <td style={tdStyle}>
                                            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                                {!b.is_read && <span style={redDot} />}
                                                {i + 1}
                                            </div>
                                        </td>
                                        <td style={{ ...tdStyle, fontWeight: 600, color: "var(--text-primary)" }}>
                                            {b.tools?.name || sm.tool_names || <span style={{ color: "var(--text-soft)", fontStyle: "italic", fontWeight: 400 }}>No Tool Specified</span>}
                                        </td>
                                        <td style={{ ...tdStyle, color: "var(--text-secondary)", maxWidth: 140, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{b.file_name || "—"}</td>
                                        <td style={{ ...tdStyle, color: "var(--text-secondary)" }}>{b.created_at ? new Date(b.created_at).toLocaleDateString() : "—"}</td>
                                        <td style={tdStyle}>
                                            <span style={{ padding: "3px 10px", borderRadius: 6, fontSize: 11, fontWeight: 600, background: sm.count > 0 ? "#eff6ff" : "#f1f5f9", color: sm.count > 0 ? "#2563eb" : "#94a3b8" }}>
                                                {sm.count} Record{sm.count !== 1 ? "s" : ""}
                                            </span>
                                        </td>
                                        <td style={{ ...tdStyle, fontWeight: 600, color: sm.total > 0 ? "var(--success)" : "var(--text-soft)" }}>
                                            {sm.total > 0 ? currency(sm.total) : "—"}
                                        </td>
                                        <td style={tdStyle}>
                                            <span style={{ padding: "3px 10px", borderRadius: 6, fontSize: 11, fontWeight: 600, background: sc.bg, color: sc.color, border: `1px solid ${sc.border}` }}>{b.status}</span>
                                        </td>
                                        <td style={tdStyle} onClick={e => e.stopPropagation()}>
                                            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                                                <button onClick={() => handleOpenBill(b)} style={viewBtn}>
                                                    {getCurrentUser().role === 'site_officer' ? 'View' : 'View & Record'}
                                                </button>
                                                {b.status === "Rejected" && (
                                                    <button onClick={() => setDeleteBillConfirm(b.id)} 
                                                        style={{ ...iconBtn, color: "var(--error)", background: "var(--glass-rose)", borderRadius: 8, padding: "4px 8px", border: "1px solid var(--border-subtle)" }} 
                                                        title="Delete Rejected Bill">
                                                        🗑
                                                    </button>
                                                )}
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* ── Bill Delete Confirm ── */}
            {deleteBillConfirm && (
                <Modal onClose={() => setDeleteBillConfirm(null)}>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "var(--text-primary)", marginBottom: 12 }}>Delete Tool Bill</h3>
                    <p style={{ fontSize: 13, color: "var(--text-soft)", marginBottom: 20 }}>Are you sure you want to delete this bill record? This action cannot be undone.</p>
                    <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                        <button onClick={() => setDeleteBillConfirm(null)} style={cancelBtnStyle}>Cancel</button>
                        <button onClick={() => handleDeleteBill(deleteBillConfirm)} style={{ ...saveBtnStyle, background: "var(--error)" }}>Delete Permanently</button>
                    </div>
                </Modal>
            )}
        </div>
    );
}


/* ═══════════════════════════════════════════════════════════════
   SPLIT-SCREEN: Bill Image (left) + Records & Form (right)
   ═══════════════════════════════════════════════════════════════ */
function BillDetailView({ bill, onBack, flash, msg }) {
    const user = getCurrentUser();
    const isSiteOfficer = user.role === "site_officer";
    const [tools, setTools] = useState([]);
    const [records, setRecords] = useState([]);
    const [billData, setBillData] = useState(bill);
    const [saving, setSaving] = useState(false);
    const [zoom, setZoom] = useState(1);
    const [showAllTools, setShowAllTools] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [expandedId, setExpandedId] = useState(null);
    const [showRejectDialog, setShowRejectDialog] = useState(false);
    const [rejectReason, setRejectReason] = useState("");
    const [deleteConfirm, setDeleteConfirm] = useState(null);

    const isPdf = (bill.file_type || "").includes("pdf");

    /* ── Empty form ── */
    const emptyForm = () => ({
        tool_id: "", custom_tool_name: "",
        bill_number: "", bill_date: "", vendor_name: "", vendor_contact: "",
        items: [{ item_description: "", quantity: 1, unit_price: 0 }],
        payment_amount: "", payment_method: "Cash",
        reference_number: "", payment_date: new Date().toISOString().slice(0, 10),
        payment_status: "Unpaid", remarks: "",
    });
    const [form, setForm] = useState(emptyForm);

    /* ── Fetch tools & records ── */
    const fetchTools = useCallback(async () => {
        try {
            const r = await fetch(`${API}/tools`, { headers: hdr() });
            if (r.ok) setTools(await r.json());
        } catch { /* */ }
    }, []);

    const fetchRecords = useCallback(async () => {
        try {
            const r = await fetch(`${API}/tool-bill-payments?bill_id=${bill.id}`, { headers: hdr() });
            if (r.ok) setRecords(await r.json());
        } catch { /* */ }
    }, [bill.id]);

    const refreshBill = useCallback(async () => {
        try {
            const r = await fetch(`${API}/tool-bills/${bill.id}`, { headers: hdr() });
            if (r.ok) setBillData(await r.json());
        } catch { /* */ }
    }, [bill.id]);

    useEffect(() => { fetchTools(); fetchRecords(); }, [fetchTools, fetchRecords]);

    /* ── Tool filtering ── */
    const recentTools = useMemo(() => {
        if (showAllTools) return tools;
        const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 30);
        const recent = tools.filter(t => t.created_at && new Date(t.created_at) >= cutoff);
        return recent.length > 0 ? recent : tools;
    }, [tools, showAllTools]);

    /* ── Form helpers ── */
    const setField = (k, v) => setForm(p => ({ ...p, [k]: v }));
    const handleToolSelect = (id) => setForm(p => ({ ...p, tool_id: id, custom_tool_name: id ? "" : p.custom_tool_name }));
    const handleCustomTool = (name) => setForm(p => ({ ...p, custom_tool_name: name, tool_id: name ? "" : p.tool_id }));

    /* ── Items ── */
    const addItem = () => setForm(p => ({ ...p, items: [...p.items, { item_description: "", quantity: 1, unit_price: 0 }] }));
    const removeItem = (idx) => { if (form.items.length <= 1) return; setForm(p => ({ ...p, items: p.items.filter((_, i) => i !== idx) })); };
    const updateItem = (idx, field, val) => setForm(p => ({ ...p, items: p.items.map((it, i) => i === idx ? { ...it, [field]: val } : it) }));

    const grandTotal = useMemo(() => form.items.reduce((s, it) => s + ((parseInt(it.quantity) || 0) * (parseFloat(it.unit_price) || 0)), 0), [form.items]);

    /* ── SAVE / UPDATE ── */
    const handleSave = async () => {
        if (!form.tool_id && !(form.custom_tool_name || "").trim()) {
            flash("Please explicitly select a tool or type a tool name manually", "err"); return;
        }
        if (!form.items.some(it => (it.item_description || "").trim())) {
            flash("At least one item with a description is required", "err"); return;
        }
        setSaving(true);
        try {
            const payload = {
                bill_id: bill.id,
                tool_id: form.tool_id || null,
                custom_tool_name: form.custom_tool_name || null,
                bill_number: form.bill_number,
                bill_date: form.bill_date || null,
                vendor_name: form.vendor_name,
                vendor_contact: form.vendor_contact,
                items: form.items.filter(it => (it.item_description || "").trim()),
                payment_amount: parseFloat(form.payment_amount) || grandTotal,
                payment_method: form.payment_method,
                reference_number: form.reference_number,
                payment_date: form.payment_date || null,
                payment_status: form.payment_status,
                remarks: form.remarks,
                entered_by: user.id || null,
            };
            const url = editingId ? `${API}/tool-bill-payments/${editingId}` : `${API}/tool-bill-payments`;
            const method = editingId ? "PUT" : "POST";
            const r = await fetch(url, { method, headers: hdr(), body: JSON.stringify(payload) });
            if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d.error || "Save failed"); }

            flash(editingId ? "Payment record updated!" : "Payment record saved!", "ok");
            setForm(emptyForm());
            setEditingId(null);
            fetchRecords();
            refreshBill();
        } catch (e) { flash(e.message, "err"); }
        setSaving(false);
    };

    /* ── EDIT ── */
    const handleEdit = (rec) => {
        const items = (rec.tool_bill_items || []).length > 0
            ? rec.tool_bill_items.map(it => ({ item_description: it.item_description || "", quantity: it.quantity || 1, unit_price: it.unit_price || 0 }))
            : [{ item_description: rec.item_name || "", quantity: rec.quantity || 1, unit_price: rec.unit_price || 0 }];

        setForm({
            tool_id: rec.tool_id || "",
            custom_tool_name: rec.custom_tool_name || "",
            bill_number: rec.bill_number || "",
            bill_date: rec.bill_date ? rec.bill_date.slice(0, 10) : "",
            vendor_name: rec.vendor_name || "",
            vendor_contact: rec.vendor_contact || "",
            items,
            payment_amount: rec.payment_amount || "",
            payment_method: rec.payment_method || "Cash",
            reference_number: rec.reference_number || "",
            payment_date: rec.payment_date ? rec.payment_date.slice(0, 10) : "",
            payment_status: rec.payment_status || "Unpaid",
            remarks: rec.remarks || "",
        });
        setEditingId(rec.id);
        document.getElementById("bill-form-section")?.scrollIntoView({ behavior: "smooth" });
    };

    /* ── DELETE ── */
    const handleDelete = async (id) => {
        try {
            const r = await fetch(`${API}/tool-bill-payments/${id}`, { method: "DELETE", headers: hdr() });
            if (!r.ok) throw new Error("Delete failed");
            flash("Record deleted", "ok");
            if (editingId === id) { setEditingId(null); setForm(emptyForm()); }
            setDeleteConfirm(null);
            fetchRecords();
            refreshBill();
        } catch (e) { flash(e.message, "err"); }
    };

    /* ── STATUS ACTIONS ── */
    const handleMarkProcessed = async () => {
        try {
            const r = await fetch(`${API}/tool-bills/${bill.id}/mark`, { method: "PUT", headers: hdr(), body: JSON.stringify({ status: "Processed" }) });
            if (!r.ok) throw new Error("Failed"); flash("Bill marked as Processed!", "ok"); refreshBill();
        } catch (e) { flash(e.message, "err"); }
    };
    const handleReject = async () => {
        if (!rejectReason.trim()) { flash("Please provide a rejection reason", "err"); return; }
        try {
            const r = await fetch(`${API}/tool-bills/${bill.id}/mark`, { method: "PUT", headers: hdr(), body: JSON.stringify({ status: "Rejected", reject_reason: rejectReason }) });
            if (!r.ok) throw new Error("Failed"); flash("Bill rejected", "ok"); setShowRejectDialog(false); setRejectReason(""); refreshBill();
        } catch (e) { flash(e.message, "err"); }
    };

    const sc = STATUS_CHIP[billData.status] || STATUS_CHIP.Pending;

    return (
        <div>
            {msg.text && <Flash text={msg.text} type={msg.type} />}

            {/* ── Top bar ── */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 10 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                    <button onClick={onBack} style={backBtn}>← Back to List</button>
                    <span style={{ padding: "4px 12px", borderRadius: 6, fontSize: 12, fontWeight: 600, background: sc.bg, color: sc.color, border: `1px solid ${sc.border}` }}>{billData.status}</span>
                    {billData.tools?.name && <span style={{ fontSize: 13, color: "var(--text-soft)" }}>Tool: <strong style={{ color: "var(--text-primary)" }}>{billData.tools.name}</strong></span>}
                    {billData.file_name && <span style={{ fontSize: 12, color: "var(--text-muted)" }}>({billData.file_name})</span>}
                </div>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {!isSiteOfficer && billData.status !== "Processed" && billData.status !== "Rejected" && (
                        <>
                            <button onClick={handleMarkProcessed} style={processedBtn}>✓ Mark as Processed</button>
                            <button onClick={() => setShowRejectDialog(true)} style={rejectBtn}>✗ Reject</button>
                        </>
                    )}
                </div>
            </div>

            {/* ═══ SPLIT SCREEN ═══ */}
            <div style={{ display: "flex", gap: 16, minHeight: "calc(100vh - 240px)" }}>
                {/* ─── LEFT: Bill Image Viewer ─── */}
                <div style={leftPanel}>
                    <div style={imgToolbar}>
                        <span style={{ fontSize: 13, fontWeight: 600, color: "var(--text-primary)" }}>📄 Bill Image</span>
                        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                            <button onClick={() => setZoom(z => Math.max(0.25, z - 0.25))} style={zoomBtn}>−</button>
                            <span style={{ fontSize: 12, color: "var(--text-muted)", minWidth: 40, textAlign: "center" }}>{Math.round(zoom * 100)}%</span>
                            <button onClick={() => setZoom(z => Math.min(3, z + 0.25))} style={zoomBtn}>+</button>
                            <button onClick={() => setZoom(1)} style={zoomBtn}>Reset</button>
                            <a href={bill.image_path} target="_blank" rel="noopener noreferrer" style={openLink}>Open ↗</a>
                        </div>
                    </div>
                    <div style={imgContainer}>
                        {isPdf ? (
                            <iframe src={bill.image_path} style={{ width: "100%", height: "100%", minHeight: 600, border: "none", borderRadius: 8 }} title="Bill PDF" />
                        ) : (
                            <img src={bill.image_path} alt="Bill" style={{ maxWidth: "100%", transform: `scale(${zoom})`, transformOrigin: "top center", transition: "transform 0.2s", borderRadius: 8, boxShadow: "0 2px 12px rgba(0,0,0,0.1)" }} />
                        )}
                    </div>
                </div>

                {/* ─── RIGHT: Records + Form ─── */}
                <div style={rightPanel}>
                    {/* ═══ RECORDED PAYMENTS TABLE ═══ */}
                    <div style={sectionCard}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                            <h3 style={{ fontSize: 15, fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>Recorded Payments</h3>
                            <span style={{ padding: "3px 10px", borderRadius: 6, fontSize: 11, fontWeight: 600, background: records.length > 0 ? "var(--glass-blue)" : "var(--bg-body)", color: records.length > 0 ? "var(--brand-primary, #2563eb)" : "var(--text-soft)" }}>
                                {records.length} Record{records.length !== 1 ? "s" : ""}
                            </span>
                        </div>

                        {records.length === 0 ? (
                            <div style={{ textAlign: "center", padding: "24px 16px", color: "var(--text-muted)", fontSize: 13, background: "var(--bg-body)", borderRadius: 8 }}>
                                [NOTICE] No payment records yet. Read the bill image and enter details below.
                            </div>
                        ) : (
                            <div style={{ border: "1px solid var(--border-subtle)", borderRadius: 8, overflow: "hidden" }}>
                                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                                    <thead>
                                        <tr style={{ background: "var(--table-header-bg)" }}>
                                            {["#", "Bill No", "Vendor", "Items", "Grand Total", "Payment", "Method", "Status", "Date", ""].map(h => (
                                                <th key={h} style={{ padding: "8px 10px", fontSize: 10, fontWeight: 700, color: "var(--text-soft)", textAlign: "left", whiteSpace: "nowrap", borderBottom: "2px solid var(--border-subtle)" }}>{h}</th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {records.map((rec, i) => {
                                            const mc = METHOD_CHIP[rec.payment_method] || METHOD_CHIP.Cash;
                                            const pc = PAY_CHIP[rec.payment_status] || PAY_CHIP.Unpaid;
                                            const itemCount = (rec.tool_bill_items || []).length || rec.quantity || 0;
                                            const itemsTotal = (rec.tool_bill_items || []).reduce((s, it) => s + Number(it.total_price || 0), 0) || Number(rec.total_price || 0);
                                            return (
                                                <tr key={rec.id} style={{ background: editingId === rec.id ? "var(--glass-blue)" : i % 2 === 0 ? "var(--bg-surface)" : "var(--bg-body)", borderBottom: "1px solid var(--border-subtle)" }}>
                                                    <td style={rtd}>{i + 1}</td>
                                                    <td style={{ ...rtd, fontWeight: 500 }}>{rec.bill_number || "—"}</td>
                                                    <td style={rtd}>{rec.vendor_name || "—"}</td>
                                                    <td style={rtd}>{itemCount}</td>
                                                    <td style={{ ...rtd, fontWeight: 600, color: "var(--success)" }}>{currency(itemsTotal)}</td>
                                                    <td style={{ ...rtd, fontWeight: 600, color: "var(--text-primary)" }}>{currency(rec.payment_amount)}</td>
                                                    <td style={rtd}><span style={{ ...chipStyle, background: mc.bg, color: mc.color }}>{rec.payment_method}</span></td>
                                                    <td style={rtd}><span style={{ ...chipStyle, background: pc.bg, color: pc.color }}>{rec.payment_status}</span></td>
                                                    <td style={{ ...rtd, color: "var(--text-soft)" }}>{rec.created_at ? new Date(rec.created_at).toLocaleDateString() : "—"}</td>
                                                    <td style={{ ...rtd, whiteSpace: "nowrap" }}>
                                                        <button onClick={() => setExpandedId(expandedId === rec.id ? null : rec.id)} style={iconBtn} title="Details">📋</button>
                                                        {!isSiteOfficer && (
                                                            <>
                                                                <button onClick={() => handleEdit(rec)} style={iconBtn} title="Edit">Edit</button>
                                                                <button onClick={() => setDeleteConfirm(rec.id)} style={{ ...iconBtn, color: "var(--error)" }} title="Delete">🗑</button>
                                                            </>
                                                        )}
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                    <tfoot>
                                        <tr style={{ borderTop: "2px solid var(--border-subtle)", background: "var(--table-header-bg)" }}>
                                            <td colSpan={5} style={{ padding: "8px 10px", textAlign: "right", fontSize: 12, fontWeight: 700, color: "var(--text-soft)" }}>Total:</td>
                                            <td style={{ padding: "8px 10px", fontSize: 13, fontWeight: 700, color: "var(--success)" }}>
                                                {currency(records.reduce((s, r) => s + Number(r.payment_amount || 0), 0))}
                                            </td>
                                            <td colSpan={4}></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        )}

                        {/* ── Expanded Detail Panel ── */}
                        {expandedId && records.find(r => r.id === expandedId) && (() => {
                            const rec = records.find(r => r.id === expandedId);
                            const items = rec.tool_bill_items || [];
                            return (
                                <div style={{ marginTop: 12, background: "var(--bg-body)", borderRadius: 10, padding: 16, border: "1px solid var(--border-subtle)" }}>
                                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                                        <h4 style={{ margin: 0, fontSize: 13, fontWeight: 700, color: "var(--text-primary)" }}>Payment Record Details</h4>
                                        <button onClick={() => setExpandedId(null)} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 14, color: "var(--text-soft)" }}>✕</button>
                                    </div>
                                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, fontSize: 12, marginBottom: 12, color: "var(--text-primary)" }}>
                                        <div><span style={{ color: "var(--text-soft)" }}>Bill #:</span> <strong>{rec.bill_number || "—"}</strong></div>
                                        <div><span style={{ color: "var(--text-soft)" }}>Bill Date:</span> <strong>{rec.bill_date ? new Date(rec.bill_date).toLocaleDateString() : "—"}</strong></div>
                                        <div><span style={{ color: "var(--text-soft)" }}>Vendor:</span> <strong>{rec.vendor_name || "—"}</strong></div>
                                        <div><span style={{ color: "var(--text-soft)" }}>Contact:</span> <strong>{rec.vendor_contact || "—"}</strong></div>
                                        <div><span style={{ color: "var(--text-soft)" }}>Tool:</span> <strong>{rec.tools?.name || rec.custom_tool_name || "—"}</strong></div>
                                        <div><span style={{ color: "var(--text-soft)" }}>Ref #:</span> <strong>{rec.reference_number || "—"}</strong></div>
                                    </div>
                                    {items.length > 0 && (
                                        <table style={{ width: "100%", borderCollapse: "collapse", background: "var(--bg-surface)", borderRadius: 6, overflow: "hidden", marginBottom: 10, border: "1px solid var(--border-subtle)" }}>
                                            <thead><tr style={{ background: "var(--table-header-bg)" }}>
                                                {["Item", "Qty", "Unit Price", "Total"].map(h => <th key={h} style={{ padding: "6px 10px", fontSize: 10, fontWeight: 700, color: "var(--text-soft)", textAlign: "left" }}>{h}</th>)}
                                            </tr></thead>
                                            <tbody>
                                                {items.map((it, j) => (
                                                    <tr key={it.id || j} style={{ borderTop: "1px solid #f1f5f9" }}>
                                                        <td style={{ padding: "6px 10px", fontSize: 12 }}>{it.item_description}</td>
                                                        <td style={{ padding: "6px 10px", fontSize: 12, textAlign: "center" }}>{it.quantity}</td>
                                                        <td style={{ padding: "6px 10px", fontSize: 12 }}>{currency(it.unit_price)}</td>
                                                        <td style={{ padding: "6px 10px", fontSize: 12, fontWeight: 600, color: "var(--success)" }}>{currency(it.total_price)}</td>
                                                    </tr>
                                                ))}
                                                <tr style={{ borderTop: "2px solid var(--border-subtle)" }}>
                                                    <td colSpan={3} style={{ padding: "6px 10px", fontSize: 12, fontWeight: 700, textAlign: "right" }}>Grand Total:</td>
                                                    <td style={{ padding: "6px 10px", fontSize: 13, fontWeight: 700, color: "var(--success)" }}>{currency(items.reduce((s, it) => s + Number(it.total_price || 0), 0))}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    )}
                                    {rec.remarks && <div style={{ fontSize: 12, color: "var(--text-muted)" }}><strong>Notes:</strong> {rec.remarks}</div>}
                                </div>
                            );
                        })()}
                    </div>

                    {/* ═══ PAYMENT FORM (Hidden for Site Officers) ═══ */}
                    {!isSiteOfficer && (
                        <div id="bill-form-section" style={sectionCard}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                            <h3 style={{ fontSize: 15, fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>
                                {editingId ? "Edit Payment Record" : "Record Tool Bill Payment"}
                            </h3>
                            {editingId && (
                                <button onClick={() => { setEditingId(null); setForm(emptyForm()); }} style={cancelEditBtn}>Cancel Edit</button>
                            )}
                        </div>

                        {/* ── Section 1: Bill Information ── */}
                        <SectionHeader icon="📋" title="Bill Information" sub="Read from the bill image" />
                        <div style={gridRow3}>
                            <Field label="Bill Number / Invoice #" value={form.bill_number} onChange={v => setField("bill_number", v)} placeholder="INV-00123" />
                            <Field label="Bill Date" value={form.bill_date} onChange={v => setField("bill_date", v)} type="date" />
                            <Field label="Vendor / Supplier" value={form.vendor_name} onChange={v => setField("vendor_name", v)} placeholder="ABC Corp" />
                        </div>
                        <div style={{ ...gridRow3, gridTemplateColumns: "1fr", marginTop: 8 }}>
                            <Field label="Vendor Contact (Optional)" value={form.vendor_contact} onChange={v => setField("vendor_contact", v)} placeholder="Phone or email" />
                        </div>

                        {/* ── Section 2: Tool Selection ── */}
                        <SectionHeader icon="🔧" title="Tool Selection *" sub="Select from existing tools or type a new name." mt={20} />
                        <div style={{ background: "var(--glass-blue)", borderRadius: 10, padding: 14, border: "1px solid var(--border-subtle)" }}>
                            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                                <div>
                                    <label style={labelStyle}>Select Existing Tool</label>
                                    <select
                                        style={{ ...inputStyle, background: form.custom_tool_name ? "var(--bg-body)" : "var(--bg-surface)" }}
                                        value={form.tool_id}
                                        onChange={e => handleToolSelect(e.target.value)}
                                        disabled={!!form.custom_tool_name}>
                                        <option value="">— None —</option>
                                        {recentTools.map(t => <option key={t.id} value={t.id}>{t.name}{t.tool_code ? ` (${t.tool_code})` : ""}</option>)}
                                    </select>
                                    <label style={{ fontSize: 10, color: "var(--text-muted)", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, marginTop: 4 }}>
                                        <input type="checkbox" checked={showAllTools} onChange={e => setShowAllTools(e.target.checked)} /> Show all tools
                                    </label>
                                </div>
                                <div>
                                    <label style={labelStyle}>OR Type Tool Name Manually</label>
                                    <input
                                        style={{ ...inputStyle, background: form.tool_id ? "var(--bg-body)" : "var(--glass-amber)", borderColor: form.tool_id ? "var(--border-subtle)" : "var(--glass-amber)" }}
                                        value={form.custom_tool_name}
                                        onChange={e => handleCustomTool(e.target.value)}
                                        placeholder="Type tool name..."
                                        disabled={!!form.tool_id} />
                                </div>
                            </div>
                        </div>

                        {/* ── Section 3: Item Details ── */}
                        <SectionHeader icon="📦" title="Item Details" sub="Add line items from the bill" mt={20} />
                        <div style={{ border: "1px solid var(--border-subtle)", borderRadius: 8, overflow: "hidden" }}>
                            <table style={{ width: "100%", borderCollapse: "collapse" }}>
                                <thead>
                                    <tr style={{ background: "var(--table-header-bg)" }}>
                                        <th style={itemTh}>Item Description *</th>
                                        <th style={{ ...itemTh, textAlign: "center", width: 70 }}>Qty</th>
                                        <th style={{ ...itemTh, textAlign: "right", width: 100 }}>Unit Price</th>
                                        <th style={{ ...itemTh, textAlign: "right", width: 100 }}>Total</th>
                                        <th style={{ width: 36 }}></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {form.items.map((it, idx) => {
                                        const rowTotal = (parseInt(it.quantity) || 0) * (parseFloat(it.unit_price) || 0);
                                        return (
                                            <tr key={idx} style={{ borderTop: "1px solid var(--border-subtle)" }}>
                                                <td style={{ padding: "5px 6px" }}>
                                                    <input style={{ ...inputStyle, padding: "6px 8px", fontSize: 12 }} value={it.item_description} onChange={e => updateItem(idx, "item_description", e.target.value)} placeholder="Item description" />
                                                </td>
                                                <td style={{ padding: "5px 6px" }}>
                                                    <input type="number" min="1" style={{ ...inputStyle, padding: "6px 8px", fontSize: 12, textAlign: "center" }} value={it.quantity} onChange={e => updateItem(idx, "quantity", e.target.value)} />
                                                </td>
                                                <td style={{ padding: "5px 6px" }}>
                                                    <input type="number" min="0" step="0.01" style={{ ...inputStyle, padding: "6px 8px", fontSize: 12, textAlign: "right" }} value={it.unit_price} onChange={e => updateItem(idx, "unit_price", e.target.value)} />
                                                </td>
                                                <td style={{ padding: "6px", textAlign: "right", fontSize: 13, fontWeight: 600, color: "var(--success-color)" }}>{currency(rowTotal)}</td>
                                                <td style={{ padding: "4px" }}>
                                                    {form.items.length > 1 && <button onClick={() => removeItem(idx)} style={trashBtn}>🗑</button>}
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                                <tfoot>
                                    <tr style={{ borderTop: "2px solid var(--border-subtle)", background: "var(--table-header-bg)" }}>
                                        <td colSpan={2} style={{ padding: "8px 10px" }}>
                                            <button onClick={addItem} style={addItemBtn}>+ Add Item</button>
                                        </td>
                                        <td style={{ padding: "8px 10px", textAlign: "right", fontSize: 13, fontWeight: 700, color: "var(--text-primary)" }}>Grand Total:</td>
                                        <td style={{ padding: "8px 10px", textAlign: "right", fontSize: 15, fontWeight: 700, color: "var(--success-color)" }}>{currency(grandTotal)}</td>
                                        <td></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                        {/* ── Section 4: Payment Details ── */}
                        <SectionHeader icon="💳" title="Payment Details" mt={20} />
                        <div style={gridRow3}>
                            <Field label="Payment Amount" value={form.payment_amount} onChange={v => setField("payment_amount", v)} type="number" placeholder={grandTotal.toString()} />
                            <div>
                                <label style={labelStyle}>Payment Method</label>
                                <select style={inputStyle} value={form.payment_method} onChange={e => setField("payment_method", e.target.value)}>
                                    {PAYMENT_METHODS.map(m => <option key={m} value={m}>{m}</option>)}
                                </select>
                            </div>
                            <Field label="Reference Number" value={form.reference_number} onChange={v => setField("reference_number", v)} placeholder="Cheque / Transfer ref" />
                        </div>
                        <div style={{ ...gridRow3, gridTemplateColumns: "1fr 1fr", marginTop: 8 }}>
                            <Field label="Payment Date" value={form.payment_date} onChange={v => setField("payment_date", v)} type="date" />
                            <div>
                                <label style={labelStyle}>Payment Status</label>
                                <select style={inputStyle} value={form.payment_status} onChange={e => setField("payment_status", e.target.value)}>
                                    {PAYMENT_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                            </div>
                        </div>
                        <div style={{ marginTop: 8 }}>
                            <label style={labelStyle}>Notes / Remarks</label>
                            <textarea style={{ ...inputStyle, minHeight: 56, resize: "vertical" }} value={form.remarks} onChange={e => setField("remarks", e.target.value)} placeholder="Optional notes..." />
                        </div>

                        {/* ── Action Buttons ── */}
                        <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
                            <button onClick={handleSave} disabled={saving} style={saveBtnStyle}>
                                {saving ? "Saving..." : editingId ? "Update Payment" : "Save Payment"}
                            </button>
                            {editingId && (
                                <button onClick={() => { setEditingId(null); setForm(emptyForm()); }} style={cancelBtnStyle}>Cancel</button>
                            )}
                        </div>
                    </div>
                    )}
                </div>
            </div>            {/* ── Reject Dialog ── */}
            {showRejectDialog && (
                <Modal onClose={() => setShowRejectDialog(false)}>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "var(--text-primary)", marginBottom: 12 }}>Reject Bill</h3>
                    <p style={{ fontSize: 13, color: "var(--text-soft)", marginBottom: 16 }}>Please provide a reason for rejecting this bill.</p>
                    <textarea value={rejectReason} onChange={e => setRejectReason(e.target.value)} style={{ ...inputStyle, minHeight: 80, marginBottom: 16 }} placeholder="Rejection reason..." autoFocus />
                    <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                        <button onClick={() => setShowRejectDialog(false)} style={cancelBtnStyle}>Cancel</button>
                        <button onClick={handleReject} style={{ ...saveBtnStyle, background: "var(--error)" }}>Reject Bill</button>
                    </div>
                </Modal>
            )}

            {/* ── Delete Confirm ── */}
            {deleteConfirm && (
                <Modal onClose={() => setDeleteConfirm(null)}>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "var(--text-primary)", marginBottom: 12 }}>Delete Payment Record</h3>
                    <p style={{ fontSize: 13, color: "var(--text-soft)", marginBottom: 20 }}>Are you sure you want to delete this payment record? This action cannot be undone.</p>
                    <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                        <button onClick={() => setDeleteConfirm(null)} style={cancelBtnStyle}>Cancel</button>
                        <button onClick={() => handleDelete(deleteConfirm)} style={{ ...saveBtnStyle, background: "var(--error)" }}>Delete</button>
                    </div>
                </Modal>
            )}
        </div>
    );
}


/* ═══════════════════════════════════════════════════════════════
   HELPER COMPONENTS
   ═══════════════════════════════════════════════════════════════ */
function Flash({ text, type }) {
    return (
        <div style={{
            padding: "12px 20px", borderRadius: 10, marginBottom: 16, fontSize: 14, fontWeight: 500,
            background: type === "ok" ? "var(--glass-green)" : "var(--glass-rose)", 
            color: type === "ok" ? "var(--success)" : "var(--error)",
            border: `1px solid var(--border-subtle)`,
        }}>{text}</div>
    );
}

function SectionHeader({ icon, title, sub, mt = 0 }) {
    return (
        <div style={{ marginTop: mt, marginBottom: 10 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: "var(--text-primary)" }}>{icon} {title}</div>
            {sub && <p style={{ fontSize: 11, color: "var(--text-muted)", margin: "2px 0 0" }}>{sub}</p>}
        </div>
    );
}

function Field({ label, value, onChange, type = "text", placeholder = "" }) {
    return (
        <div>
            <label style={labelStyle}>{label}</label>
            <input type={type} style={inputStyle} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} />
        </div>
    );
}

function Modal({ onClose, children }) {
    return (
        <>
            <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", backdropFilter: "blur(4px)", zIndex: 2000 }} />
            <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%,-50%)", background: "var(--bg-surface)", color: "var(--text-primary)", borderRadius: 16, padding: 28, boxShadow: "0 20px 60px rgba(0,0,0,0.5)", zIndex: 2001, width: 420, maxWidth: "90vw", border: "1px solid var(--border-subtle)" }}>
                {children}
            </div>
        </>
    );
}


/* ═══════════════════════════════════════════════════════════════
   STYLES
   ═══════════════════════════════════════════════════════════════ */
const inputStyle = { width: "100%", padding: "8px 12px", border: "1px solid var(--input-border)", borderRadius: 8, fontSize: 13, boxSizing: "border-box", background: "var(--input-bg)", color: "var(--input-text)" };
const labelStyle = { display: "block", fontSize: 11, fontWeight: 600, color: "var(--text-soft)", marginBottom: 3 };
const chipStyle = { padding: "2px 8px", borderRadius: 5, fontSize: 10, fontWeight: 600, whiteSpace: "nowrap" };
const gridRow3 = { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 };

const filterInput = { padding: "8px 14px", border: "1px solid var(--input-border)", borderRadius: 8, fontSize: 13, width: 240, background: "var(--input-bg)", color: "var(--input-text)" };
const filterSelect = { padding: "8px 14px", border: "1px solid var(--input-border)", borderRadius: 8, fontSize: 13, background: "var(--input-bg)", color: "var(--input-text)" };
const refreshBtn = { padding: "8px 18px", background: "var(--brand-primary, #2563eb)", color: "#fff", border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer" };
const viewBtn = { padding: "6px 14px", background: "linear-gradient(135deg,#3b82f6,#2563eb)", color: "#fff", border: "none", borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: "pointer" };
const backBtn = { padding: "8px 16px", background: "var(--bg-body)", color: "var(--text-soft)", border: "1px solid var(--border-subtle)", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer" };
const processedBtn = { padding: "8px 16px", background: "linear-gradient(135deg,#16a34a,#15803d)", color: "#fff", border: "none", borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: "pointer" };
const rejectBtn = { padding: "8px 16px", background: "var(--glass-rose)", color: "#dc2626", border: "1px solid var(--border-subtle)", borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: "pointer" };
const cancelEditBtn = { padding: "4px 12px", background: "var(--bg-body)", color: "var(--text-soft)", border: "1px solid var(--border-subtle)", borderRadius: 6, fontSize: 11, fontWeight: 500, cursor: "pointer" };
const saveBtnStyle = { padding: "10px 24px", background: "linear-gradient(135deg,#3b82f6,#2563eb)", color: "#fff", border: "none", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer" };
const cancelBtnStyle = { padding: "10px 18px", background: "var(--bg-body)", color: "var(--text-soft)", border: "1px solid var(--border-subtle)", borderRadius: 8, fontSize: 13, fontWeight: 500, cursor: "pointer" };
const addItemBtn = { padding: "4px 12px", background: "var(--glass-blue)", color: "#2563eb", border: "1px solid var(--border-subtle)", borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: "pointer" };
const trashBtn = { background: "var(--glass-rose)", color: "#dc2626", border: "none", borderRadius: 6, padding: "4px 6px", cursor: "pointer", fontSize: 12 };
const iconBtn = { background: "none", border: "none", cursor: "pointer", fontSize: 14, padding: "2px 4px", color: "var(--text-soft)" };

const tableCard = { background: "var(--bg-surface)", borderRadius: 12, border: "1px solid var(--border-subtle)", overflow: "hidden", boxShadow: "var(--shadow-sm)" };
const sectionCard = { background: "var(--bg-surface)", borderRadius: 12, border: "1px solid var(--border-subtle)", padding: 20, marginBottom: 16, boxShadow: "var(--shadow-sm)" };
const thStyle = { padding: "10px 14px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "var(--text-soft)", borderBottom: "2px solid var(--border-subtle)", background: "var(--table-header-bg)", whiteSpace: "nowrap" };
const tdStyle = { padding: "10px 14px", fontSize: 13, borderBottom: "1px solid var(--border-subtle)", color: "var(--text-primary)" };
const rtd = { padding: "7px 10px", fontSize: 12, borderBottom: "1px solid var(--border-subtle)", color: "var(--text-primary)" };
const emptyTd = { padding: 40, textAlign: "center", color: "var(--text-muted)" };
const redDot = { display: "inline-block", width: 8, height: 8, borderRadius: "50%", background: "var(--error)", flexShrink: 0 };
const itemTh = { padding: "8px 10px", fontSize: 11, fontWeight: 600, color: "var(--text-soft)", textAlign: "left" };

const leftPanel = { flex: "0 0 50%", maxWidth: "50%", background: "var(--bg-surface)", borderRadius: 12, border: "1px solid var(--border-subtle)", overflow: "hidden", display: "flex", flexDirection: "column", boxShadow: "var(--shadow-sm)" };
const rightPanel = { flex: "0 0 calc(50% - 16px)", maxWidth: "calc(50% - 16px)", overflowY: "auto", maxHeight: "calc(100vh - 240px)" };
const imgToolbar = { padding: "10px 16px", background: "var(--table-header-bg)", borderBottom: "1px solid var(--border-subtle)", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 };
const imgContainer = { flex: 1, overflow: "auto", background: "var(--bg-body)", display: "flex", alignItems: "flex-start", justifyContent: "center", padding: 16 };
const zoomBtn = { padding: "4px 10px", background: "var(--bg-body)", border: "1px solid var(--border-subtle)", color: "var(--text-primary)", borderRadius: 6, cursor: "pointer", fontSize: 12, fontWeight: 600 };
const openLink = { padding: "4px 10px", background: "var(--glass-blue)", color: "#2563eb", border: "1px solid var(--border-subtle)", borderRadius: 6, fontSize: 11, textDecoration: "none", fontWeight: 600, display: "flex", alignItems: "center" };
