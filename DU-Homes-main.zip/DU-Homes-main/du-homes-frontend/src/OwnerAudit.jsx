import React, { useCallback, useEffect, useMemo, useRef, useState } from "react"; // Importing React hooks for state, side effects, and memoization
import PrintHeader from "./PrintHeader"; // Importing a custom component for the document's print header

// Configuration constants and utility functions for the Audit dashboard
const API = (import.meta.env.VITE_API_URL || "http://localhost:8080").replace(/\/+$/, ""); // Setting the base API URL from environment variables or fallback
const HIGH_VALUE_THRESHOLD = 15000; // Defining a threshold for highlighting large financial transactions
const money = (v) => `Rs. ${Number(v || 0).toLocaleString("en-LK", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`; // Formatting numbers as Sri Lankan Rupees (LKR)
const shortMoney = (v) => { // Compact currency formatter for dashboard KPIs (K/M suffixes)
    const n = Number(v || 0); // Converting input to number
    if (n >= 1000000) return `Rs. ${(n / 1000000).toFixed(2)}M`; // Formatting as Millions if >= 1,000,000
    if (n >= 1000) return `Rs. ${(n / 1000).toFixed(1)}K`; // Formatting as Thousands if >= 1,000
    return money(n); // Using standard formatting for smaller amounts
};
const dateOnly = (v) => (v ? new Date(v).toISOString().slice(0, 10) : ""); // Extracting YYYY-MM-DD from a date string or object
const auth = () => { // Helper to retrieve auth tokens and construct the Authorization header
    const t = localStorage.getItem("token") || localStorage.getItem("access_token") || ""; // Checking both standard token keys
    return t ? { Authorization: `Bearer ${t}` } : {}; // Returning header object if token exists
};
// UI Helper: Renders a pill-shaped status indicator (chip)
const chip = (label, bg = "var(--border-subtle)", color = "var(--text-primary)") => <span style={{ display: "inline-flex", padding: "5px 10px", borderRadius: 999, background: bg, color, fontSize: 11, fontWeight: 800 }}>{label}</span>;
const tone = (v) => { // Logic to determine color schemes (background and text) based on status strings
    const s = String(v || "").toLowerCase(); // Normalizing the status string
    if (["paid", "present", "good", "processed", "active"].includes(s)) return ["rgba(22,163,74,0.15)", "#22c55e"]; // Green theme for positive states
    if (["pending", "partial", "allocated", "fair", "new", "in progress"].includes(s)) return ["rgba(202,138,4,0.15)", "#eab308"]; // Yellow theme for neutral/in-progress states
    if (["absent", "poor", "lost", "damaged", "rejected"].includes(s)) return ["rgba(239,68,68,0.15)", "#ef4444"]; // Red theme for negative/critical states
    return ["var(--border-subtle)", "var(--text-primary)"]; // Default fallback theme
};
const iconWrap = (bg, color, child) => ( // Wrapper for KPI icons to ensure consistent sizing and styling
    <div style={{ width: 52, height: 52, borderRadius: 18, background: bg, color, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        {child}
    </div>
);
// SVG Icon Components for the dashboard
const IconSite = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 21h18" /><path d="M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16" /><path d="M9 9h1" /><path d="M9 13h1" /><path d="M14 9h1" /><path d="M14 13h1" /></svg>;
const IconWorkers = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>;
const IconMoney = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="6" width="20" height="12" rx="2" /><circle cx="12" cy="12" r="2" /></svg>;
const IconAttendance = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><path d="M22 4 12 14.01l-3-3" /></svg>;
const IconTools = () => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94z" /></svg>;
const IconSearch = ({ size = 18 }) => <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.35-4.35" /></svg>;
const IconDownload = () => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><path d="M7 10l5 5 5-5" /><path d="M12 15V3" /></svg>;
const IconRefresh = ({ spin }) => <svg className={spin ? "spin" : ""} width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12a9 9 0 1 1-2.64-6.36" /><path d="M21 3v6h-6" /></svg>;

// Icon for external link buttons
const IconExternalLink = () => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /><polyline points="15 3 21 3 21 9" /><line x1="10" y1="14" x2="21" y2="3" /></svg>;

// Side Drawer component to show full object details when a row is clicked
function Detail({ row, tab, onClose }) {
    if (!row) return null; // Only render if a row object is provided
    // Check if this is a tool-bill with an associated image/PDF
    const billImageUrl = row.raw?.image_path || null;
    const billFileType = row.raw?.file_type || "";
    const isPdf = billFileType.includes("pdf");
    return (
        <div onClick={onClose} style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.45)", backdropFilter: "blur(8px)", zIndex: 999, display: "flex", justifyContent: "flex-end" }}>
            <div onClick={(e) => e.stopPropagation()} style={{ width: "min(500px,100vw)", height: "100%", background: "var(--bg-surface)", padding: 24, overflowY: "auto", borderLeft: "1px solid var(--border-subtle)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                    <div><div style={{ fontSize: 11, color: "var(--text-soft)", fontWeight: 800, textTransform: "uppercase" }}>Executive Detail</div><h2 style={{ margin: "8px 0 0", fontSize: 26, fontWeight: 900, color: "var(--text-primary)" }}>{tab}</h2></div>
                    <button onClick={onClose} style={{ border: "1px solid var(--border-subtle)", background: "var(--bg-body)", color: "var(--text-primary)", borderRadius: 12, width: 38, height: 38, cursor: "pointer" }}>X</button>
                </div>

                {/* Bill image/PDF preview for tool-bills */}
                {billImageUrl && (
                    <div style={{ marginBottom: 16, border: "1px solid var(--border-subtle)", borderRadius: 16, overflow: "hidden", background: "var(--bg-body)" }}>
                        <div style={{ padding: "12px 14px", display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid var(--border-subtle)" }}>
                            <div style={{ fontSize: 11, color: "var(--text-soft)", fontWeight: 800, textTransform: "uppercase" }}>Bill Preview</div>
                            <a href={billImageUrl} target="_blank" rel="noopener noreferrer" style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 12px", borderRadius: 10, background: "var(--brand-primary, #2563eb)", color: "#fff", fontSize: 12, fontWeight: 700, textDecoration: "none" }}><IconExternalLink /> Open Full</a>
                        </div>
                        <div style={{ padding: 12 }}>
                            {isPdf ? (
                                <iframe src={billImageUrl} style={{ width: "100%", height: 400, border: "none", borderRadius: 8 }} title="Bill PDF" />
                            ) : (
                                <img src={billImageUrl} alt="Bill" style={{ width: "100%", borderRadius: 8, boxShadow: "0 2px 12px rgba(0,0,0,0.15)" }} />
                            )}
                        </div>
                    </div>
                )}

                <div style={{ display: "grid", gap: 10 }}>
                    {/* Iterating over the row entries to display key-value pairs */}
                    {Object.entries(row).filter(([k]) => !["id", "raw", "_imageUrl"].includes(k)).map(([k, v]) => (
                        <div key={k} style={{ border: "1px solid var(--border-subtle)", borderRadius: 16, padding: 14, background: "var(--bg-body)" }}>
                            <div style={{ fontSize: 11, color: "var(--text-soft)", fontWeight: 800, textTransform: "uppercase", marginBottom: 6 }}>{k}</div>
                            <div style={{ fontSize: 15, color: "var(--text-primary)", fontWeight: 700 }}>{String(v)}</div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}

// Main Executive Audit Component
export default function OwnerAudit() {
    const now = new Date(); // Getting current timestamp
    const first = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10); // Calculating first day of current month (YYYY-MM-DD)
    const last = now.toISOString().slice(0, 10); // Getting today's date (YYYY-MM-DD)
    
    // State management for loading states, UI filters, and data
    const [loading, setLoading] = useState(true); // Primary loading state (initial fetch)
    const [syncing, setSyncing] = useState(false); // Background sync state
    const [error, setError] = useState(""); // API error message state
    const [tab, setTab] = useState("finance"); // Currently active audit tab (e.g., finance, attendance)
    const [query, setQuery] = useState(""); // Search input state
    const [range, setRange] = useState({ from: first, to: last }); // Date range filter state
    const [page, setPage] = useState(1); // Current pagination page
    const [perPage, setPerPage] = useState(15); // Items per page setting
    const [selected, setSelected] = useState(null); // Currently selected row for the Detail view
    const [stamp, setStamp] = useState(new Date()); // Timestamp of the last successful data load
    const searchRef = useRef(null); // Reference to the search input for auto-focus shortcuts
    const explorerRef = useRef(null); // Reference to the Audit Explorer section for scroll-into-view
    const [kpiDrawer, setKpiDrawer] = useState(null); // State to track which KPI detail drawer is open
    const [data, setData] = useState({ sites: [], workers: [], payments: [], attendance: [], tools: [], deployments: [], toolBills: [], allocations: [], assignments: [], officers: [] }); // Consolidated data store
    const [deletedMap, setDeletedMap] = useState({}); // Lookup map for entities that were deleted but referenced in logs

    // Primary data fetcher: Pulls all required resources from the API
    const load = useCallback(async (silent = false) => {
        if (silent) setSyncing(true); else setLoading(true); // Toggle appropriate loading indicator
        const names = ["fields?archived=true", "workers?archived=true", "payments", "attendance", "tools", "deployments", "tool-bills", "tool-allocations", "assignments", "officers"]; // List of endpoints
        try {
            // Fetching all data in parallel for speed
            const out = await Promise.all(names.map((n) => fetch(`${API}/${n}`, { headers: auth() }).then((r) => r.ok ? r.json() : [])));
            
            // Updating the main data state (unwrapping pagination if needed for sites/workers)
            setData({ 
                sites: Array.isArray(out[0]) ? out[0] : out[0].data || [], 
                workers: Array.isArray(out[1]) ? out[1] : out[1].data || [], 
                payments: out[2], 
                attendance: out[3], 
                tools: out[4], 
                deployments: out[5], 
                toolBills: out[6], 
                allocations: out[7], 
                assignments: out[8], 
                officers: out[9] 
            });
            
            // Fetching deleted entities fallback to resolve IDs for items no longer in the primary lists
            fetch(`${API}/deleted-entities?type=worker,site`, { headers: auth() })
                .then(r => r.json()).then(d => {
                    const map = {};
                    (Array.isArray(d) ? d : []).forEach(e => { map[e.entity_id] = e; });
                    setDeletedMap(map); // Storing in a map for O(1) lookup
                }).catch(() => {});
                
            setStamp(new Date()); // Updating last sync time
            setError(""); // Clearing any previous errors
        } catch (e) {
            setError(e.message || "Failed to load data"); // Displaying error if fetch fails
        } finally {
            setLoading(false); // Stopping initial loader
            setSyncing(false); // Stopping sync indicator
        }
    }, []);

    // Side effects for lifecycle events
    useEffect(() => { load(); }, [load]); // Run initial load on component mount
    useEffect(() => { const id = setInterval(() => load(true), 300000); return () => clearInterval(id); }, [load]); // Set up background sync every 5 minutes
    useEffect(() => { setPage(1); }, [tab, query, range.from, range.to, perPage]); // Reset pagination when any filter changes
    useEffect(() => { // Global keyboard shortcuts (Ctrl+F to search, Esc to close detail)
        const onKey = (e) => { 
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "f") { e.preventDefault(); searchRef.current?.focus(); } 
            if (e.key === "Escape") { setSelected(null); setQuery(""); } 
        }; 
        window.addEventListener("keydown", onKey); 
        return () => window.removeEventListener("keydown", onKey); 
    }, []);

    // Memoized ID-to-Object maps for efficient lookups in resolvers
    const siteMap = useMemo(() => Object.fromEntries(data.sites.map((s) => [s.id, s])), [data.sites]);
    const workerMap = useMemo(() => Object.fromEntries(data.workers.map((w) => [w.id, w])), [data.workers]);
    const officerMap = useMemo(() => Object.fromEntries(data.officers.map((o) => [o.id, o])), [data.officers]);
    
    // Resolvers to handle displaying names for archived or deleted entities
    const getWorkerName = useCallback((id) => {
        if (!id) return "General"; // Handle unassigned worker refs
        if (workerMap[id]) return workerMap[id].full_name + (workerMap[id].is_archived ? " (Archived)" : ""); // Found in active/archived list
        if (deletedMap[id]) return deletedMap[id].entity_name + " (Deleted)"; // Found in deleted history
        return "Unknown Worker"; // Fallback
    }, [workerMap, deletedMap]);
    
    const getSiteName = useCallback((id) => {
        if (!id) return "-";
        if (siteMap[id]) return siteMap[id].name + (siteMap[id].is_archived ? " (Archived)" : "");
        if (deletedMap[id]) return deletedMap[id].entity_name + " (Deleted)";
        return "-";
    }, [siteMap, deletedMap]);

    // Workforce assignment logic
    const activeAssignments = useMemo(() => data.assignments.filter((a) => !a.to_date || a.to_date >= range.to), [data.assignments, range.to]); // Filtering assignments active in current range
    const bySite = useMemo(() => Object.fromEntries(activeAssignments.map((a) => [a.site_id, a])), [activeAssignments]); // Lookup active assignment by site ID
    const byWorker = useMemo(() => Object.fromEntries(activeAssignments.filter((a) => a.worker_id).map((a) => [a.worker_id, a])), [activeAssignments]); // Lookup active assignment by worker ID
    const inRange = useCallback((v) => { const d = dateOnly(v); return !d || (d >= range.from && d <= range.to); }, [range.from, range.to]); // Date filter helper

    // Calculating high-level metrics for the KPI dashboard
    const todayAttendance = useMemo(() => data.attendance.filter((a) => dateOnly(a.date) === last), [data.attendance, last]);
    const pendingReturns = useMemo(() => data.allocations.filter((a) => !a.returned_date && String(a.status || "").toLowerCase() !== "returned"), [data.allocations]);
    const lowStockTools = useMemo(() => data.tools.filter((t) => Number(t.available || 0) <= 2), [data.tools]);
    const todayPresent = useMemo(() => todayAttendance.filter((a) => String(a.status).toLowerCase() === "present"), [todayAttendance]);
    const todayAbsent = useMemo(() => todayAttendance.filter((a) => String(a.status).toLowerCase() === "absent"), [todayAttendance]);

    const stats = useMemo(() => {
        const payroll = data.payments.filter((p) => inRange(p.date)).reduce((s, p) => s + Number(p.net_pay || 0), 0); // Sum of payroll in range
        return {
            sites: data.sites.length, // Count of all managed sites
            workers: data.workers.length, // Total workforce count
            payroll, // Aggregated financial total
            present: todayPresent.length, // Worker presence today
            absent: todayAbsent.length, // Worker absence today
            returns: pendingReturns.length, // Count of tools not yet returned
            lowStock: lowStockTools.length, // Count of items with critical stock levels
        };
    }, [data, inRange, todayPresent, todayAbsent, pendingReturns, lowStockTools]);

    // KPI detail data: exact items behind each KPI number
    const kpiDetails = useMemo(() => ({
        sites: {
            title: "Operational Sites",
            columns: ["Site", "Owner", "Location"],
            rows: data.sites.map((s) => [s.name + (s.is_archived ? " (Archived)" : ""), s.owner_name || "-", s.address || "-"]),
        },
        workforce: {
            title: "Active Workforce",
            columns: ["Name", "Trade", "Daily Rate", "Phone"],
            rows: data.workers.map((w) => [w.full_name + (w.is_archived ? " (Archived)" : ""), w.worker_type || "-", money(w.daily_rate || 0), w.phone || "-"]),
        },
        payroll: {
            title: "Period Payroll Breakdown",
            columns: ["Date", "Worker", "Site", "Amount", "Method"],
            rows: data.payments.filter((p) => inRange(p.date)).map((p) => [dateOnly(p.date), getWorkerName(p.worker_id), getSiteName(p.site_id), money(p.net_pay || 0), p.method || "-"]),
        },
        returns: {
            title: "Pending Tool Returns",
            columns: ["Tool", "Worker", "Site", "Qty", "Allocated Date", "Status"],
            rows: pendingReturns.map((a) => {
                const toolName = data.tools.find((t) => t.id === a.tool_id)?.name || "Unknown";
                return [toolName, getWorkerName(a.worker_id), getSiteName(a.site_id), a.qty || 1, dateOnly(a.allocated_date), a.status || "-"];
            }),
        },
        attendance: {
            title: "Today's Attendance",
            columns: ["Worker", "Site", "Status"],
            rows: todayAttendance.map((a) => [getWorkerName(a.worker_id), getSiteName(a.site_id), a.status || "-"]),
        },
    }), [data, inRange, getWorkerName, getSiteName, pendingReturns, todayAttendance]);

    // Helper: navigate to a tab and scroll the explorer into view
    const goToTab = useCallback((tabName) => {
        setTab(tabName);
        setTimeout(() => explorerRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 100);
    }, []);

    // Data Transformation: Formatting raw data for display in tables based on active tab
    const tabs = useMemo(() => ({
        finance: data.payments.filter((p) => inRange(p.date)).map((p) => ({ id: p.id, date: dateOnly(p.date), worker: getWorkerName(p.worker_id), site: getSiteName(p.site_id), amount: money(p.net_pay || 0), status: p.status || "-", method: p.method || "-", raw: p })),
        attendance: data.attendance.filter((a) => inRange(a.date)).map((a) => ({ id: a.id, date: dateOnly(a.date), worker: getWorkerName(a.worker_id), site: getSiteName(a.site_id), status: a.status || "-", raw: a })),
        workforce: data.workers.map((w) => ({ id: w.id, name: w.full_name + (w.is_archived ? " (Archived)" : ""), trade: w.worker_type || "-", rate: money(w.daily_rate || 0), site: getSiteName(byWorker[w.id]?.site_id), phone: w.phone || "-", raw: w })),
        sites: data.sites.map((s) => ({ id: s.id, site: s.name + (s.is_archived ? " (Archived)" : ""), owner: s.owner_name || "-", location: s.address || "-", officer: officerMap[bySite[s.id]?.officer_id]?.full_name || "Not assigned", runs: data.deployments.filter((d) => d.site_id === s.id && inRange(d.date)).length, raw: s })),
        tools: data.tools.map((t) => ({ id: t.id, tool: t.name, code: t.tool_code || "-", total: t.total_qty || 0, available: t.available || 0, condition: t.condition || "-", raw: t })),
        deployments: data.deployments.filter((d) => inRange(d.date)).map((d) => ({ id: d.id, date: dateOnly(d.date), site: getSiteName(d.site_id), workers: d.deployment_workers?.length || 0, notes: d.notes || "-", raw: d })),
        "tool-bills": data.toolBills.filter((b) => inRange(b.created_at)).map((b) => ({ id: b.id, created: dateOnly(b.created_at), tool: data.tools.find((t) => t.id === b.tool_id)?.name || "Unlinked", file: b.file_name || "-", _imageUrl: b.image_path || "", status: b.status || "-", note: b.note || "-", raw: b })),
    }), [data, inRange, getWorkerName, getSiteName, byWorker, bySite, officerMap]);

    // Dynamic column definitions for each tab
    const columns = { finance: ["date", "worker", "site", "amount", "status", "method"], attendance: ["date", "worker", "site", "status"], workforce: ["name", "trade", "rate", "site", "phone"], sites: ["site", "owner", "location", "officer", "runs"], tools: ["tool", "code", "total", "available", "condition"], deployments: ["date", "site", "workers", "notes"], "tool-bills": ["created", "tool", "file", "status", "note"] };
    
    // Filtering and Pagination logic
    const rows = useMemo(() => (tabs[tab] || []).filter((r) => Object.values(r).some((v) => String(v).toLowerCase().includes(query.toLowerCase()))), [tabs, tab, query]); // Filtering based on search query
    const totalPages = Math.max(1, Math.ceil(rows.length / perPage)); // Calculating total pages for pagination UI
    const view = rows.slice((page - 1) * perPage, page * perPage); // Slicing data for current page view

    // Export functionality: Converts current filtered table to CSV format
    const exportCSV = () => {
        if (!rows.length) return;
        const headers = columns[tab]; // Getting headers for current tab
        const csv = [headers.join(","), ...rows.map((r) => headers.map((h) => `"${String(r[h] ?? "").replace(/"/g, '""')}"`).join(","))].join("\n"); // Generating CSV rows
        const a = document.createElement("a"); // Creating hidden download link
        a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" })); // Creating object URL from CSV string
        a.download = `owner-audit-${tab}.csv`; // Setting filename
        a.click(); // Triggering download
    };

    // Full-screen loading UI
    if (loading) return <div style={{ padding: 80, textAlign: "center" }}><span style={{ display: "inline-flex", gap: 10, alignItems: "center", padding: "16px 22px", background: "var(--bg-surface)", color: "var(--text-primary)", border: "1px solid var(--border-subtle)", borderRadius: 16 }}><IconRefresh spin /> Syncing executive data...</span></div>;

    return (
        <div style={{ maxWidth: 1560, margin: "0 auto", padding: "8px 28px 40px" }}>
            <PrintHeader title="Executive Audit and Business Intelligence" /> {/* Header component for document printing */}
            <Detail row={selected} tab={tab} onClose={() => setSelected(null)} /> {/* Side detail viewer */}
            
            {/* Embedded styles for animations and table hover effects */}
            <style>{`.spin{animation:spin 1s linear infinite}@keyframes spin{to{transform:rotate(360deg)}} .owner-table tbody tr:hover td{background:var(--bg-body)} @media(max-width:1100px){.owner-hero,.owner-kpis,.owner-panels{grid-template-columns:1fr!important}}`}</style>

            {/* Dashboard Hero Section: Welcome and Audit Controls */}
            <div className="owner-hero" style={{ display: "grid", gridTemplateColumns: "1.35fr 0.85fr", gap: 22, marginTop: 18, marginBottom: 24 }}>
                <section style={{ background: "linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #312e81 100%)", color: "#fff", borderRadius: 28, padding: 28, border: "1px solid rgba(255,255,255,0.1)", boxShadow: "0 20px 40px rgba(0,0,0,0.4)" }}>
                    <div style={{ fontSize: 12, fontWeight: 800, color: "#fbbf24", textTransform: "uppercase", marginBottom: 10, letterSpacing: 1.2 }}>⭐ Company Owner Command View</div>
                    <h1 style={{ margin: 0, fontSize: 34, fontWeight: 900, lineHeight: 1.05, textShadow: "0 2px 10px rgba(0,0,0,0.5)" }}>Executive Audit Log</h1>
                    <p style={{ margin: "14px 0 20px", fontSize: 15, lineHeight: 1.65, color: "rgba(255,255,255,0.85)" }}>A cleaner owner dashboard for reviewing payroll, attendance, sites, deployments, tools, and procurement in one place.</p>
                    <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                        {chip(`Last sync ${stamp.toLocaleTimeString()}`, "rgba(255,255,255,0.15)", "#fff")}
                        {chip(syncing ? "Background sync running" : "Live data ready", syncing ? "rgba(253,230,138,0.2)" : "rgba(134,239,172,0.2)", syncing ? "#fde68a" : "#bbf7d0")}
                    </div>
                </section>
                
                {/* Audit Controls: Date range and export buttons */}
                <section style={{ background: "var(--bg-surface)", border: "1px solid var(--border-subtle)", borderRadius: 28, padding: 24, boxShadow: "var(--shadow-sm)" }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 18 }}>
                        <div>
                            <div style={{ fontSize: 12, color: "var(--text-soft)", fontWeight: 800, textTransform: "uppercase" }}>Audit Controls</div>
                            <div style={{ marginTop: 6, fontSize: 22, fontWeight: 900, color: "var(--text-primary)" }}>Review Window</div>
                        </div>
                        <button onClick={() => load(true)} style={{ width: 42, height: 42, borderRadius: 14, border: "1px solid var(--border-subtle)", background: "var(--bg-body)", color: "var(--text-primary)", cursor: "pointer" }}><IconRefresh spin={syncing} /></button>
                    </div>
                    <div style={{ display: "grid", gap: 14 }}>
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                            <input type="date" value={range.from} onChange={(e) => setRange((p) => ({ ...p, from: e.target.value }))} style={{ padding: "12px 14px", borderRadius: 14, border: "1px solid var(--border-subtle)", background: "var(--input-bg)", color: "var(--text-primary)", fontSize: 13, fontWeight: 700 }} />
                            <input type="date" value={range.to} onChange={(e) => setRange((p) => ({ ...p, to: e.target.value }))} style={{ padding: "12px 14px", borderRadius: 14, border: "1px solid var(--border-subtle)", background: "var(--input-bg)", color: "var(--text-primary)", fontSize: 13, fontWeight: 700 }} />
                        </div>
                        <div style={{ display: "flex", gap: 10 }}>
                            <button onClick={exportCSV} style={{ flex: 1, padding: "12px 16px", borderRadius: 14, border: "1px solid var(--border-subtle)", background: "var(--bg-body)", color: "var(--text-primary)", fontWeight: 800, cursor: "pointer", display: "flex", justifyContent: "center", alignItems: "center", gap: 8 }}><IconDownload /> Export CSV</button>
                            <button onClick={() => window.print()} style={{ flex: 1, padding: "12px 16px", borderRadius: 14, border: "none", background: "var(--brand-primary, #2563eb)", color: "#fff", fontWeight: 800, cursor: "pointer" }}>Save PDF</button>
                        </div>
                        {error && <div style={{ padding: "12px 14px", borderRadius: 14, background: "rgba(220,38,38,0.15)", color: "#ef4444", fontWeight: 700, fontSize: 13 }}>{error}</div>}
                    </div>
                </section>
            </div>

            {/* KPI Detail Drawer: Shows the exact data behind each KPI card */}
            {kpiDrawer && kpiDetails[kpiDrawer] && (
                <div onClick={() => setKpiDrawer(null)} style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.45)", backdropFilter: "blur(8px)", zIndex: 999, display: "flex", justifyContent: "center", alignItems: "center" }}>
                    <div onClick={(e) => e.stopPropagation()} style={{ width: "min(820px, 95vw)", maxHeight: "85vh", background: "var(--bg-surface)", borderRadius: 28, border: "1px solid var(--border-subtle)", boxShadow: "0 25px 50px rgba(0,0,0,0.4)", display: "flex", flexDirection: "column", overflow: "hidden" }}>
                        <div style={{ padding: "22px 24px", borderBottom: "1px solid var(--border-subtle)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                            <div>
                                <div style={{ fontSize: 11, color: "var(--text-soft)", fontWeight: 800, textTransform: "uppercase" }}>KPI Breakdown</div>
                                <div style={{ fontSize: 22, fontWeight: 900, color: "var(--text-primary)", marginTop: 4 }}>{kpiDetails[kpiDrawer].title}</div>
                                <div style={{ fontSize: 12, color: "var(--text-soft)", fontWeight: 700, marginTop: 4 }}>{kpiDetails[kpiDrawer].rows.length} record{kpiDetails[kpiDrawer].rows.length !== 1 ? "s" : ""}</div>
                            </div>
                            <button onClick={() => setKpiDrawer(null)} style={{ border: "1px solid var(--border-subtle)", background: "var(--bg-body)", color: "var(--text-primary)", borderRadius: 12, width: 38, height: 38, cursor: "pointer", fontSize: 16, fontWeight: 700 }}>X</button>
                        </div>
                        <div style={{ flex: 1, overflowY: "auto", padding: 0 }}>
                            {kpiDetails[kpiDrawer].rows.length === 0 ? (
                                <div style={{ padding: 50, textAlign: "center", color: "var(--text-soft)" }}>
                                    <div style={{ fontSize: 22, fontWeight: 800, color: "var(--text-primary)", marginBottom: 8 }}>No Records</div>
                                    <div style={{ fontSize: 13 }}>Nothing to display for this metric.</div>
                                </div>
                            ) : (
                                <table style={{ width: "100%", borderCollapse: "separate", borderSpacing: 0 }}>
                                    <thead>
                                        <tr>{kpiDetails[kpiDrawer].columns.map((h) => <th key={h} style={{ padding: "14px 18px", background: "var(--bg-body)", borderBottom: "1px solid var(--border-subtle)", textAlign: "left", fontSize: 11, color: "var(--text-soft)", textTransform: "uppercase", fontWeight: 900, position: "sticky", top: 0 }}>{h}</th>)}</tr>
                                    </thead>
                                    <tbody>
                                        {kpiDetails[kpiDrawer].rows.map((row, i) => (
                                            <tr key={i}>
                                                {row.map((cell, j) => (
                                                    <td key={j} style={{ padding: "13px 18px", borderBottom: "1px solid var(--border-subtle)", fontSize: 13, color: "var(--text-primary)", fontWeight: 600 }}>
                                                        {kpiDetails[kpiDrawer].columns[j] === "Status" ? chip(cell, ...tone(cell)) : cell}
                                                    </td>
                                                ))}
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* KPI Grid: Displays high-level summary metrics — clickable cards */}
            <div className="owner-kpis" style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 18, marginBottom: 24 }}>
                {[
                    { label: "Operational Sites", value: stats.sites, sub: `${tabs.sites.length} visible sites`, icon: iconWrap("rgba(37,99,235,0.15)", "#3b82f6", <IconSite />), action: () => { goToTab("sites"); setKpiDrawer("sites"); } },
                    { label: "Active Workforce", value: stats.workers, sub: `${stats.present} present today`, icon: iconWrap("rgba(202,138,4,0.15)", "#eab308", <IconWorkers />), action: () => { goToTab("workforce"); setKpiDrawer("workforce"); } },
                    { label: "Period Payroll", value: shortMoney(stats.payroll), sub: `${stats.absent} absent today`, icon: iconWrap("rgba(22,163,74,0.15)", "#22c55e", <IconMoney />), action: () => { goToTab("finance"); setKpiDrawer("payroll"); } },
                    { label: "Pending Returns", value: stats.returns, sub: `${stats.lowStock} low-stock items`, icon: iconWrap("rgba(239,68,68,0.15)", "#ef4444", <IconTools />), action: () => setKpiDrawer("returns") },
                    { label: "Attendance Snapshot", value: stats.present, sub: stats.absent ? `${stats.absent} absences to review` : "Attendance stable", icon: iconWrap("rgba(124,58,237,0.15)", "#8b5cf6", <IconAttendance />), action: () => { goToTab("attendance"); setKpiDrawer("attendance"); } }
                ].map((c) => (
                    <div key={c.label} onClick={c.action} style={{ background: "var(--bg-surface)", border: "1px solid var(--border-subtle)", borderRadius: 24, padding: 20, display: "flex", justifyContent: "space-between", gap: 14, boxShadow: "var(--shadow-sm)", cursor: "pointer", transition: "transform 0.15s, box-shadow 0.15s" }} onMouseEnter={(e) => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 8px 24px rgba(0,0,0,0.25)"; }} onMouseLeave={(e) => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "var(--shadow-sm)"; }}>
                        <div><div style={{ fontSize: 11, color: "var(--text-soft)", fontWeight: 800, textTransform: "uppercase", marginBottom: 8 }}>{c.label}</div><div style={{ fontSize: 32, fontWeight: 900, color: "var(--text-primary)", lineHeight: 1.1 }}>{c.value}</div><div style={{ fontSize: 12, color: "var(--text-soft)", fontWeight: 700, marginTop: 8 }}>{c.sub}</div></div>
                        {c.icon}
                    </div>
                ))}
            </div>

            {/* Business Intelligence Panels: Highlights and Leaderboards */}
            <div className="owner-panels" style={{ display: "grid", gridTemplateColumns: "1.05fr 0.95fr", gap: 18, marginBottom: 24 }}>
                {/* Executive Signals: Logic-based alerts for immediate attention */}
                <section style={{ background: "var(--bg-surface)", border: "1px solid var(--border-subtle)", borderRadius: 24, padding: 22, boxShadow: "var(--shadow-sm)" }}>
                    <div style={{ fontSize: 12, color: "var(--brand-primary, #2563eb)", fontWeight: 800, textTransform: "uppercase", marginBottom: 6 }}>Executive Signals</div>
                    <div style={{ fontSize: 24, fontWeight: 900, color: "var(--text-primary)", marginBottom: 16 }}>What Needs Attention</div>
                    <div style={{ display: "grid", gap: 12 }}>
                        {[
                            stats.payroll > 0 ? `Payroll in range totals ${money(stats.payroll)}.` : "No payroll data in this window.",
                            stats.absent ? `${stats.absent} absences were recorded today.` : "No absences recorded today.",
                            stats.returns ? `${stats.returns} tool allocations remain open without return logs.` : "No open tool-return backlog.",
                            data.payments.filter((p) => inRange(p.date) && Number(p.net_pay || 0) >= HIGH_VALUE_THRESHOLD).length ? "High-value payments detected in this window." : "No unusually high payments detected."
                        ].map((s, i) => <div key={i} style={{ borderRadius: 18, padding: "16px 18px", border: "1px solid var(--border-subtle)", background: "var(--bg-body)", color: "var(--text-primary)", fontSize: 14, lineHeight: 1.6 }}>{s}</div>)}
                    </div>
                </section>
                
                {/* Operational Leaders: Rank sites by activity (deployments) in range */}
                <section style={{ background: "var(--bg-surface)", border: "1px solid var(--border-subtle)", borderRadius: 24, padding: 22, boxShadow: "var(--shadow-sm)" }}>
                    <div style={{ fontSize: 12, color: "var(--brand-primary, #2563eb)", fontWeight: 800, textTransform: "uppercase", marginBottom: 6 }}>Top Site Activity</div>
                    <div style={{ fontSize: 24, fontWeight: 900, color: "var(--text-primary)", marginBottom: 16 }}>Operational Leaders</div>
                    <div style={{ display: "grid", gap: 12 }}>
                        {[...data.sites].map((s) => ({ s, runs: data.deployments.filter((d) => d.site_id === s.id && inRange(d.date)).length })).sort((a, b) => b.runs - a.runs).slice(0, 4).map((x, i) => (
                            <div key={x.s.id} style={{ borderRadius: 18, border: "1px solid var(--border-subtle)", padding: 16, background: "var(--bg-body)" }}>
                                <div style={{ fontSize: 11, color: "var(--text-soft)", fontWeight: 800, textTransform: "uppercase", marginBottom: 6 }}>Rank {i + 1}</div>
                                <div style={{ fontSize: 18, fontWeight: 800, color: "var(--text-primary)" }}>{x.s.name}</div>
                                <div style={{ marginTop: 4, color: "var(--text-soft)", fontSize: 13 }}>{x.s.owner_name || "No owner set"}</div>
                                <div style={{ marginTop: 8, fontSize: 22, fontWeight: 900, color: "var(--brand-primary, #2563eb)" }}>{x.runs}</div>
                                <div style={{ color: "var(--text-soft)", fontSize: 12 }}>runs in selected period</div>
                            </div>
                        ))}
                    </div>
                </section>
            </div>

            {/* Audit Explorer: The main searchable and filterable table */}
            {/* ref used for scroll-into-view from KPI card clicks */}
            <section ref={explorerRef} style={{ background: "var(--bg-surface)", border: "1px solid var(--border-subtle)", borderRadius: 28, padding: 22, boxShadow: "var(--shadow-sm)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16, flexWrap: "wrap", marginBottom: 18 }}>
                    <div>
                        <div style={{ fontSize: 12, color: "var(--brand-primary, #2563eb)", fontWeight: 800, textTransform: "uppercase", marginBottom: 6 }}>Audit Explorer</div>
                        <div style={{ fontSize: 26, fontWeight: 900, color: "var(--text-primary)" }}>{tab.replace("-", " ")} Review</div>
                        <div style={{ marginTop: 8, fontSize: 13, color: "var(--text-soft)", fontWeight: 700 }}>{rows.length} filtered records in the selected window</div>
                    </div>
                    
                    {/* Search and Page Size controls */}
                    <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                        <div style={{ position: "relative" }}>
                            <div style={{ position: "absolute", top: 12, left: 14, color: "var(--text-soft)" }}><IconSearch /></div>
                            <input ref={searchRef} value={query} onChange={(e) => setQuery(e.target.value)} placeholder={`Search ${tab.replace("-", " ")} records`} style={{ width: 280, padding: "12px 14px 12px 42px", borderRadius: 14, border: "1px solid var(--border-subtle)", background: "var(--input-bg)", color: "var(--text-primary)", fontSize: 13, outline: "none" }} />
                        </div>
                        <select value={perPage} onChange={(e) => setPerPage(Number(e.target.value))} style={{ padding: "12px 14px", borderRadius: 14, border: "1px solid var(--border-subtle)", background: "var(--input-bg)", color: "var(--text-primary)", fontWeight: 700, fontSize: 13 }}>{[15, 25, 50, 100].map((n) => <option key={n} value={n}>Show {n}</option>)}</select>
                    </div>
                </div>
                
                {/* Tab Navigation: Switch between different data entities */}
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 20 }}>
                    {Object.keys(tabs).map((k) => (
                        <button key={k} onClick={() => setTab(k)} style={{ padding: "12px 18px", borderRadius: 16, border: tab === k ? "2px solid var(--brand-primary, #2563eb)" : "1px solid var(--border-subtle)", background: tab === k ? "rgba(37,99,235,0.1)" : "var(--bg-body)", color: tab === k ? "var(--brand-primary, #2563eb)" : "var(--text-soft)", fontWeight: 800, fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", gap: 10 }}>
                            {k.replace("-", " ")}
                            <span style={{ padding: "2px 8px", borderRadius: 999, background: tab === k ? "rgba(37,99,235,0.2)" : "var(--border-subtle)", color: tab === k ? "var(--brand-primary, #2563eb)" : "var(--text-soft)", fontSize: 10, fontWeight: 800 }}>{tabs[k].length}</span>
                        </button>
                    ))}
                </div>
                
                {/* Active Filter Info & Contextual Totals */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 10 }}>
                    <span style={{ padding: "6px 12px", borderRadius: 999, background: "var(--bg-body)", color: "var(--text-primary)", fontSize: 12, fontWeight: 700 }}>{range.from} to {range.to}</span>
                    {tab === "finance" && chip(`Total ${money(data.payments.filter((p) => inRange(p.date)).reduce((s, p) => s + Number(p.net_pay || 0), 0))}`, "rgba(22,163,74,0.15)", "#22c55e")}
                </div>
                
                {/* Data Table Container */}
                <div style={{ border: "1px solid var(--border-subtle)", borderRadius: 22, overflow: "hidden" }}>
                    {!view.length ? (
                        /* Empty State: Shown when no records match filters */
                        <div style={{ padding: 70, textAlign: "center", color: "var(--text-soft)" }}>
                            <div style={{ display: "inline-flex", width: 72, height: 72, borderRadius: 999, background: "var(--bg-body)", alignItems: "center", justifyContent: "center", marginBottom: 18 }}><IconSearch size={34} /></div>
                            <div style={{ fontSize: 28, fontWeight: 900, color: "var(--text-primary)", marginBottom: 8 }}>No Records Found</div>
                            <div style={{ fontSize: 14 }}>Adjust the search or date range to reveal more detail.</div>
                        </div>
                    ) : (
                        /* Responsive Table: Dynamic columns based on active tab */
                        <div style={{ overflowX: "auto" }}>
                            <table className="owner-table" style={{ width: "100%", borderCollapse: "separate", borderSpacing: 0 }}>
                                <thead>
                                    <tr>{columns[tab].map((c) => <th key={c} style={{ padding: "16px 18px", background: "var(--bg-body)", borderBottom: "1px solid var(--border-subtle)", textAlign: "left", fontSize: 11, color: "var(--text-soft)", textTransform: "uppercase", fontWeight: 900 }}>{c}</th>)}</tr>
                                </thead>
                                <tbody>
                                    {view.map((r) => (
                                        <tr key={r.id} onClick={() => setSelected(r)} style={{ cursor: "pointer" }}>
                                            {columns[tab].map((c) => (
                                                <td key={c} style={{ padding: "16px 18px", borderBottom: "1px solid var(--border-subtle)", fontSize: 14, color: "var(--text-primary)" }}>
                                                    {c === "status" || c === "condition" ? chip(r[c], ...tone(r[c]))
                                                     : c === "file" && r._imageUrl ? (
                                                        <a href={r._imageUrl} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} style={{ color: "var(--brand-primary, #2563eb)", textDecoration: "underline", fontWeight: 700, display: "inline-flex", alignItems: "center", gap: 6 }}>
                                                            {r[c]} <IconExternalLink />
                                                        </a>
                                                     ) : r[c]}
                                                </td>
                                            ))}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
                
                {/* Pagination Controls */}
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 18, flexWrap: "wrap", gap: 12 }}>
                    <div style={{ fontSize: 12, fontWeight: 800, color: "var(--text-soft)", textTransform: "uppercase" }}>Page {page} of {totalPages}</div>
                    <div style={{ display: "flex", gap: 10 }}>
                        <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1} style={{ padding: "10px 16px", borderRadius: 12, border: "1px solid var(--border-subtle)", background: "var(--bg-body)", color: "var(--text-primary)", cursor: page === 1 ? "not-allowed" : "pointer", opacity: page === 1 ? 0.45 : 1, fontWeight: 700 }}>Previous</button>
                        <button onClick={() => setPage((p) => Math.min(totalPages, p + 1))} disabled={page === totalPages} style={{ padding: "10px 16px", borderRadius: 12, border: "none", background: "var(--brand-primary, #2563eb)", color: "#fff", cursor: page === totalPages ? "not-allowed" : "pointer", opacity: page === totalPages ? 0.45 : 1, fontWeight: 700 }}>Next</button>
                    </div>
                </div>
            </section>
        </div>
    );
}
