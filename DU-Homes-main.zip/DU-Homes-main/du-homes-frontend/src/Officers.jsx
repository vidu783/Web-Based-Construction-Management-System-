import React, { useEffect, useState } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8080";
const hdr = () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("access_token") || localStorage.getItem("token") || ""}`,
});

const roleBadge = {
    site_officer: { bg: "#dbeafe", color: "#1d4ed8", label: "Site Officer" },
    project_manager: { bg: "#dcfce7", color: "#16a34a", label: "Project Manager" },
    admin: { bg: "#fef3c7", color: "#d97706", label: "Admin" },
    finance_officer: { bg: "#f3e8ff", color: "#7c3aed", label: "Finance Officer" },
};

export default function Officers() {
    const [officers, setOfficers] = useState([]);
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [msg, setMsg] = useState({ text: "", type: "" });
    const [showForm, setShowForm] = useState(false);
    const [editId, setEditId] = useState(null);
    const [form, setForm] = useState({ full_name: "", phone: "", email: "", role: "site_officer", nic: "" });
    const [search, setSearch] = useState("");
    const [linkingId, setLinkingId] = useState(null);
    const [fieldErrors, setFieldErrors] = useState({});

    const validate = () => {
        const errs = {};
        if (!form.full_name.trim()) errs.full_name = "Full name is required";
        else if (form.full_name.trim().length < 2) errs.full_name = "Name must be at least 2 characters";
        if (form.phone.trim() && !/^\d{10}$/.test(form.phone.trim())) errs.phone = "Phone must be 10 digits";
        if (form.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) errs.email = "Invalid email format";
        if (form.nic.trim() && !/^(\d{9}[vVxX]|\d{12})$/.test(form.nic.trim())) errs.nic = "Invalid NIC format";
        setFieldErrors(errs);
        return Object.keys(errs).length === 0;
    };

    const flash = (text, type = "ok") => {
        setMsg({ text, type });
        setTimeout(() => setMsg({ text: "", type: "" }), 4000);
    };

    /* ── Fetch officers & users ── */
    const fetchOfficers = async () => {
        try {
            const res = await fetch(`${API}/officers`, { headers: hdr() });
            const data = await res.json();
            setOfficers(Array.isArray(data) ? data : []);
        } catch { setOfficers([]); }
    };

    const fetchUsers = async () => {
        try {
            const res = await fetch(`${API}/auth/users`, {
                headers: hdr(),
            });
            const data = await res.json();
            setUsers(Array.isArray(data) ? data : []);
        } catch { setUsers([]); }
    };

    useEffect(() => {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        Promise.all([fetchOfficers(), fetchUsers()]).then(() => setLoading(false));
    }, []);

    /* ── CRUD handlers ── */
    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validate()) return;
        try {
            const url = editId ? `${API}/officers/${editId}` : `${API}/officers`;
            const method = editId ? "PUT" : "POST";
            const res = await fetch(url, {
                method,
                headers: hdr(),
                body: JSON.stringify(form),
            });
            if (!res.ok) {
                const err = await res.json();
                return flash(err.error || "Failed", "err");
            }
            flash(editId ? "Officer updated" : "Officer added");
            setShowForm(false);
            setEditId(null);
            setForm({ full_name: "", phone: "", email: "", role: "site_officer", nic: "" });
            setFieldErrors({});
            fetchOfficers();
        } catch (e) {
            flash(e.message, "err");
        }
    };

    const handleEdit = (o) => {
        setForm({ full_name: o.full_name, phone: o.phone || "", email: o.email || "", role: o.role || "site_officer", nic: o.nic || "" });
        setEditId(o.id);
        setShowForm(true);
    };

    const handleDelete = async (id) => {
        if (!confirm("Delete this officer?")) return;
        try {
            const res = await fetch(`${API}/officers/${id}`, { method: "DELETE", headers: hdr() });
            if (!res.ok) {
                const err = await res.json();
                return flash(err.detail || err.error || "Failed to delete", "err");
            }
            flash("Officer deleted");
            fetchOfficers();
        } catch (e) {
            flash(e.message, "err");
        }
    };

    /* ── Link / Unlink ── */
    const handleLink = async (officerId, userId) => {
        try {
            if (!userId) {
                // unlink
                const res = await fetch(`${API}/officers/${officerId}/unlink`, { method: "PATCH", headers: hdr() });
                if (!res.ok) {
                    const err = await res.json();
                    return flash(err.error || "Unlink failed", "err");
                }
                flash("Account unlinked");
            } else {
                const res = await fetch(`${API}/officers/${officerId}/link`, {
                    method: "PATCH",
                    headers: hdr(),
                    body: JSON.stringify({ user_id: userId }),
                });
                if (!res.ok) {
                    const err = await res.json();
                    return flash(err.error || "Link failed", "err");
                }
                flash("Account linked successfully");
            }
            setLinkingId(null);
            fetchOfficers();
        } catch (e) {
            flash(e.message, "err");
        }
    };

    /* ── Helpers ── */
    const linkedUserIds = officers.filter((o) => o.user_id).map((o) => o.user_id);
    const getLinkedUser = (userId) => users.find((u) => u.id === userId);

    const filtered = officers.filter((o) => {
        const q = search.toLowerCase();
        return (
            (o.full_name || "").toLowerCase().includes(q) ||
            (o.email || "").toLowerCase().includes(q) ||
            (o.phone || "").includes(q) ||
            (o.nic || "").includes(q)
        );
    });

    /* ── Styles ── */
    const card = {
        background: "var(--bg-surface)",
        borderRadius: 16,
        padding: 24,
        boxShadow: "var(--shadow-sm)",
        color: "var(--text-primary)",
    };
    const btnPrimary = {
        background: "linear-gradient(135deg,#6366f1,#8b5cf6)",
        color: "#fff",
        border: "none",
        borderRadius: 10,
        padding: "10px 20px",
        cursor: "pointer",
        fontWeight: 600,
        fontSize: 14,
    };
    const btnDanger = {
        background: "var(--glass-rose)",
        color: "#dc2626",
        border: "none",
        borderRadius: 8,
        padding: "6px 14px",
        cursor: "pointer",
        fontSize: 13,
        fontWeight: 500,
    };
    const btnGhost = {
        background: "var(--border-subtle)",
        color: "var(--text-soft)",
        border: "none",
        borderRadius: 8,
        padding: "6px 14px",
        cursor: "pointer",
        fontSize: 13,
        fontWeight: 500,
    };
    const inputStyle = {
        width: "100%",
        padding: "10px 14px",
        border: "1px solid var(--input-border)",
        background: "var(--input-bg)",
        color: "var(--input-text)",
        borderRadius: 10,
        fontSize: 14,
        outline: "none",
        boxSizing: "border-box",
    };
    const inpErr = (field) => ({
        ...inputStyle,
        border: fieldErrors[field] ? "1px solid #dc2626" : "1px solid var(--input-border)",
        background: fieldErrors[field] ? "var(--glass-rose)" : "var(--input-bg)",
    });
    const errText = { color: "#dc2626", fontSize: 11, marginTop: 2, fontWeight: 500 };
    const thStyle = {
        padding: "12px 16px",
        textAlign: "left",
        fontSize: 12,
        fontWeight: 600,
        color: "var(--text-soft)",
        textTransform: "uppercase",
        letterSpacing: 0.5,
        borderBottom: "2px solid var(--border-subtle)",
        background: "var(--table-header-bg)",
    };
    const tdStyle = {
        padding: "14px 16px",
        fontSize: 14,
        color: "var(--text-primary)",
        borderBottom: "1px solid var(--border-subtle)",
    };

    if (loading) {
        return (
            <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: 400 }}>
                <div style={{ width: 40, height: 40, border: "4px solid var(--border-subtle)", borderTopColor: "var(--primary)", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
                <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
            </div>
        );
    }

    return (
        <div style={{ padding: 0, maxWidth: 1200, margin: "0 auto" }}>
            {/* Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
                <div>
                    <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: "var(--text-primary)" }}>Officers</h2>
                    <p style={{ margin: "4px 0 0", fontSize: 14, color: "var(--text-muted)" }}>
                        {officers.length} officer{officers.length !== 1 ? "s" : ""} registered
                    </p>
                </div>
                <button
                    style={btnPrimary}
                    onClick={() => {
                        setShowForm(!showForm);
                        setEditId(null);
                        setForm({ full_name: "", phone: "", email: "", role: "site_officer", nic: "" });
                        setFieldErrors({});
                    }}
                >
                    {showForm ? "Cancel" : "+ Add Officer"}
                </button>
            </div>

            {/* Flash message */}
            {msg.text && (
                <div
                    style={{
                        padding: "12px 20px",
                        borderRadius: 10,
                        marginBottom: 16,
                        fontSize: 14,
                        fontWeight: 500,
                        background: msg.type === "err" ? "var(--glass-rose)" : "var(--glass-green)",
                        color: msg.type === "err" ? "#dc2626" : "#16a34a",
                        border: `1px solid ${msg.type === "err" ? "#dc262633" : "#16a34a33"}`,
                    }}
                >
                    {msg.text}
                </div>
            )}

            {/* Form */}
            {showForm && (
                <div style={{ ...card, marginBottom: 24, border: "1px solid var(--border-subtle)" }}>
                    <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 600, color: "var(--text-primary)" }}>
                        {editId ? "Edit Officer" : "New Officer"}
                    </h3>
                    <form onSubmit={handleSubmit}>
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                            <div>
                                <label style={{ fontSize: 13, fontWeight: 500, color: "var(--text-soft)", display: "block", marginBottom: 4 }}>Full Name *</label>
                                <input
                                    style={inpErr("full_name")}
                                    placeholder="Full name"
                                    value={form.full_name}
                                    onChange={(e) => {
                                        setForm({ ...form, full_name: e.target.value });
                                        if (fieldErrors.full_name) setFieldErrors((p) => ({ ...p, full_name: undefined }));
                                    }}
                                />
                                {fieldErrors.full_name && <span style={errText}>{fieldErrors.full_name}</span>}
                            </div>
                            <div>
                                <label style={{ fontSize: 13, fontWeight: 500, color: "var(--text-soft)", display: "block", marginBottom: 4 }}>Phone</label>
                                <input
                                    style={inpErr("phone")}
                                    placeholder="Phone"
                                    value={form.phone}
                                    onChange={(e) => {
                                        setForm({ ...form, phone: e.target.value });
                                        if (fieldErrors.phone) setFieldErrors((p) => ({ ...p, phone: undefined }));
                                    }}
                                />
                                {fieldErrors.phone && <span style={errText}>{fieldErrors.phone}</span>}
                            </div>
                            <div>
                                <label style={{ fontSize: 13, fontWeight: 500, color: "var(--text-soft)", display: "block", marginBottom: 4 }}>Email</label>
                                <input
                                    style={inpErr("email")}
                                    type="email"
                                    placeholder="Email"
                                    value={form.email}
                                    onChange={(e) => {
                                        setForm({ ...form, email: e.target.value });
                                        if (fieldErrors.email) setFieldErrors((p) => ({ ...p, email: undefined }));
                                    }}
                                />
                                {fieldErrors.email && <span style={errText}>{fieldErrors.email}</span>}
                            </div>
                            <div>
                                <label style={{ fontSize: 13, fontWeight: 500, color: "var(--text-soft)", display: "block", marginBottom: 4 }}>NIC</label>
                                <input
                                    style={inpErr("nic")}
                                    placeholder="NIC number"
                                    value={form.nic}
                                    onChange={(e) => {
                                        setForm({ ...form, nic: e.target.value });
                                        if (fieldErrors.nic) setFieldErrors((p) => ({ ...p, nic: undefined }));
                                    }}
                                />
                                {fieldErrors.nic && <span style={errText}>{fieldErrors.nic}</span>}
                            </div>
                            <div>
                                <label style={{ fontSize: 13, fontWeight: 500, color: "var(--text-soft)", display: "block", marginBottom: 4 }}>Role</label>
                                <select
                                    style={{ ...inputStyle, cursor: "pointer" }}
                                    value={form.role}
                                    onChange={(e) => setForm({ ...form, role: e.target.value })}
                                >
                                    <option value="site_officer">Site Officer</option>
                                    <option value="project_manager">Project Manager</option>
                                    <option value="admin">Admin</option>
                                    <option value="finance_officer">Finance Officer</option>
                                </select>
                            </div>
                        </div>
                        <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
                            <button type="submit" style={btnPrimary}>
                                {editId ? "Update" : "Add Officer"}
                            </button>
                            <button
                                type="button"
                                style={btnGhost}
                                onClick={() => {
                                    setShowForm(false);
                                    setEditId(null);
                                }}
                            >
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            )}

            {/* Search */}
            <div style={{ marginBottom: 16 }}>
                <input
                    style={{ ...inputStyle, maxWidth: 360 }}
                    placeholder="Search officers..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
            </div>

            {/* Stats */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginBottom: 24 }}>
                {Object.entries(roleBadge).map(([key, val]) => {
                    const count = officers.filter((o) => o.role === key).length;
                    const linked = officers.filter((o) => o.role === key && o.user_id).length;
                    return (
                        <div key={key} style={{ ...card, borderLeft: `4px solid ${val.color}`, padding: 16 }}>
                            <div style={{ fontSize: 12, color: "var(--text-soft)", fontWeight: 500 }}>{val.label}</div>
                            <div style={{ fontSize: 28, fontWeight: 700, color: val.color, marginTop: 4 }}>{count}</div>
                            <div style={{ fontSize: 11, color: linked === count && count > 0 ? "#16a34a" : "#f59e0b", marginTop: 4 }}>
                                {linked}/{count} linked
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* Table */}
            <div style={{ ...card, padding: 0, overflow: "hidden" }}>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                        <tr style={{ background: "var(--table-header-bg, #f8fafc)" }}>
                            <th style={thStyle}>Officer</th>
                            <th style={thStyle}>Phone</th>
                            <th style={thStyle}>NIC</th>
                            <th style={thStyle}>Role</th>
                            <th style={thStyle}>Linked Account</th>
                            <th style={{ ...thStyle, textAlign: "right" }}>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filtered.length === 0 ? (
                            <tr>
                                <td colSpan={6} style={{ ...tdStyle, textAlign: "center", color: "var(--text-muted)", padding: 40 }}>
                                    No officers found
                                </td>
                            </tr>
                        ) : (
                            filtered.map((o, i) => {
                                const badge = roleBadge[o.role] || roleBadge.site_officer;
                                const linkedUser = o.user_id ? getLinkedUser(o.user_id) : null;
                                const isLinking = linkingId === o.id;

                                return (
                                    <tr
                                        key={o.id}
                                        style={{
                                            background: i % 2 === 0 ? "var(--bg-surface)" : "var(--bg-body, #fafbfc)",
                                            transition: "background 0.15s",
                                        }}
                                        onMouseEnter={(e) => (e.currentTarget.style.background = "var(--table-row-hover, #f1f5f9)")}
                                        onMouseLeave={(e) => (e.currentTarget.style.background = i % 2 === 0 ? "var(--bg-surface)" : "var(--bg-body, #fafbfc)")}
                                    >
                                        {/* Name & Email */}
                                        <td style={tdStyle}>
                                            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                                                <div
                                                    style={{
                                                        width: 36,
                                                        height: 36,
                                                        borderRadius: 10,
                                                        background: `linear-gradient(135deg, ${badge.color}22, ${badge.color}44)`,
                                                        display: "flex",
                                                        alignItems: "center",
                                                        justifyContent: "center",
                                                        fontWeight: 700,
                                                        fontSize: 14,
                                                        color: badge.color,
                                                    }}
                                                >
                                                    {(o.full_name || "?")[0].toUpperCase()}
                                                </div>
                                                <div>
                                                    <div style={{ fontWeight: 600, color: "var(--text-primary)" }}>{o.full_name}</div>
                                                    {o.email && <div style={{ fontSize: 12, color: "var(--text-muted)" }}>{o.email}</div>}
                                                </div>
                                            </div>
                                        </td>

                                        {/* Phone */}
                                        <td style={{ ...tdStyle, fontFamily: "monospace", fontSize: 13 }}>{o.phone || "—"}</td>

                                        {/* NIC */}
                                        <td style={{ ...tdStyle, fontSize: 13 }}>{o.nic || "—"}</td>

                                        {/* Role */}
                                        <td style={tdStyle}>
                                            <span
                                                style={{
                                                    display: "inline-block",
                                                    padding: "4px 12px",
                                                    borderRadius: 20,
                                                    fontSize: 12,
                                                    fontWeight: 600,
                                                    background: badge.bg,
                                                    color: badge.color,
                                                }}
                                            >
                                                {badge.label}
                                            </span>
                                        </td>

                                        {/* Linked Account */}
                                        <td style={tdStyle}>
                                            {isLinking ? (
                                                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                                    <select
                                                        style={{ ...inputStyle, padding: "6px 10px", fontSize: 13, maxWidth: 200 }}
                                                        defaultValue={o.user_id || ""}
                                                        onChange={(e) => handleLink(o.id, e.target.value)}
                                                    >
                                                        <option value="">— Unlink —</option>
                                                        {users
                                                            .filter((u) => !linkedUserIds.includes(u.id) || u.id === o.user_id)
                                                            .map((u) => (
                                                                <option key={u.id} value={u.id}>
                                                                    {u.email || u.full_name || u.id.slice(0, 8)}
                                                                </option>
                                                            ))}
                                                    </select>
                                                    <button
                                                        style={{ ...btnGhost, padding: "6px 10px", fontSize: 12 }}
                                                        onClick={() => setLinkingId(null)}
                                                    >
                                                        Cancel
                                                    </button>
                                                </div>
                                            ) : linkedUser ? (
                                                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                                    <div
                                                        style={{
                                                            width: 8,
                                                            height: 8,
                                                            borderRadius: "50%",
                                                            background: "#22c55e",
                                                            boxShadow: "0 0 6px #22c55e88",
                                                        }}
                                                    />
                                                    <div>
                                                        <div style={{ fontSize: 13, fontWeight: 500, color: "var(--text-primary)" }}>
                                                            {linkedUser.email || linkedUser.full_name}
                                                        </div>
                                                        <div style={{ fontSize: 11, color: "var(--text-muted)", fontFamily: "monospace" }}>
                                                            {o.user_id?.slice(0, 12)}...
                                                        </div>
                                                    </div>
                                                    <button
                                                        style={{ ...btnGhost, padding: "4px 8px", fontSize: 11, marginLeft: 4 }}
                                                        onClick={() => setLinkingId(o.id)}
                                                    >
                                                        Change
                                                    </button>
                                                </div>
                                            ) : (
                                                <button
                                                    style={{
                                                        background: "var(--glass-blue)",
                                                        color: "var(--primary-light, #3b82f6)",
                                                        border: "1px dashed var(--primary-light, #93c5fd)",
                                                        borderRadius: 8,
                                                        padding: "6px 14px",
                                                        cursor: "pointer",
                                                        fontSize: 13,
                                                        fontWeight: 500,
                                                    }}
                                                    onClick={() => setLinkingId(o.id)}
                                                >
                                                    Link Account
                                                </button>
                                            )}
                                        </td>

                                        {/* Actions */}
                                        <td style={{ ...tdStyle, textAlign: "right" }}>
                                            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
                                                <button style={btnGhost} onClick={() => handleEdit(o)}>
                                                    Edit
                                                </button>
                                                <button style={btnDanger} onClick={() => handleDelete(o.id)}>
                                                    Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
