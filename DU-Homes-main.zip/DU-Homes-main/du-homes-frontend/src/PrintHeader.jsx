/**
 * PrintHeader.jsx — Professional Letterhead for DU Homes & Engineering
 *
 * HOW IT WORKS:
 * - The letterhead div uses className="print-only" → hidden on screen, shown when printing
 * - index.css already handles @media print: shows .print-only, hides .no-print, hides nav/sidebar
 * - This file injects NO global CSS that could break the page — it only works with existing classes
 *
 * Usage:
 *   1. <PrintHeader title="..." subtitle="..." /> at the top of any printable component
 *   2. Add className="no-print" to buttons/controls you want hidden on paper
 *   3. Use <PrintButton /> to trigger window.print()
 */

import React from 'react';

const DU_RED = '#B22222';

/* ══════════════════════════════════════════════════════════════════════════ */
/*  PrintHeader — letterhead shown only when printing                         */
/* ══════════════════════════════════════════════════════════════════════════ */
const PrintHeader = ({ title = 'Report', subtitle = '' }) => {
    const today = new Date();
    const formattedDate = today.toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
    const formattedTime = today.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

    return (
        <>
            {/* ── LETTERHEAD — hidden on screen, shown on paper ── */}
            <div className="print-only" style={{ fontFamily: 'Arial, Helvetica, sans-serif', marginBottom: 0, pageBreakAfter: 'avoid' }}>

                {/* Top red stripe */}
                <div style={{ height: 8, background: DU_RED, width: '100%', marginBottom: 0 }} />

                {/* Company identity row */}
                <div style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '16px 20px 14px',
                    background: '#fff',
                    borderBottom: `3px solid ${DU_RED}`,
                }}>
                    {/* Left: logo + name */}
                    <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                        <img
                            src="/logo.jpg"
                            alt="DU Homes"
                            style={{ width: 64, height: 64, borderRadius: 8, objectFit: 'cover', border: `2px solid ${DU_RED}` }}
                        />
                        <div>
                            <div style={{ fontSize: 26, fontWeight: 900, color: DU_RED, lineHeight: 1, letterSpacing: '-1px', fontFamily: 'Arial Black, Arial, sans-serif' }}>
                                <span style={{ color: '#000' }}>DU</span> HOMES
                            </div>
                            <div style={{ fontSize: 10, fontWeight: 800, color: '#111', letterSpacing: '2px', marginTop: 1 }}>
                                &amp; ENGINEERING
                            </div>
                            <div style={{ fontSize: 7.5, color: '#777', marginTop: 3, fontStyle: 'italic' }}>
                                Construction &amp; Engineering Management System
                            </div>
                        </div>
                    </div>

                    {/* Right: contact info */}
                    <div style={{ textAlign: 'right', fontSize: 8.5, color: '#444', lineHeight: 1.8 }}>
                        <div style={{ fontWeight: 700, color: '#111', marginBottom: 2, fontSize: 9 }}>Contact Information</div>
                        <div>Address: 51, Abilmeegama, Pilimathalawa</div>
                        <div>Phone: 081 238 6577 &nbsp;|&nbsp; Mobile: 071 722 0100 / 071 440 2574</div>
                        <div>Email: duhomes01@gmail.com</div>
                    </div>
                </div>

                {/* Report title band */}
                <div style={{
                    background: DU_RED,
                    padding: '8px 20px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                }}>
                    <div>
                        <div style={{ fontSize: 14, fontWeight: 900, color: '#fff', letterSpacing: '0.3px' }}>{title}</div>
                        {subtitle && <div style={{ fontSize: 8, color: 'rgba(255,255,255,0.85)', marginTop: 2 }}>{subtitle}</div>}
                    </div>
                    <div style={{ textAlign: 'right', color: 'rgba(255,255,255,0.9)', fontSize: 8, lineHeight: 1.7 }}>
                        <div style={{ fontWeight: 700 }}>Printed: {formattedDate}</div>
                        <div>Time: {formattedTime}</div>
                    </div>
                </div>

                {/* Confidentiality strip */}
                <div style={{
                    display: 'flex', justifyContent: 'space-between',
                    padding: '4px 20px',
                    background: '#f5f5f5',
                    borderBottom: '1px solid #ddd',
                    fontSize: 7.5, color: '#666',
                }}>
                    <span>DU Homes &amp; Engineering — Internal Document</span>
                    <span style={{ color: DU_RED, fontWeight: 700 }}>CONFIDENTIAL</span>
                </div>

                {/* Spacing before content */}
                <div style={{ height: 12 }} />
            </div>

            {/* ── FOOTER — fixed at bottom of every printed page ── */}
            <div className="print-footer" style={{
                position: 'fixed',
                bottom: 0, left: 0, right: 0,
                background: DU_RED,
                color: '#fff',
                fontSize: 7.5,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '5px 20px',
                zIndex: 9999,
            }}>
                <span>DU Homes &amp; Engineering | 51, Abilmeegama, Pilimathalawa</span>
                <span style={{ opacity: 0.9 }}>081 238 6577 | duhomes01@gmail.com</span>
            </div>
        </>
    );
};

/* ══════════════════════════════════════════════════════════════════════════ */
/*  PrintButton — triggers window.print(), hidden on paper                   */
/* ══════════════════════════════════════════════════════════════════════════ */
export const PrintButton = ({ label = 'Print / Save PDF', style = {} }) => (
    <button
        className="no-print"
        onClick={() => window.print()}
        style={{
            padding: '8px 18px',
            background: DU_RED,
            color: '#fff',
            border: 'none',
            borderRadius: 8,
            fontWeight: 700,
            fontSize: 13,
            cursor: 'pointer',
            display: 'inline-flex',
            alignItems: 'center',
            gap: 8,
            boxShadow: `0 3px 10px ${DU_RED}44`,
            transition: 'opacity 0.15s',
            ...style,
        }}
        onMouseEnter={(e) => (e.currentTarget.style.opacity = '0.85')}
        onMouseLeave={(e) => (e.currentTarget.style.opacity = '1')}
    >
        <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <polyline points="6 9 6 2 18 2 18 9"></polyline>
            <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
            <rect x="6" y="14" width="12" height="8"></rect>
        </svg>
        {label}
    </button>
);

/* ══════════════════════════════════════════════════════════════════════════ */
/*  NoPrint — hides children on paper (convenience wrapper)                  */
/* ══════════════════════════════════════════════════════════════════════════ */
export const NoPrint = ({ children }) => (
    <div className="no-print">{children}</div>
);

export default PrintHeader;
