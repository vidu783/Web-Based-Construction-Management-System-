// ============================================================================
// FEATURE: App.jsx — Main Application Shell for DU Homes
// FIX: Profile pictures now use user-specific localStorage keys
// ENHANCED: Added OT Management module
// ============================================================================

// All imports must appear at the top of the module
import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { apiFetch } from "./apiFetch";
import Login from "./Login";
import Dashboard from "./Dashboard";
import Sites from "./Sites";
import Workers from "./Workers";
import Officers from "./Officers";
import Assignments from "./Assignments";
import Deployments from "./Deployments";
import Attendance from "./Attendance";
import ToolsAndEquipment from "./ToolsAndEquipment";
import Payments from "./Payments";
import UserManagement from "./UserManagement";
import UserProfile from "./UserProfile";
import OTManagement from "./OTManagement";
import OwnerAudit from "./OwnerAudit";

import AuditLogs from "./AuditLogs";
import NotificationBell from "./components/NotificationBell";


// ── Error Boundary: catches render crashes in any page component ──────────────
import { Component } from "react";
class ErrorBoundary extends Component {
    constructor(props) { super(props); this.state = { hasError: false, error: null }; }
    static getDerivedStateFromError(error) { return { hasError: true, error }; }
    componentDidCatch(error, info) { console.error("[ErrorBoundary] Caught:", error, info); }
    render() {
        if (this.state.hasError) {
            return (
                <div style={{ textAlign: "center", padding: 60, color: "var(--text-soft)" }}>
                    <div style={{ color: "var(--warning)", marginBottom: 16, display: 'flex', justifyContent: 'center' }}>
                        <svg width="48" height="48" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                            <line x1="12" y1="9" x2="12" y2="13"></line>
                            <line x1="12" y1="17" x2="12.01" y2="17"></line>
                        </svg>
                    </div>
                    <h3 style={{ color: "var(--text-primary)", marginBottom: 8 }}>Something went wrong</h3>
                    <p style={{ fontSize: 13, marginBottom: 20 }}>Please refresh or navigate to another page.</p>
                    <button
                        onClick={() => { this.setState({ hasError: false, error: null }); this.props.onReset?.(); }}
                        style={{ padding: "8px 20px", background: "var(--primary-gradient,#c8102e)", color: "#fff", border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 600 }}
                    >Try Again</button>
                </div>
            );
        }
        return this.props.children;
    }
}

/**
 * App.jsx - Main Application Component
 * This file serves as the layout wrapper and routing engine for the DU Homes CMS.
 * It handles:
 * 1. User authentication and session persistence
 * 2. Role-based access control (RBAC)
 * 3. Global theme management (Dark/Light mode)
 * 4. Responsive sidebar and navigation
 */

// API base URL configuration with environment variable support
const API_URL = (import.meta.env.VITE_API_URL || "http://localhost:8080").replace(/\/+$/, "");


/**
 * Role Access Definition
 * Maps each user role to the keys of navigation items they are permitted to access.
 */
const ROLE_ACCESS = {
    admin: ["dashboard", "sites", "workers", "officers", "assignments", "deployments", "attendance", "tools", "payments", "ot", "users", "profile", "audit-logs"],
    project_manager: ["dashboard", "sites", "workers", "officers", "assignments", "deployments", "attendance", "tools", "payments", "ot", "profile"],
    site_officer: ["dashboard", "attendance", "tools", "ot", "payments", "profile"],
    finance_officer: ["dashboard", "payments", "workers", "ot", "profile"],
    company_owner: ["dashboard", "audit", "profile"],
};



const NAV_ITEMS = [
    { key: "dashboard", label: "Dashboard", section: "OVERVIEW" },
    { key: "audit", label: "Audit & Preview", section: "OVERVIEW" },
    { key: "sites", label: "Sites", section: "SITE MANAGEMENT" },
    { key: "workers", label: "Workers", section: "SITE MANAGEMENT" },
    { key: "officers", label: "Officers", section: "SITE MANAGEMENT" },
    { key: "assignments", label: "Assignments", section: "SITE MANAGEMENT" },
    { key: "deployments", label: "Deployments", section: "OPERATIONS" },
    { key: "attendance", label: "Daily Attendance", section: "OPERATIONS" },
    { key: "tools", label: "Tools & Equipment", section: "OPERATIONS" },
    { key: "ot", label: "OT Management", section: "OPERATIONS" },
    { key: "payments", label: "Payments", section: "FINANCE" },
    { key: "users", label: "User Management", section: "ADMINISTRATION" },
    { key: "audit-logs", label: "Audit Logs", section: "ADMINISTRATION" },
    { key: "profile", label: "My Profile", section: "ACCOUNT" },
];


const SIDEBAR_SECTIONS = ["OVERVIEW", "SITE MANAGEMENT", "OPERATIONS", "FINANCE", "ADMINISTRATION", "ACCOUNT"];

const ROLE_COLORS = {
    admin: { bg: "var(--glass-rose)", color: "var(--error, #dc2626)", label: "Administrator" },
    project_manager: { bg: "var(--glass-green)", color: "var(--success, #16a34a)", label: "Project Manager" },
    site_officer: { bg: "var(--glass-blue)", color: "var(--primary-light, #2563eb)", label: "Site Officer" },
    finance_officer: { bg: "var(--glass-purple)", color: "var(--primary-purple, #7c3aed)", label: "Finance Officer" },
    company_owner: { bg: "linear-gradient(135deg, #0f172a, #1e3a8a)", color: "#fbbf24", label: "Company Owner" },
};


const icons = {
    dashboard: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <rect x="3" y="3" width="7" height="7" rx="1.5" />
            <rect x="14" y="3" width="7" height="7" rx="1.5" />
            <rect x="3" y="14" width="7" height="7" rx="1.5" />
            <rect x="14" y="14" width="7" height="7" rx="1.5" />
        </svg>
    ),
    audit: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
            <circle cx="12" cy="12" r="3" />
        </svg>
    ),
    sites: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-6h6v6" />
        </svg>
    ),
    workers: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
            <circle cx="9" cy="7" r="4" />
            <path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75" />
        </svg>
    ),
    officers: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <path d="M12 2l3 7h7l-5.5 4.5 2 7L12 16l-6.5 4.5 2-7L2 9h7z" />
        </svg>
    ),
    assignments: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2" />
            <rect x="9" y="3" width="6" height="4" rx="1" />
            <path d="M9 14l2 2 4-4" />
        </svg>
    ),
    deployments: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <rect x="1" y="3" width="15" height="13" rx="2" />
            <path d="M16 8l5 3-5 3V8zM2 18h20" />
        </svg>
    ),
    attendance: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <path d="M22 11.08V12a10 10 0 11-5.93-9.14" />
            <path d="M22 4L12 14.01l-3-3" />
        </svg>
    ),
    tools: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91A6 6 0 0114.7 6.3z" />
        </svg>
    ),
    ot: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" />
            <path d="M12 6v6l4 2" />
            <path d="M16 1l2 2M8 1L6 3" />
        </svg>
    ),
    payments: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <rect x="1" y="4" width="22" height="16" rx="2" />
            <path d="M1 10h22" />
        </svg>
    ),
    users: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="3" />
            <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" />
        </svg>
    ),
    profile: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2" />
            <circle cx="12" cy="7" r="4" />
        </svg>
    ),
    menu: (
        <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M3 12h18M3 6h18M3 18h18" />
        </svg>
    ),
    close: (
        <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M18 6L6 18M6 6l12 12" />
        </svg>
    ),
    collapse: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M11 17l-5-5 5-5M18 17l-5-5 5-5" />
        </svg>
    ),
    expand: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M13 7l5 5-5 5M6 7l5 5-5 5" />
        </svg>
    ),
    logout: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" />
        </svg>
    ),
    home: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
            <path d="M9 22V12h6v10" />
        </svg>
    ),
    notification: (
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
            <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" />
        </svg>
    ),
};

const NavIcon = ({ name }) => icons[name] || icons.home;

const iconBtn = {
    background: "none", border: "none", cursor: "pointer",
    padding: 6, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center",
};
const btnPrimary = {
    background: "var(--primary-gradient, linear-gradient(135deg, #991b1b, #c8102e))", color: "#fff",
    border: "none", borderRadius: 8, padding: "10px 20px",
    fontSize: 14, fontWeight: 600, cursor: "pointer",
};

const Logo = ({ size = 36, radius = 10, shadow = true, style: extraStyle = {} }) => (
    <img
        src="/logo.jpg"
        alt="DU Homes"
        style={{
            width: size, height: size, borderRadius: radius, objectFit: "cover",
            boxShadow: shadow ? "0 2px 8px rgba(0,0,0,0.2)" : "none",
            ...extraStyle,
        }}
        onError={(e) => {
            e.target.style.display = "none";
            const fallback = document.createElement("div");
            fallback.textContent = "DU";
            Object.assign(fallback.style, {
                width: `${size}px`, height: `${size}px`, borderRadius: `${radius}px`,
                background: "var(--primary-gradient, linear-gradient(135deg,#991b1b,#c8102e))",
                display: "flex", alignItems: "center", justifyContent: "center",
                color: "#fff", fontWeight: "800", fontSize: `${Math.round(size * 0.42)}px`,
            });
            e.target.parentNode.insertBefore(fallback, e.target);
        }}
    />
);

const getUserPicKey = (userData) => {
    const uid = userData?.id || userData?.email || "default";
    return `profile_pic_${uid}`;
};

export default function App() {
    // --- State Hooks ---
    const [user, setUser] = useState(null);               // Current authenticated user object
    const [page, setPage] = useState("dashboard");       // Current active view
    const [sidebarOpen, setSidebarOpen] = useState(true); // Desktop sidebar toggle
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false); // Mobile menu overlay toggle
    const [isMobile, setIsMobile] = useState(window.innerWidth < 768); // Screen size tracking
    const [clock, setClock] = useState(new Date());      // Real-time clock for header
    const [sessionChecked, setSessionChecked] = useState(false); // Prevents flash of login screen
    const [headerHover, setHeaderHover] = useState(null); // Tracks hovered nav item in header
    const [showLogoutConfirm, setShowLogoutConfirm] = useState(false); // Logout modal toggle
    const [unreadBills, setUnreadBills] = useState(0);    // Notification count for finance


    /**
     * DARK MODE LOGIC: Theme Initialization
     * Priority: 1. LocalStorage saved preference, 2. System preference
     */
    const [isDark, setIsDark] = useState(() => {
        const saved = localStorage.getItem("du-homes-theme");
        if (saved) return saved === "dark";
        return window.matchMedia("(prefers-color-scheme: dark)").matches;
    });

    /**
     * DARK MODE LOGIC: Theme Persistance & Injection
     * Updates the data-theme attribute on the root element which CSS variables depend on.
     */
    useEffect(() => {
        const theme = isDark ? "dark" : "light";
        document.documentElement.setAttribute("data-theme", theme);
        document.documentElement.style.colorScheme = theme;
        localStorage.setItem("du-homes-theme", theme);
        // Update meta tag to tell Chrome (Android) which color scheme is active
        const metaCS = document.querySelector('meta[name="color-scheme"]');
        if (metaCS) metaCS.setAttribute("content", theme);
    }, [isDark]);


    // Hydrate user session from localStorage on mount
    useEffect(() => {
        try {
            const storedUser = localStorage.getItem("user");
            const token = localStorage.getItem("token") || localStorage.getItem("access_token");
            if (storedUser && token) {
                const parsed = JSON.parse(storedUser);
                if (parsed && parsed.id) setUser(parsed);
            } else {
                setUser(null);
                localStorage.removeItem("user");
                localStorage.removeItem("token");
                localStorage.removeItem("access_token");
                localStorage.removeItem("refresh_token");
            }
        } catch { /* no-op */ }
        setSessionChecked(true);
    }, []);


    useEffect(() => {
        const t = setInterval(() => setClock(new Date()), 1000);
        return () => clearInterval(t);
    }, []);

    useEffect(() => {
        const onResize = () => {
            const mobile = window.innerWidth < 768;
            setIsMobile(mobile);
            if (mobile) setSidebarOpen(false);
            else setMobileMenuOpen(false);
        };
        window.addEventListener("resize", onResize);
        return () => window.removeEventListener("resize", onResize);
    }, []);

    // Global keyboard shortcuts
    useEffect(() => {
        const onKey = (e) => {
            // Sidebar toggle (Ctrl+B)
            if ((e.ctrlKey || e.metaKey) && e.key === "b") {
                e.preventDefault();
                if (!isMobile) setSidebarOpen((p) => !p);
            }
            // DARK MODE LOGIC: Theme toggle shortcut (Ctrl+Shift+T)
            if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === "t") {
                e.preventDefault();
                setIsDark((d) => !d);
            }
            if (e.key === "Escape") {
                setMobileMenuOpen(false);
                setShowLogoutConfirm(false);
            }
        };
        window.addEventListener("keydown", onKey);
        return () => window.removeEventListener("keydown", onKey);
    }, [isMobile]);


    const currentUser = useMemo(() => {
        try { return user || JSON.parse(localStorage.getItem("user") || "{}"); }
        catch { return {}; }
    }, [user]);

    const userRole = currentUser.role || "";
    const allowedPages = useMemo(() => ROLE_ACCESS[userRole] || [], [userRole]);

    const filteredNav = useMemo(
        () => NAV_ITEMS.filter((n) => allowedPages.includes(n.key)),
        [allowedPages]
    );

    const groupedNav = useMemo(() => {
        const groups = {};
        SIDEBAR_SECTIONS.forEach((s) => { groups[s] = []; });
        filteredNav.forEach((n) => {
            if (groups[n.section]) groups[n.section].push(n);
        });
        return groups;
    }, [filteredNav]);

    const handleLogin = useCallback((userData) => {
        setUser(userData);
        localStorage.setItem("user", JSON.stringify(userData));
        setPage("dashboard");
    }, []);

    const [sessionExpiredMsg, setSessionExpiredMsg] = useState("");

    const handleLogout = useCallback((reason = "") => {
        setUser(null);
        setPage("dashboard");
        setShowLogoutConfirm(false);
        localStorage.removeItem("user");
        localStorage.removeItem("token");
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
        if (reason && typeof reason === "string") setSessionExpiredMsg(reason);
    }, []);

    // Listen for session-expired events fired by apiFetch when token refresh fails
    useEffect(() => {
        const onExpired = () => handleLogout("Your session has expired. Please sign in again.");
        window.addEventListener("session-expired", onExpired);
        return () => window.removeEventListener("session-expired", onExpired);
    }, [handleLogout]);

    const handleUserUpdate = useCallback((updatedUser) => {
        setUser(updatedUser);
        localStorage.setItem("user", JSON.stringify(updatedUser));
    }, []);

    const navigate = useCallback((p) => {
        setPage(p);
        setMobileMenuOpen(false);
    }, []);

    useEffect(() => {
        if (user && allowedPages.length > 0 && !allowedPages.includes(page)) {
            setPage(allowedPages[0] || "dashboard");
        }
    }, [user, page, allowedPages]);

    // Fetch unread tool bills count for notification badge
    useEffect(() => {
        if (!user) return;
        const role = user.role || "";
        if (!["finance_officer", "admin", "project_manager"].includes(role)) return;
        const fetchCount = async () => {
            try {
                const r = await apiFetch(`${API_URL}/tool-bills/unread-count`);
                if (r.ok) { const d = await r.json(); setUnreadBills(d.count || 0); }
            } catch { /* ignore */ }
        };
        fetchCount();
        const iv = setInterval(fetchCount, 60000);
        return () => clearInterval(iv);
    }, [user]);

    /**
     * Component Dispatcher / Router
     * Returns the appropriate component based on the 'page' state.
     */
    const renderPage = () => {
        if (!allowedPages.includes(page)) {
            return (
                <div style={{ textAlign: "center", padding: 80, color: "var(--text-soft)" }}>
                    <div style={{ color: "var(--text-soft)", marginBottom: 16, display: 'flex', justifyContent: 'center' }}>
                        <svg width="48" height="48" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                            <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                            <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                        </svg>
                    </div>
                    <h2 style={{ color: "var(--text-primary)", marginBottom: 8 }}>Access Denied</h2>
                    <p>You don't have permission to view this page.</p>
                    <button onClick={() => setPage("dashboard")} style={{ ...btnPrimary, marginTop: 20 }}>
                        Go to Dashboard
                    </button>
                </div>
            );
        }
        switch (page) {
            case "dashboard": return <Dashboard />;
            case "sites": return <Sites />;
            case "workers": return <Workers />;
            case "officers": return <Officers />;
            case "assignments": return <Assignments />;
            case "deployments": return <Deployments />;
            case "attendance": return <Attendance />;
            case "tools": return <ToolsAndEquipment />;
            case "payments": return <Payments />;
            case "ot": return <OTManagement />;
            case "users": return <UserManagement />;
            case "profile": return <UserProfile user={currentUser} onUserUpdate={handleUserUpdate} />;
            case "audit": return <OwnerAudit />;
            case "audit-logs": return <AuditLogs />;
            default: return <Dashboard />;
        }
    };



    if (!sessionChecked) {
        return (
            <div style={{
                display: "flex", alignItems: "center", justifyContent: "center",
                height: "100vh", background: "var(--bg-body)",
            }}>
                <div style={{ textAlign: "center", color: "var(--text-soft)" }}>
                    <div style={{ margin: "0 auto 16px", animation: "pulse 2s ease-in-out infinite" }}>
                        <Logo size={64} radius={18} />
                    </div>
                    <h2 style={{ fontSize: 20, fontWeight: 700, color: "var(--text-primary)", marginBottom: 4 }}>DU Homes</h2>
                    <p style={{ fontSize: 13, fontWeight: 500, color: "var(--text-soft)" }}>Loading Construction Management System...</p>
                    <div style={{
                        width: 120, height: 3, background: "var(--border-subtle)", borderRadius: 2,
                        margin: "16px auto 0", overflow: "hidden",
                    }}>
                        <div style={{
                            width: "40%", height: "100%",
                            background: "linear-gradient(90deg,#3b82f6,#8b5cf6)",
                            borderRadius: 2, animation: "loadBar 1.5s ease-in-out infinite",
                        }} />
                    </div>
                    <style>{`
                        @keyframes pulse { 0%,100% { transform:scale(1); opacity:1; } 50% { transform:scale(1.06); opacity:0.9; } }
                        @keyframes loadBar { 0% { transform:translateX(-100%); } 100% { transform:translateX(350%); } }
                    `}</style>
                </div>
            </div>
        );
    }

    if (!user) return (
        <Login
            onLogin={(userData) => {
                setSessionExpiredMsg("");
                handleLogin(userData);
            }}
            sessionExpiredMsg={sessionExpiredMsg}
        />
    );

    const roleInfo = ROLE_COLORS[userRole] || { bg: "#f1f5f9", color: "#475569", label: userRole };
    const sideW = sidebarOpen ? 260 : 72;
    const transition = "all 0.3s cubic-bezier(0.4,0,0.2,1)";
    const profilePic = localStorage.getItem(getUserPicKey(currentUser));

    return (
        <div style={{
            minHeight: "100vh",
            background: "var(--bg-body)",
            color: "var(--text-primary)",
            fontFamily: "'Inter','Segoe UI',system-ui,sans-serif",
            transition: "all 0.3s ease"
        }}>
            <style>{`
                @keyframes spin { to { transform: rotate(360deg); } }
                @keyframes fadeIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
                @keyframes slideIn { from { opacity:0; transform:translateX(-20px); } to { opacity:1; transform:translateX(0); } }
                @keyframes pulse { 0%,100% { transform:scale(1); } 50% { transform:scale(1.05); } }
                @keyframes modalIn { from { opacity:0; transform:scale(0.9); } to { opacity:1; transform:scale(1); } }
                ::-webkit-scrollbar { width:6px; }
                ::-webkit-scrollbar-track { background:transparent; }
                ::-webkit-scrollbar-thumb { background:var(--text-soft); border-radius:3px; opacity: 0.3; }
                ::-webkit-scrollbar-thumb:hover { background:var(--text-primary); }
                * { box-sizing:border-box; margin:0; padding:0; }
                body { overflow-x:hidden; background: var(--bg-body); color: var(--text-primary); }
                .avatar-btn:hover { transform: scale(1.08); box-shadow: 0 0 0 3px var(--brand-primary, rgba(59,130,246,0.3)) !important; }
                /* Hide scrollbar on header nav while keeping scroll functionality */
                header nav::-webkit-scrollbar { display: none; }
            `}</style>

            {/* Header */}
            <header style={{
                position: "fixed", top: 0, left: 0, right: 0, height: 52, zIndex: 1000,
                background: "var(--bg-navbar)",
                backdropFilter: "blur(12px)",
                display: "flex", alignItems: "center", justifyContent: "space-between",
                padding: "0 10px", borderBottom: "1px solid var(--navbar-border)",
                boxShadow: "0 4px 12px rgba(0,0,0,0.05)",
                transition: "all 0.3s ease",
            }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, flexShrink: 0 }}>
                    {isMobile && (
                        <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} style={{ ...iconBtn, color: "var(--text-primary)" }}>
                            {mobileMenuOpen ? <NavIcon name="close" /> : <NavIcon name="menu" />}
                        </button>
                    )}
                    <div style={{ display: "flex", alignItems: "center", gap: 6, cursor: "pointer" }}
                        onClick={() => navigate("dashboard")}>
                        <Logo size={28} radius={8} />
                        {!isMobile && (
                            <div>
                                <div style={{ color: "var(--text-primary)", fontWeight: 700, fontSize: 13, lineHeight: 1.2 }}>DU Homes</div>
                                <div style={{ color: "var(--text-soft)", fontSize: 9, letterSpacing: "0.03em" }}>Construction Management</div>
                            </div>
                        )}
                    </div>
                </div>

                {!isMobile && (
                    <nav style={{
                        display: "flex", gap: 1, alignItems: "center",
                        flex: 1, justifyContent: "flex-start",
                        overflow: "hidden",
                        margin: "0 6px",
                    }}>
                        {filteredNav.filter(n => n.key !== "profile").map((n) => {
                            const active = page === n.key;
                            const hovered = headerHover === n.key;
                            return (
                                <button key={n.key} onClick={() => navigate(n.key)}
                                    onMouseEnter={() => setHeaderHover(n.key)}
                                    onMouseLeave={() => setHeaderHover(null)}
                                    style={{
                                        background: active ? "var(--border-medium)" : hovered ? "var(--border-subtle)" : "transparent",
                                        color: active ? "var(--text-primary)" : "var(--text-secondary)",
                                        border: "none", borderRadius: 6, padding: "5px 8px", fontSize: 11,
                                        fontWeight: active ? 700 : 500, cursor: "pointer",
                                        transition: "all 0.2s ease", whiteSpace: "nowrap", position: "relative",
                                        flexShrink: 0,
                                    }}>
                                    {n.label}
                                    {n.key === "payments" && unreadBills > 0 && (
                                        <span style={{
                                            position: "absolute", top: 0, right: 0,
                                            minWidth: 14, height: 14, borderRadius: 7,
                                            background: "#dc2626", color: "#fff",
                                            fontSize: 8, fontWeight: 700,
                                            display: "flex", alignItems: "center", justifyContent: "center",
                                            padding: "0 3px", boxShadow: "0 1px 4px rgba(220,38,38,0.4)",
                                        }}>{unreadBills}</span>
                                    )}
                                    {active && (
                                        <span style={{
                                            position: "absolute", bottom: 1, left: "50%", transform: "translateX(-50%)",
                                            width: 14, height: 2, borderRadius: 1, background: "var(--brand-primary, #3b82f6)",
                                        }} />
                                    )}
                                </button>
                            );
                        })}
                    </nav>
                )}

                {/* DARK MODE LOGIC: Theme Toggle Button */}
                <button
                    onClick={() => setIsDark(!isDark)}
                    style={{
                        background: "none", border: "none", cursor: "pointer",
                        fontSize: 15, lineHeight: 1, padding: "4px 6px", borderRadius: 8,
                        transition: "background 0.2s", flexShrink: 0,
                        color: "var(--text-primary)",
                        display: 'flex', alignItems: 'center'
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.background = "var(--bg-body)")}
                    onMouseLeave={(e) => (e.currentTarget.style.background = "none")}
                >
                    {isDark ? (
                        <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                        </svg>
                    ) : (
                        <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="5"></circle>
                            <line x1="12" y1="1" x2="12" y2="3"></line>
                            <line x1="12" y1="21" x2="12" y2="23"></line>
                            <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                            <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                            <line x1="1" y1="12" x2="3" y2="12"></line>
                            <line x1="21" y1="12" x2="23" y2="12"></line>
                            <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                            <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                        </svg>
                    )}
                </button>
                {["admin", "project_manager", "company_owner"].includes(userRole) && <NotificationBell />}


                <div style={{ display: "flex", alignItems: "center", gap: 6, flexShrink: 0 }}>
                    {!isMobile && (
                        <div style={{ textAlign: "right" }}>
                            <div style={{ color: "var(--text-primary)", fontSize: 11, fontWeight: 600, fontVariantNumeric: "tabular-nums" }}>
                                {clock.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                            </div>
                            <div style={{ color: "var(--text-soft)", fontSize: 9 }}>
                                {clock.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
                            </div>
                        </div>
                    )}

                    <div style={{
                        background: roleInfo.bg, padding: "3px 7px", borderRadius: 5,
                        fontSize: 9, fontWeight: 700, color: roleInfo.color,
                        letterSpacing: "0.02em", border: `1px solid ${roleInfo.color}22`,
                        whiteSpace: "nowrap",
                    }}>{roleInfo.label}</div>

                    <div
                        className="avatar-btn"
                        onClick={() => navigate("profile")}
                        title={`${currentUser.full_name || currentUser.email || "User"} — Click to view profile`}
                        style={{
                            width: 30, height: 30, borderRadius: "50%",
                            background: profilePic ? "transparent" : "var(--primary-gradient, linear-gradient(135deg,#3b82f6,#8b5cf6))",
                            display: "flex", alignItems: "center", justifyContent: "center",
                            color: "#fff", fontWeight: 700, fontSize: 12,
                            cursor: "pointer", border: "2px solid var(--border-subtle)",
                            transition: "all 0.2s ease", overflow: "hidden",
                        }}
                    >
                        {profilePic ? (
                            <img src={profilePic} alt="Profile" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                        ) : (
                            (currentUser.full_name || currentUser.email || "U").charAt(0).toUpperCase()
                        )}
                    </div>
                </div>
            </header>

            {/* Logout Modal */}
            {showLogoutConfirm && (
                <>
                    <div onClick={() => setShowLogoutConfirm(false)}
                        style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.4)", backdropFilter: "blur(4px)", zIndex: 2000 }} />
                    <div style={{
                        position: "fixed", top: "50%", left: "50%", transform: "translate(-50%,-50%)",
                        background: "var(--bg-surface)", borderRadius: 16, padding: 32,
                        boxShadow: "0 20px 60px rgba(0,0,0,0.4)", zIndex: 2001, width: 340, textAlign: "center",
                        border: "1px solid var(--border-subtle)",
                        animation: "modalIn 0.2s ease-out",
                    }}>
                        <div style={{ margin: "0 auto 16px" }}><Logo size={48} radius={14} /></div>
                        <h3 style={{ fontSize: 18, fontWeight: 700, color: "var(--text-primary)", marginBottom: 8 }}>Logout</h3>
                        <p style={{ fontSize: 14, color: "var(--text-soft)", marginBottom: 24 }}>
                            Are you sure you want to sign out of <strong>{currentUser.full_name || "your account"}</strong>?
                        </p>
                        <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
                            <button onClick={() => setShowLogoutConfirm(false)} style={{
                                background: "var(--bg-body)", color: "var(--text-soft)", border: "1px solid var(--border-subtle)",
                                borderRadius: 8, padding: "10px 24px", fontSize: 14, fontWeight: 600, cursor: "pointer",
                            }}>Cancel</button>
                            <button onClick={handleLogout} style={{
                                background: "linear-gradient(135deg,#ef4444,#dc2626)", color: "#fff",
                                border: "none", borderRadius: 8, padding: "10px 24px", fontSize: 14,
                                fontWeight: 600, cursor: "pointer", boxShadow: "0 2px 8px rgba(239,68,68,0.3)",
                            }}>Sign Out</button>
                        </div>
                    </div>
                </>
            )}

            {/* Desktop Sidebar */}
            {!isMobile && (
                <aside style={{
                    position: "fixed", top: 52, left: 0, bottom: 0, width: sideW,
                    background: "var(--bg-sidebar)", borderRight: "1px solid var(--border-subtle)",
                    transition, zIndex: 900, overflowY: "auto", overflowX: "hidden",
                    boxShadow: "2px 0 10px rgba(0,0,0,0.04)", display: "flex", flexDirection: "column",
                }}>
                    <div style={{ display: "flex", justifyContent: sidebarOpen ? "flex-end" : "center", padding: "12px 10px 4px", flexShrink: 0 }}>
                        <button onClick={() => setSidebarOpen(!sidebarOpen)}
                            style={{ ...iconBtn, color: "#64748b" }}
                            title={sidebarOpen ? "Collapse (Ctrl+B)" : "Expand (Ctrl+B)"}>
                            <NavIcon name={sidebarOpen ? "collapse" : "expand"} />
                        </button>
                    </div>

                    <div style={{ flex: 1, overflow: "auto" }}>
                        {SIDEBAR_SECTIONS.map((section) => {
                            const items = groupedNav[section];
                            if (!items || items.length === 0) return null;
                            return (
                                <div key={section} style={{ marginBottom: 4 }}>
                                    {sidebarOpen && (
                                        <div style={{
                                            padding: "14px 20px 6px", fontSize: 10, fontWeight: 700,
                                            color: "var(--text-soft)", letterSpacing: "0.08em", textTransform: "uppercase",
                                        }}>{section}</div>
                                    )}
                                    {items.map((n) => {
                                        const active = page === n.key;
                                        return (
                                            <button key={n.key} onClick={() => navigate(n.key)}
                                                title={!sidebarOpen ? n.label : undefined}
                                                style={{
                                                    display: "flex", alignItems: "center", gap: 12, width: "100%",
                                                    padding: sidebarOpen ? "10px 20px" : "10px 0",
                                                    justifyContent: sidebarOpen ? "flex-start" : "center",
                                                    background: active ? "var(--bg-body)" : "transparent",
                                                    color: active ? "var(--primary, #C8102E)" : "var(--text-soft)",
                                                    border: "none",
                                                    borderLeft: active ? "3px solid var(--primary, #C8102E)" : "3px solid transparent",
                                                    cursor: "pointer", fontSize: 13, fontWeight: active ? 600 : 400,
                                                    transition: "all 0.15s ease", borderRadius: 0,
                                                }}>
                                                <span style={{ flexShrink: 0, display: "flex", opacity: active ? 1 : 0.7 }}>
                                                    <NavIcon name={n.key} />
                                                </span>
                                                {sidebarOpen && <span style={{ whiteSpace: "nowrap" }}>{n.label}</span>}
                                                {n.key === "payments" && unreadBills > 0 && (
                                                    <span style={{
                                                        minWidth: 16, height: 16, borderRadius: 8,
                                                        background: "#dc2626", color: "#fff",
                                                        fontSize: 9, fontWeight: 700,
                                                        display: "flex", alignItems: "center", justifyContent: "center",
                                                        padding: "0 4px", marginLeft: sidebarOpen ? "auto" : 0,
                                                        position: sidebarOpen ? "static" : "absolute",
                                                        top: sidebarOpen ? undefined : 4,
                                                        right: sidebarOpen ? undefined : 4,
                                                    }}>{unreadBills}</span>
                                                )}
                                                {active && sidebarOpen && !(n.key === "payments" && unreadBills > 0) && (
                                                    <span style={{
                                                        marginLeft: "auto", width: 6, height: 6, borderRadius: "50%",
                                                        background: "var(--primary, #C8102E)", flexShrink: 0,
                                                    }} />
                                                )}
                                            </button>
                                        );
                                    })}
                                </div>
                            );
                        })}
                    </div>

                    <div style={{ flexShrink: 0, borderTop: "1px solid var(--border-subtle)" }}>
                        <button onClick={() => setShowLogoutConfirm(true)}
                            style={{
                                display: "flex", alignItems: "center", gap: 12, width: "100%",
                                padding: sidebarOpen ? "10px 20px" : "10px 0",
                                justifyContent: sidebarOpen ? "flex-start" : "center",
                                background: "transparent", color: "#ef4444", border: "none",
                                cursor: "pointer", fontSize: 13, fontWeight: 500, transition,
                            }}>
                            <NavIcon name="logout" />
                            {sidebarOpen && <span>Logout</span>}
                        </button>

                        {sidebarOpen && (
                            <div
                                onClick={() => navigate("profile")}
                                style={{
                                    margin: "4px 12px 12px", padding: "12px",
                                    background: "var(--bg-body)",
                                    borderRadius: 12, border: "1px solid var(--border-subtle)",
                                    cursor: "pointer", transition: "all 0.2s",
                                }}
                            >
                                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                                    {profilePic ? (
                                        <div style={{
                                            width: 32, height: 32, borderRadius: 8, overflow: "hidden", flexShrink: 0,
                                        }}>
                                            <img src={profilePic} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                                        </div>
                                    ) : (
                                        <Logo size={32} radius={8} shadow={false} />
                                    )}
                                    <div style={{ minWidth: 0 }}>
                                        <div style={{
                                            fontSize: 13, fontWeight: 600, color: "var(--text-primary)",
                                            overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                                        }}>
                                            {currentUser.full_name || currentUser.email || "User"}
                                        </div>
                                        <div style={{
                                            fontSize: 11, color: "var(--text-muted)",
                                            overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                                        }}>
                                            {currentUser.email || ""}
                                        </div>
                                    </div>
                                </div>
                                <div style={{
                                    display: "inline-block", padding: "3px 10px", borderRadius: 6,
                                    fontSize: 10, fontWeight: 700, background: roleInfo.bg, color: roleInfo.color,
                                    border: `1px solid ${roleInfo.color}22`,
                                }}>{roleInfo.label}</div>
                            </div>
                        )}
                    </div>
                </aside>
            )}

            {/* Mobile Sidebar */}
            {isMobile && mobileMenuOpen && (
                <>
                    <div onClick={() => setMobileMenuOpen(false)}
                        style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)", backdropFilter: "blur(4px)", zIndex: 950 }} />
                    <aside style={{
                        position: "fixed", top: 60, left: 0, bottom: 0, width: 280,
                        background: "var(--bg-surface)", zIndex: 960, overflowY: "auto",
                        boxShadow: "4px 0 24px rgba(0,0,0,0.4)", animation: "slideIn 0.25s ease-out",
                        borderRight: "1px solid var(--border-subtle)",
                    }}>
                        <div onClick={() => navigate("profile")} style={{
                            padding: "16px 20px", borderBottom: "1px solid var(--border-subtle)",
                            background: "var(--bg-body)", cursor: "pointer",
                        }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                                {profilePic ? (
                                    <div style={{ width: 36, height: 36, borderRadius: 10, overflow: "hidden", flexShrink: 0 }}>
                                        <img src={profilePic} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                                    </div>
                                ) : (
                                    <Logo size={36} radius={10} shadow={false} />
                                )}
                                <div>
                                    <div style={{ fontSize: 14, fontWeight: 600, color: "var(--text-primary)" }}>
                                        {currentUser.full_name || currentUser.email || "User"}
                                    </div>
                                    <div style={{ fontSize: 11, color: "var(--text-soft)", marginTop: 1 }}>{currentUser.email || ""}</div>
                                </div>
                            </div>
                            <div style={{
                                display: "inline-block", marginTop: 8, padding: "3px 10px", borderRadius: 6,
                                fontSize: 10, fontWeight: 700, background: roleInfo.bg, color: roleInfo.color,
                            }}>{roleInfo.label}</div>
                        </div>

                        {SIDEBAR_SECTIONS.map((section) => {
                            const items = groupedNav[section];
                            if (!items || items.length === 0) return null;
                            return (
                                <div key={section}>
                                    <div style={{
                                        padding: "14px 20px 4px", fontSize: 10, fontWeight: 700,
                                        color: "var(--text-soft)", letterSpacing: "0.08em", textTransform: "uppercase",
                                    }}>{section}</div>
                                    {items.map((n) => {
                                        const active = page === n.key;
                                        return (
                                            <button key={n.key} onClick={() => navigate(n.key)}
                                                style={{
                                                    display: "flex", alignItems: "center", gap: 12, width: "100%",
                                                    padding: "12px 20px", background: active ? "var(--bg-body)" : "transparent",
                                                    color: active ? "var(--brand-primary, #3b82f6)" : "var(--text-soft)",
                                                    border: "none", borderLeft: active ? "3px solid var(--brand-primary, #3b82f6)" : "3px solid transparent",
                                                    cursor: "pointer", fontSize: 14, fontWeight: active ? 600 : 400,
                                                }}>
                                                <NavIcon name={n.key} />
                                                <span>{n.label}</span>
                                            </button>
                                        );
                                    })}
                                </div>
                            );
                        })}

                        <div style={{ borderTop: "1px solid var(--border-subtle)", marginTop: 8, padding: "8px 0" }}>
                            {/* DARK MODE LOGIC: Mobile Theme Toggle */}
                            <button onClick={() => setIsDark(!isDark)}
                                style={{
                                    display: "flex", alignItems: "center", gap: 12, width: "100%",
                                    padding: "12px 20px", background: "transparent",
                                    color: "var(--text-primary)",
                                    border: "none", cursor: "pointer", fontSize: 14, fontWeight: 500,
                                    touchAction: "manipulation", WebkitTapHighlightColor: "transparent",
                                }}>
                                {isDark ? (
                                    <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
                                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                                    </svg>
                                ) : (
                                    <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" viewBox="0 0 24 24">
                                        <circle cx="12" cy="12" r="5"></circle>
                                        <line x1="12" y1="1" x2="12" y2="3"></line>
                                        <line x1="12" y1="21" x2="12" y2="23"></line>
                                        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                                        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                                        <line x1="1" y1="12" x2="3" y2="12"></line>
                                        <line x1="21" y1="12" x2="23" y2="12"></line>
                                        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                                        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                                    </svg>
                                )}
                                <span>{isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}</span>
                            </button>
                            <button onClick={() => { setMobileMenuOpen(false); setShowLogoutConfirm(true); }}
                                style={{
                                    display: "flex", alignItems: "center", gap: 12, width: "100%",
                                    padding: "12px 20px", background: "transparent", color: "#ef4444",
                                    border: "none", cursor: "pointer", fontSize: 14, fontWeight: 500,
                                }}>
                                <NavIcon name="logout" />
                                <span>Logout</span>
                            </button>
                        </div>
                    </aside>
                </>
            )}

            {/* Main Content */}
            <main style={{
                marginTop: 52, marginLeft: isMobile ? 0 : sideW, transition,
                minHeight: "calc(100vh - 52px)", padding: isMobile ? "16px" : "24px",
                animation: "fadeIn 0.3s ease-out",
            }}>
                <div className="screen-only" style={{

                    display: "flex", alignItems: "center", justifyContent: "space-between",
                    marginBottom: 20, flexWrap: "wrap", gap: 8,
                }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13 }}>
                        <span style={{ color: "#94a3b8", cursor: "pointer", transition: "color 0.15s" }}
                            onClick={() => navigate("dashboard")}
                            onMouseEnter={(e) => e.target.style.color = "#3b82f6"}
                            onMouseLeave={(e) => e.target.style.color = "#94a3b8"}>
                            Home
                        </span>
                        <span style={{ color: "#cbd5e1" }}>/</span>
                        <span style={{ color: "var(--text-primary)", fontWeight: 600 }}>
                            {NAV_ITEMS.find((n) => n.key === page)?.label || "Dashboard"}
                        </span>
                    </div>
                    {isMobile && (
                        <div style={{ fontSize: 11, color: "#94a3b8", fontVariantNumeric: "tabular-nums" }}>
                            {clock.toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                            {" "}{clock.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
                        </div>
                    )}
                </div>

                <ErrorBoundary key={page} onReset={() => {}}>
                    {renderPage()}
                </ErrorBoundary>
            </main>

            <footer style={{
                marginLeft: isMobile ? 0 : sideW, transition,
                padding: "16px 24px", borderTop: "1px solid var(--border-subtle)",
                background: "var(--bg-surface)", textAlign: "center",
                fontSize: 12, color: "var(--text-soft)",
                display: "flex", justifyContent: "center", alignItems: "center", gap: 8,
            }}>
                <span>DU Homes Construction Management System</span>
                <span style={{ color: "#cbd5e1" }}>|</span>
                <span>&copy; {new Date().getFullYear()}</span>
            </footer>
        </div>
    );
}
