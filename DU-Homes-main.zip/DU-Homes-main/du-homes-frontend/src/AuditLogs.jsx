// ─────────────────────────────────────────────────────────────────────────────
// FILE: AuditLogs.jsx
// PURPOSE: Displays a paginated table of security audit log events (logins,
//          registrations, password changes, etc.) fetched from the backend.
//          Supports filtering by date, action type, and keyword search.
//          Also allows exporting the current logs to a CSV file.
// ─────────────────────────────────────────────────────────────────────────────

// Import React hooks we need:
// - useState: to store values like logs, filters, loading state
// - useEffect: to automatically fetch logs when filters change
// - useCallback: to memoize the fetchLogs function so it doesn't re-create on every render
import { useState, useEffect, useCallback } from "react";

// Read the API base URL from the environment variable (set in .env file)
// Remove any trailing slashes from the URL to avoid double-slash issues in requests
const API = (import.meta.env.VITE_API_URL || "http://localhost:8080").replace(/\/+$/, "");

// Helper function that returns the required HTTP headers for every API request
// - Content-Type: tells the server we're sending JSON
// - Authorization: sends the JWT token so the server knows who we are
const hdr = () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("token") || localStorage.getItem("access_token") || ""}`,
});

// Color/style definitions for each type of audit action badge shown in the table
// Each action gets a distinct background color, text color, and a short label icon
const ACTION_COLORS = {
    LOGIN:           { bg: "rgba(37,99,235,0.1)",   text: "#2563eb", icon: "[LOG]" }, // Blue — user logged in
    LOGOUT:          { bg: "rgba(100,116,139,0.1)", text: "#64748b", icon: "[OUT]" }, // Grey — user logged out
    REGISTER:        { bg: "rgba(22,163,74,0.1)",   text: "#16a34a", icon: "[REG]" }, // Green — new user registered
    CHANGE_PASSWORD: { bg: "rgba(245,158,11,0.1)",  text: "#d97706", icon: "[KEY]" }, // Amber — password changed
    UPDATE_PROFILE:  { bg: "rgba(139,92,246,0.1)",  text: "#7c3aed", icon: "[UPD]" }, // Purple — profile updated
    DELETE:          { bg: "rgba(220,38,38,0.1)",   text: "#dc2626", icon: "[DEL]" }, // Red — something deleted
};

// ─────────────────────────────────────────────────────────────────────────────
// MAIN COMPONENT: AuditLogs
// ─────────────────────────────────────────────────────────────────────────────
export default function AuditLogs() {
    // State: the list of audit log records fetched from the server (current page)
    const [logs, setLogs] = useState([]);

    // State: total number of log entries across ALL pages (used to show "X total events")
    const [total, setTotal] = useState(0);

    // State: total number of pages available (used for pagination buttons)
    const [pages, setPages] = useState(1);

    // State: true while logs are being fetched, shows a spinner in the table
    const [loading, setLoading] = useState(true);

    // State: holds an error message if the API call fails
    const [error, setError] = useState("");

    // ── Filter States ─────────────────────────────────────────────────────────
    // Current page number (starts at 1)
    const [page, setPage] = useState(1);

    // Date range filter — "from" date (inclusive)
    const [fromDate, setFromDate] = useState("");

    // Date range filter — "to" date (inclusive)
    const [toDate, setToDate] = useState("");

    // Action type filter (e.g. "LOGIN", "REGISTER") — empty string means show all
    const [filterAction, setFilterAction] = useState("");

    // Keyword search — filters the currently loaded logs client-side (no API call)
    const [search, setSearch] = useState("");

    // How many log records to load per page
    const limit = 25;

    // ── fetchLogs ─────────────────────────────────────────────────────────────
    // This function calls the backend to get a page of audit logs.
    // It is wrapped in useCallback so it only re-creates when its dependencies change.
    // Dependencies: page, fromDate, toDate, filterAction
    const fetchLogs = useCallback(async () => {
        setLoading(true); // Show the spinner while loading
        try {
            // Build the query string parameters to send with the request
            const params = new URLSearchParams({ page, limit });
            if (fromDate)      params.append("from",   fromDate);     // Add start date filter if set
            if (toDate)        params.append("to",     toDate);       // Add end date filter if set
            if (filterAction)  params.append("action", filterAction); // Add action type filter if set

            // Make the GET request to /audit-logs with the filters as query params
            const r = await fetch(`${API}/audit-logs?${params}`, { headers: hdr() });

            // If the server returned an error status, extract and show the error message
            if (!r.ok) {
                const d = await r.json();
                setError(d.error || "Failed to load audit logs");
                return; // Stop here — don't try to use the bad data
            }

            // Parse the successful JSON response
            const d = await r.json();

            // Store the logs for the current page
            setLogs(d.data || []);

            // Store the total number of logs (across all pages)
            setTotal(d.total || 0);

            // Store the total number of pages
            setPages(d.pages || 1);

            // Clear any previous error message since this request succeeded
            setError("");
        } catch (e) {
            // If the network call itself fails (e.g. server is down), show the error
            setError(e.message);
        } finally {
            // Always hide the spinner when done, whether it succeeded or failed
            setLoading(false);
        }
    }, [page, fromDate, toDate, filterAction]); // Re-run if any of these change

    // Automatically call fetchLogs whenever the fetchLogs function changes
    // (i.e. whenever page, fromDate, toDate, or filterAction changes)
    useEffect(() => { fetchLogs(); }, [fetchLogs]);

    // ── Client-side search filter ─────────────────────────────────────────────
    // If the user typed something in the search box, filter the already-loaded logs.
    // This runs in the browser — no extra API call needed for keyword search.
    const filtered = search.trim()
        ? logs.filter((l) =>
            (l.user_email  || "").toLowerCase().includes(search.toLowerCase()) || // Match by email
            (l.action      || "").toLowerCase().includes(search.toLowerCase()) || // Match by action type
            (l.ip_address  || "").includes(search)                                // Match by IP address
        )
        : logs; // If no search term, show all loaded logs

    // ── exportCSV ─────────────────────────────────────────────────────────────
    // Creates a downloadable CSV file from the currently loaded logs.
    // The user clicks "Export CSV" and their browser automatically downloads it.
    const exportCSV = () => {
        // Define the column headers for the CSV file
        const header = "Timestamp,User Email,Action,Resource,IP Address,Detail";

        // Map each log entry to a CSV row
        const rows = logs.map((l) => [
            new Date(l.created_at).toLocaleString(), // Convert timestamp to human-readable
            l.user_email  || "",
            l.action      || "",
            l.resource    || "",
            l.ip_address  || "",
            JSON.stringify(l.detail || {}),          // Serialize the detail object as JSON string
        ].map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")); // Wrap each field in quotes, escape internal quotes

        // Join header and all rows into one big CSV string
        const csv = [header, ...rows].join("\n");

        // Create a Blob (a file-like object) from the CSV string
        const blob = new Blob([csv], { type: "text/csv" });

        // Create a temporary URL pointing to the Blob so the browser can download it
        const url = URL.createObjectURL(blob);

        // Create an invisible <a> link element to trigger the download
        const a = document.createElement("a");
        a.href = url;

        // Set the filename to include today's date (e.g. "audit-logs-2026-04-28.csv")
        a.download = `audit-logs-${new Date().toISOString().slice(0, 10)}.csv`;

        // Programmatically click the link to start the download
        a.click();

        // Clean up the temporary URL from memory
        URL.revokeObjectURL(url);
    };

    // ── Inline Style Objects ──────────────────────────────────────────────────
    // These are reusable CSS style objects used throughout the JSX below.
    // They reference CSS variables defined in index.css for dark/light mode support.

    // Style for card/panel containers (background, border, shadow)
    const card = {
        background: "var(--bg-surface)", borderRadius: 14,
        border: "1px solid var(--border-subtle)", boxShadow: "var(--shadow-sm)",
    };

    // Style for table header cells (<th>)
    const th = {
        padding: "10px 14px", textAlign: "left", fontSize: 11, fontWeight: 700,
        color: "var(--text-soft)", textTransform: "uppercase", letterSpacing: 0.5,
        borderBottom: "2px solid var(--border-subtle)", background: "var(--table-header-bg)",
        whiteSpace: "nowrap",
    };

    // Style for table data cells (<td>)
    const td = {
        padding: "10px 14px", fontSize: 13, borderBottom: "1px solid var(--border-subtle)",
        color: "var(--text-primary)", verticalAlign: "middle",
    };

    // Style for input fields and select dropdowns
    const inp = {
        padding: "8px 12px", borderRadius: 8, border: "1px solid var(--input-border)",
        background: "var(--input-bg)", color: "var(--text-primary)", fontSize: 13, outline: "none",
    };

    // Style for the primary action buttons (red gradient, white text)
    const btnPrimary = {
        background: "linear-gradient(135deg, #C8102E, #e8334a)", color: "#fff", border: "none",
        padding: "8px 20px", borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: "pointer",
    };

    // ─────────────────────────────────────────────────────────────────────────
    // RENDER — the actual UI
    // ─────────────────────────────────────────────────────────────────────────
    return (
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>

            {/* ── Page Header ── */}
            {/* Shows the page title, total event count, Refresh and Export CSV buttons */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20, flexWrap: "wrap", gap: 12 }}>
                <div>
                    <h2 style={{ fontSize: 22, fontWeight: 800, margin: 0, color: "var(--text-primary)" }}>Security Audit Logs</h2>
                    <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--text-soft)" }}>
                        System access and action history — {total.toLocaleString()} total events
                    </p>
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                    {/* Refresh button — re-fetches the logs from the server */}
                    <button style={{ ...btnPrimary, background: "var(--bg-body)", color: "var(--text-primary)", border: "1px solid var(--border-subtle)" }} onClick={fetchLogs}>
                        Refresh
                    </button>
                    {/* Export CSV button — triggers the exportCSV function */}
                    <button style={btnPrimary} onClick={exportCSV}>Export CSV</button>
                </div>
            </div>

            {/* ── Filter Bar ── */}
            {/* Contains search input, action type dropdown, date range pickers, and a Clear button */}
            <div style={{ ...card, padding: "14px 16px", marginBottom: 16, display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>

                {/* Keyword search — filters loaded logs client-side by email, action, or IP */}
                <input
                    style={{ ...inp, flex: "1 1 200px" }}
                    placeholder="Search email, action, IP…"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />

                {/* Action type dropdown — filters by specific action (LOGIN, REGISTER, etc.) */}
                {/* Resets to page 1 when changed so we don't land on a non-existent page */}
                <select style={{ ...inp, cursor: "pointer" }} value={filterAction} onChange={(e) => { setFilterAction(e.target.value); setPage(1); }}>
                    <option value="">All Actions</option>
                    <option value="LOGIN">LOGIN</option>
                    <option value="REGISTER">REGISTER</option>
                    <option value="LOGOUT">LOGOUT</option>
                    <option value="CHANGE_PASSWORD">CHANGE_PASSWORD</option>
                    <option value="UPDATE_PROFILE">UPDATE_PROFILE</option>
                </select>

                {/* From date picker — sets the start of the date range filter */}
                <input type="date" style={inp} value={fromDate} onChange={(e) => { setFromDate(e.target.value); setPage(1); }} title="From date" />

                {/* To date picker — sets the end of the date range filter */}
                <input type="date" style={inp} value={toDate}   onChange={(e) => { setToDate(e.target.value);   setPage(1); }} title="To date" />

                {/* Clear button — only shown when at least one filter is active */}
                {(fromDate || toDate || filterAction) && (
                    <button
                        onClick={() => { setFromDate(""); setToDate(""); setFilterAction(""); setPage(1); }}
                        style={{ ...inp, cursor: "pointer", color: "var(--error)", fontWeight: 600 }}
                    >
                        Clear
                    </button>
                )}
            </div>

            {/* ── Error Message ── */}
            {/* Only shown if the API call returned an error */}
            {error && (
                <div style={{ padding: "10px 16px", marginBottom: 14, borderRadius: 10, fontSize: 13, background: "var(--glass-rose)", color: "#dc2626", border: "1px solid #dc262633" }}>
                    {error}
                </div>
            )}

            {/* ── Logs Table ── */}
            <div style={{ ...card, overflow: "hidden" }}>
                <div style={{ overflowX: "auto" }}> {/* Allows horizontal scroll on small screens */}
                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                        <thead>
                            <tr>
                                {/* Column headers */}
                                <th style={{ ...th, width: 170 }}>Timestamp</th>
                                <th style={th}>User</th>
                                <th style={th}>Action</th>
                                <th style={th}>Resource</th>
                                <th style={th}>IP Address</th>
                                <th style={th}>Detail</th>
                            </tr>
                        </thead>
                        <tbody>
                            {loading ? (
                                // ── Loading State ──
                                // Shows a spinning circle while data is being fetched
                                <tr>
                                    <td colSpan={6} style={{ ...td, textAlign: "center", padding: 40, color: "var(--text-soft)" }}>
                                        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: 10 }}>
                                            {/* CSS spinner animation */}
                                            <div style={{ width: 20, height: 20, border: "3px solid var(--border-subtle)", borderTopColor: "var(--brand-primary,#2563eb)", borderRadius: "50%", animation: "spin 0.8s linear infinite" }} />
                                            Loading audit logs…
                                        </div>
                                        {/* Define the spin keyframe animation inline */}
                                        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
                                    </td>
                                </tr>
                            ) : filtered.length === 0 ? (
                                // ── Empty State ──
                                // Shown when no logs match the current filters
                                <tr>
                                    <td colSpan={6} style={{ ...td, textAlign: "center", padding: 40, color: "var(--text-soft)" }}>
                                        No log entries found for the selected filters.
                                    </td>
                                </tr>
                            ) : (
                                // ── Data Rows ──
                                // Render one row per audit log entry
                                filtered.map((log, i) => {
                                    // Get the colour scheme for this action type (defaults to grey if unknown)
                                    const ac = ACTION_COLORS[log.action] || { bg: "rgba(100,116,139,0.1)", text: "#64748b", icon: "[LOG]" };
                                    return (
                                        // Alternating row background for readability (zebra stripes)
                                        <tr key={log.id} style={{ background: i % 2 === 0 ? "transparent" : "var(--bg-body)" }}>

                                            {/* Timestamp cell — formatted as "Apr 28, 05:33:00" */}
                                            <td style={{ ...td, fontSize: 12, whiteSpace: "nowrap", color: "var(--text-soft)" }}>
                                                {new Date(log.created_at).toLocaleString("en-US", { month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                                            </td>

                                            {/* User cell — shows email and a short version of the user ID */}
                                            <td style={td}>
                                                <div style={{ fontWeight: 600, fontSize: 13 }}>
                                                    {/* Show email or "Unknown" if missing */}
                                                    {log.user_email || <span style={{ color: "var(--text-soft)", fontStyle: "italic" }}>Unknown</span>}
                                                </div>
                                                {/* Show first 8 characters of the user UUID below the email */}
                                                {log.user_id && <div style={{ fontSize: 10, color: "var(--text-soft)", fontFamily: "monospace" }}>{log.user_id.slice(0, 8)}…</div>}
                                            </td>

                                            {/* Action cell — a coloured badge showing the action type */}
                                            <td style={td}>
                                                <span style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "3px 10px", borderRadius: 99, fontSize: 11, fontWeight: 700, background: ac.bg, color: ac.text }}>
                                                    {ac.icon} {log.action} {/* e.g. "[LOG] LOGIN" */}
                                                </span>
                                            </td>

                                            {/* Resource cell — what was accessed (e.g. "auth", "workers") */}
                                            <td style={{ ...td, fontSize: 12, color: "var(--text-soft)" }}>{log.resource || "—"}</td>

                                            {/* IP Address cell — the client's IP address at time of action */}
                                            <td style={{ ...td, fontSize: 12, fontFamily: "monospace" }}>{log.ip_address || "—"}</td>

                                            {/* Detail cell — extra data stored about the action (shown as JSON code) */}
                                            <td style={{ ...td, fontSize: 11, color: "var(--text-soft)", maxWidth: 200 }}>
                                                {log.detail ? (
                                                    <code style={{ background: "var(--bg-body)", padding: "2px 6px", borderRadius: 4, fontSize: 11, wordBreak: "break-all" }}>
                                                        {/* If detail is an object, convert it to a JSON string for display */}
                                                        {typeof log.detail === "object" ? JSON.stringify(log.detail) : log.detail}
                                                    </code>
                                                ) : "—"}
                                            </td>
                                        </tr>
                                    );
                                })
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            {/* ── Pagination ── */}
            {/* Only shown when there is more than one page of results */}
            {pages > 1 && (
                <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: 8, marginTop: 16 }}>
                    {/* Previous page button — disabled when already on page 1 */}
                    <button
                        onClick={() => setPage((p) => Math.max(1, p - 1))}   // Go to previous page, but never below 1
                        disabled={page === 1}
                        style={{ ...inp, cursor: page === 1 ? "not-allowed" : "pointer", opacity: page === 1 ? 0.5 : 1, padding: "6px 14px" }}
                    >← Prev</button>

                    {/* Page counter — shows current page, total pages, and total entries */}
                    <span style={{ fontSize: 13, color: "var(--text-soft)", fontWeight: 500 }}>
                        Page {page} of {pages} ({total.toLocaleString()} entries)
                    </span>

                    {/* Next page button — disabled when already on the last page */}
                    <button
                        onClick={() => setPage((p) => Math.min(pages, p + 1))} // Go to next page, but never beyond last
                        disabled={page === pages}
                        style={{ ...inp, cursor: page === pages ? "not-allowed" : "pointer", opacity: page === pages ? 0.5 : 1, padding: "6px 14px" }}
                    >Next →</button>
                </div>
            )}
        </div>
    );
}
