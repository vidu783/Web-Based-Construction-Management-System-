import { useState, useEffect, useCallback, useMemo } from "react";

/* ─── Helpers ──────────────────────────────────────────────────────────────── */
const API = (import.meta.env.VITE_API_URL || "http://localhost:8080").replace(/\/+$/, "");
const hdr = () => {
    const t = localStorage.getItem("token") || localStorage.getItem("access_token") || "";
    return { "Content-Type": "application/json", ...(t ? { Authorization: `Bearer ${t}` } : {}) };
};
const currency = (v) =>
    `Rs ${Number(v || 0).toLocaleString("en-LK", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

/* ═══════════════════════════════════════════════════════════════════════════ */
export default function OTManagement() {
    /* ── current user & role ─────────────────────────────────────────────────── */
    const user = useMemo(() => {
        try {
            return JSON.parse(localStorage.getItem("user") || "{}");
        } catch {
            return {};
        }
    }, []);
    const role = user.role || "";

    // Guard: if no role (logged out mid-render), render nothing safely
    if (!role) return null;
    const isFinance = role === "finance_officer";
    const canSubmit = ["admin", "site_officer", "project_manager"].includes(role);
    // finance_officer can now approve/reject OT (Feature 2 enforcement)
    const canReview = ["admin", "project_manager", "finance_officer"].includes(role);


    /* ── state ───────────────────────────────────────────────────────────────── */
    const [tab, setTab] = useState(canSubmit ? "submit" : "review");
    const [requests, setRequests] = useState([]);
    const [workers, setWorkers] = useState([]);
    const [sites, setSites] = useState([]);
    const [deployments, setDeployments] = useState([]);
    const [attendance, setAttendance] = useState([]);
    const [officers, setOfficers] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [profiles, setProfiles] = useState([]);
    const [deletedEntities, setDeletedEntities] = useState([]);
    const [loading, setLoading] = useState(false);
    const [msg, setMsg] = useState({ text: "", type: "" });
    const [selected, setSelected] = useState(new Set());

    // filters
    const [filterStatus, setFilterStatus] = useState("all");
    const [filterSite, setFilterSite] = useState("all");
    const [filterMonth, setFilterMonth] = useState(new Date().toISOString().slice(0, 7));

    // submit
    const [submitDate, setSubmitDate] = useState(new Date().toISOString().slice(0, 10));
    const [otEntries, setOtEntries] = useState({});
    const [reviewNote, setReviewNote] = useState("");

    /* ── flash message ───────────────────────────────────────────────────────── */
    const flash = useCallback((text, type = "success") => {
        setMsg({ text, type });
        setTimeout(() => setMsg({ text: "", type: "" }), 4000);
    }, []);

    /* ── data fetchers ───────────────────────────────────────────────────────── */
    const fetchRequests = useCallback(async () => {
        try {
            const params = new URLSearchParams();
            if (filterMonth) params.append("month", filterMonth);
            const r = await fetch(`${API}/ot-requests?${params}`, { headers: hdr() });
            if (r.ok) {
                const d = await r.json();
                setRequests(Array.isArray(d) ? d : []);
            }
        } catch (e) {
            console.error("Fetch OT requests error:", e);
        }
    }, [filterMonth]);

    const fetchWorkers = useCallback(async () => {
        try {
            const r = await fetch(`${API}/workers?archived=true`, { headers: hdr() });
            if (r.ok) {
                const d = await r.json();
                const arr = Array.isArray(d) ? d : d.data || [];
                setWorkers(arr);
            }
        } catch (e) {
            console.error("Fetch workers error:", e);
        }
    }, []);

    const fetchSites = useCallback(async () => {
        try {
            const r = await fetch(`${API}/fields?archived=true`, { headers: hdr() });
            if (r.ok) {
                const d = await r.json();
                const arr = Array.isArray(d) ? d : d.data || [];
                setSites(arr);
            }
        } catch (e) {
            console.error("Fetch sites error:", e);
        }
    }, []);

    const fetchDeployments = useCallback(async () => {
        try {
            const r = await fetch(`${API}/deployments?date=${submitDate}`, { headers: hdr() });
            if (r.ok) {
                const d = await r.json();
                const arr = Array.isArray(d) ? d : d.data || [];
                console.log("Deployments fetched:", arr.length, arr);
                setDeployments(arr);
            }
        } catch (e) {
            console.error("Fetch deployments error:", e);
        }
    }, [submitDate]);

    const fetchAttendance = useCallback(async () => {
        try {
            const r = await fetch(`${API}/attendance?date=${submitDate}`, { headers: hdr() });
            if (r.ok) {
                const d = await r.json();
                const arr = Array.isArray(d) ? d : d.data || [];
                console.log("Attendance fetched:", arr.length);
                setAttendance(arr);
            }
        } catch (e) {
            console.error("Fetch attendance error:", e);
        }
    }, [submitDate]);

    const fetchOfficers = useCallback(async () => {
        try {
            const r = await fetch(`${API}/officers`, { headers: hdr() });
            if (r.ok) setOfficers(await r.json());
        } catch { /* silent */ }
    }, []);

    const fetchAssignments = useCallback(async () => {
        try {
            const r = await fetch(`${API}/assignments`, { headers: hdr() });
            if (r.ok) {
                const d = await r.json();
                setAssignments(Array.isArray(d) ? d : d.data || []);
            }
        } catch { /* silent */ }
    }, []);

    const fetchProfiles = useCallback(async () => {
        try {
            const r = await fetch(`${API}/auth/users`, { headers: hdr() });
            if (r.ok) setProfiles(await r.json());
        } catch { /* silent */ }
    }, []);

    const loadAll = useCallback(async () => {
        setLoading(true);
        await Promise.all([
            fetchRequests(), fetchWorkers(), fetchSites(),
            fetchDeployments(), fetchAttendance(), fetchOfficers(), fetchAssignments(), fetchProfiles(),
        ]);
        fetch(`${API}/deleted-entities?type=worker,site`, { headers: hdr() })
            .then(r => r.json()).then(d => setDeletedEntities(Array.isArray(d) ? d : [])).catch(() => {});
        setLoading(false);
    }, [fetchRequests, fetchWorkers, fetchSites, fetchDeployments, fetchAttendance, fetchOfficers, fetchAssignments, fetchProfiles]);

    useEffect(() => { loadAll(); }, [loadAll]);
    useEffect(() => { 
        fetchDeployments(); 
        fetchAttendance(); 
        
        // AUTO-FILL: set initial otEntries from existing requests for the date
        const initial = {};
        requests.forEach(r => {
            if (r.date === submitDate) {
                initial[`${String(r.worker_id)}:::${String(r.site_id)}`] = r.ot_hours;
            }
        });
        setOtEntries(initial);
    }, [submitDate, fetchDeployments, fetchAttendance, requests]);
    useEffect(() => { fetchRequests(); }, [filterMonth, fetchRequests]);

    /* ── role-based site access ──────────────────────────────────────────────── */
    const allowedSiteIds = useMemo(() => {
        if (["admin", "finance_officer", "project_manager"].includes(role)) return null;

        let matchedOfficer = officers.find((o) => o.user_id === user.id);
        if (!matchedOfficer) {
            matchedOfficer = officers.find((o) => {
                const nameMatch = o.full_name && user.full_name && o.full_name.toLowerCase().trim() === user.full_name.toLowerCase().trim();
                const phoneMatch = o.phone && user.phone && o.phone.replace(/\s/g, "") === user.phone?.replace(/\s/g, "");
                return nameMatch || phoneMatch;
            });
        }

        if (!matchedOfficer) return [];

        const ids = assignments
            .filter((a) => a.officer_id === matchedOfficer.id)
            .filter((a) => !a.to_date || a.to_date >= submitDate)
            .map((a) => a.site_id);

        return [...new Set(ids)];
    }, [role, user.id, user.full_name, user.phone, officers, assignments, submitDate]);

    /* ── maps & helpers ──────────────────────────────────────────────────────── */
    const workerMap = useMemo(() => {
        const m = {};
        workers.forEach((w) => (m[w.id] = w));
        return m;
    }, [workers]);

    const siteMap = useMemo(() => {
        const m = {};
        sites.forEach((s) => (m[s.id] = s));
        return m;
    }, [sites]);

    const deletedMap = useMemo(() => Object.fromEntries(deletedEntities.map(e => [e.entity_id, e])), [deletedEntities]);
    const workerNode = (id) => { const w = workers.find(x => x.id === id); if (!w) { const snap = deletedMap[id]; return (<>{snap?.entity_name || "Deleted Worker"} <span className="archived-badge">deleted</span></>); } return (<>{w?.full_name || w?.name}{w?.is_archived && <span className="archived-badge">deleted</span>}</>); };
    const siteNode = (id) => { const s = sites.find(x => x.id === id); if (!s) { const snap = deletedMap[id]; return (<>{snap?.entity_name || "Deleted Site"} <span className="archived-badge">deleted</span></>); } return (<>{s?.name}{s?.is_archived && <span className="archived-badge">deleted</span>}</>); };
    const getWorkerName = (id) => {
        const w = workerMap[id];
        if (!w) return "Unknown";
        return w.full_name || w.name || "Unknown";
    };
    const getSiteName = (id) => siteMap[id]?.name || "Unknown Site";

    const ROLE_LABELS = { admin: "Admin", project_manager: "Project Manager", site_officer: "Site Officer", finance_officer: "Finance Officer" };
    const getReviewerLabel = (reviewedById) => {
        if (!reviewedById) return "";
        const p = profiles.find((u) => u.id === reviewedById);
        if (!p) return "";
        const roleName = ROLE_LABELS[p.role] || p.role || "User";
        const name = p.full_name || p.email || "Unknown";
        return `by ${roleName} - ${name}`;
    };

    const isPresent = (workerId) => {
        return attendance.some(
            (a) =>
                a.worker_id === workerId &&
                a.date === submitDate &&
                (a.status === "present" || a.status === "Present")
        );
    };

    /* ══════════════════════════════════════════════════════════════════════════ */
    /* ── SITE GROUPS — handles nested deployment_workers structure ──────────── */
    /* ══════════════════════════════════════════════════════════════════════════ */
    const siteGroups = useMemo(() => {
        const groups = {};

        deployments.forEach((dep) => {
            const sId = dep.site_id || dep.field_id;
            if (!sId) return;
            if (allowedSiteIds && !allowedSiteIds.includes(sId)) return;

            if (!groups[sId]) groups[sId] = { siteName: dep.sites?.name || getSiteName(sId), notes: dep.notes || "", workers: [] };

            // ─── KEY FIX: extract workers from nested deployment_workers array ───
            const dw = dep.deployment_workers || dep.workers || [];
            if (Array.isArray(dw) && dw.length > 0) {
                dw.forEach((entry) => {
                    // entry could be { worker_id: "..." } or { worker_id: "...", workers: { ... } }
                    const wId = entry.worker_id || entry.id;
                    if (wId && !groups[sId].workers.includes(wId)) {
                        groups[sId].workers.push(wId);
                    }
                });
            }

            // ─── Fallback: if deployment itself has a single worker_id (flat structure) ───
            if (dw.length === 0 && dep.worker_id) {
                if (!groups[sId].workers.includes(dep.worker_id)) {
                    groups[sId].workers.push(dep.worker_id);
                }
            }
        });

        console.log("Site groups built:", Object.entries(groups).map(([sid, g]) => `${g.siteName}: ${g.workers.length} workers`));
        return groups;
    }, [deployments, allowedSiteIds]);

    /* ── OT entry helpers ────────────────────────────────────────────────────── */
    const getOtEntry = (workerId, siteId) => {
        const k = `${String(workerId)}:::${String(siteId)}`;
        return otEntries[k] !== undefined ? otEntries[k] : "";
    };

    const setOtEntry = (workerId, siteId, val) => {
        const k = `${String(workerId)}:::${String(siteId)}`;
        setOtEntries((prev) => ({ ...prev, [k]: val }));
    };

    /* ── existing request lookup ─────────────────────────────────────────────── */
    const getExistingRequest = (workerId, siteId) =>
        requests.find((r) => r.worker_id === workerId && r.site_id === siteId && r.date === submitDate);

    /* ── submit ──────────────────────────────────────────────────────────────── */
    const handleSubmitOT = async () => {
        const payload = [];
        Object.entries(otEntries).forEach(([key, hrs]) => {
            const h = Number(hrs);
            if (!h || h <= 0) return;
            const parts = key.split(":::");
            const workerId = parts[0];
            const siteId = parts[1];
            payload.push({
                worker_id: workerId,
                site_id: siteId,
                date: submitDate,
                ot_hours: h,
                reason: "",
                requested_by: user.id || null,
            });
        });

        if (payload.length === 0) {
            flash("Enter OT hours for at least one worker", "error");
            return;
        }

        try {
            const r = await fetch(`${API}/ot-requests/bulk`, {
                method: "POST",
                headers: hdr(),
                body: JSON.stringify({ requests: payload }),
            });
            const d = await r.json();
            if (r.ok) {
                flash(`OT submitted: ${d.created || 0} created, ${d.updated || 0} updated, ${d.skipped || 0} skipped`);
                setOtEntries({});
                fetchRequests();
            } else {
                flash(d.error || "Submit failed", "error");
            }
        } catch (e) {
            flash(`Submit error: ${e.message}`, "error");
        }
    };

    /* ── review actions (all PUT to avoid CORS) ──────────────────────────────── */
    const handleApprove = async (id) => {
        try {
            const r = await fetch(`${API}/ot-requests/${id}/approve`, {
                method: "PUT",
                headers: hdr(),
                body: JSON.stringify({ reviewed_by: user.id, review_note: reviewNote || null }),
            });
            if (r.ok) { flash("Approved"); fetchRequests(); }
            else { const d = await r.json(); flash(d.error || "Approve failed", "error"); }
        } catch (e) { flash(`Error: ${e.message}`, "error"); }
    };

    const handleReject = async (id) => {
        try {
            const r = await fetch(`${API}/ot-requests/${id}/reject`, {
                method: "PUT",
                headers: hdr(),
                body: JSON.stringify({ reviewed_by: user.id, review_note: reviewNote || null }),
            });
            if (r.ok) { flash("Rejected"); fetchRequests(); }
            else { const d = await r.json(); flash(d.error || "Reject failed", "error"); }
        } catch (e) { flash(`Error: ${e.message}`, "error"); }
    };

    const handleBulkApprove = async () => {
        if (selected.size === 0) return flash("Select requests first", "error");
        try {
            const r = await fetch(`${API}/ot-requests/bulk-approve`, {
                method: "POST",
                headers: hdr(),
                body: JSON.stringify({ ids: [...selected], reviewed_by: user.id, review_note: reviewNote || null }),
            });
            if (r.ok) { flash(`Approved ${selected.size} requests`); setSelected(new Set()); fetchRequests(); }
            else { const d = await r.json(); flash(d.error || "Bulk approve failed", "error"); }
        } catch (e) { flash(`Error: ${e.message}`, "error"); }
    };

    const handleBulkReject = async () => {
        if (selected.size === 0) return flash("Select requests first", "error");
        try {
            const r = await fetch(`${API}/ot-requests/bulk-reject`, {
                method: "POST",
                headers: hdr(),
                body: JSON.stringify({ ids: [...selected], reviewed_by: user.id, review_note: reviewNote || null }),
            });
            if (r.ok) { flash(`Rejected ${selected.size} requests`); setSelected(new Set()); fetchRequests(); }
            else { const d = await r.json(); flash(d.error || "Bulk reject failed", "error"); }
        } catch (e) { flash(`Error: ${e.message}`, "error"); }
    };

    const handleDelete = async (id) => {
        if (!confirm("Delete this OT request?")) return;
        try {
            const r = await fetch(`${API}/ot-requests/${id}`, { method: "DELETE", headers: hdr() });
            if (r.ok) { flash("Deleted"); fetchRequests(); }
            else { flash("Delete failed", "error"); }
        } catch (e) { flash(`Error: ${e.message}`, "error"); }
    };

    const toggleSelect = (id) => {
        setSelected((prev) => {
            const n = new Set(prev);
            n.has(id) ? n.delete(id) : n.add(id);
            return n;
        });
    };

    const toggleSelectAll = (ids) => {
        setSelected((prev) => {
            const allSelected = ids.every((id) => prev.has(id));
            const n = new Set(prev);
            ids.forEach((id) => (allSelected ? n.delete(id) : n.add(id)));
            return n;
        });
    };

    /* ── filtered requests ───────────────────────────────────────────────────── */
    const filtered = useMemo(() => {
        let list = [...requests];
        if (filterStatus !== "all") list = list.filter((r) => r.status === filterStatus);
        if (filterSite !== "all") list = list.filter((r) => r.site_id === filterSite);
        if (allowedSiteIds) list = list.filter((r) => allowedSiteIds.includes(r.site_id));
        return list;
    }, [requests, filterStatus, filterSite, allowedSiteIds]);

    /* ── stats ───────────────────────────────────────────────────────────────── */
    const stats = useMemo(() => {
        const s = { active: 0, totalHrs: 0, totalCost: 0 };
        requests.forEach((r) => {
            if (r.status !== "rejected") {
                s.active++;
                const h = Number(r.ot_hours || 0);
                s.totalHrs += h;
                const w = workerMap[r.worker_id];
                const hourly = w ? Number(w.daily_rate || 0) / 8 : 0;
                s.totalCost += hourly * 1.5 * h;
            }
        });
        return s;
    }, [requests, workerMap]);

    /* ── styles ──────────────────────────────────────────────────────────────── */
    const card = { background: "var(--bg-surface)", borderRadius: 12, padding: "16px 20px", boxShadow: "var(--shadow-sm)", border: "1px solid var(--border-subtle)", flex: "1 1 180px", minWidth: 170 };
    const cardLabel = { fontSize: 11, color: "var(--text-soft)", fontWeight: 600, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 4 };
    const cardVal = { fontSize: 22, fontWeight: 700, color: "var(--text-primary)" };
    const btnBase = { padding: "8px 18px", border: "none", borderRadius: 8, cursor: "pointer", fontWeight: 600, fontSize: 13, transition: "all .15s" };
    const btnPrimary = { ...btnBase, background: "var(--brand-primary, #2563eb)", color: "#fff" };
    const btnSuccess = { ...btnBase, background: "var(--success)", color: "#fff" };
    const btnDanger = { ...btnBase, background: "var(--error)", color: "#fff" };
    const btnOutline = { ...btnBase, background: "transparent", color: "var(--brand-primary, #2563eb)", border: "1.5px solid var(--brand-primary, #2563eb)" };
    const btnSmSuccess = { ...btnBase, background: "var(--success)", color: "#fff", padding: "5px 12px", fontSize: 11 };
    const btnSmDanger = { ...btnBase, background: "var(--error)", color: "#fff", padding: "5px 12px", fontSize: 11 };
    const btnSmOutline = { ...btnBase, background: "transparent", color: "var(--error)", border: "1.5px solid var(--error)", padding: "5px 12px", fontSize: 11 };
    const input = { padding: "7px 10px", borderRadius: 8, border: "1.5px solid var(--border-subtle)", fontSize: 13, outline: "none", background: "var(--input-bg)", color: "var(--text-primary)" };
    const th = { padding: "10px 12px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "var(--text-soft)", textTransform: "uppercase", letterSpacing: 0.5, borderBottom: "2px solid var(--border-subtle)", background: "var(--table-header-bg)", whiteSpace: "nowrap" };
    const tdStyle = { padding: "10px 12px", fontSize: 13, borderBottom: "1px solid var(--border-subtle)", verticalAlign: "middle", color: "var(--text-primary)" };
    const statusBadge = (status) => {
        const colors = { pending: { bg: "rgba(245,158,11,0.15)", text: "#f59e0b" }, approved: { bg: "rgba(22,163,74,0.15)", text: "#16a34a" }, rejected: { bg: "rgba(220,38,38,0.15)", text: "#dc2626" } };
        const c = colors[status] || colors.pending;
        return { display: "inline-block", padding: "3px 10px", borderRadius: 99, fontSize: 11, fontWeight: 700, background: c.bg, color: c.text, border: `1px solid ${c.text}30` };
    };
    const tabBtnStyle = (active) => ({
        padding: "10px 24px", border: "none",
        borderBottom: active ? "3px solid var(--brand-primary, #2563eb)" : "3px solid transparent",
        background: "transparent", color: active ? "var(--brand-primary, #2563eb)" : "var(--text-soft)",
        fontWeight: active ? 700 : 500, fontSize: 14, cursor: "pointer",
    });

    /* ═══════════════════════════════════════════════════════════════════════════ */
    /* ── RENDER ──────────────────────────────────────────────────────────────── */
    /* ═══════════════════════════════════════════════════════════════════════════ */
    if (loading) {
        return (
            <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: 300 }}>
                <div style={{ textAlign: "center" }}>
                    <div style={{ width: 36, height: 36, border: "3px solid var(--border-subtle)", borderTopColor: "var(--brand-primary, #2563eb)", borderRadius: "50%", animation: "spin 1s linear infinite", margin: "0 auto 12px" }} />
                    <p style={{ color: "var(--text-soft)", fontSize: 14 }}>Loading OT Management…</p>
                    <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
                </div>
            </div>
        );
    }

    return (
        <div style={{ maxWidth: 1200, margin: "0 auto", fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif" }}>
            {/* Header */}
            <div style={{ marginBottom: 20 }}>
                <h2 style={{ fontSize: 22, fontWeight: 700, color: "var(--text-primary)", margin: 0 }}>OT Management</h2>
                <p style={{ fontSize: 13, color: "var(--text-soft)", margin: "4px 0 0" }}>
                    {isFinance ? "View overtime requests (read-only)" : "Submit & review overtime requests"} • {role.replace(/_/g, " ").toUpperCase()}
                </p>
            </div>

            {/* Flash message */}
            {msg.text && (
                <div style={{
                    padding: "10px 16px", borderRadius: 8, marginBottom: 16, fontSize: 13, fontWeight: 600,
                    background: msg.type === "error" ? "var(--glass-rose, #fee2e2)" : "var(--glass-green, #d1fae5)",
                    color: msg.type === "error" ? "var(--error, #991b1b)" : "var(--success, #065f46)",
                    border: `1px solid var(--border-subtle)`,
                }}>
                    {msg.text}
                </div>
            )}

            {/* Stats */}
            <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 20 }}>
                <div style={card}><div style={cardLabel}>Active Requests</div><div style={{ ...cardVal, color: "var(--brand-primary, #2563eb)" }}>{stats.active}</div></div>
                <div style={card}><div style={cardLabel}>Total OT Hours</div><div style={{ ...cardVal, color: "var(--brand-purple, #7c3aed)" }}>{stats.totalHrs.toFixed(1)}h</div></div>
                <div style={card}><div style={cardLabel}>Total OT Cost</div><div style={{ ...cardVal, color: "var(--success)", fontSize: 18 }}>{currency(stats.totalCost)}</div></div>
            </div>

            {/* Tabs */}
            <div style={{ display: "flex", borderBottom: "2px solid var(--border-subtle)", marginBottom: 20 }}>
                {canSubmit && <button style={tabBtnStyle(tab === "submit")} onClick={() => setTab("submit")}>Submit OT</button>}
                <button style={tabBtnStyle(tab === "review")} onClick={() => setTab("review")}>
                    {canReview ? "Review Requests" : "View Requests"}
                </button>
            </div>

            {/* ─── SUBMIT TAB ───────────────────────────────────────────────────── */}
            {tab === "submit" && canSubmit && (
                <div>
                    <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20, flexWrap: "wrap" }}>
                        <label style={{ fontSize: 13, fontWeight: 600, color: "var(--text-primary)" }}>Date:</label>
                        <input type="date" value={submitDate} onChange={(e) => setSubmitDate(e.target.value)} style={{ ...input, width: 180 }} />
                        <button style={btnPrimary} onClick={handleSubmitOT}>Submit OT Requests</button>
                        <span style={{ fontSize: 12, color: "var(--text-soft)" }}>
                            {Object.values(otEntries).filter((v) => Number(v) > 0).length} worker(s) with OT
                        </span>
                    </div>

                    {Object.keys(siteGroups).length === 0 && (
                        <div style={{ ...card, textAlign: "center", color: "#94a3b8", padding: 40 }}>
                            No deployments found for {submitDate}. Deploy workers first.
                        </div>
                    )}

                    {Object.entries(siteGroups).map(([siteId, group]) => {
                        const workerIds = group.workers;
                        const presentCount = workerIds.filter((wId) => isPresent(wId)).length;
                        const absentCount = workerIds.length - presentCount;

                        return (
                            <div key={siteId} style={{ ...card, marginBottom: 16, padding: 0, overflow: "hidden" }}>
                                {/* Site header */}
                                <div style={{
                                    padding: "12px 20px", background: "var(--bg-body)", color: "var(--text-primary)",
                                    display: "flex", justifyContent: "space-between", alignItems: "center",
                                    borderBottom: "1px solid var(--border-subtle)",
                                }}>
                                    <div>
                                        <span style={{ fontWeight: 700, fontSize: 14 }}>{group.siteName}</span>
                                        <span style={{ fontWeight: 400, fontSize: 12, marginLeft: 10, opacity: 0.85 }}>
                                            {workerIds.length} worker(s)
                                        </span>
                                        {group.notes && (
                                            <span style={{ fontWeight: 400, fontSize: 11, marginLeft: 10, opacity: 0.7 }}>
                                                Notes: {group.notes}
                                            </span>
                                        )}
                                    </div>
                                    <div style={{ display: "flex", gap: 8 }}>
                                        <span style={{ padding: "2px 10px", borderRadius: 99, fontSize: 11, fontWeight: 600, background: "rgba(22,163,74,0.15)", color: "#16a34a" }}>
                                            {presentCount} present
                                        </span>
                                        {absentCount > 0 && (
                                            <span style={{ padding: "2px 10px", borderRadius: 99, fontSize: 11, fontWeight: 600, background: "rgba(220,38,38,0.15)", color: "#dc2626" }}>
                                                {absentCount} absent
                                            </span>
                                        )}
                                    </div>
                                </div>

                                {/* Worker table */}
                                <div style={{ overflowX: "auto" }}>
                                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                                        <thead>
                                            <tr>
                                                <th style={{ ...th, width: 40 }}>#</th>
                                                <th style={th}>Worker</th>
                                                <th style={th}>Daily Rate</th>
                                                <th style={th}>Attendance</th>
                                                <th style={th}>Existing OT</th>
                                                <th style={{ ...th, width: 130 }}>OT Hours</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {workerIds.map((wId, i) => {
                                                const w = workerMap[wId];
                                                const present = isPresent(wId);
                                                const existing = getExistingRequest(wId, siteId);
                                                return (
                                                    <tr key={wId} style={{ background: i % 2 === 0 ? "transparent" : "var(--bg-body)" }}>
                                                        <td style={tdStyle}>{i + 1}</td>
                                                        <td style={{ ...tdStyle, fontWeight: 600, color: "var(--text-primary)" }}>
                                                            {workerNode(wId)}
                                                            {w?.worker_id && <span style={{ fontSize: 10, color: "var(--text-soft)", marginLeft: 6 }}>#{w.worker_id}</span>}
                                                        </td>
                                                        <td style={tdStyle}>{currency(w?.daily_rate || 0)}</td>
                                                        <td style={tdStyle}>
                                                            <span style={{
                                                                display: "inline-block", padding: "3px 10px", borderRadius: 99, fontSize: 11, fontWeight: 700,
                                                                background: present ? "var(--glass-green, #d1fae5)" : "var(--glass-rose, #fee2e2)",
                                                                color: present ? "var(--success, #065f46)" : "var(--error, #991b1b)",
                                                            }}>
                                                                {present ? "Present" : "Absent"}
                                                            </span>
                                                        </td>
                                                        <td style={tdStyle}>
                                                            {existing ? (
                                                                <span style={{ fontWeight: 600 }}>{existing.ot_hours}h</span>
                                                            ) : (
                                                                <span style={{ color: "var(--text-soft)", fontSize: 12 }}>—</span>
                                                            )}
                                                        </td>
                                                        <td style={tdStyle}>
                                                            {present ? (
                                                                <input
                                                                    type="number" min="0" max="12" step="0.5"
                                                                    value={getOtEntry(wId, siteId)}
                                                                    onChange={(e) => setOtEntry(wId, siteId, e.target.value)}
                                                                    placeholder={"0"}
                                                                    style={{
                                                                        ...input, width: 110, textAlign: "center",
                                                                        borderColor: existing ? 'var(--brand-purple, #a78bfa)' : "var(--border-subtle)",
                                                                        background: existing ? 'var(--glass-purple, #f5f3ff)' : "var(--input-bg)",
                                                                        color: "var(--input-text, var(--text-primary))",
                                                                        fontWeight: existing ? 700 : 600,
                                                                    }}
                                                                />
                                                            ) : (
                                                                <span style={{ color: "var(--text-soft)", fontSize: 12 }}>N/A (absent)</span>
                                                            )}
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}

            {/* ─── REVIEW TAB ───────────────────────────────────────────────────── */}
            {tab === "review" && (
                <div>
                    {/* Filters */}
                    <div style={{ display: "flex", gap: 12, marginBottom: 16, flexWrap: "wrap", alignItems: "center" }}>
                        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} style={{ ...input, width: 150 }}>
                            <option value="all">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="approved">Approved</option>
                            <option value="rejected">Rejected</option>
                        </select>
                        <select value={filterSite} onChange={(e) => setFilterSite(e.target.value)} style={{ ...input, width: 200 }}>
                            <option value="all">All Sites</option>
                            {sites.filter((s) => !allowedSiteIds || allowedSiteIds.includes(s.id)).map((s) => (
                                <option key={s.id} value={s.id}>{s.name}</option>
                            ))}
                        </select>
                        <input type="month" value={filterMonth} onChange={(e) => setFilterMonth(e.target.value)} style={{ ...input, width: 170 }} />
                        {canReview && (
                            <input type="text" placeholder="Review note (optional)" value={reviewNote} onChange={(e) => setReviewNote(e.target.value)} style={{ ...input, width: 230 }} />
                        )}
                    </div>

                    {/* Bulk actions */}
                    {canReview && (
                        <div style={{ display: "flex", gap: 10, marginBottom: 16, alignItems: "center", flexWrap: "wrap" }}>
                            <button style={btnSuccess} onClick={handleBulkApprove}>Approve Selected ({selected.size})</button>
                            <button style={btnDanger} onClick={handleBulkReject}>Reject Selected ({selected.size})</button>
                            {selected.size > 0 && <button style={btnOutline} onClick={() => setSelected(new Set())}>Clear Selection</button>}
                        </div>
                    )}

                    {/* Requests table */}
                    <div style={{ ...card, padding: 0, overflow: "hidden" }}>
                        <div style={{ overflowX: "auto" }}>
                            <table style={{ width: "100%", borderCollapse: "collapse" }}>
                                <thead>
                                    <tr>
                                        {canReview && (
                                            <th style={{ ...th, width: 40 }}>
                                                <input type="checkbox"
                                                    onChange={() => toggleSelectAll(filtered.filter((r) => r.status === "pending").map((r) => r.id))}
                                                    checked={filtered.filter((r) => r.status === "pending").length > 0 && filtered.filter((r) => r.status === "pending").every((r) => selected.has(r.id))}
                                                />
                                            </th>
                                        )}
                                        <th style={th}>Date</th>
                                        <th style={th}>Worker</th>
                                        <th style={th}>Site</th>
                                        <th style={th}>OT Hours</th>
                                        <th style={th}>Est. Pay</th>
                                        <th style={th}>Status</th>
                                        <th style={th}>Submitted</th>
                                        {canReview && <th style={th}>Actions</th>}
                                    </tr>
                                </thead>
                                <tbody>
                                    {filtered.length === 0 ? (
                                        <tr>
                                            <td colSpan={canReview ? 9 : 7} style={{ ...tdStyle, textAlign: "center", color: "var(--text-soft)", padding: 40 }}>
                                                No OT requests found for the selected filters.
                                            </td>
                                        </tr>
                                    ) : (
                                        filtered.map((r, i) => {
                                            const w = workerMap[r.worker_id];
                                            const hourly = w ? Number(w.daily_rate || 0) / 8 : 0;
                                            const estPay = hourly * 1.5 * Number(r.ot_hours || 0);
                                            return (
                                                <tr key={r.id} style={{ background: i % 2 === 0 ? "transparent" : "var(--bg-body)" }}>
                                                    {canReview && (
                                                        <td style={tdStyle}>
                                                            {r.status === "pending" && <input type="checkbox" checked={selected.has(r.id)} onChange={() => toggleSelect(r.id)} />}
                                                        </td>
                                                    )}
                                                    <td style={{ ...tdStyle, fontWeight: 600, whiteSpace: "nowrap" }}>{r.date}</td>
                                                    <td style={{ ...tdStyle, fontWeight: 600 }}>{workerNode(r.worker_id)}</td>
                                                    <td style={tdStyle}>{siteNode(r.site_id)}</td>
                                                    <td style={{ ...tdStyle, fontWeight: 700, color: "var(--brand-purple, #7c3aed)" }}>{Number(r.ot_hours || 0).toFixed(1)}h</td>
                                                    <td style={{ ...tdStyle, color: "var(--brand-primary, #2563eb)", fontWeight: 600 }}>{currency(estPay)}</td>
                                                    <td style={tdStyle}>
                                                        <div>
                                                            <span style={statusBadge(r.status)}>{r.status}</span>
                                                            {r.reviewed_by && (r.status === "approved" || r.status === "rejected") && (
                                                                <div style={{ fontSize: 10, color: "var(--text-soft)", marginTop: 3, fontStyle: "italic" }}>
                                                                    {getReviewerLabel(r.reviewed_by)}
                                                                </div>
                                                            )}
                                                        </div>
                                                    </td>
                                                    <td style={{ ...tdStyle, fontSize: 11, color: "var(--text-soft)" }}>{r.created_at ? new Date(r.created_at).toLocaleDateString() : "—"}</td>
                                                    {canReview && (
                                                        <td style={tdStyle}>
                                                            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                                                                {r.status === "pending" && (
                                                                    <>
                                                                        <button style={btnSmSuccess} onClick={() => handleApprove(r.id)}>Approve</button>
                                                                        <button style={btnSmDanger} onClick={() => handleReject(r.id)}>Reject</button>
                                                                    </>
                                                                )}
                                                                <button style={btnSmOutline} onClick={() => handleDelete(r.id)}>Delete</button>
                                                            </div>
                                                        </td>
                                                    )}
                                                </tr>
                                            );
                                        })
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div style={{ marginTop: 12, fontSize: 12, color: "var(--text-soft)", textAlign: "right" }}>
                        Showing {filtered.length} of {requests.length} requests
                    </div>
                </div>
            )}
        </div>
    );
}
