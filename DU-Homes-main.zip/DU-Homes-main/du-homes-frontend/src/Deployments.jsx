import { useState, useEffect, useCallback } from "react";
import DeploymentReport from "./DeploymentReport";

const API = import.meta.env.VITE_API_URL || "http://localhost:8080";
const hdr = () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("access_token") || localStorage.getItem("token") || ""}`,
});

export default function Deployments() {
    const today = new Date().toISOString().slice(0, 10);
    const [tab, setTab] = useState("manage");
    const [deployments, setDeployments] = useState([]);
    const [workers, setWorkers] = useState([]);
    const [sites, setSites] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [officers, setOfficers] = useState([]);
    const [deletedEntities, setDeletedEntities] = useState([]);
    const [search, setSearch] = useState("");
    const [loading, setLoading] = useState(false);
    const [msg, setMsg] = useState("");
    const [form, setForm] = useState({ site_id: "", date: today, notes: "" });
    const [addWorkerForm, setAddWorkerForm] = useState({});
    const [editingTask, setEditingTask] = useState(null); // { deploymentId, workerId, task }

    const fetchDeployments = useCallback(async () => {
        try {
            const r = await fetch(`${API}/deployments`, { headers: hdr() });
            if (r.ok) {
                const data = await r.json();
                console.log("Deployments fetched:", data.length);
                setDeployments(data);
            } else {
                console.error("Deployments fetch failed:", r.status);
            }
        } catch (err) { console.error("Deployments fetch error:", err); }
    }, []);

    const fetchWorkers = useCallback(async () => {
        try {
            const r = await fetch(`${API}/workers?archived=true`, { headers: hdr() });
            if (r.ok) {
                const data = await r.json();
                console.log("Workers fetched:", data.length, data);
                setWorkers(data);
            } else {
                console.error("Workers fetch failed:", r.status);
            }
        } catch (err) { console.error("Workers fetch error:", err); }
    }, []);

    const fetchSites = useCallback(async () => {
        try {
            const r = await fetch(`${API}/fields?archived=true`, { headers: hdr() });
            if (r.ok) {
                const data = await r.json();
                setSites(data);
            }
        } catch (err) { console.error("Sites fetch error:", err); }
    }, []);

    const fetchAssignments = useCallback(async () => {
        try {
            const r = await fetch(`${API}/assignments`, { headers: hdr() });
            if (r.ok) setAssignments(await r.json());
        } catch { /* silent */ }
    }, []);

    const fetchOfficers = useCallback(async () => {
        try {
            const r = await fetch(`${API}/officers`, { headers: hdr() });
            if (r.ok) setOfficers(await r.json());
        } catch { /* silent */ }
    }, []);

    useEffect(() => {
        fetchDeployments();
        fetchWorkers();
        fetchSites();
        fetchAssignments();
        fetchOfficers();
        fetch(`${API}/deleted-entities?type=worker,site`, { headers: hdr() })
            .then(r => r.json()).then(d => setDeletedEntities(Array.isArray(d) ? d : []))
            .catch(() => {});
    }, [fetchDeployments, fetchWorkers, fetchSites, fetchAssignments, fetchOfficers]);

    const getSiteName = (id, dep = {}) => dep.site_name || sites.find((s) => s.id === id)?.name || deletedEntities.find(e => e.entity_id === id)?.entity_name || "Unknown";
    const getWorkerName = (id, dw = {}) => dw.worker_name || workers.find((w) => w.id === id)?.full_name || deletedEntities.find(e => e.entity_id === id)?.entity_name || "Unknown";
    const deletedMap = Object.fromEntries(deletedEntities.map(e => [e.entity_id, e]));
    
    const siteNode = (id, dep = {}) => {
        if (dep.site_name && dep.site_name !== "Unknown Site") {
            return (<>{dep.site_name} {dep.site_archived && <span className="archived-badge">deleted</span>}</>);
        }
        const s = sites.find(x => x.id === id); 
        if (!s) { 
            const snap = deletedMap[id]; 
            return (<>{snap?.entity_name || "Deleted Site"} <span className="archived-badge">deleted</span></>); 
        } 
        return (<>{s?.name}{s?.is_archived && <span className="archived-badge">deleted</span>}</>); 
    };

    const workerNode = (id, dw = {}) => { 
        if (dw.worker_name && dw.worker_name !== "Unknown Worker") {
            return (<>{dw.worker_name} {dw.is_archived && <span className="archived-badge">deleted</span>}</>);
        }
        const w = workers.find(x => x.id === id); 
        if (!w) { 
            const snap = deletedMap[id]; 
            return (<>{snap?.entity_name || "Deleted Worker"} <span className="archived-badge">deleted</span></>); 
        } 
        return (<>{w?.full_name}{w?.is_archived && <span className="archived-badge">deleted</span>}</>); 
    };

    /* ── assigned officer for a site ── */
    const getAssignedOfficer = (siteId) => {
        const a = assignments.find((a) => a.site_id === siteId && (!a.to_date || a.to_date >= today));
        if (!a) return null;
        const o = officers.find((o) => o.id === a.officer_id);
        return o ? o.full_name : null;
    };

    const handleCreate = async (e) => {
        e.preventDefault();
        if (!form.site_id) { setMsg("Select a site"); return; }
        if (form.date < today && !window.confirm("You are creating a deployment for a past date. PROCEED?")) return;
        if (!getAssignedOfficer(form.site_id)) {
            setMsg("Cannot create deployment: This site has no assigned site officer. Please assign an officer first in Officer Assignments.");
            return;
        }
        // Validate: only one deployment per site per day
        const existingDeployment = deployments.find((d) => d.site_id === form.site_id && d.date === form.date);
        if (existingDeployment) {
            setMsg(`A deployment already exists for ${getSiteName(form.site_id)} on ${form.date}. Each site can only have one deployment per day.`);
            return;
        }
        setLoading(true); setMsg("");
        const currentUser = JSON.parse(localStorage.getItem("user") || "{}");
        const recorderData = {
            recorded_by_name: currentUser.full_name || currentUser.name || "Admin",
            recorded_by_role: currentUser.role || "admin"
        };
        try {
            const r = await fetch(`${API}/deployments`, {
                method: "POST", headers: hdr(), body: JSON.stringify({ ...form, ...recorderData }),
            });
            if (r.ok) {
                setMsg("Deployment created ✓");
                setForm({ site_id: "", date: today, notes: "" });
                fetchDeployments();
            } else {
                const d = await r.json();
                setMsg(d.error || "Create failed");
            }
        } catch (err) { setMsg(err.message); }
        setLoading(false);
    };

    const handleDelete = async (id) => {
        if (!confirm("Delete this deployment?")) return;
        setLoading(true);
        try {
            await fetch(`${API}/deployments/${id}`, { method: "DELETE", headers: hdr() });
            setMsg("Deleted ✓");
            fetchDeployments();
        } catch (err) { setMsg(err.message); }
        setLoading(false);
    };

    const handleAddWorker = async (deploymentId) => {
        const wf = addWorkerForm[deploymentId];
        if (!wf || !wf.worker_id) {
            setMsg("Select a worker first");
            return;
        }
        setLoading(true); setMsg("");
        try {
            const body = {
                worker_id: wf.worker_id,
                task: wf.task || "",
            };
            console.log("Adding worker to deployment:", deploymentId, body);
            const r = await fetch(`${API}/deployments/${deploymentId}/workers`, {
                method: "POST",
                headers: hdr(),
                body: JSON.stringify(body),
            });
            if (r.ok) {
                setMsg("Worker added ✓");
                setAddWorkerForm((prev) => ({
                    ...prev,
                    [deploymentId]: { worker_id: "", task: "" },
                }));
                fetchDeployments();
            } else {
                const d = await r.json();
                console.error("Add worker failed:", d);
                setMsg(d.error || "Add worker failed");
            }
        } catch (err) {
            console.error("Add worker error:", err);
            setMsg(err.message);
        }
        setLoading(false);
    };

    const handleRemoveWorker = async (deploymentId, workerId) => {
        if (!confirm("Remove this worker from deployment?")) return;
        setLoading(true);
        try {
            await fetch(`${API}/deployments/${deploymentId}/workers/${workerId}`, {
                method: "DELETE", headers: hdr(),
            });
            setMsg("Worker removed ✓");
            fetchDeployments();
        } catch (err) { setMsg(err.message); }
        setLoading(false);
    };

    const handleUpdateTask = async (deploymentId, workerId, newTask) => {
        setLoading(true);
        try {
            const r = await fetch(`${API}/deployments/${deploymentId}/workers/${workerId}`, {
                method: "PUT",
                headers: hdr(),
                body: JSON.stringify({ task: newTask }),
            });
            if (r.ok) {
                setMsg("Task updated ✓");
                setEditingTask(null);
                fetchDeployments();
            } else {
                const d = await r.json();
                setMsg(d.error || "Update failed");
            }
        } catch (err) { setMsg(err.message); }
        setLoading(false);
    };

    const filtered = deployments.filter((d) => {
        const q = search.toLowerCase();
        return (
            getSiteName(d.site_id, d).toLowerCase().includes(q) ||
            (d.date || "").includes(q) ||
            (d.notes || "").toLowerCase().includes(q)
        );
    });

    const isPast = (date) => date < today;

    /* ── Report Tab ── */
    // The report tab now uses the professional DeploymentReport component

    const th = { padding: "10px 10px", borderBottom: "2px solid var(--border-subtle)", textAlign: "left", fontSize: 13, fontWeight: 700, background: "var(--table-header-bg)", color: "var(--text-primary)", whiteSpace: "nowrap" };
    const td = { padding: "10px 10px", borderBottom: "1px solid var(--border-subtle)", fontSize: 13, color: "var(--text-primary)", verticalAlign: "middle" };
    const inp = { padding: "8px 12px", borderRadius: 8, border: "1px solid var(--input-border)", background: "var(--input-bg)", color: "var(--input-text)", fontSize: 14, boxSizing: "border-box" };
    const btnPrimary = { background: "var(--primary, #991b1b)", color: "#fff", border: "none", padding: "8px 20px", borderRadius: 8, fontWeight: 700, fontSize: 13, cursor: "pointer" };
    const tabBtn = (active) => ({
        padding: "10px 24px",
        border: "none",
        fontWeight: 700,
        fontSize: 14,
        cursor: "pointer",
        borderRadius: "8px 8px 0 0",
        background: active ? "var(--primary, #991b1b)" : "var(--border-subtle)",
        color: active ? "#fff" : "var(--text-soft)",
    });

    return (
        <div>
            <h2 style={{ fontSize: 22, fontWeight: 800, marginBottom: 20 }}>Deployments</h2>

            {msg && (
                <div style={{
                    padding: "10px 16px", borderRadius: 8, marginBottom: 16,
                    background: msg.includes("✓") ? "var(--glass-green)" : "var(--glass-rose)",
                    color: msg.includes("✓") ? "#166534" : "#991b1b",
                    border: `1px solid ${msg.includes("✓") ? "#16653433" : "#dc262633"}`,
                    fontWeight: 600, fontSize: 14,
                }}>{msg}</div>
            )}

            <div style={{ display: "flex", gap: 4, marginBottom: 0 }}>
                <button style={tabBtn(tab === "manage")} onClick={() => setTab("manage")}>Manage Deployments</button>
                <button style={tabBtn(tab === "report")} onClick={() => setTab("report")}>Deployment Report</button>
            </div>

            <div style={{
                background: "var(--bg-surface)", borderRadius: "0 12px 12px 12px", border: "1px solid var(--border-subtle)",
                padding: 24, marginBottom: 24, boxShadow: "var(--shadow-sm)",
            }}>

                {/* ════════ MANAGE TAB ════════ */}
                {tab === "manage" && (
                    <div>
                        <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16, color: "var(--text-primary)" }}>Create Deployment</h3>
                        <form onSubmit={handleCreate} style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "flex-end", marginBottom: 24 }}>
                            <div>
                                <label style={{ fontSize: 12, fontWeight: 600, color: "var(--text-soft)", display: "block", marginBottom: 4 }}>Site *</label>
                                <select style={{ ...inp, minWidth: 180 }} value={form.site_id} onChange={(e) => setForm({ ...form, site_id: e.target.value })} required>
                                    <option value="">Select site...</option>
                                    {sites.map((s) => {
                                        const hasOfficer = !!getAssignedOfficer(s.id);
                                        return (
                                            <option key={s.id} value={s.id}>
                                                {s.name}{hasOfficer ? '' : ' (No Officer [!])'}
                                            </option>
                                        );
                                    })}
                                </select>
                                {form.site_id && !getAssignedOfficer(form.site_id) && (
                                    <div style={{ fontSize: 11, color: "#dc2626", marginTop: 4, fontWeight: 600 }}>
                                        [!] No officer assigned to this site
                                    </div>
                                )}
                                {form.site_id && getAssignedOfficer(form.site_id) && (
                                    <div style={{ fontSize: 11, color: "#16a34a", marginTop: 4, fontWeight: 600 }}>
                                        Officer: {getAssignedOfficer(form.site_id)}
                                    </div>
                                )}
                            </div>
                            <div>
                                <label style={{ fontSize: 12, fontWeight: 600, color: "var(--text-soft)", display: "block", marginBottom: 4 }}>Date * <span style={{ fontSize: 11, color: "var(--text-muted)" }}>(today or future)</span></label>
                                <input type="date" style={inp} value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} required />
                            </div>
                            <div>
                                <label style={{ fontSize: 12, fontWeight: 600, color: "var(--text-soft)", display: "block", marginBottom: 4 }}>Notes</label>
                                <input style={{ ...inp, minWidth: 200 }} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Optional notes..." />
                            </div>
                            <button type="submit" style={btnPrimary} disabled={loading}>Create Deployment</button>
                        </form>

                        <div style={{ marginBottom: 16, display: "flex", gap: 12, alignItems: "center" }}>
                            <input style={{ ...inp, minWidth: 250 }} placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} />
                            <span style={{ fontSize: 13, color: "#64748b" }}>{filtered.length} deployments</span>
                        </div>

                        {filtered.sort((a, b) => b.date.localeCompare(a.date)).map((d) => {
                            const past = isPast(d.date);
                            const dWorkers = d.deployment_workers || [];
                            const wf = addWorkerForm[d.id] || { worker_id: "", task: "" };
                            const alreadyAdded = dWorkers.map((dw) => dw.worker_id);

                            // UI: Check if the selected worker is already assigned to another site on this same date
                            const assignedElsewhere = wf.worker_id ? deployments.find(other => 
                                other.id !== d.id && 
                                other.date === d.date && 
                                (other.deployment_workers || []).some(dw => dw.worker_id == wf.worker_id)
                            ) : null;

                            // Filter available workers: active + not already in this deployment
                            const availableWorkers = workers.filter((w) => {
                                const isActive = !w.status || w.status === "active";
                                const notAdded = !alreadyAdded.includes(w.id);
                                return isActive && notAdded;
                            });

                            return (
                                <div key={d.id} style={{
                                    border: "1px solid var(--border-subtle)", borderRadius: 12, marginBottom: 16, overflow: "hidden",
                                    borderLeft: past ? "4px solid var(--text-muted)" : "4px solid var(--primary, #991b1b)",
                                    opacity: past ? 0.75 : 1,
                                    background: "var(--bg-surface)",
                                }}>
                                    <div style={{
                                        display: "flex", justifyContent: "space-between", alignItems: "center",
                                        padding: "12px 16px", background: "var(--table-header-bg)",
                                    }}>
                                        <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
                                            <span style={{ fontSize: 14, fontWeight: 600, color: "var(--text-primary)" }}>Date: {d.date}</span>
                                            <span style={{ color: "var(--primary, #991b1b)", fontWeight: 700 }}>Site: {siteNode(d.site_id, d)}</span>
                                            {getAssignedOfficer(d.site_id) && (
                                                <span style={{ fontSize: 11, color: "var(--primary-light, #2563eb)", background: "var(--glass-blue)", padding: "2px 10px", borderRadius: 8, fontWeight: 600 }}>
                                                    Officer: {getAssignedOfficer(d.site_id)}
                                                </span>
                                            )}
                                            {!getAssignedOfficer(d.site_id) && (
                                                <span style={{ fontSize: 11, color: "var(--error, #dc2626)", background: "var(--glass-rose)", padding: "2px 10px", borderRadius: 8, fontWeight: 600 }}>
                                                    No Officer [!]
                                                </span>
                                            )}
                                            {d.notes && <span style={{ fontSize: 12, color: "var(--text-soft)" }}>Notes: {d.notes}</span>}
                                            {past && <span style={{ background: "var(--text-muted)", color: "#fff", padding: "2px 8px", borderRadius: 8, fontSize: 11, fontWeight: 700 }}>PAST</span>}
                                            <span style={{ background: "var(--glass-blue)", color: "var(--primary-light, #1e40af)", padding: "2px 8px", borderRadius: 8, fontSize: 11, fontWeight: 600 }}>
                        {dWorkers.length} worker{dWorkers.length !== 1 ? "s" : ""}
                      </span>
                                        </div>
                                        <button onClick={() => handleDelete(d.id)} style={{
                                            background: "#991b1b", color: "#fff", border: "none", padding: "6px 16px",
                                            borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: "pointer",
                                        }}>Delete</button>
                                    </div>

                                    <div style={{ padding: "0 16px 16px" }}>
                                        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 8 }}>
                                            <thead>
                                            <tr>
                                                <th style={th}>#</th>
                                                <th style={th}>Worker</th>
                                                <th style={th}>Task</th>
                                                <th style={th}>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            {dWorkers.length === 0 ? (
                                                <tr>
                                                    <td colSpan={4} style={{ ...td, textAlign: "center", color: "var(--text-muted)", padding: 20 }}>
                                                        No workers assigned
                                                    </td>
                                                </tr>
                                            ) : (
                                                dWorkers.map((dw, i) => (
                                                    <tr key={dw.worker_id || i} style={{ background: i % 2 === 0 ? "var(--bg-surface)" : "var(--table-header-bg)" }}>
                                                        <td style={td}>{i + 1}</td>
                                                        <td style={{ ...td, fontWeight: 600 }}>{workerNode(dw.worker_id, dw)}</td>
                                                        <td style={td}>
                                                            {editingTask && editingTask.deploymentId === d.id && editingTask.workerId === dw.worker_id ? (
                                                                <input
                                                                    style={{ ...inp, padding: "4px 8px", fontSize: 13, minWidth: 120 }}
                                                                    value={editingTask.task}
                                                                    onChange={(e) => setEditingTask({ ...editingTask, task: e.target.value })}
                                                                    autoFocus
                                                                />
                                                            ) : (
                                                                dw.task || "—"
                                                            )}
                                                        </td>
                                                        <td style={{ ...td, display: "flex", gap: 8 }}>
                                                            {editingTask && editingTask.deploymentId === d.id && editingTask.workerId === dw.worker_id ? (
                                                                <>
                                                                    <button onClick={() => handleUpdateTask(d.id, dw.worker_id, editingTask.task)} style={{
                                                                        background: "var(--glass-green)", color: "#166534", border: "1px solid #16653433",
                                                                        padding: "4px 12px", borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: "pointer",
                                                                    }}>Save</button>
                                                                    <button onClick={() => setEditingTask(null)} style={{
                                                                        background: "var(--bg-surface)", color: "var(--text-soft)", border: "1px solid var(--border-subtle)",
                                                                        padding: "4px 12px", borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: "pointer",
                                                                    }}>Cancel</button>
                                                                </>
                                                            ) : (
                                                                <>
                                                                    <button onClick={() => setEditingTask({ deploymentId: d.id, workerId: dw.worker_id, task: dw.task || "" })} style={{
                                                                        background: "var(--bg-surface)", color: "var(--text-primary)", border: "1px solid var(--border-subtle)",
                                                                        padding: "4px 12px", borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: "pointer",
                                                                    }}>Edit</button>
                                                                    {!past && (
                                                                        <button onClick={() => handleRemoveWorker(d.id, dw.worker_id)} style={{
                                                                            background: "#fee2e2", color: "#991b1b", border: "none",
                                                                            padding: "4px 12px", borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: "pointer",
                                                                        }}>Remove</button>
                                                                    )}
                                                                </>
                                                            )}
                                                        </td>
                                                    </tr>
                                                ))
                                            )}
                                            </tbody>
                                        </table>

                                        {/* ADD WORKER FORM — only for non-past deployments */}
                                        {!past && (
                                            <div style={{
                                                display: "flex", gap: 10, alignItems: "center", marginTop: 12, flexWrap: "wrap",
                                                padding: "12px", background: "var(--table-header-bg)", borderRadius: 8, border: "1px solid var(--border-subtle)",
                                            }}>
                                                <select
                                                    style={{ ...inp, minWidth: 200 }}
                                                    value={wf.worker_id}
                                                    onChange={(e) => {
                                                        console.log("Selected worker:", e.target.value);
                                                        setAddWorkerForm((prev) => ({
                                                            ...prev,
                                                            [d.id]: { ...wf, worker_id: e.target.value },
                                                        }));
                                                    }}
                                                >
                                                    <option value="">+ Select Worker</option>
                                                    {availableWorkers.map((w) => (
                                                        <option key={w.id} value={w.id}>
                                                            {w.full_name} ({w.worker_type || "worker"})
                                                        </option>
                                                    ))}
                                                </select>
                                                <input
                                                    style={{ ...inp, width: 150 }}
                                                    placeholder="Task (optional)"
                                                    value={wf.task || ""}
                                                    onChange={(e) =>
                                                        setAddWorkerForm((prev) => ({
                                                            ...prev,
                                                            [d.id]: { ...wf, task: e.target.value },
                                                        }))
                                                    }
                                                />
                                                <button
                                                    onClick={() => handleAddWorker(d.id)}
                                                    style={{
                                                        ...btnPrimary,
                                                        padding: "8px 20px",
                                                        opacity: !wf.worker_id ? 0.5 : 1,
                                                    }}
                                                    disabled={loading || !wf.worker_id}
                                                >
                                                    Add Worker
                                                </button>
                                                
                                                {/* UI: Warning — worker already at another site today */}
                                                {assignedElsewhere && (
                                                    <div style={{
                                                        padding: "6px 12px", background: "var(--glass-amber)", 
                                                        color: "var(--warning, #92400e)", borderRadius: 8,
                                                        fontSize: 12, fontWeight: 700, border: "1px solid #f59e0b33",
                                                        display: "flex", alignItems: "center", gap: 6
                                                    }}>
                                                        <span>[!]</span>
                                                        <span>{getWorkerName(wf.worker_id, {})} is already at <strong>{getSiteName(assignedElsewhere.site_id, assignedElsewhere)}</strong> today</span>
                                                    </div>
                                                )}

                                                {availableWorkers.length === 0 && (
                                                    <span style={{ fontSize: 12, color: "#f59e0b", fontWeight: 600 }}>
                            All workers are already assigned to this deployment
                          </span>
                                                )}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            );
                        })}

                        {filtered.length === 0 && (
                            <div style={{ textAlign: "center", color: "#94a3b8", padding: 40 }}>
                                No deployments found
                            </div>
                        )}
                    </div>
                )}

                {/* ════════ REPORT TAB ════════ */}
                {tab === "report" && (
                    <DeploymentReport />
                )}
            </div>
        </div>
    );
}
