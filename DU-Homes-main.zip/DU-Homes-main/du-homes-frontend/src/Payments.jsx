import { useState, useEffect, useCallback, useRef } from "react";
import ToolBills from "./ToolBills";
import PrintHeader, { PrintButton } from "./PrintHeader";


/* ───── helpers ───── */
const API = (import.meta.env.VITE_API_URL || "http://localhost:8080").replace(/\/+$/, "");
const hdr = () => {
    const t = localStorage.getItem("token") || localStorage.getItem("access_token") || "";
    return { "Content-Type": "application/json", ...(t ? { Authorization: `Bearer ${t}` } : {}) };
};
const currency = (v) => `Rs ${Number(v || 0).toLocaleString("en-LK", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

/* ───── Icons ───── */
const IconDaily = () => <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>;
const IconAttendance = () => <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><polyline points="17 11 19 13 23 9"></polyline></svg>;
const IconLog = () => <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>;
const IconPayroll = () => <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"></rect><circle cx="12" cy="12" r="2"></circle><path d="M6 12h.01M18 12h.01"></path></svg>;
const IconBills = () => <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>;

/* ───── get current user from localStorage ───── */
const getCurrentUser = () => {
    try { return JSON.parse(localStorage.getItem("user") || "{}"); } catch { return {}; }
};

/* ───── main export ───── */
export default function Payments() {
    const [tab, setTab] = useState("daily");
    const [unreadBillCount, setUnreadBillCount] = useState(0);

    // Fetch unread bill count for notification badge
    useEffect(() => {
        const fetchUnread = async () => {
            try {
                const t = localStorage.getItem("token") || localStorage.getItem("access_token") || "";
                const r = await fetch(`${API}/tool-bills/unread-count`, {
                    headers: { "Content-Type": "application/json", ...(t ? { Authorization: `Bearer ${t}` } : {}) },
                });
                if (r.ok) {
                    const d = await r.json();
                    setUnreadBillCount(d.count || 0);
                }
            } catch { /* ignore */ }
        };
        fetchUnread();
        const interval = setInterval(fetchUnread, 60000);
        return () => clearInterval(interval);
    }, []);

    const tabBtn = (key) => ({
        display: "flex", alignItems: "center", gap: "8px",
        padding: "12px 20px", fontSize: 13, fontWeight: tab === key ? 700 : 600, cursor: "pointer",
        background: tab === key ? "var(--bg-surface)" : "transparent",
        color: tab === key ? "var(--primary-purple, #7c3aed)" : "var(--text-soft)",
        border: "none",
        borderBottom: tab === key ? "3px solid var(--primary-purple, #7c3aed)" : "3px solid transparent",
        borderTopLeftRadius: "8px", borderTopRightRadius: "8px",
        transition: "all 0.2s cubic-bezier(0.4, 0, 0.2, 1)",
    });
    
    return (
        <div style={{ color: "var(--text-primary)" }}>
            <style>{`
                .finance-card {
                    flex: 1 1 140px; background: var(--bg-surface); border: 1px solid var(--border-subtle);
                    border-radius: 12px; padding: 20px; box-shadow: var(--shadow-sm);
                    transition: transform 0.2s, box-shadow 0.2s;
                }
                .finance-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md, 0 8px 30px rgba(0,0,0,0.12)); }
                .finance-card-label { font-size: 11px; font-weight: 700; color: var(--text-soft); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px; }
                .finance-card-val { font-size: 26px; font-weight: 800; line-height: 1.1; display: flex; align-items: baseline; gap: 4px; }
                
                .finance-table-wrapper { background: var(--bg-surface); border: 1px solid var(--border-subtle); border-radius: 12px; overflow: hidden; box-shadow: var(--shadow-sm); }
                .finance-table { width: 100%; border-collapse: collapse; }
                .finance-table th { background: var(--table-header-bg); backdrop-filter: blur(10px); padding: 14px 20px; font-size: 11px; text-transform: uppercase; letter-spacing: 0.1em; color: var(--text-soft); font-weight: 700; border-bottom: 1px solid var(--border-subtle); text-align: left; white-space: nowrap; }
                .finance-table td { padding: 14px 20px; font-size: 13px; font-weight: 500; color: var(--text-primary); border-bottom: 1px solid var(--border-subtle); }
                .finance-table tbody tr { transition: background 0.2s; }
                .finance-table tbody tr:hover { background: var(--bg-body); }
                
                .status-badge { display: inline-flex; align-items: center; padding: 4px 10px; border-radius: 8px; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em; }
                .badge-paid { background: #dcfce7; color: #166534; }
                .badge-pending { background: #fef9c3; color: #854d0e; }
                .badge-absent { background: #fee2e2; color: #991b1b; }
                .badge-present { background: #dcfce7; color: #166534; }
                .badge-unmarked { background: var(--border-subtle); color: var(--text-soft); }
                
                .modern-input { width: 60px; padding: 8px 12px; border: 1px solid var(--input-border); border-radius: 8px; font-size: 13px; font-weight: 500; background: var(--input-bg); color: var(--text-primary); text-align: right; outline: none; transition: all 0.2s; }
                .modern-input:focus { border-color: #7c3aed; box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.15); }
                .modern-select { padding: 8px 12px; border: 1px solid var(--input-border); border-radius: 8px; font-size: 13px; font-weight: 500; background: var(--input-bg); color: var(--text-primary); outline: none; transition: all 0.2s; }
                
                .btn-sys { padding: 8px 18px; border: none; border-radius: 8px; font-size: 13px; font-weight: 700; cursor: pointer; transition: all 0.2s; display: inline-flex; align-items: center; gap: 6px; }
                .btn-primary { background: linear-gradient(135deg, #7c3aed, #4f46e5); color: #fff; box-shadow: 0 4px 12px rgba(124, 58, 237, 0.2); }
                .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 6px 15px rgba(124, 58, 237, 0.3); }
                .btn-secondary { background: var(--bg-surface); border: 1px solid var(--border-subtle); color: var(--text-primary); }
                .btn-secondary:hover { background: var(--bg-body); }
                .btn-success { background: linear-gradient(135deg, #16a34a, #059669); color: #fff; box-shadow: 0 4px 12px rgba(22, 163, 74, 0.2); }
                
                @media print {
                    /* ── 1. Hide ALL interactive controls ── */
                    .no-print,
                    .btn-sys,
                    button,
                    input[type="date"],
                    input[type="month"],
                    select,
                    .modern-input,
                    .modern-select { display: none !important; }

                    /* ── 2. Force clean white paper (targeted — don't override inline styles) ── */
                    html, body, #root, main {
                        background: #fff !important;
                        color: #000 !important;
                        margin: 0 !important;
                        padding: 0 !important;
                    }
                    /* Only decorative effects removed — NOT backgrounds (would break letterhead) */
                    * {
                        box-shadow: none !important;
                        text-shadow: none !important;
                        transition: none !important;
                        animation: none !important;
                    }

                    /* ── 3. Fix scroll containers (targeted — NOT global div override) ── */
                    .finance-table-wrapper,
                    .finance-table-wrapper > div { overflow: visible !important; }

                    /* ── 4. Summary card row ── */
                    .finance-card {
                        border: 1px solid #ccc !important;
                        background: #fff !important;
                        page-break-inside: avoid !important;
                        break-inside: avoid !important;
                        padding: 6px 10px !important;
                        min-width: 80px !important;
                    }
                    .finance-card-label { color: #555 !important; font-size: 7.5pt !important; margin-bottom: 2px !important; }
                    .finance-card-val   { font-size: 13pt !important; color: #000 !important; }

                    /* ── 5. Table wrapper ── */
                    .finance-table-wrapper {
                        border: 1px solid #bbb !important;
                        page-break-inside: avoid !important;
                        break-inside: avoid !important;
                        margin-bottom: 16px !important;
                    }

                    /* ── 6. Table: compressed for A4, red headers ── */
                    .finance-table {
                        width: 100% !important;
                        table-layout: fixed !important;
                        border-collapse: collapse !important;
                        font-size: 7.5pt !important;
                    }
                    .finance-table th {
                        background: #B22222 !important;
                        color: #fff !important;
                        font-size: 7pt !important;
                        font-weight: 700 !important;
                        text-transform: uppercase !important;
                        letter-spacing: 0.02em !important;
                        border: 1px solid #888 !important;
                        padding: 4px 5px !important;
                        white-space: nowrap !important;
                        overflow: hidden !important;
                        text-overflow: ellipsis !important;
                    }
                    .finance-table td {
                        color: #000 !important;
                        font-size: 7.5pt !important;
                        border: 1px solid #ddd !important;
                        padding: 4px 5px !important;
                        vertical-align: middle !important;
                        word-break: break-word !important;
                    }
                    .finance-table tbody tr:nth-child(even) td {
                        background: #f9f9f9 !important;
                    }

                    /* ── 7. Grand sum row ── */
                    .grand-sum-row td {
                        font-weight: 900 !important;
                        color: #000 !important;
                        border-top: 2px solid #B22222 !important;
                        background: #f0f0f0 !important;
                    }

                    /* ── 8. Site header/summary rows ── */
                    .site-print-header {
                        font-size: 9pt !important;
                        font-weight: 700 !important;
                        color: #000 !important;
                        padding: 6px 0 3px !important;
                        border-bottom: 1px solid #B22222 !important;
                        margin-bottom: 4px !important;
                    }

                    /* ── 9. Status badges ── */
                    .status-badge { border: 1px solid #999 !important; font-size: 6.5pt !important; padding: 2px 5px !important; }
                    .badge-paid    { background: #d1fae5 !important; color: #065f46 !important; border-color: #6ee7b7 !important; }
                    .badge-pending { background: #fef3c7 !important; color: #92400e !important; border-color: #fcd34d !important; }
                    .badge-absent  { background: #fee2e2 !important; color: #991b1b !important; border-color: #fca5a5 !important; }
                    .badge-present { background: #d1fae5 !important; color: #065f46 !important; border-color: #6ee7b7 !important; }
                    .badge-unmarked { background: #f1f5f9 !important; color: #334155 !important; border-color: #cbd5e1 !important; }

                    /* ── 10. Per-site block spacing ── */
                    .site-print-block { margin-bottom: 14px !important; page-break-inside: avoid !important; }
                }



            `}</style>
            
            <div style={{ marginBottom: 32 }} className="no-print">
                <h1 style={{ fontSize: 28, fontWeight: 900, color: "var(--text-primary)", marginBottom: 8, display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ width: 10, height: 20, background: "linear-gradient(135deg, #7c3aed, #4f46e5)", borderRadius: 4 }}></div>
                    Finance & Operations Ledger
                </h1>
                <p style={{ color: "var(--text-soft)", fontSize: 14, fontWeight: 500 }}>Secure gateway for payroll processing, tool billing, and operative disbursements.</p>
            </div>
            
            <div style={{ display: "flex", gap: 4, borderBottom: "2px solid var(--border-subtle)", marginBottom: 24, flexWrap: "wrap" }} className="no-print">
                <button style={tabBtn("daily")} onClick={() => setTab("daily")}><IconDaily /> Daily Salary Sheet</button>
                <button style={tabBtn("attendance")} onClick={() => setTab("attendance")}><IconAttendance /> Daily Attendance</button>
                <button style={tabBtn("log")} onClick={() => setTab("log")}><IconLog /> Payment Records</button>
                <button style={tabBtn("payroll")} onClick={() => setTab("payroll")}><IconPayroll /> Monthly Payroll</button>
                <button style={{ ...tabBtn("bills"), position: "relative" }} onClick={() => { setTab("bills"); setUnreadBillCount(0); }}>
                    <IconBills /> Tool Bills
                    {unreadBillCount > 0 && (
                        <span style={{
                            position: "absolute", top: 2, right: 2,
                            minWidth: 18, height: 18, borderRadius: 10,
                            background: "#dc2626", color: "#fff",
                            fontSize: 10, fontWeight: 700,
                            display: "flex", alignItems: "center", justifyContent: "center",
                            padding: "0 5px", boxShadow: "0 2px 6px rgba(220,38,38,0.3)",
                            animation: "pulse 2s ease-in-out infinite",
                        }}>{unreadBillCount}</span>
                    )}
                </button>
            </div>
            {tab === "daily" && <DailySalarySheet />}
            {tab === "attendance" && <AttendanceView />}
            {tab === "log" && <PaymentLog />}
            {tab === "payroll" && <PayrollTab />}
            {tab === "bills" && <ToolBills />}
        </div>
    );
}

/* ══════════════════════════════════════════════
   TAB 1 — DAILY SALARY SHEET
   ══════════════════════════════════════════════ */
function DailySalarySheet() {
    const today = new Date().toISOString().slice(0, 10);
    const [date, setDate] = useState(today);
    const [workers, setWorkers] = useState([]);
    const [sites, setSites] = useState([]);
    const [deployments, setDeployments] = useState([]);
    const [attendance, setAttendance] = useState([]);
    const [payments, setPayments] = useState([]);
    const [otRequests, setOtRequests] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [officers, setOfficers] = useState([]);
    const [overrides, setOverrides] = useState({});
    const [loading, setLoading] = useState(false);
    const [msg, setMsg] = useState("");
    const msgTimeout = useRef(null);
    const flash = (text) => {
        if (msgTimeout.current) clearTimeout(msgTimeout.current);
        setMsg(text);
        msgTimeout.current = setTimeout(() => setMsg(""), 3000);
    };

    const user = getCurrentUser();
    const role = user.role || "";
    const isSiteOfficer = role === "site_officer";
    const isFinance = role === "finance_officer" || role === "admin" || role === "project_manager";

    const fetchAll = useCallback(async () => {
        setLoading(true);
        if (msgTimeout.current) clearTimeout(msgTimeout.current);
        setMsg("");
        try {
            const [wR, sR, dR, aR, pR, otR, asR, ofR] = await Promise.all([
                fetch(`${API}/workers?archived=true`, { headers: hdr() }),
                fetch(`${API}/fields?archived=true`, { headers: hdr() }),
                fetch(`${API}/deployments?date=${date}`, { headers: hdr() }),
                fetch(`${API}/attendance?date=${date}`, { headers: hdr() }),
                fetch(`${API}/payments?date=${date}`, { headers: hdr() }),
                fetch(`${API}/ot-requests?month=${date.slice(0, 7)}`, { headers: hdr() }),
                fetch(`${API}/assignments`, { headers: hdr() }),
                fetch(`${API}/officers`, { headers: hdr() }),
            ]);
            const [w, s, d, a, p, ot, as_, of_] = await Promise.all([wR.json(), sR.json(), dR.json(), aR.json(), pR.json(), otR.json(), asR.json(), ofR.json()]);
            setWorkers(Array.isArray(w) ? w : []);
            setSites(Array.isArray(s) ? s : []);
            setDeployments(Array.isArray(d) ? d : []);
            setAttendance(Array.isArray(a) ? a : []);
            setPayments(Array.isArray(p) ? p : []);
            setOtRequests(Array.isArray(ot) ? ot : []);
            setAssignments(Array.isArray(as_) ? as_ : []);
            setOfficers(Array.isArray(of_) ? of_ : []);
            setOverrides({});
        } catch (e) { setMsg("Failed to load data: " + e.message); }
        setLoading(false);
    }, [date]);

    const refreshPayments = async () => {
        try {
            const r = await fetch(`${API}/payments?date=${date}`, { headers: hdr() });
            if (r.ok) {
                const data = await r.json();
                setPayments(Array.isArray(data) ? data : []);
            }
        } catch { /* ignore */ }
    };

    useEffect(() => { fetchAll(); }, [fetchAll]);

    /* ── role-based site filtering ── */
    const allowedSiteIds = (() => {
        if (!isSiteOfficer) return null;
        const userId = user.id;
        return assignments
            .filter((a) => a.officer_id === userId || a.user_id === userId)
            .map((a) => a.site_id);
    })();

    /* ── helpers ── */
    const getWorker = (id) => workers.find((w) => w.id === id);
    const getSiteName = (id) => (sites.find((s) => s.id === id) || {}).name || "Unknown Site";
    const getPayment = (wId, sId) => payments.find((p) => p.worker_id === wId && p.site_id === sId && p.date === date);
    const isPresent = (wId, sId) => attendance.some((a) => a.worker_id === wId && (a.site_id === sId || !a.site_id) && a.date === date && a.status === "present");

    /* ── assigned officer for a site ── */
    const getAssignedOfficer = (siteId) => {
        const a = assignments.find((a) => a.site_id === siteId && (!a.to_date || a.to_date >= today));
        if (!a) return null;
        const o = officers.find((o) => o.id === a.officer_id);
        return o ? o.full_name : null;
    };

    /* ── OT request lookup (Direct/Live) ── */
    const getOtRecord = (workerId, siteId) => {
        return otRequests.find(
            (r) => String(r.worker_id) === String(workerId) && String(r.site_id) === String(siteId) && r.date === date
        );
    };

    const getOvr = (wId, sId, field) => {
        const k = `${wId}_${sId}`;
        if (overrides[k] && overrides[k][field] !== undefined) return overrides[k][field];
        return undefined;
    };
    const setOvr = (wId, sId, field, val) => {
        const k = `${wId}_${sId}`;
        setOverrides((prev) => ({ ...prev, [k]: { ...(prev[k] || {}), [field]: val } }));
    };

    /* ── pay calculator — all values overridable ── */
    const getWorkerPay = (workerId, siteId) => {
        const w = getWorker(workerId);
        const existing = getPayment(workerId, siteId);
        const otRec = getOtRecord(workerId, siteId);
        
        const daily_rate = Math.max(0, Number(getOvr(workerId, siteId, "daily_rate") ?? existing?.daily_rate ?? w?.daily_rate ?? 0));
        const normal_hours = Math.max(0, Number(getOvr(workerId, siteId, "normal_hours") ?? existing?.normal_hours ?? 8));
        
        // Use live OT request value if it exists, otherwise fallback to existing payment or 0
        const ot_hours = Math.max(0, Number(getOvr(workerId, siteId, "ot_hours") ?? otRec?.ot_hours ?? existing?.ot_hours ?? 0));
        const deductions = Math.max(0, Number(getOvr(workerId, siteId, "deductions") ?? existing?.deductions ?? 0));

        // Base pay: overridable, defaults to calculated
        const basePayOverride = getOvr(workerId, siteId, "base_pay");
        const base_pay = basePayOverride !== undefined
            ? Math.max(0, +Number(basePayOverride).toFixed(2))
            : Math.max(0, +(daily_rate * (normal_hours / 8)).toFixed(2));

        // OT pay: overridable, defaults to calculated
        const otPayOverride = getOvr(workerId, siteId, "ot_pay");
        const ot_pay = otPayOverride !== undefined
            ? Math.max(0, +Number(otPayOverride).toFixed(2))
            : Math.max(0, +((daily_rate / 8) * 1.5 * ot_hours).toFixed(2));

        const rawNet = base_pay + ot_pay - deductions;
        const net_pay = rawNet < 0 ? 0 : +rawNet.toFixed(2);
        return { 
            daily_rate, normal_hours, ot_hours, 
            deductions, base_pay, ot_pay, net_pay, status: existing?.status || "pending" 
        };
    };

    /* ── group deployed workers by site ── */
    const deployedBySite = (() => {
        const map = {};
        deployments.forEach((dep) => {
            const sId = dep.site_id;
            if (!sId) return;
            if (allowedSiteIds && !allowedSiteIds.includes(sId)) return;
            const wIds = dep.deployment_workers?.map((dw) => dw.worker_id) || dep.workers || [];
            if (!map[sId]) map[sId] = new Set();
            (Array.isArray(wIds) ? wIds : []).forEach((wid) => map[sId].add(wid));
        });
        const result = {};
        Object.entries(map).forEach(([sId, wSet]) => { result[sId] = [...wSet]; });
        return result;
    })();

    const allSiteIds = Object.keys(deployedBySite);

    /* ── toggle paid ── */
    const togglePaid = async (workerId, siteId) => {
        const existing = getPayment(workerId, siteId);
        const pay = getWorkerPay(workerId, siteId);
        const newStatus = existing?.status === "paid" ? "pending" : "paid";

        // Optimistic UI update
        setPayments((prev) => prev.map((p) => p.id === existing?.id ? { ...p, status: newStatus } : p));

        try {
            if (existing) {
                await fetch(`${API}/payments/${existing.id}`, { method: "PUT", headers: hdr(), body: JSON.stringify({ ...pay, status: newStatus }) });
            } else {
                await fetch(`${API}/payments`, {
                    method: "POST", headers: hdr(),
                    body: JSON.stringify({ worker_id: workerId, site_id: siteId, date, ...pay, status: "paid" }),
                });
            }

            setOverrides((prev) => {
                const next = { ...prev };
                delete next[`${workerId}_${siteId}`];
                return next;
            });
            await refreshPayments();
        } catch (e) { setMsg("Error: " + e.message); }
    };

    /* ── approve OT request directly from salary sheet ── */
    const handleApproveOt = async (otId) => {
        try {
            const r = await fetch(`${API}/ot-requests/${otId}/approve`, { method: "PUT", headers: hdr() });
            if (r.ok) {
                flash("OT Approved!");
                await fetchAll();
            } else {
                flash("Error approving OT");
            }
        } catch (e) {
            flash("Error: " + e.message);
        }
    };

    /* ── save single worker payment ── */
    const handleSaveWorker = async (workerId, siteId) => {
        const pay = getWorkerPay(workerId, siteId);
        const existing = getPayment(workerId, siteId);
        try {
            if (existing) {
                await fetch(`${API}/payments/${existing.id}`, { method: "PUT", headers: hdr(), body: JSON.stringify(pay) });
            } else {
                await fetch(`${API}/payments`, {
                    method: "POST", headers: hdr(),
                    body: JSON.stringify({ worker_id: workerId, site_id: siteId, date, ...pay }),
                });
            }
            flash("Saved!");

            setOverrides((prev) => {
                const next = { ...prev };
                delete next[`${workerId}_${siteId}`];
                return next;
            });
            await refreshPayments();
        } catch (e) { setMsg("Error: " + e.message); }
    };

    /* ── pay all in site ── */
    const handlePayAllSite = async (siteId) => {
        const wIds = deployedBySite[siteId] || [];
        for (const wid of wIds) {
            if (!isPresent(wid, siteId)) continue;
            const pay = getWorkerPay(wid, siteId);
            const existing = getPayment(wid, siteId);
            try {
                const recorderData = {
                    recorded_by_name: getCurrentUser().full_name || getCurrentUser().name || "Admin",
                    recorded_by_role: getCurrentUser().role || "admin"
                };
                if (existing) {
                    await fetch(`${API}/payments/${existing.id}`, { method: "PUT", headers: hdr(), body: JSON.stringify({ ...pay, status: "paid", ...recorderData }) });
                } else {
                    await fetch(`${API}/payments`, {
                        method: "POST", headers: hdr(),
                        body: JSON.stringify({ worker_id: wid, site_id: siteId, date, ...pay, status: "paid", ...recorderData }),
                    });
                }
            } catch { /* skip */ }
        }
        flash("All present workers marked as paid!");

        setOverrides((prev) => {
            const next = { ...prev };
            wIds.forEach((wid) => { delete next[`${wid}_${siteId}`]; });
            return next;
        });
        await refreshPayments();
    };

    /* ── CSV export ── */
    const exportCSV = () => {
        let csv = "Site,Worker,Daily Rate,Normal Hrs,OT Hrs (Approved),Base Pay,OT Pay,Deductions (Advances),Net Pay,Status\n";
        allSiteIds.forEach((sId) => {
            (deployedBySite[sId] || []).forEach((wid) => {
                const w = getWorker(wid);
                const pay = getWorkerPay(wid, sId);
                csv += `"${getSiteName(sId)}","${w?.full_name || w?.name || wid}",${pay.daily_rate},${pay.normal_hours},${pay.ot_hours},${pay.base_pay},${pay.ot_pay},${pay.deductions},${pay.net_pay},${pay.status}\n`;
            });
        });
        const blob = new Blob([csv], { type: "text/csv" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = `salary_sheet_${date}.csv`;
        a.click();
    };

    /* ── summary totals ── */
    const totals = (() => {
        let basePay = 0, otPay = 0, deductions = 0, netPay = 0, paid = 0, absent = 0, workerCount = 0;
        allSiteIds.forEach((sId) => {
            (deployedBySite[sId] || []).forEach((wid) => {
                workerCount++;
                if (!isPresent(wid, sId)) { absent++; return; }
                const pay = getWorkerPay(wid, sId);
                basePay += pay.base_pay;
                otPay += pay.ot_pay;
                deductions += pay.deductions;
                netPay += pay.net_pay;
                if (pay.status === "paid") paid++;
            });
        });
        return { sites: allSiteIds.length, workerCount, absent, paid, basePay, otPay, deductions, netPay };
    })();

    const th = { padding: "10px 8px", fontSize: 11, fontWeight: 700, color: "var(--text-soft)", textAlign: "left", borderBottom: "2px solid var(--border-subtle)", background: "var(--table-header-bg)", whiteSpace: "nowrap" };
    const td = { padding: "8px", fontSize: 12, borderBottom: "1px solid var(--border-subtle)", color: "var(--text-primary)" };
    const inputS = { width: 60, padding: "4px 6px", border: "1px solid var(--input-border)", borderRadius: 6, fontSize: 12, textAlign: "right", background: "var(--input-bg)", color: "var(--input-text)" };
    const card = (label, value, color) => (
        <div className="finance-card">
            <div className="finance-card-label">{label}</div>
            <div className="finance-card-val" style={{ color: color || "var(--text-primary)" }}>{value}</div>
        </div>
    );

    return (
        <div>
            {/* Professional letterhead — visible only when printing */}
            <PrintHeader title="Daily Salary Sheet" subtitle={`Payroll for ${date}`} />

            {/* controls — hidden on print */}
            <div className="no-print" style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap", marginBottom: 16 }}>

                <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="modern-input" style={{ width: "auto" }} />
                <button onClick={fetchAll} disabled={loading} className="btn-sys btn-primary">
                    {loading ? "Loading..." : "Refresh Data"}
                </button>
                <PrintButton label="Print / Save PDF" />

                <button onClick={exportCSV} className="btn-sys btn-secondary">Export CSV</button>
                {isSiteOfficer && (
                    <span style={{ fontSize: 11, color: "#f59e0b", fontWeight: 600, background: "#fffbeb", padding: "4px 10px", borderRadius: 6 }}>
                        Showing your assigned sites only
                    </span>
                )}
                {msg && <span style={{ fontSize: 12, color: msg.startsWith("Error") ? "#ef4444" : "#16a34a", fontWeight: 600 }}>{msg}</span>}
            </div>


            {/* summary cards */}
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 20 }}>
                {card("Sites", totals.sites, "#2563eb")}
                {card("Workers", totals.workerCount)}
                {card("Absent", totals.absent, "#f59e0b")}
                {card("Paid", totals.paid, "#16a34a")}
                {card("Base Pay", currency(totals.basePay))}
                {card("OT Pay", currency(totals.otPay), "#7c3aed")}
                {card("Deductions (Advances)", currency(totals.deductions), "#ef4444")}
                {card("Net Pay", currency(totals.netPay), "#059669")}
            </div>

            {allSiteIds.length === 0 && !loading && (
                <div style={{ textAlign: "center", padding: 40, color: "var(--text-muted)" }}>
                    {isSiteOfficer ? "No deployments found for your assigned sites on this date." : "No deployments found for this date."}
                </div>
            )}

            {/* per-site tables */}
            {allSiteIds.map((sId) => {
                const wIds = deployedBySite[sId] || [];
                return (
                    <div key={sId} style={{ background: "var(--bg-surface)", borderRadius: 12, border: "1px solid var(--border-subtle)", marginBottom: 20, overflow: "hidden", boxShadow: "var(--shadow-sm)" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 16px", background: "var(--table-header-bg)", borderBottom: "1px solid var(--border-subtle)", flexWrap: "wrap", gap: 8 }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                                <span style={{ fontWeight: 700, fontSize: 14, color: "var(--text-primary)" }}>{getSiteName(sId)}</span>
                                <span style={{ fontSize: 11, color: "var(--text-muted)" }}>({wIds.length} workers)</span>
                                {getAssignedOfficer(sId) && (
                                    <span style={{ fontSize: 11, color: "#2563eb", background: "#eff6ff", padding: "2px 10px", borderRadius: 20, fontWeight: 600 }}>
                                        Officer: {getAssignedOfficer(sId)}
                                    </span>
                                )}
                            </div>
                            <button onClick={() => handlePayAllSite(sId)} className="btn-sys btn-success">
                                Pay All Present
                            </button>
                        </div>
                        <div style={{ overflowX: "auto" }}>
                            <table className="finance-table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Worker</th>
                                        <th>Status</th>
                                        <th>Daily Rate</th>
                                        <th>Hrs</th>
                                        <th>OT Hrs</th>
                                        <th>Base Pay</th>
                                        <th>OT Pay</th>
                                        <th>Advances</th>
                                        <th>Net Pay</th>
                                        <th className="no-print">Paid</th>
                                        <th className="no-print">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {wIds.map((wid, idx) => {
                                        const w = getWorker(wid);
                                        const present = isPresent(wid, sId);
                                        const pay = getWorkerPay(wid, sId);
                                        const deductionExceeds = pay.deductions > (pay.base_pay + pay.ot_pay);
                                        return (
                                            <tr key={wid} style={{ background: !present ? "rgba(239,68,68,0.08)" : "" }}>
                                                <td>{idx + 1}</td>
                                                <td style={{ fontWeight: 800, color: "var(--text-primary)" }}>
                                                     {w?.full_name || w?.name || wid}
                                                     {w?.is_archived && <span className="archived-badge">deleted</span>}
                                                 </td>
                                                <td>
                                                    <span className={`status-badge ${present ? 'badge-present' : 'badge-absent'}`}>{present ? "Present" : "Absent"}</span>
                                                </td>
                                                <td>
                                                    {present ? (
                                                        <input type="number" min="0" step="100" value={getOvr(wid, sId, "daily_rate") ?? pay.daily_rate}
                                                            onChange={(e) => {
                                                                const val = e.target.value;
                                                                if (val === "") setOvr(wid, sId, "daily_rate", undefined);
                                                                else setOvr(wid, sId, "daily_rate", Math.max(0, Number(val)));
                                                            }}
                                                            className="modern-input"
                                                            style={{
                                                                border: getOvr(wid, sId, "daily_rate") !== undefined ? "1.5px solid #2563eb" : "",
                                                                background: getOvr(wid, sId, "daily_rate") !== undefined ? "rgba(37,99,235,0.12)" : ""
                                                            }}
                                                        />
                                                    ) : "-"}
                                                </td>
                                                <td>
                                                    {present ? (
                                                        <input type="number" min="0" max="24" step="0.5" value={getOvr(wid, sId, "normal_hours") ?? pay.normal_hours}
                                                            onChange={(e) => setOvr(wid, sId, "normal_hours", Math.max(0, Number(e.target.value)))} className="modern-input" style={{ width: 50 }} />
                                                    ) : "-"}
                                                </td>
                                                {/* OT Hours — editable, shows approved value as default */}
                                                <td>
                                                    {present ? (() => {
                                                        const otRec = getOtRecord(wid, sId);
                                                        return (
                                                        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                                                            <input type="number" min="0" max="12" step="0.5"
                                                                value={getOvr(wid, sId, "ot_hours") ?? pay.ot_hours}
                                                                onChange={(e) => setOvr(wid, sId, "ot_hours", Math.max(0, Number(e.target.value)))}
                                                                className="modern-input"
                                                                style={{
                                                                    width: 50,
                                                                    border: pay.ot_hours > 0 ? "1.5px solid #7c3aed" : "",
                                                                    background: pay.ot_hours > 0 ? "rgba(124,58,237,0.12)" : "",
                                                                    color: pay.ot_hours > 0 ? "#7c3aed" : "",
                                                                    fontWeight: pay.ot_hours > 0 ? 800 : 500,
                                                                }}
                                                            />
                                                            {otRec && otRec.status === "pending" && (
                                                                <button
                                                                    onClick={() => handleApproveOt(otRec.id)}
                                                                    className="btn-sys"
                                                                    style={{ background: "#16a34a", color: "#fff", padding: "4px 8px", fontSize: 10, minWidth: "auto", boxShadow: "0 2px 4px rgba(22,163,74,0.2)" }}
                                                                    title="Approve OT Request"
                                                                >
                                                                    Approve
                                                                </button>
                                                            )}
                                                        </div>
                                                        );
                                                    })() : "-"}
                                                </td>
                                                {/* Base Pay — editable */}
                                                <td>
                                                    {present ? (
                                                        <input type="number" min="0" step="50"
                                                            value={getOvr(wid, sId, "base_pay") ?? pay.base_pay}
                                                            onChange={(e) => setOvr(wid, sId, "base_pay", Math.max(0, Number(e.target.value)))}
                                                            className="modern-input" style={{ width: 80 }}
                                                        />
                                                    ) : "-"}
                                                </td>
                                                {/* OT Pay — directly editable */}
                                                <td>
                                                    {present ? (
                                                        <input type="number" min="0" step="50"
                                                            value={getOvr(wid, sId, "ot_pay") ?? pay.ot_pay}
                                                            onChange={(e) => setOvr(wid, sId, "ot_pay", Math.max(0, Number(e.target.value)))}
                                                            className="modern-input"
                                                            style={{
                                                                width: 80,
                                                                border: pay.ot_pay > 0 ? "1.5px solid #7c3aed" : "",
                                                                background: pay.ot_pay > 0 ? "rgba(124,58,237,0.12)" : "",
                                                                color: pay.ot_pay > 0 ? "#7c3aed" : "",
                                                                fontWeight: pay.ot_pay > 0 ? 800 : 500,
                                                            }}
                                                        />
                                                    ) : "-"}
                                                </td>
                                                {/* Deductions */}
                                                <td>
                                                    {present ? (
                                                        <div>
                                                            <input type="number" min="0" step="100"
                                                                value={getOvr(wid, sId, "deductions") ?? pay.deductions}
                                                                onChange={(e) => setOvr(wid, sId, "deductions", Math.max(0, Number(e.target.value)))}
                                                                className="modern-input"
                                                                style={{
                                                                    width: 80,
                                                                    border: deductionExceeds ? "1.5px solid #f59e0b" : "1px solid #ef4444",
                                                                    background: deductionExceeds ? "rgba(245,158,11,0.12)" : "rgba(239,68,68,0.1)",
                                                                    color: "#ef4444"
                                                                }}
                                                                title={deductionExceeds ? "Deductions exceed earnings" : ""}
                                                            />
                                                            {deductionExceeds && (
                                                                <div style={{ fontSize: 9, color: "#f59e0b", marginTop: 2, fontWeight: 700 }}>EXCEEDS PAY</div>
                                                            )}
                                                        </div>
                                                    ) : "-"}
                                                </td>
                                                {/* Net Pay */}
                                                <td style={{ fontWeight: 800, color: "#059669" }}>{present ? currency(pay.net_pay) : "-"}</td>
                                                <td className="no-print">
                                                    {present ? (
                                                        <input type="checkbox" checked={pay.status === "paid"}
                                                            onChange={() => togglePaid(wid, sId)}
                                                            style={{ width: 18, height: 18, cursor: "pointer", accentColor: "#16a34a" }} />
                                                    ) : "-"}
                                                </td>
                                                <td className="no-print">
                                                    {present ? (
                                                        <div style={{ display: "flex", gap: 6 }}>
                                                            <button onClick={() => handleSaveWorker(wid, sId)} className="btn-sys btn-primary" style={{ padding: "6px 12px", fontSize: 11 }}>
                                                                Save
                                                            </button>
                                                            {overrides[`${wid}_${sId}`] && (
                                                                <button onClick={() => {
                                                                    setOverrides((prev) => {
                                                                        const next = { ...prev };
                                                                        delete next[`${wid}_${sId}`];
                                                                        return next;
                                                                    });
                                                                }} className="btn-sys btn-secondary" style={{ padding: "6px 12px", fontSize: 11 }}>
                                                                    Reset
                                                                </button>
                                                            )}
                                                        </div>
                                                    ) : "-"}
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                );
            })}
        </div>
    );
}

/* ══════════════════════════════════════════════
   TAB 2 — PAYMENT LOG
   ══════════════════════════════════════════════ */
function PaymentLog() {
    const [payments, setPayments] = useState([]);
    const [workers, setWorkers] = useState([]);
    const [sites, setSites] = useState([]);
    const [deletedEntities, setDeletedEntities] = useState([]);
    const [filterDate, setFilterDate] = useState("");
    const [filterWorker, setFilterWorker] = useState("");
    const [filterSite, setFilterSite] = useState("");
    const [filterStatus, setFilterStatus] = useState("");
    const [loading, setLoading] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editData, setEditData] = useState(null);
    const [modalMsg, setModalMsg] = useState("");

    const fetchData = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (filterDate) params.append("date", filterDate);
            if (filterWorker) params.append("worker_id", filterWorker);
            if (filterSite) params.append("site_id", filterSite);
            if (filterStatus) params.append("status", filterStatus);

            const [pR, wR, sR, deR] = await Promise.all([
                fetch(`${API}/payments?${params}`, { headers: hdr() }),
                fetch(`${API}/workers?archived=true`, { headers: hdr() }),
                fetch(`${API}/fields?archived=true`, { headers: hdr() }),
                fetch(`${API}/deleted-entities?type=worker,site`, { headers: hdr() }),
            ]);
            const [p, w, s, de] = await Promise.all([pR.json(), wR.json(), sR.json(), deR.json()]);
            setPayments(Array.isArray(p) ? p : []);
            setWorkers(Array.isArray(w) ? w : []);
            setSites(Array.isArray(s) ? s : []);
            setDeletedEntities(Array.isArray(de) ? de : []);
        } catch { /* ignore */ }
        setLoading(false);
    }, [filterDate, filterWorker, filterSite, filterStatus]);

    useEffect(() => { fetchData(); }, [fetchData]);

    const getWorkerName = (id) => {
        if (!id) return "General / Site Exp";
        const w = workers.find((x) => x.id === id);
        return w?.full_name || w?.name || deletedEntities.find(e => e.entity_id === id)?.entity_name || id;
    };
    const getSiteName = (id) => (sites.find((s) => s.id === id) || {}).name || deletedEntities.find(e => e.entity_id === id)?.entity_name || id;
    const deletedMap = Object.fromEntries(deletedEntities.map(e => [e.entity_id, e]));
    const workerNode = (id) => { const w = workers.find((x) => x.id === id); if (!w) { const snap = deletedMap[id]; return (<>{snap?.entity_name || "Deleted Worker"} <span className="archived-badge">deleted</span></>); } return (<>{w?.full_name || w?.name}{w?.is_archived && <span className="archived-badge">deleted</span>}</>); };
    const siteNode = (id) => { const s = sites.find((x) => x.id === id); if (!s) { const snap = deletedMap[id]; return (<>{snap?.entity_name || "Deleted Site"} <span className="archived-badge">deleted</span></>); } return (<>{s?.name}{s?.is_archived && <span className="archived-badge">deleted</span>}</>); };

    const handleDelete = async (id) => {
        if (!confirm("Delete this payment record?")) return;
        try {
            await fetch(`${API}/payments/${id}`, { method: "DELETE", headers: hdr() });
            fetchData();
        } catch { /* ignore */ }
    };

    const handleSaveModal = async (data) => {
        setLoading(true);
        setModalMsg("");
        try {
            const isEdit = !!data.id;
            const url = isEdit ? `${API}/payments/${data.id}` : `${API}/payments`;
            const method = isEdit ? "PUT" : "POST";

            const recorderData = {
                recorded_by_name: getCurrentUser().full_name || getCurrentUser().name || "Admin",
                recorded_by_role: getCurrentUser().role || "admin"
            };

            const res = await fetch(url, {
                method,
                headers: hdr(),
                body: JSON.stringify({ ...data, ...recorderData })
            });

            if (!res.ok) {
                const err = await res.json();
                throw new Error(err.error || "Save failed");
            }

            setIsModalOpen(false);
            setEditData(null);
            fetchData();
        } catch (e) {
            setModalMsg(e.message);
        } finally {
            setLoading(false);
        }
    };

    const summary = (() => {
        let paid = 0, pending = 0, total = 0;
        payments.forEach((p) => {
            total += Number(p.net_pay || 0);
            if (p.status === "paid") paid += Number(p.net_pay || 0);
            else pending += Number(p.net_pay || 0);
        });
        return { records: payments.length, paid, pending, total };
    })();

    const exportCSV = () => {
        let csv = "Date,Worker,Site,Daily Rate,Hrs,OT Hrs,Base Pay,OT Pay,Deductions (Advances),Net Pay,Status,Category,Method,Reference\n";
        payments.forEach((p) => {
            csv += `${p.date},"${getWorkerName(p.worker_id)}","${getSiteName(p.site_id)}",${p.daily_rate},${p.normal_hours},${p.ot_hours},${p.base_pay},${p.ot_pay},${p.deductions},${p.net_pay},${p.status},"${p.category || "salary"}","${p.method || "cash"}","${p.reference || ""}"\n`;
        });
        const blob = new Blob([csv], { type: "text/csv" });
        const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `payment_log.csv`; a.click();
    };

    const th = { padding: "10px 8px", fontSize: 11, fontWeight: 700, color: "#64748b", textAlign: "left", borderBottom: "2px solid #e2e8f0", background: "#f8fafc", whiteSpace: "nowrap" };
    const td = { padding: "8px", fontSize: 12, borderBottom: "1px solid #f1f5f9" };
    const card = (label, value, color) => (
        <div style={{ flex: "1 1 140px", background: "#fff", borderRadius: 10, padding: "14px 16px", border: "1px solid #e2e8f0" }}>
            <div style={{ fontSize: 11, color: "#64748b", marginBottom: 4 }}>{label}</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: color || "#1e293b" }}>{value}</div>
        </div>
    );

    const groupedPayments = (() => {
        const groups = {};
        payments.forEach(p => {
            if (!groups[p.site_id]) groups[p.site_id] = [];
            groups[p.site_id].push(p);
        });
        return groups;
    })();

    return (
        <div>
            {/* Letterhead — print only */}
            <PrintHeader title="Payment Records" subtitle="Financial transaction log" />

            {/* filters — hidden on print */}
            <div className="no-print" style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 16, alignItems: "center" }}>

                <input type="date" value={filterDate} onChange={(e) => setFilterDate(e.target.value)} className="modern-input" style={{ width: "auto" }} />
                <select value={filterWorker} onChange={(e) => setFilterWorker(e.target.value)} className="modern-select">
                    <option value="">All Workers</option>
                    {workers.map((w) => <option key={w.id} value={w.id}>{w.full_name || w.name}</option>)}
                </select>
                <select value={filterSite} onChange={(e) => setFilterSite(e.target.value)} className="modern-select">
                    <option value="">All Sites</option>
                    {sites.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
                <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="modern-select">
                    <option value="">All Statuses</option>
                    <option value="paid">Paid</option>
                    <option value="pending">Pending</option>
                </select>
                <button onClick={fetchData} disabled={loading} className="btn-sys btn-primary">
                    {loading ? "Searching..." : "Apply Filters"}
                </button>
                <button onClick={exportCSV} className="btn-sys btn-secondary">
                    Export CSV
                </button>
                <PrintButton label="Print" />

                <div style={{ flex: 1 }}></div>
                <button onClick={() => { setEditData(null); setIsModalOpen(true); }} className="btn-sys btn-success">
                    + Record Manual Payment
                </button>
            </div>

            {/* summary */}
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 20 }}>
                {card("Records", summary.records)}
                {card("Paid", currency(summary.paid), "#16a34a")}
                {card("Pending", currency(summary.pending), "#f59e0b")}
                {card("Total", currency(summary.total), "#2563eb")}
            </div>

            {/* tables grouped by site */}
            {Object.keys(groupedPayments).length === 0 ? (
                <div style={{ background: "var(--bg-surface)", borderRadius: 12, border: "1px solid var(--border-subtle)", textAlign: "center", padding: 30, color: "var(--text-muted)" }}>
                    No payment records found
                </div>
            ) : Object.entries(groupedPayments).map(([siteId, groupPayments]) => {
                let siteTotal = 0, sitePaid = 0, sitePending = 0;
                groupPayments.forEach(p => {
                    siteTotal += Number(p.net_pay || 0);
                    if (p.status === "paid") sitePaid += Number(p.net_pay || 0);
                    else sitePending += Number(p.net_pay || 0);
                });

                return (
                    <div key={siteId} style={{ background: "var(--bg-surface)", borderRadius: 12, border: "1px solid var(--border-subtle)", overflow: "hidden", marginBottom: 20, boxShadow: "var(--shadow-sm)" }}>
                        {/* Site header */}
                        <div style={{ padding: "12px 16px", background: "var(--table-header-bg)", borderBottom: "1px solid var(--border-subtle)", display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10 }}>
                            <div>
                                <span style={{ fontWeight: 700, color: "var(--text-primary)", marginRight: 12 }}>
                                    {siteNode(siteId)}
                                    <span style={{ fontSize: 11, color: "var(--text-muted)", fontWeight: 500 }}> ({groupPayments.length} records)</span>
                                </span>
                            </div>
                            <div style={{ fontSize: 13, display: "flex", gap: 16, color: "var(--text-soft)" }}>
                                <span>Paid: <span style={{ fontWeight: 700, color: "#16a34a" }}>{currency(sitePaid)}</span></span>
                                <span>Pending: <span style={{ fontWeight: 700, color: "#f59e0b" }}>{currency(sitePending)}</span></span>
                                <span style={{ borderLeft: "1px solid var(--border-subtle)", paddingLeft: 16 }}>Total: <span style={{ fontWeight: 700, color: "var(--text-primary)" }}>{currency(siteTotal)}</span></span>
                            </div>
                        </div>

                        {/* table for this site */}
                        <div style={{ overflowX: "auto" }}>
                            <table className="finance-table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Date</th>
                                        <th>Worker</th>
                                        <th>Daily Rate</th>
                                        <th>Hrs</th>
                                        <th>OT</th>
                                        <th>Base</th>
                                        <th>OT Pay</th>
                                        <th>Advances</th>
                                        <th>Net Pay</th>
                                        <th>Status</th>
                                        <th>Category</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {groupPayments.map((p, i) => {
                                        const isSal = ["salary", "advance", "bonus"].includes(p.category || "salary");
                                        return (
                                            <tr key={p.id}>
                                                <td>{i + 1}</td>
                                                <td>{p.date}</td>
                                                <td style={{ fontWeight: 800, color: "#0f172a" }}>{workerNode(p.worker_id)}</td>
                                                <td>{isSal ? currency(p.daily_rate) : "—"}</td>
                                                <td>{isSal ? p.normal_hours : "—"}</td>
                                                <td style={{ color: Number(p.ot_hours) > 0 ? "#7c3aed" : undefined, fontWeight: 700 }}>{isSal ? p.ot_hours : "—"}</td>
                                                <td>{isSal ? currency(p.base_pay) : "—"}</td>
                                                <td style={{ color: "#7c3aed", fontWeight: 700 }}>{isSal ? currency(p.ot_pay) : "—"}</td>
                                                <td style={{ color: "#ef4444", fontWeight: 700 }}>{currency(p.deductions)}</td>
                                                <td style={{ fontWeight: 800, color: "#059669" }}>{currency(p.net_pay)}</td>
                                                <td>
                                                    <span className={`status-badge ${p.status === 'paid' ? 'badge-paid' : 'badge-pending'}`}>{p.status === 'paid' ? 'Settled' : 'Pending'}</span>
                                                </td>
                                                <td>
                                                    <span style={{ fontSize: 10, fontWeight: 800, color: "#64748b", textTransform: "uppercase", letterSpacing: "0.05em", padding: "4px 8px", background: "#f8fafc", borderRadius: 6, border: "1px solid #e2e8f0" }}>{p.category || "salary"}</span>
                                                </td>
                                                <td>
                                                    <div style={{ display: "flex", gap: 6 }}>
                                                        <button onClick={() => { setEditData(p); setIsModalOpen(true); }} className="btn-sys btn-secondary" style={{ padding: "6px 12px", fontSize: 11 }}>
                                                            Edit
                                                        </button>
                                                        <button onClick={() => handleDelete(p.id)} className="btn-sys" style={{ padding: "6px 12px", fontSize: 11, background: "#fef2f2", color: "#dc2626", border: "1px solid #fecaca" }}>
                                                            Delete
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                );
            })}


            {isModalOpen && (
                <PaymentModal
                    data={editData}
                    workers={workers}
                    sites={sites}
                    onClose={() => setIsModalOpen(false)}
                    onSave={handleSaveModal}
                    loading={loading}
                    error={modalMsg}
                />
            )}
        </div>
    );
}

function PaymentModal({ data, workers, sites, onClose, onSave, loading, error }) {
    const isEdit = !!data?.id;
    const [form, setForm] = useState({
        worker_id: data?.worker_id || "",
        site_id: data?.site_id || "",
        date: data?.date || new Date().toISOString().slice(0, 10),
        category: data?.category || "salary",
        amount: data?.net_pay || 0,
        method: data?.method || "cash",
        reference: data?.reference || "",
        notes: data?.notes || ""
    });

    const isSalary = form.category === "salary" || form.category === "bonus" || form.category === "advance";

    return (
        <div style={{ position: "fixed", top: 0, left: 0, right: 0, bottom: 0, background: "rgba(15,23,42,0.6)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, backdropFilter: "blur(6px)" }}>
            <div style={{ background: "#ffffff", borderRadius: 16, width: "100%", maxWidth: 500, padding: 30, boxShadow: "0 25px 50px -12px rgba(0,0,0,0.25)", border: "1px solid #e2e8f0" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 24, alignItems: "center" }}>
                    <h3 style={{ margin: 0, fontSize: 20, fontWeight: 800, color: "#0f172a" }}>{isEdit ? "Edit Financial Record" : "Record New Payment"}</h3>
                    <button onClick={onClose} style={{ background: "#f1f5f9", border: "none", width: 32, height: 32, borderRadius: 16, fontSize: 18, color: "#64748b", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>&times;</button>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, maxHeight: "65vh", overflowY: "auto", paddingRight: 8 }}>
                    <div style={{ gridColumn: "span 2" }}>
                        <label style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Category</label>
                        <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="modern-select" style={{ width: "100%" }}>
                            <option value="salary">Daily Salary</option>
                            <option value="advance">Salary Advance</option>
                            <option value="bonus">Bonus / Incentive</option>
                            <option value="material">Material Expense</option>
                            <option value="fuel">Fuel / Transport</option>
                            <option value="repair">Maintenance / Repair</option>
                            <option value="utilities">Utilities (Water/Elec)</option>
                            <option value="other">Other Expense</option>
                        </select>
                    </div>

                    <div>
                        <label style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Site</label>
                        <select value={form.site_id} onChange={e => setForm({ ...form, site_id: e.target.value })} className="modern-select" style={{ width: "100%" }}>
                            <option value="">No Site / General</option>
                            {sites.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                        </select>
                    </div>

                    <div>
                        <label style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", display: "block", marginBottom: 6 }}>{isSalary ? "Worker" : "Recipient (Optional)"}</label>
                        <select value={form.worker_id} onChange={e => setForm({ ...form, worker_id: e.target.value })} className="modern-select" style={{ width: "100%" }}>
                            <option value="">None</option>
                            {workers.map(w => <option key={w.id} value={w.id}>{w.full_name || w.name}</option>)}
                        </select>
                    </div>

                    <div>
                        <label style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Date</label>
                        <input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} className="modern-input" style={{ width: "100%", textAlign: "left" }} />
                    </div>

                    <div>
                        <label style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Amount (Rs)</label>
                        <input type="number" value={form.amount} onChange={e => setForm({ ...form, amount: Math.max(0, Number(e.target.value)) })} className="modern-input" style={{ width: "100%", textAlign: "left", fontWeight: 700, color: "#0f172a" }} />
                    </div>

                    <div>
                        <label style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Method</label>
                        <select value={form.method} onChange={e => setForm({ ...form, method: e.target.value })} className="modern-select" style={{ width: "100%" }}>
                            <option value="cash">Cash</option>
                            <option value="bank">Bank Transfer</option>
                            <option value="cheque">Cheque</option>
                        </select>
                    </div>

                    <div>
                        <label style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Reference #</label>
                        <input type="text" value={form.reference} onChange={e => setForm({ ...form, reference: e.target.value })} placeholder="e.g. TxID, Cheque #" className="modern-input" style={{ width: "100%", textAlign: "left" }} />
                    </div>

                    <div style={{ gridColumn: "span 2" }}>
                        <label style={{ fontSize: 11, fontWeight: 700, color: "#64748b", textTransform: "uppercase", display: "block", marginBottom: 6 }}>Notes</label>
                        <textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Details about this payment..." className="modern-input" style={{ width: "100%", textAlign: "left", minHeight: 60, fontFamily: "inherit" }} />
                    </div>
                </div>

                {error && <div style={{ marginTop: 15, padding: 10, background: "#fef2f2", color: "#ef4444", borderRadius: 8, fontSize: 12, fontWeight: 600 }}>{error}</div>}

                <div style={{ display: "flex", gap: 10, marginTop: 24, paddingTop: 20, borderTop: "1px solid #e2e8f0" }}>
                    <button onClick={onClose} className="btn-sys btn-secondary" style={{ flex: 1, padding: "12px", justifyContent: "center" }}>Cancel</button>
                    <button onClick={() => onSave({
                        ...form,
                        id: data?.id,
                        net_pay: form.amount,
                        base_pay: isSalary ? undefined : 0,
                        ot_pay: isSalary ? undefined : 0
                    })} disabled={loading} className="btn-sys btn-primary" style={{ flex: 2, padding: "12px", justifyContent: "center" }}>
                        {loading ? "Saving..." : isEdit ? "Update Payment" : "Save Payment"}
                    </button>
                </div>
            </div>
        </div>
    );
}



/* ══════════════════════════════════════════════
   TAB 3 — MONTHLY PAYROLL
   ══════════════════════════════════════════════ */
function PayrollTab() {
    const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));
    const [payments, setPayments] = useState([]);
    const [workers, setWorkers] = useState([]);
    const [sites, setSites] = useState([]);
    const [deletedEntities, setDeletedEntities] = useState([]);
    const [loading, setLoading] = useState(false);
    const [view, setView] = useState("worker");

    const generate = useCallback(async () => {
        setLoading(true);
        try {
            const [y, m] = month.split("-").map(Number);
            const start = `${month}-01`;
            const end = `${y}-${String(m).padStart(2, "0")}-${new Date(y, m, 0).getDate()}`;
            const [pR, wR, sR, deR] = await Promise.all([
                fetch(`${API}/payments?from=${start}&to=${end}`, { headers: hdr() }),
                fetch(`${API}/workers?archived=true`, { headers: hdr() }),
                fetch(`${API}/fields?archived=true`, { headers: hdr() }),
                fetch(`${API}/deleted-entities?type=worker,site`, { headers: hdr() }),
            ]);
            const [p, w, s, de] = await Promise.all([pR.json(), wR.json(), sR.json(), deR.json()]);
            setPayments(Array.isArray(p) ? p : []);
            setWorkers(Array.isArray(w) ? w : []);
            setSites(Array.isArray(s) ? s : []);
            setDeletedEntities(Array.isArray(de) ? de : []);
        } catch { /* ignore */ }
        setLoading(false);
    }, [month]);

    const getWorkerName = (id) => { const w = workers.find((x) => x.id === id); return w?.full_name || w?.name || deletedEntities.find(e => e.entity_id === id)?.entity_name || id; };
    const getSiteName = (id) => (sites.find((s) => s.id === id) || {}).name || deletedEntities.find(e => e.entity_id === id)?.entity_name || id;
    const deletedMap = Object.fromEntries(deletedEntities.map(e => [e.entity_id, e]));
    const workerNode = (id) => { const w = workers.find((x) => x.id === id); if (!w) { const snap = deletedMap[id]; return (<>{snap?.entity_name || "Deleted Worker"} <span className="archived-badge">deleted</span></>); } return (<>{w?.full_name || w?.name}{w?.is_archived && <span className="archived-badge">deleted</span>}</>); };
    const siteNode = (id) => { const s = sites.find((x) => x.id === id); if (!s) { const snap = deletedMap[id]; return (<>{snap?.entity_name || "Deleted Site"} <span className="archived-badge">deleted</span></>); } return (<>{s?.name}{s?.is_archived && <span className="archived-badge">deleted</span>}</>); };

    const byWorker = (() => {
        const map = {};
        payments.forEach((p) => {
            const isSal = ["salary", "advance", "bonus"].includes(p.category || "salary");
            if (!isSal) return; // Skip non-salary items for payroll totals

            if (!map[p.worker_id]) map[p.worker_id] = { days: 0, base: 0, ot: 0, otHrs: 0, deductions: 0, net: 0, paid: 0, pending: 0 };
            const m = map[p.worker_id];
            m.days++;
            m.base += Number(p.base_pay || 0);
            m.ot += Number(p.ot_pay || 0);
            m.otHrs += Number(p.ot_hours || 0);
            m.deductions += Number(p.deductions || 0);
            m.net += Number(p.net_pay || 0);
            if (p.status === "paid") m.paid += Number(p.net_pay || 0);
            else m.pending += Number(p.net_pay || 0);
        });
        return Object.entries(map).map(([wid, v]) => ({ wid, ...v }));
    })();

    const bySite = (() => {
        const map = {};
        payments.forEach((p) => {
            const isSal = ["salary", "advance", "bonus"].includes(p.category || "salary");
            if (!isSal) return; // Skip non-salary items for payroll totals

            if (!map[p.site_id]) map[p.site_id] = { days: 0, base: 0, ot: 0, otHrs: 0, deductions: 0, net: 0, paid: 0, pending: 0 };
            const m = map[p.site_id];
            m.days++;
            m.base += Number(p.base_pay || 0);
            m.ot += Number(p.ot_pay || 0);
            m.otHrs += Number(p.ot_hours || 0);
            m.deductions += Number(p.deductions || 0);
            m.net += Number(p.net_pay || 0);
            if (p.status === "paid") m.paid += Number(p.net_pay || 0);
            else m.pending += Number(p.net_pay || 0);
        });
        return Object.entries(map).map(([sid, v]) => ({ sid, ...v }));
    })();

    const totalSummary = (() => {
        let base = 0, ot = 0, ded = 0, net = 0, paid = 0, pending = 0;
        payments.forEach((p) => {
            const isSal = ["salary", "advance", "bonus"].includes(p.category || "salary");
            if (!isSal) return;

            base += Number(p.base_pay || 0); ot += Number(p.ot_pay || 0);
            ded += Number(p.deductions || 0); net += Number(p.net_pay || 0);
            if (p.status === "paid") paid += Number(p.net_pay || 0);
            else pending += Number(p.net_pay || 0);
        });
        return { workers: byWorker.length, days: payments.length, paid, pending, total: net };
    })();

    const exportCSV = () => {
        const rows = view === "worker" ? byWorker : bySite;
        let csv = `${view === "worker" ? "Worker" : "Site"},Days,Base Pay,OT Pay,OT Hours,Deductions (Advances),Net Pay,Paid,Pending\n`;
        rows.forEach((r) => {
            const label = view === "worker" ? getWorkerName(r.wid) : getSiteName(r.sid);
            csv += `"${label}${view === "worker" && !workers.find(w => w.id === r.wid) ? " [deleted]" : ""}",${r.days},${r.base.toFixed(2)},${r.ot.toFixed(2)},${r.otHrs},${r.deductions.toFixed(2)},${r.net.toFixed(2)},${r.paid.toFixed(2)},${r.pending.toFixed(2)}\n`;
        });
        const blob = new Blob([csv], { type: "text/csv" });
        const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `payroll_${month}_${view}.csv`; a.click();
    };

    const th = { padding: "10px 8px", fontSize: 11, fontWeight: 700, color: "var(--text-soft)", textAlign: "left", borderBottom: "2px solid var(--border-subtle)", background: "var(--table-header-bg)", whiteSpace: "nowrap" };
    const td = { padding: "8px", fontSize: 12, borderBottom: "1px solid var(--border-subtle)", color: "var(--text-primary)" };
    const card = (label, value, color) => (
        <div className="finance-card">
            <div className="finance-card-label">{label}</div>
            <div className="finance-card-val" style={{ color: color || "#0f172a" }}>{value}</div>
        </div>
    );

    return (
        <div>
            {/* Letterhead — print only */}
            <PrintHeader title="Monthly Payroll Report" subtitle={`Payroll summary for ${month}`} />

            {/* ── Controls (hidden on print) ── */}
            <div className="no-print" style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap", marginBottom: 16 }}>
                <input type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="modern-input" style={{ width: "auto" }} />
                <button onClick={generate} disabled={loading} className="btn-sys btn-primary">
                    {loading ? "Generating..." : "Generate Payroll"}
                </button>
                <PrintButton label="Print Payroll" />

                <div style={{ display: "flex", gap: 4, background: "#f1f5f9", borderRadius: 8, padding: 4 }}>
                    <button onClick={() => setView("worker")}
                        style={{ padding: "6px 14px", borderRadius: 6, border: "none", fontSize: 12, fontWeight: view === "worker" ? 700 : 600, background: view === "worker" ? "#fff" : "transparent", color: view === "worker" ? "#7c3aed" : "#64748b", cursor: "pointer", boxShadow: view === "worker" ? "0 2px 4px rgba(0,0,0,0.05)" : "none" }}>
                        By Worker
                    </button>
                    <button onClick={() => setView("site")}
                        style={{ padding: "6px 14px", borderRadius: 6, border: "none", fontSize: 12, fontWeight: view === "site" ? 700 : 600, background: view === "site" ? "#fff" : "transparent", color: view === "site" ? "#7c3aed" : "#64748b", cursor: "pointer", boxShadow: view === "site" ? "0 2px 4px rgba(0,0,0,0.05)" : "none" }}>
                        By Site
                    </button>
                </div>
                <button onClick={exportCSV} className="btn-sys btn-secondary">
                    Export CSV
                </button>
            </div>



            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 20 }}>
                {card("Workers", totalSummary.workers)}
                {card("Working Days", totalSummary.days)}
                {card("Paid", currency(totalSummary.paid), "#16a34a")}
                {card("Pending", currency(totalSummary.pending), "#f59e0b")}
                {card("Total", currency(totalSummary.total), "#2563eb")}
            </div>

            <div className="finance-table-wrapper">
                <div style={{ overflowX: "auto" }}>
                    <table className="finance-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>{view === "worker" ? "Worker" : "Site"}</th>
                                <th>Days</th>
                                <th>Base Pay</th>
                                <th>OT Hours</th>
                                <th>OT Pay</th>
                                <th>Advances</th>
                                <th>Net Pay</th>
                                <th>Paid</th>
                                <th>Pending</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(view === "worker" ? byWorker : bySite).length === 0 ? (
                                <tr><td colSpan={10} style={{ textAlign: "center", padding: 30, color: "var(--text-muted)", fontWeight: 600 }}>No payroll data. Select a month and click Generate.</td></tr>
                            ) : (view === "worker" ? byWorker : bySite).map((row, i) => (
                                <tr key={row.wid || row.sid}>
                                    <td>{i + 1}</td>
                                    <td style={{ fontWeight: 800, color: "#0f172a" }}>
                                        {view === "worker" ? workerNode(row.wid) : siteNode(row.sid)}
                                    </td>
                                    <td>{row.days}</td>
                                    <td>{currency(row.base)}</td>
                                    <td style={{ color: row.otHrs > 0 ? "#7c3aed" : "inherit", fontWeight: 700 }}>{row.otHrs}</td>
                                    <td style={{ color: "#7c3aed", fontWeight: 700 }}>{currency(row.ot)}</td>
                                    <td style={{ color: "#ef4444", fontWeight: 700 }}>{currency(row.deductions)}</td>
                                    <td style={{ fontWeight: 800, color: "#059669" }}>{currency(row.net)}</td>
                                    <td style={{ color: "#16a34a", fontWeight: 700 }}>{currency(row.paid)}</td>
                                    <td style={{ color: "#d97706", fontWeight: 700 }}>{currency(row.pending)}</td>
                                </tr>
                            ))}
                            {(view === "worker" ? byWorker : bySite).length > 0 && (
                                <tr className="grand-sum-row" style={{ background: "#f8fafc", fontWeight: 900 }}>
                                    <td></td>
                                    <td style={{ fontWeight: 900 }}>TOTAL GRAND SUM</td>
                                    <td>{(view === "worker" ? byWorker : bySite).reduce((s, r) => s + r.days, 0)}</td>
                                    <td>{currency((view === "worker" ? byWorker : bySite).reduce((s, r) => s + r.base, 0))}</td>
                                    <td>{(view === "worker" ? byWorker : bySite).reduce((s, r) => s + r.otHrs, 0)}</td>
                                    <td style={{ color: "#7c3aed" }}>{currency((view === "worker" ? byWorker : bySite).reduce((s, r) => s + r.ot, 0))}</td>
                                    <td style={{ color: "#ef4444" }}>{currency((view === "worker" ? byWorker : bySite).reduce((s, r) => s + r.deductions, 0))}</td>
                                    <td style={{ color: "#059669" }}>{currency((view === "worker" ? byWorker : bySite).reduce((s, r) => s + r.net, 0))}</td>
                                    <td style={{ color: "#16a34a" }}>{currency((view === "worker" ? byWorker : bySite).reduce((s, r) => s + r.paid, 0))}</td>
                                    <td style={{ color: "#d97706" }}>{currency((view === "worker" ? byWorker : bySite).reduce((s, r) => s + r.pending, 0))}</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

/* ══════════════════════════════════════════════
   TAB — ATTENDANCE VIEW (Read-Only)
   ══════════════════════════════════════════════ */
function AttendanceView() {
    const today = new Date().toISOString().slice(0, 10);
    const [date, setDate] = useState(today);
    const [workers, setWorkers] = useState([]);
    const [sites, setSites] = useState([]);
    const [deployments, setDeployments] = useState([]);
    const [attendance, setAttendance] = useState([]);
    const [assignments, setAssignments] = useState([]);
    const [officers, setOfficers] = useState([]);
    const [otRequests, setOtRequests] = useState([]);
    const [loading, setLoading] = useState(false);

    const fetchAll = useCallback(async () => {
        setLoading(true);
        try {
            const [wR, sR, dR, aR, asR, ofR, otR] = await Promise.all([
                fetch(`${API}/workers?archived=true`, { headers: hdr() }),
                fetch(`${API}/fields?archived=true`, { headers: hdr() }),
                fetch(`${API}/deployments?date=${date}`, { headers: hdr() }),
                fetch(`${API}/attendance?date=${date}`, { headers: hdr() }),
                fetch(`${API}/assignments`, { headers: hdr() }),
                fetch(`${API}/officers`, { headers: hdr() }),
                fetch(`${API}/ot-requests?month=${date.slice(0, 7)}`, { headers: hdr() }),
            ]);
            const [w, s, d, a, as_, of_, ot_] = await Promise.all([
                wR.json(), sR.json(), dR.json(), aR.json(), asR.json(), ofR.json(), otR.json()
            ]);
            setWorkers(Array.isArray(w) ? w : []);
            setSites(Array.isArray(s) ? s : []);
            setDeployments(Array.isArray(d) ? d : []);
            setAttendance(Array.isArray(a) ? a : []);
            setAssignments(Array.isArray(as_) ? as_ : []);
            setOfficers(Array.isArray(of_) ? of_ : []);
            setOtRequests(Array.isArray(ot_) ? ot_ : []);
        } catch { /* ignore */ }
        setLoading(false);
    }, [date]);

    useEffect(() => { fetchAll(); }, [fetchAll]);

    const getWorkerName = (id) => workers.find((w) => w.id === id)?.full_name || "Unknown";
    const getWorkerType = (id) => workers.find((w) => w.id === id)?.worker_type || "—";
    const getSiteName = (id) => (sites.find((s) => s.id === id) || {}).name || "Unknown Site";
    const getStatus = (wId, sId) => {
        const rec = attendance.find((a) => a.worker_id === wId && (a.site_id === sId || !a.site_id) && a.date === date);
        return rec ? rec.status : null;
    };
    const getAssignedOfficer = (siteId) => {
        const a = assignments.find((a) => a.site_id === siteId && (!a.to_date || a.to_date >= today));
        if (!a) return null;
        const o = officers.find((o) => o.id === a.officer_id);
        return o ? o.full_name : null;
    };
    const getOtLabel = (wId, sId) => {
        const r = otRequests.find(x => String(x.worker_id) === String(wId) && String(x.site_id) === String(sId) && x.date === date);
        if (!r) return "—";
        return <span style={{ fontWeight: 600 }}>{r.ot_hours || 0}h</span>;
    };

    /* group deployed workers by site */
    const deployedBySite = (() => {
        const map = {};
        deployments.forEach((dep) => {
            const sId = dep.site_id;
            if (!sId) return;
            const wIds = dep.deployment_workers?.map((dw) => dw.worker_id) || [];
            if (!map[sId]) map[sId] = new Set();
            wIds.forEach((wid) => map[sId].add(wid));
        });
        const result = {};
        Object.entries(map).forEach(([sId, wSet]) => { result[sId] = [...wSet]; });
        return result;
    })();

    const allSiteIds = Object.keys(deployedBySite);

    /* stats */
    const stats = (() => {
        let deployed = 0, present = 0, absent = 0, unmarked = 0;
        allSiteIds.forEach((sId) => {
            (deployedBySite[sId] || []).forEach((wid) => {
                deployed++;
                const s = getStatus(wid, sId);
                if (s === "present") present++;
                else if (s === "absent") absent++;
                else unmarked++;
            });
        });
        return { deployed, present, absent, unmarked, sites: allSiteIds.length, rate: deployed > 0 ? Math.round((present / deployed) * 100) : 0 };
    })();

    const card = (label, value, color) => (
        <div className="finance-card">
            <div className="finance-card-label">{label}</div>
            <div className="finance-card-val" style={{ color: color || "#0f172a" }}>{value}</div>
        </div>
    );

    /* day navigation */
    const shiftDate = (days) => {
        const d = new Date(date);
        d.setDate(d.getDate() + days);
        setDate(d.toISOString().slice(0, 10));
    };
    const dayLabel = date === today ? "Today" : new Date(date).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });

    return (
        <div>
            {/* Letterhead — print only */}
            <PrintHeader title="Daily Attendance Report" subtitle={`Attendance register for ${date}`} />

            {/* Controls — hidden on print */}
            <div className="no-print" style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap", marginBottom: 16 }}>


                <button onClick={() => shiftDate(-1)} className="btn-sys btn-secondary" style={{ padding: "8px 12px", fontSize: 16, lineHeight: 1 }}>‹</button>
                <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="modern-input" style={{ width: "auto" }} />
                <button onClick={() => shiftDate(1)} className="btn-sys btn-secondary" style={{ padding: "8px 12px", fontSize: 16, lineHeight: 1 }}>›</button>
                {date !== today && (
                    <button onClick={() => setDate(today)} className="btn-sys btn-secondary" style={{ color: "#2563eb" }}>Today</button>
                )}
                <button onClick={fetchAll} disabled={loading} className="btn-sys btn-primary">
                    {loading ? "Loading..." : "Refresh Check-Ins"}
                </button>
                <PrintButton label="Print Attendance" />
                <span style={{ fontSize: 13, color: "#64748b", fontWeight: 700, marginLeft: 8 }}>{dayLabel}</span>
            </div>


            {/* Stats */}
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 20 }}>
                {card("Sites", stats.sites, "#2563eb")}
                {card("Deployed", stats.deployed)}
                {card("Present", stats.present, "#16a34a")}
                {card("Absent", stats.absent, "#ef4444")}
                {card("Unmarked", stats.unmarked, "#f59e0b")}
                {card("Attendance %", `${stats.rate}%`, stats.rate >= 80 ? "#16a34a" : stats.rate >= 50 ? "#f59e0b" : "#ef4444")}
            </div>

            {allSiteIds.length === 0 && !loading && (
                <div style={{ textAlign: "center", padding: 40, color: "var(--text-muted)" }}>No deployments found for this date.</div>
            )}

            {/* Per-site attendance tables */}
            {allSiteIds.map((sId) => {
                const wIds = deployedBySite[sId] || [];
                const sitePresent = wIds.filter((wid) => getStatus(wid, sId) === "present").length;
                const siteAbsent = wIds.filter((wid) => getStatus(wid, sId) === "absent").length;
                const officerName = getAssignedOfficer(sId);
                return (
                    <div key={sId} style={{ background: "var(--bg-surface)", borderRadius: 12, border: "1px solid var(--border-subtle)", marginBottom: 16, overflow: "hidden", boxShadow: "var(--shadow-sm)" }}>
                        {/* Site header */}
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 16px", background: "var(--table-header-bg)", borderBottom: "1px solid var(--border-subtle)", flexWrap: "wrap", gap: 8 }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                                <span style={{ fontWeight: 700, fontSize: 14, color: "var(--text-primary)" }}>{getSiteName(sId)}</span>
                                <span style={{ fontSize: 11, color: "var(--text-muted)" }}>({wIds.length} workers)</span>
                                {officerName && (
                                    <span style={{ fontSize: 11, color: "#2563eb", background: "#eff6ff", padding: "2px 10px", borderRadius: 20, fontWeight: 600 }}>
                                        Officer: {officerName}
                                    </span>
                                )}
                            </div>
                            <div style={{ display: "flex", gap: 6 }}>
                                <span className="status-badge badge-present">{sitePresent} present</span>
                                {siteAbsent > 0 && <span className="status-badge badge-absent">{siteAbsent} absent</span>}
                            </div>
                        </div>
                        {/* Workers table */}
                        <div style={{ overflowX: "auto" }}>
                            <table className="finance-table">
                                <thead>
                                    <tr>
                                        <th style={{ width: 40 }}>#</th>
                                        <th>Worker</th>
                                        <th>Type</th>
                                        <th>Daily Rate</th>
                                        <th>OT Hrs</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {wIds.map((wid, idx) => {
                                        const status = getStatus(wid, sId);
                                        const w = workers.find((x) => x.id === wid);
                                        return (
                                            <tr key={wid} style={{ background: status === "absent" ? "#fef2f2" : "" }}>
                                                <td>{idx + 1}</td>
                                                <td style={{ fontWeight: 800, color: "#0f172a" }}>{getWorkerName(wid)}</td>
                                                <td>{getWorkerType(wid)}</td>
                                                <td>{currency(w?.daily_rate || 0)}</td>
                                                <td>{getOtLabel(wid, sId)}</td>
                                                <td><span className={`status-badge ${status === 'present' ? 'badge-present' : status === 'absent' ? 'badge-absent' : 'badge-unmarked'}`}>{status || "Unmarked"}</span></td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                );
            })}
        </div>
    );
}
