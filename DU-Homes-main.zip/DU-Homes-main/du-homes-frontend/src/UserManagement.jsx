// ============================================================================
// FEATURE: UserManagement.jsx — User Role & Permission Management Module
// Implemented by: IT24102845
// This component allows administrators to view all registered users, search
// and filter them by role, and change their roles to control access permissions
// across the DU Homes Construction Management System.
//
// FLOW: Complete user journey:
//   1. Component mounts → fetches all users from GET /auth/users
//   2. Users are displayed in a table with role stat cards above
//   3. Admin can search users by name, email, phone, or role
//   4. Admin can filter by role using pill buttons (All, Admin, PM, SO, FO)
//   5. Admin clicks "Change Role" → dropdown appears → selects new role → "Save"
//   6. Role is updated via PUT /auth/users/:id/role → UI updates immediately
//   7. Admin can copy user IDs to clipboard for reference
//
// DB: Integrates with Supabase 'profiles' table via Express backend endpoints:
//   - GET    /auth/users           → Fetch all users with profiles
//   - PUT    /auth/users/:id/role  → Update a user's role in profiles table
// ============================================================================

import { useState, useEffect, useCallback } from "react";

// DB: API base URL — connects to Express backend which queries Supabase
const API = import.meta.env.VITE_API_URL || "http://localhost:8080";

// DB: Authorization header builder — attaches JWT token for authenticated admin API requests
const hdr = () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${localStorage.getItem("access_token") || localStorage.getItem("token") || ""}`,
});

// ============================================================================
// FEATURE: Role Configuration
// Defines the four system roles with their display properties.
// DB: These role values correspond to the 'role' column in the Supabase 'profiles' table.
// UI: Each role has a unique color and icon for visual identification throughout the app.
// VALIDATION: Role changes are restricted to these four predefined values.
// ============================================================================
const ROLES = [
    { value: "admin", label: "System Administrator", color: "#C8102E", icon: "A" },
    { value: "project_manager", label: "Project Manager", color: "#2563eb", icon: "PM" },
    { value: "site_officer", label: "Site Officer", color: "#16a34a", icon: "SO" },
    { value: "finance_officer", label: "Finance Officer", color: "#f59e0b", icon: "FO" },
    { value: "company_owner", label: "Company Owner", color: "#1e3a8a", icon: "CO" },
];

export default function UserManagement() {
    // DB: State holding all users fetched from Supabase profiles table
    const [users, setUsers] = useState([]);

    // UI: Search and filter state for the user table
    const [search, setSearch] = useState("");
    const [filterRole, setFilterRole] = useState("all");

    // UI: Loading state — shows spinner during API calls
    const [loading, setLoading] = useState(false);

    // VALIDATION: Message state for success/error feedback
    const [msg, setMsg] = useState("");

    // UI: Hover tracking for table rows and stat cards (visual feedback)
    const [hoveredRow, setHoveredRow] = useState(null);
    const [hoveredCard, setHoveredCard] = useState(null);

    // FLOW: Tracks which user row has the role-change dropdown open
    const [confirmChange, setConfirmChange] = useState(null);

    // UI: Tracks which user ID was recently copied to clipboard
    const [copiedId, setCopiedId] = useState(null);

    // ========================================================================
    // DB: Fetch All Users
    // Sends GET request to /auth/users endpoint which queries the Supabase
    // 'profiles' table joined with auth.users to get email, name, phone, role.
    // FLOW: Step 1 — Load all users on initial component mount
    // VALIDATION: Handles API errors and displays error messages to the admin.
    // ========================================================================
    const fetchUsers = useCallback(async () => {
        setLoading(true);
        try {
            const r = await fetch(`${API}/auth/users`, { headers: hdr() }); // DB: GET all users from Supabase
            if (r.ok) {
                const data = await r.json();
                console.log("Users fetched:", data.length);
                setUsers(data);
            } else {
                const err = await r.json();
                setMsg(err.error || "Failed to load users"); // VALIDATION: Display server error
            }
        } catch (e) {
            setMsg(e.message); // VALIDATION: Handle network/connection errors
        }
        setLoading(false);
    }, []);

    // FLOW: Trigger initial data fetch when component mounts
    useEffect(() => {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        fetchUsers();
    }, [fetchUsers]);

    // UI: Auto-clear feedback messages after 4 seconds for clean UX
    useEffect(() => {
        if (msg) {
            const timer = setTimeout(() => setMsg(""), 4000);
            return () => clearTimeout(timer);
        }
    }, [msg]);

    // ========================================================================
    // SYSTEM LOGIC: Role Change Handler (Optimistic Update)
    // FLOW: This function updates the server AND the local state simultaneously.
    // 1. Send Update -> 2. If successful, update UI immediately.
    // ========================================================================
    const handleRoleChange = async (userId, newRole) => {
        setMsg("");
        setConfirmChange(null); // UI: Close the role-change dropdown

        try {
            // GOAL: Update the 'role' in the backend profiles table
            const r = await fetch(`${API}/auth/users/${userId}/role`, {
                method: "PUT",
                headers: hdr(),
                body: JSON.stringify({ role: newRole }), 
            });
            const data = await r.json();
            if (r.ok) {
                const roleLabel = ROLES.find((rl) => rl.value === newRole)?.label || newRole;
                setMsg(`Role updated to ${roleLabel}`);
                
                // GOAL: Optimistic UI Update
                // Instead of re-fetching ALL users (which is slow), we just update
                // the specific user in our local 'users' state. This makes the
                // app feel much faster to the administrator.
                setUsers((prev) =>
                    prev.map((u) => (u.id === userId ? { ...u, role: newRole } : u))
                );
            } else {
                setMsg(data.error || "Failed to update role"); 
            }
        } catch (e) {
            setMsg(e.message); 
        }
    };

    // ========================================================================
    // UI: Copy User ID to Clipboard
    // FLOW: Step 7 — Admin clicks the copy icon next to a user's ID.
    // Shows a brief checkmark confirmation, then reverts after 2 seconds.
    // ========================================================================
    const handleCopyId = (id) => {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(id).then(() => {
                setCopiedId(id);
                setTimeout(() => setCopiedId(null), 2000); // UI: Reset copy indicator after 2s
            });
        }
    };

    // ========================================================================
    // SYSTEM LOGIC: Client-Side Searching & Filtering
    // GOAL: Instant feedback without server requests.
    // This function filters the master list of users based on TWO criteria:
    // 1. Text search (Name/Email/Phone/Role)
    // 2. Role filter (Selected role pill)
    // ========================================================================
    const filtered = users.filter((u) => {
        const q = search.toLowerCase();
        // Check if the search term exists in any user field
        const matchesSearch =
            (u.full_name || "").toLowerCase().includes(q) ||
            (u.email || "").toLowerCase().includes(q) ||
            (u.phone || "").toLowerCase().includes(q) ||
            (u.role || "").toLowerCase().includes(q);
            
        // Check if the user's role matches the selected filter pill
        const matchesRole = filterRole === "all" || u.role === filterRole;
        
        return matchesSearch && matchesRole;
    });

    // ========================================================================
    // FEATURE: Role Statistics Calculation
    // DB: Counts users per role from the fetched data for the stat cards.
    // UI: Displayed as interactive cards above the table with proportional bars.
    // ========================================================================
    const roleCounts = {};
    ROLES.forEach((r) => { roleCounts[r.value] = 0; });
    users.forEach((u) => {
        const role = u.role || "site_officer";
        if (roleCounts[role] !== undefined) roleCounts[role]++;
    });

    // UI: Generate initials from user name or email for the avatar display
    const getInitials = (name, email) => {
        if (name && name.trim()) {
            return name.split(" ").map((w) => w[0]).join("").toUpperCase().slice(0, 2);
        }
        if (email) return email[0].toUpperCase();
        return "?";
    };

    // UI: Helper to get full role object (label, color, icon) for a given role value
    const getRoleObj = (role) => ROLES.find((r) => r.value === role) || ROLES[2];

    // ========================================================================
    // UI: Style Definitions
    // Reusable style objects for stat cards, table, inputs, badges, and filter pills.
    // Cards and rows have hover effects for interactive visual feedback.
    // ========================================================================

    // UI: Stat card style — changes background and elevation on hover
    const cardStyle = (color, isHovered) => ({
        flex: "1 1 180px",
        background: isHovered
            ? `linear-gradient(135deg, ${color}20, ${color}08)`
            : "var(--bg-surface)",
        borderRadius: 14,
        padding: "20px 22px",
        border: `1px solid ${color}30`,
        boxShadow: isHovered
            ? `0 8px 24px ${color}25`
            : "var(--shadow-sm)",
        transition: "all 0.3s ease",
        transform: isHovered ? "translateY(-3px)" : "none",
        cursor: "default",
        position: "relative",
        overflow: "hidden",
    });

    const thStyle = {
        padding: "12px 16px", textAlign: "left", fontSize: 11, fontWeight: 700,
        color: "var(--text-soft)", borderBottom: "2px solid var(--border-subtle)", textTransform: "uppercase",
        letterSpacing: 0.8, background: "var(--table-header-bg)",
    };

    const tdBase = {
        padding: "14px 16px", fontSize: 13, borderBottom: "1px solid var(--border-subtle)",
        color: "var(--text-primary)", verticalAlign: "middle", transition: "background 0.15s",
    };

    const inp = {
        padding: "10px 14px", border: "1px solid var(--border-subtle)", borderRadius: 10,
        fontSize: 13, boxSizing: "border-box", width: 280,
        outline: "none", transition: "border-color 0.2s, box-shadow 0.2s",
        background: "var(--input-bg)", color: "var(--text-primary)",
    };

    // UI: Role badge style — color-coded pill showing the user's current role
    const roleBadge = (role) => {
        const r = getRoleObj(role);
        return {
            display: "inline-flex", alignItems: "center", gap: 6,
            padding: "5px 14px", borderRadius: 20,
            fontSize: 12, fontWeight: 600,
            background: `${r.color}12`, color: r.color,
            border: `1px solid ${r.color}20`,
        };
    };

    // UI: Filter pill style — active pill is dark, inactive is light grey
    const filterPill = (value, isActive) => ({
        padding: "6px 14px", borderRadius: 20, border: "none",
        background: isActive ? "var(--text-primary)" : "var(--bg-body)",
        color: isActive ? "var(--bg-surface)" : "var(--text-soft)",
        fontSize: 12, fontWeight: 600, cursor: "pointer",
        transition: "all 0.2s ease",
        boxShadow: isActive ? "0 2px 6px rgba(0,0,0,0.1)" : "none",
    });

    return (
        <div style={{ maxWidth: 1200, margin: "0 auto" }}>

            {/* ================================================================
                UI: Page Header
                Shows title, user count, and a refresh button to re-fetch data.
                FLOW: Refresh button triggers fetchUsers() to reload from Supabase.
            ================================================================ */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
                <div>
                    <h2 style={{ fontSize: 24, fontWeight: 800, color: "var(--text-primary)", margin: 0 }}>User Management</h2>
                    <p style={{ margin: "4px 0 0", fontSize: 13, color: "var(--text-soft)" }}>
                        Manage user roles and permissions — {users.length} registered users
                    </p>
                </div>
                {/* DB: Refresh button — re-fetches all users from Supabase */}
                <button onClick={fetchUsers} disabled={loading} style={{
                    padding: "8px 20px", borderRadius: 8, border: "1px solid var(--border-subtle)",
                    background: "var(--bg-surface)", fontSize: 13, fontWeight: 600, cursor: "pointer",
                    color: "var(--text-primary)", display: "flex", alignItems: "center", gap: 6,
                    transition: "all 0.2s",
                }}>
                    <span style={{ display: "inline-block", transition: "transform 0.3s", transform: loading ? "rotate(360deg)" : "none" }}>&#x21bb;</span>
                    {loading ? "Loading..." : "Refresh"}
                </button>
            </div>

            {/* ================================================================
                VALIDATION: Feedback Message Banner
                Automatically distinguishes between success and error messages
                by checking for keywords ("Failed", "error", "failed").
                Green gradient = success, Red gradient = error.
                Auto-clears after 4 seconds via useEffect timer.
            ================================================================ */}
            {msg && (
                <div style={{
                    padding: "12px 18px", marginBottom: 18, borderRadius: 10, fontSize: 13, fontWeight: 500,
                    display: "flex", alignItems: "center", gap: 10,
                    background: msg.includes("Failed") || msg.includes("error") || msg.includes("failed")
                        ? "linear-gradient(135deg, rgba(220,38,38,0.1), rgba(220,38,38,0.05))"
                        : "linear-gradient(135deg, rgba(22,101,52,0.1), rgba(22,101,52,0.05))",
                    color: msg.includes("Failed") || msg.includes("error") || msg.includes("failed") ? "var(--error)" : "var(--success)",
                    border: `1px solid ${msg.includes("Failed") || msg.includes("error") || msg.includes("failed") ? "rgba(220,38,38,0.2)" : "rgba(22,101,52,0.2)"}`,
                }}>
                    <span style={{ fontSize: 16 }}>{msg.includes("Failed") || msg.includes("error") || msg.includes("failed") ? "\u2717" : "\u2713"}</span>
                    {msg}
                </div>
            )}

            {/* ================================================================
                FEATURE: Role Statistics Cards
                DB: Data derived from users fetched from Supabase 'profiles' table.
                UI: Four cards showing count per role with colored accent bars
                and proportional mini progress bars.
                Each card has a hover effect (elevation + tinted background).
            ================================================================ */}
            <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 24 }}>
                {ROLES.map((r) => (
                    <div
                        key={r.value}
                        style={cardStyle(r.color, hoveredCard === r.value)}
                        onMouseEnter={() => setHoveredCard(r.value)}
                        onMouseLeave={() => setHoveredCard(null)}
                    >
                        {/* UI: Colored accent bar at the top of each stat card */}
                        <div style={{
                            position: "absolute", top: 0, left: 0, right: 0, height: 3,
                            background: `linear-gradient(90deg, ${r.color}, ${r.color}55)`,
                        }} />
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                            <div>
                                <div style={{ fontSize: 12, color: "var(--text-soft)", fontWeight: 500, marginBottom: 8 }}>{r.label}s</div>
                                <div style={{ fontSize: 32, fontWeight: 800, color: r.color, lineHeight: 1 }}>{roleCounts[r.value]}</div>
                            </div>
                            {/* UI: Role icon badge */}
                            <div style={{
                                width: 40, height: 40, borderRadius: 12,
                                background: `${r.color}10`, display: "flex", alignItems: "center", justifyContent: "center",
                                fontSize: 13, fontWeight: 800, color: r.color,
                            }}>{r.icon}</div>
                        </div>
                        {/* UI: Proportional bar showing this role's share of total users */}
                        <div style={{ marginTop: 12 }}>
                            <div style={{ width: "100%", height: 3, background: "var(--border-subtle)", borderRadius: 2, overflow: "hidden" }}>
                                <div style={{
                                    width: `${users.length > 0 ? (roleCounts[r.value] / users.length) * 100 : 0}%`,
                                    height: "100%", background: r.color, borderRadius: 2,
                                    transition: "width 0.6s ease",
                                }} />
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* ================================================================
                FEATURE: Users Data Table Card
                UI: Contains the toolbar (search + role filter) and the main
                data table with all user records.
            ================================================================ */}
            <div style={{
                background: "var(--bg-surface)", borderRadius: 14, padding: 0,
                border: "1px solid var(--border-subtle)", boxShadow: "var(--shadow-sm)",
                overflow: "hidden",
            }}>

                {/* ============================================================
                    UI: Toolbar — Search Input + Role Filter Pills
                    FLOW: Steps 3-4 — Admin searches and filters users in real-time.
                    Search has a clear button (×) that appears when text is entered.
                    Input highlights with brand color on focus for visual feedback.
                ============================================================ */}
                <div style={{
                    padding: "18px 22px", borderBottom: "1px solid var(--border-subtle)",
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                    flexWrap: "wrap", gap: 12,
                }}>
                    <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                        {/* FLOW: Step 3 — Search input filters users across name, email, phone, role */}
                        <div style={{ position: "relative" }}>
                            <input
                                style={inp}
                                placeholder="Search by name, email, phone..."
                                value={search}
                                onChange={(e) => setSearch(e.target.value)}
                                onFocus={(e) => { e.target.style.borderColor = "#C8102E"; e.target.style.boxShadow = "0 0 0 3px rgba(200,16,46,0.08)"; }}
                                onBlur={(e) => { e.target.style.borderColor = "#e2e8f0"; e.target.style.boxShadow = "none"; }}
                            />
                            {/* UI: Clear search button — appears only when search has text */}
                            {search && (
                                <button onClick={() => setSearch("")} style={{
                                    position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)",
                                    background: "var(--bg-body)", border: "none", borderRadius: "50%",
                                    width: 20, height: 20, fontSize: 11, cursor: "pointer", color: "var(--text-soft)",
                                    display: "flex", alignItems: "center", justifyContent: "center",
                                }}>&times;</button>
                            )}
                        </div>

                        {/* FLOW: Step 4 — Role filter pills for quick filtering by user role */}
                        <div style={{ display: "flex", gap: 4 }}>
                            <button style={filterPill("all", filterRole === "all")} onClick={() => setFilterRole("all")}>All</button>
                            {ROLES.map((r) => (
                                <button key={r.value} style={filterPill(r.value, filterRole === r.value)} onClick={() => setFilterRole(r.value)}>
                                    {r.label.split(" ").pop()}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* UI: Result count indicator */}
                    <div style={{ fontSize: 13, color: "var(--text-soft)", fontWeight: 500 }}>
                        {filtered.length} of {users.length} users
                    </div>
                </div>

                {/* ============================================================
                    UI: Loading State
                    Shows a spinning loader while users are being fetched from
                    the Supabase backend.
                ============================================================ */}
                {loading ? (
                    <div style={{ textAlign: "center", padding: 60, color: "var(--text-soft)" }}>
                        <div style={{
                            width: 36, height: 36, border: "3px solid var(--border-subtle)", borderTopColor: "var(--brand-primary, #C8102E)",
                            borderRadius: "50%", animation: "spin 0.8s linear infinite", margin: "0 auto 12px",
                        }} />
                        Loading users...
                    </div>
                ) : (
                    /* ============================================================
                        FEATURE: Users Data Table
                        DB: Displays data from Supabase 'profiles' table.
                        UI: Columns: User (avatar + name + email), Phone, Current Role
                        (color-coded badge), Change Role (dropdown), User ID (copyable).
                        VALIDATION: Shows "No users match your search" or "No users found"
                        when the filtered list is empty.
                        FLOW: Rows have hover highlighting for better readability.
                    ============================================================ */
                    <div style={{ overflowX: "auto" }}>
                        <table style={{ width: "100%", borderCollapse: "collapse" }}>
                            <thead>
                            <tr>
                                <th style={thStyle}>User</th>
                                <th style={thStyle}>Phone</th>
                                <th style={thStyle}>Current Role</th>
                                <th style={thStyle}>Change Role</th>
                                <th style={thStyle}>User ID</th>
                            </tr>
                            </thead>
                            <tbody>
                            {/* VALIDATION: Empty state — different messages for search vs no data */}
                            {filtered.length === 0 && (
                                <tr>
                                    <td colSpan={5} style={{ ...tdBase, textAlign: "center", color: "var(--text-soft)", padding: 40 }}>
                                        {search || filterRole !== "all" ? "No users match your search" : "No users found"}
                                    </td>
                                </tr>
                            )}
                            {filtered.map((u, idx) => {
                                const roleObj = getRoleObj(u.role);
                                const isHovered = hoveredRow === u.id;
                                return (
                                    <tr
                                        key={u.id}
                                        onMouseEnter={() => setHoveredRow(u.id)}
                                        onMouseLeave={() => setHoveredRow(null)}
                                        style={{ background: isHovered ? "var(--bg-body)" : "transparent" }}
                                    >
                                        {/* DB: User column — displays name + email from Supabase profiles */}
                                        <td style={tdBase}>
                                            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                                                {/* UI: Avatar with initials, color-coded by role */}
                                                <div style={{
                                                    width: 38, height: 38, borderRadius: 10,
                                                    background: `linear-gradient(135deg, ${roleObj.color}20, ${roleObj.color}08)`,
                                                    border: `1px solid ${roleObj.color}15`,
                                                    display: "flex", alignItems: "center", justifyContent: "center",
                                                    fontSize: 13, fontWeight: 700, color: roleObj.color, flexShrink: 0,
                                                }}>
                                                    {getInitials(u.full_name, u.email)}
                                                </div>
                                                <div>
                                                    <div style={{ fontWeight: 600, color: "var(--text-primary)", fontSize: 13 }}>
                                                        {u.full_name || "No name"}
                                                    </div>
                                                    <div style={{ fontSize: 11, color: "var(--text-soft)", marginTop: 1 }}>
                                                        {u.email || "—"}
                                                    </div>
                                                </div>
                                            </div>
                                        </td>

                                        {/* DB: Phone column from Supabase profiles table */}
                                        <td style={tdBase}>
                                            {u.phone ? (
                                                <span style={{ fontFamily: "monospace", fontSize: 13, color: "var(--text-primary)" }}>{u.phone}</span>
                                            ) : (
                                                <span style={{ color: "var(--border-subtle)", fontSize: 12 }}>Not provided</span>
                                            )}
                                        </td>

                                        {/* UI: Current Role — displayed as a color-coded badge with dot indicator */}
                                        <td style={tdBase}>
                        <span style={roleBadge(u.role)}>
                          <span style={{
                              width: 6, height: 6, borderRadius: "50%",
                              background: roleObj.color, display: "inline-block",
                          }} />
                            {roleObj.label}
                        </span>
                                        </td>

                                        {/* ====================================================
                                            FEATURE: Role Change Column
                                            FLOW: Step 5 — Click "Change Role" → dropdown appears
                                            with all four roles → select new role → click "Save"
                                            → PUT request updates Supabase → UI reflects change.
                                            "Cancel" button closes the dropdown without saving.
                                            DB: Sends PUT /auth/users/:id/role on Save.
                                        ==================================================== */}
                                        <td style={tdBase}>
                                            {confirmChange === u.id ? (
                                                /* UI: Active role-change mode — shows dropdown + Save + Cancel */
                                                <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                                                    {/* VALIDATION: Dropdown pre-selects the user's current role */}
                                                    <select
                                                        defaultValue={u.role}
                                                        id={`role-select-${u.id}`}
                                                        style={{
                                                            padding: "7px 12px", borderRadius: 8,
                                                            border: "2px solid var(--brand-primary, #C8102E)", fontSize: 13,
                                                            cursor: "pointer", background: "var(--bg-surface)",
                                                            color: "var(--text-primary)", outline: "none",
                                                        }}
                                                    >
                                                        {ROLES.map((r) => (
                                                            <option key={r.value} value={r.value}>{r.label}</option>
                                                        ))}
                                                    </select>
                                                    {/* DB: Save button — triggers PUT request to update role in Supabase */}
                                                    <button
                                                        onClick={() => {
                                                            const sel = document.getElementById(`role-select-${u.id}`);
                                                            if (sel) handleRoleChange(u.id, sel.value);
                                                        }}
                                                        style={{
                                                            padding: "6px 12px", borderRadius: 6, border: "none",
                                                            background: "#C8102E", color: "#fff", fontSize: 12,
                                                            fontWeight: 600, cursor: "pointer",
                                                        }}
                                                    >Save</button>
                                                    {/* FLOW: Cancel — closes dropdown without making changes */}
                                                    <button
                                                        onClick={() => setConfirmChange(null)}
                                                        style={{
                                                            padding: "6px 10px", borderRadius: 6,
                                                            border: "1px solid var(--border-subtle)", background: "var(--bg-surface)",
                                                            fontSize: 12, cursor: "pointer", color: "var(--text-soft)",
                                                        }}
                                                    >Cancel</button>
                                                </div>
                                            ) : (
                                                /* FLOW: Step 5a — "Change Role" button to enter edit mode for this row */
                                                <button
                                                    onClick={() => setConfirmChange(u.id)}
                                                    style={{
                                                        padding: "7px 14px", borderRadius: 8,
                                                        border: "1px solid var(--border-subtle)", background: isHovered ? "var(--bg-surface)" : "transparent",
                                                        fontSize: 12, fontWeight: 500, cursor: "pointer", color: "var(--text-soft)",
                                                        transition: "all 0.2s",
                                                        display: "flex", alignItems: "center", gap: 6,
                                                    }}
                                                >
                                                    <span style={{ fontSize: 14 }}>&#9998;</span> Change Role
                                                </button>
                                            )}
                                        </td>

                                        {/* ====================================================
                                            UI: User ID Column
                                            DB: Displays the Supabase auth.users UUID (truncated).
                                            FLOW: Step 7 — Click copy icon to copy full ID to clipboard.
                                            Shows checkmark briefly after copying.
                                        ==================================================== */}
                                        <td style={tdBase}>
                                            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                                <code style={{
                                                    fontSize: 11, color: "var(--text-soft)", background: "var(--bg-body)",
                                                    padding: "3px 8px", borderRadius: 4, fontFamily: "monospace",
                                                }}>
                                                    {u.id?.slice(0, 12)}...
                                                </code>
                                                {/* UI: Copy-to-clipboard button with visual feedback */}
                                                <button
                                                    onClick={() => handleCopyId(u.id)}
                                                    style={{
                                                        background: "none", border: "none", cursor: "pointer",
                                                        fontSize: 13, color: copiedId === u.id ? "var(--success)" : "var(--text-soft)",
                                                        padding: 2, transition: "color 0.2s",
                                                    }}
                                                    title="Copy full ID"
                                                >
                                                    {copiedId === u.id ? "\u2713" : "\u2398"}
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                            </tbody>
                        </table>
                    </div>
                )}

                {/* ============================================================
                    UI: Table Footer
                    Shows filtered/total count and a legend of role colors with
                    counts. Only visible when data is loaded and results exist.
                ============================================================ */}
                {!loading && filtered.length > 0 && (
                    <div style={{
                        padding: "12px 22px", borderTop: "1px solid var(--border-subtle)",
                        display: "flex", justifyContent: "space-between", alignItems: "center",
                        fontSize: 12, color: "var(--text-soft)",
                    }}>
                        <span>Showing {filtered.length} of {users.length} users</span>
                        {/* UI: Role legend with colored dots and counts */}
                        <span>
              {ROLES.map((r) => (
                  <span key={r.value} style={{ marginLeft: 12 }}>
                  <span style={{
                      display: "inline-block", width: 8, height: 8,
                      borderRadius: "50%", background: r.color, marginRight: 4,
                      verticalAlign: "middle",
                  }} />
                      {r.label.split(" ").pop()}: {roleCounts[r.value]}
                </span>
              ))}
            </span>
                    </div>
                )}
            </div>
        </div>
    );
}
